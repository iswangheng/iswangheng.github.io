"""
百度网盘 HTTP 客户端

封装所有百度网盘 Web 接口请求。
隔离设计：后续切换到官方 API 时，只需替换本文件实现。
"""

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional
from urllib.parse import quote

import requests

from scripts.baidu_pan.config import BaiduPanConfig, config as default_config
from scripts.baidu_pan.auth import BaiduAuth

logger = logging.getLogger(__name__)

# API 重试配置
_MAX_RETRIES = 3


def _request_with_retry(session: requests.Session, method: str, url: str, timeout=30, **kwargs) -> requests.Response:
    """
    带指数退避重试的请求封装
    只对可重试错误重试（ConnectionError、Timeout、5xx），4xx 不重试
    """
    for attempt in range(_MAX_RETRIES + 1):
        try:
            resp = session.request(method, url, timeout=timeout, **kwargs)
            if resp.status_code >= 500 and attempt < _MAX_RETRIES:
                wait = 2 ** attempt
                logger.warning("服务端错误 %d，%ds 后重试 (%d/%d)", resp.status_code, wait, attempt + 1, _MAX_RETRIES)
                time.sleep(wait)
                continue
            resp.raise_for_status()
            return resp
        except (requests.ConnectionError, requests.Timeout) as e:
            if attempt == _MAX_RETRIES:
                raise
            wait = 2 ** attempt
            logger.warning("网络错误: %s，%ds 后重试 (%d/%d)", e, wait, attempt + 1, _MAX_RETRIES)
            time.sleep(wait)


class BaiduPanClient:
    """百度网盘 HTTP 客户端"""

    # Web 接口地址
    BASE_URL = "https://pan.baidu.com"
    VERIFY_URL = f"{BASE_URL}/share/verify"
    FILE_LIST_URL = f"{BASE_URL}/share/list"
    TRANSFER_URL = f"{BASE_URL}/share/transfer"
    FILEMETAS_URL = f"{BASE_URL}/api/filemetas"

    def __init__(self, cfg: Optional[BaiduPanConfig] = None):
        self.config = cfg or default_config
        self.auth = BaiduAuth(self.config)
        self.session = self.auth.get_session()

    def get_quota(self) -> Dict:
        """
        查询网盘容量信息

        Returns:
            {"total": 总容量字节, "used": 已用字节, "free": 剩余字节}
        """
        resp = _request_with_retry(
            self.session, "GET", f"{self.BASE_URL}/api/quota",
            timeout=self.config.timeout,
            params={"checkfree": "1", "checkexpire": "1"},
        )
        data = resp.json()
        total = data.get("total", 0)
        used = data.get("used", 0)
        return {"total": total, "used": used, "free": total - used}

    def verify_share(self, surl: str, pwd: str) -> dict:
        """
        验证分享提取码

        Args:
            surl: 短链标识
            pwd: 提取码

        Returns:
            {"shareid": ..., "uk": ..., "randsk": ...}

        Raises:
            RuntimeError: 验证失败
        """
        import re

        # 先访问分享页面获取 shareid 和 share_uk（分享者的 uk）
        share_page_url = f"{self.BASE_URL}/s/1{surl}"
        resp = _request_with_retry(self.session, "GET", share_page_url, timeout=self.config.timeout)

        # shareid 在页面 JSON 中
        shareid_match = re.search(r'"shareid":(\d+)', resp.text)
        if not shareid_match:
            raise RuntimeError("无法从分享页面提取 shareid，链接可能已失效")

        # share_uk 是分享者的 uk（注意不是当前登录用户的 uk）
        uk_match = re.search(r'"share_uk":"?(\d+)"?', resp.text)
        if not uk_match:
            raise RuntimeError("无法从分享页面提取 share_uk，链接可能已失效")

        shareid = shareid_match.group(1)
        uk = uk_match.group(1)

        # 验证提取码
        resp = _request_with_retry(
            self.session, "POST", self.VERIFY_URL,
            timeout=self.config.timeout,
            params={"surl": surl},
            data={"pwd": pwd, "vcode": "", "vcode_str": ""},
        )
        data = resp.json()

        if data.get("errno") != 0:
            errno = data.get("errno")
            errmsg = data.get("errmsg", "未知错误")
            raise RuntimeError(f"提取码验证失败: errno={errno}, {errmsg}")

        randsk = data.get("randsk", "")

        return {
            "shareid": shareid,
            "uk": uk,
            "randsk": randsk,
        }

    def get_share_file_list(self, shareid: str, uk: str, dir_path: str = "/", recursive: bool = True) -> List[Dict]:
        """
        获取分享文件列表（自动分页）

        Args:
            shareid: 分享 ID
            uk: 分享者 UK
            dir_path: 目录路径（默认根目录）
            recursive: 是否递归遍历子文件夹

        Returns:
            文件列表 [{"name": ..., "size": ..., "fs_id": ..., "isdir": ..., "path": ...}, ...]
        """
        is_root = dir_path == "/"
        page = 1
        page_size = 200
        all_items = []

        # 分页获取
        while True:
            resp = _request_with_retry(
                self.session, "GET", self.FILE_LIST_URL,
                timeout=self.config.timeout,
                params={
                    "shareid": shareid,
                    "uk": uk,
                    "dir": dir_path,
                    "root": "1" if is_root else "0",
                    "page": str(page),
                    "num": str(page_size),
                },
            )
            data = resp.json()

            if data.get("errno") != 0:
                raise RuntimeError(f"获取文件列表失败: errno={data.get('errno')}")

            items = data.get("list", [])
            all_items.extend(items)

            # 不足一页说明已经是最后一页
            if len(items) < page_size:
                break
            page += 1

        file_list = []
        for item in all_items:
            # isdir 可能是字符串 "1" 或整数 1
            isdir = str(item.get("isdir", "0")) == "1"
            entry = {
                "name": item.get("server_filename", ""),
                "size": int(item.get("size", 0)),
                "fs_id": int(item.get("fs_id", 0)),
                "isdir": isdir,
                "path": item.get("path", ""),
            }

            if isdir and recursive:
                # 递归遍历子文件夹
                logger.info(f"进入文件夹: {entry['name']}/")
                sub_files = self.get_share_file_list(shareid, uk, entry["path"], recursive=True)
                file_list.extend(sub_files)
            else:
                file_list.append(entry)

        return file_list

    def _get_bdstoken(self) -> str:
        """获取 bdstoken（文件管理操作需要）"""
        import re
        resp = _request_with_retry(self.session, "GET", f"{self.BASE_URL}/disk/main", timeout=self.config.timeout)
        match = re.search(r'"bdstoken":"([a-f0-9]+)"', resp.text)
        if not match:
            raise RuntimeError("无法获取 bdstoken")
        return match.group(1)

    def create_dir(self, path: str) -> None:
        """在网盘中创建目录（如果不存在）"""
        resp = _request_with_retry(
            self.session, "POST", f"{self.BASE_URL}/api/create",
            timeout=self.config.timeout,
            data={
                "path": path,
                "isdir": "1",
                "block_list": "[]",
            },
        )
        data = resp.json()
        # errno=0 创建成功，errno=-8 目录已存在
        if data.get("errno") not in (0, -8):
            logger.warning(f"创建目录可能失败: {path}, errno={data.get('errno')}")

    def transfer_files(
        self, shareid: str, uk: str, sekey: str, fsid_list: List[int], target_path: str
    ) -> Dict:
        """
        转存文件到自己的网盘

        Args:
            shareid: 分享 ID
            uk: 分享者 UK
            sekey: 验证后获取的 randsk（URL 编码后作为 sekey）
            fsid_list: 文件 fs_id 列表
            target_path: 转存目标路径

        Returns:
            {"errno": 0, "extra": {...}}
        """
        resp = _request_with_retry(
            self.session, "POST", self.TRANSFER_URL,
            timeout=self.config.timeout,
            params={
                "shareid": shareid,
                "from": uk,
                "sekey": sekey,
            },
            data={
                "fsidlist": json.dumps(fsid_list),
                "path": target_path,
            },
        )
        data = resp.json()

        errno = data.get("errno", -1)
        if errno == 0:
            logger.info(f"转存成功: {len(fsid_list)} 个文件 → {target_path}")
        elif errno == 12:
            # 文件已存在，不算错误
            logger.info(f"文件已存在于网盘: {target_path}")
        else:
            raise RuntimeError(f"转存失败: errno={errno}, {data}")

        return data

    def list_my_files(self, dir_path: str) -> List[Dict]:
        """
        列出自己网盘中的文件（自动分页）

        Args:
            dir_path: 目录路径

        Returns:
            文件列表 [{"name": ..., "size": ..., "fs_id": ..., "isdir": ...}, ...]
        """
        page = 1
        page_size = 1000
        file_list = []

        while True:
            resp = _request_with_retry(
                self.session, "GET", f"{self.BASE_URL}/api/list",
                timeout=self.config.timeout,
                params={
                    "dir": dir_path,
                    "order": "name",
                    "desc": "0",
                    "page": str(page),
                    "num": str(page_size),
                },
            )
            data = resp.json()

            if data.get("errno") != 0:
                raise RuntimeError(f"列出网盘文件失败: errno={data.get('errno')}")

            items = data.get("list", [])
            for item in items:
                file_list.append({
                    "name": item.get("server_filename", ""),
                    "size": int(item.get("size", 0)),
                    "fs_id": int(item.get("fs_id", 0)),
                    "isdir": item.get("isdir", 0) == 1,
                    "path": item.get("path", ""),
                })

            if len(items) < page_size:
                break
            page += 1

        return file_list

    def delete_files(self, paths: List[str]) -> None:
        """
        删除网盘中的文件

        Args:
            paths: 文件路径列表，如 ["/AI-Drama-Downloads/复婚37.mp4"]
        """
        bdstoken = self._get_bdstoken()
        resp = _request_with_retry(
            self.session, "POST", f"{self.BASE_URL}/api/filemanager",
            timeout=self.config.timeout,
            params={"opera": "delete", "async": "0", "bdstoken": bdstoken},
            data={"filelist": json.dumps(paths)},
        )
        data = resp.json()
        if data.get("errno") != 0:
            logger.warning(f"删除文件失败: errno={data.get('errno')}, paths={paths}")
        else:
            logger.info(f"已删除 {len(paths)} 个文件")

    def get_download_link(self, fsid: int) -> str:
        """
        获取文件下载链接（dlink）

        Args:
            fsid: 文件 fs_id（必须是自己网盘中的文件）

        Returns:
            dlink 下载地址
        """
        resp = _request_with_retry(
            self.session, "GET", self.FILEMETAS_URL,
            timeout=self.config.timeout,
            params={
                "fsids": json.dumps([fsid]),
                "dlink": "1",
            },
        )
        data = resp.json()

        if data.get("errno") != 0:
            raise RuntimeError(f"获取下载链接失败: errno={data.get('errno')}")

        # 返回结构可能是 "list" 或 "info"
        file_list = data.get("list") or data.get("info") or []
        if not file_list:
            raise RuntimeError(f"未找到文件: fsid={fsid}")

        dlink = file_list[0].get("dlink", "")
        if not dlink:
            raise RuntimeError(f"文件无下载链接: fsid={fsid}")

        return dlink

    def download_file(self, dlink: str, local_path: Path, callback: Optional[Callable] = None, max_retries: int = 3) -> Path:
        """
        流式下载文件到本地（带重试）

        Args:
            dlink: 下载链接
            local_path: 本地保存路径
            callback: 进度回调 callback(downloaded_bytes, total_bytes)
            max_retries: 最大重试次数

        Returns:
            本地文件路径
        """
        import time

        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        for attempt in range(max_retries):
            try:
                # 下载请求需要特殊 User-Agent
                headers = {
                    "User-Agent": "pan.baidu.com",
                }

                # 支持断点续传
                downloaded = 0
                if local_path.exists():
                    downloaded = local_path.stat().st_size
                    headers["Range"] = f"bytes={downloaded}-"
                    if attempt == 0:
                        logger.info(f"断点续传: 已下载 {downloaded} 字节")

                resp = self.session.get(
                    dlink,
                    headers=headers,
                    stream=True,
                    timeout=(15, None),
                )

                # 检查 HTTP 状态码
                if resp.status_code == 416:
                    # Range Not Satisfiable — 文件已下载完成
                    logger.info(f"文件已完整: {local_path}")
                    return local_path
                resp.raise_for_status()

                # 获取文件总大小
                total = int(resp.headers.get("Content-Length", 0)) + downloaded

                mode = "ab" if downloaded > 0 else "wb"
                with open(local_path, mode) as f:
                    for chunk in resp.iter_content(chunk_size=self.config.chunk_size):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if callback:
                                callback(downloaded, total)

                logger.info(f"下载完成: {local_path} ({downloaded} 字节)")
                return local_path

            except (requests.RequestException, IOError) as e:
                if attempt < max_retries - 1:
                    wait = 5 * (attempt + 1)
                    logger.warning(f"下载出错 (第{attempt + 1}次): {e}, {wait}秒后重试...")
                    time.sleep(wait)
                else:
                    raise RuntimeError(f"下载失败（已重试{max_retries}次）: {e}")

    # ========== Upload ==========

    # Upload slice size: 4 MB (Baidu Pan limit per slice)
    UPLOAD_SLICE_SIZE = 4 * 1024 * 1024

    def upload_file(self, local_path: Path, remote_path: str, callback: Optional[Callable] = None) -> Dict:
        """
        Upload a local file to Baidu Pan using the three-step flow:
        1. precreate — register intent, send file MD5 + slice MD5 list
        2. superfile2 — upload each 4MB slice
        3. create — finalize and merge slices

        Args:
            local_path: local file to upload
            remote_path: full path on Baidu Pan (e.g. "/AI-Drama-Clips/video.mp4")
            callback: optional progress callback(uploaded_bytes, total_bytes)

        Returns:
            API response dict from the create step (contains fs_id, path, etc.)
        """
        local_path = Path(local_path)
        if not local_path.exists():
            raise FileNotFoundError(f"文件不存在: {local_path}")

        file_size = local_path.stat().st_size
        logger.info(f"开始上传: {local_path.name} ({file_size / 1024 / 1024:.1f} MB) → {remote_path}")

        # Calculate MD5 for each 4MB slice
        slice_md5_list = []
        content_md5 = hashlib.md5()
        with open(local_path, 'rb') as f:
            while True:
                chunk = f.read(self.UPLOAD_SLICE_SIZE)
                if not chunk:
                    break
                slice_md5_list.append(hashlib.md5(chunk).hexdigest())
                content_md5.update(chunk)

        content_md5_hex = content_md5.hexdigest()

        # Step 1: precreate
        precreate_data = {
            'path': remote_path,
            'size': str(file_size),
            'isdir': '0',
            'autoinit': '1',
            'rtype': '3',  # 3 = overwrite if exists
            'block_list': json.dumps(slice_md5_list),
            'content-md5': content_md5_hex,
        }
        resp = _request_with_retry(
            self.session, 'POST', f'{self.BASE_URL}/api/precreate',
            timeout=self.config.timeout,
            data=precreate_data,
        )
        pre_result = resp.json()
        if pre_result.get('errno') != 0:
            raise RuntimeError(f"预创建失败: errno={pre_result.get('errno')}, {pre_result}")

        uploadid = pre_result.get('uploadid')
        if not uploadid:
            raise RuntimeError(f"预创建未返回 uploadid: {pre_result}")

        # Step 2: upload slices
        uploaded_bytes = 0
        with open(local_path, 'rb') as f:
            for part_seq, md5 in enumerate(slice_md5_list):
                chunk = f.read(self.UPLOAD_SLICE_SIZE)
                upload_url = (
                    f'https://d.pcs.baidu.com/rest/2.0/pcs/superfile2'
                    f'?method=upload&type=tmpfile'
                    f'&path={quote(remote_path, safe="")}'
                    f'&uploadid={quote(uploadid, safe="")}'
                    f'&partseq={part_seq}'
                )
                resp = _request_with_retry(
                    self.session, 'POST', upload_url,
                    timeout=300,  # large file slices may take time
                    files={'file': ('chunk', chunk)},
                )
                result = resp.json()
                if 'md5' not in result:
                    raise RuntimeError(f"分片 {part_seq} 上传失败: {result}")

                uploaded_bytes += len(chunk)
                if callback:
                    callback(uploaded_bytes, file_size)

                logger.debug(f"分片 {part_seq + 1}/{len(slice_md5_list)} 上传完成")

        # Step 3: create (merge slices)
        create_data = {
            'path': remote_path,
            'size': str(file_size),
            'isdir': '0',
            'rtype': '3',
            'uploadid': uploadid,
            'block_list': json.dumps(slice_md5_list),
        }
        resp = _request_with_retry(
            self.session, 'POST', f'{self.BASE_URL}/api/create',
            timeout=self.config.timeout,
            data=create_data,
        )
        create_result = resp.json()
        if create_result.get('errno') != 0:
            raise RuntimeError(f"合并创建失败: errno={create_result.get('errno')}, {create_result}")

        logger.info(f"上传完成: {remote_path} (fs_id={create_result.get('fs_id')})")
        return create_result

    # ========== Share ==========

    def create_share_link(self, fs_ids: List[int], period: int = 7, pwd: str = '') -> Dict:
        """
        Create a share link for files on Baidu Pan.

        Args:
            fs_ids: list of fs_id to share
            period: validity period in days (0=permanent, 1, 7, 30)
            pwd: custom 4-char password; if empty, Baidu auto-generates one

        Returns:
            {"link": "https://pan.baidu.com/s/1xxxx", "pwd": "abcd", "shorturl": "1xxxx"}
        """
        bdstoken = self._get_bdstoken()
        data = {
            'fid_list': json.dumps(fs_ids),
            'schannel': '0',
            'channel_list': '[]',
            'period': str(period),
        }
        if pwd:
            data['pwd'] = pwd

        resp = _request_with_retry(
            self.session, 'POST', f'{self.BASE_URL}/share/set',
            timeout=self.config.timeout,
            params={'bdstoken': bdstoken},
            data=data,
        )
        result = resp.json()
        if result.get('errno') != 0:
            raise RuntimeError(f"创建分享链接失败: errno={result.get('errno')}, {result}")

        shorturl = result.get('shorturl', '')
        share_pwd = result.get('pwd', pwd)
        link = result.get('link', shorturl)

        logger.info(f"分享链接已创建: {link} 提取码: {share_pwd}")
        return {
            'link': link,
            'pwd': share_pwd,
            'shorturl': shorturl,
        }
