"""OpenClaw runtime helpers for workflow state, telemetry, and release metadata."""
from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Union

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OPENCLAW_DIR = PROJECT_ROOT / 'openclaw'
PROGRESS_DIR = Path.home() / 'Documents' / 'AI-Drama-Cut' / '.progress'
RELAY_DIR = PROGRESS_DIR / '.relay'
VERSION_FILE = OPENCLAW_DIR / 'version.json'


STAGE_LABELS = {
    'downloading': '下载素材',
    'preprocessing': '预处理',
    'keyframe_extraction': '关键帧提取',
    'asr_extraction': 'ASR 语音识别',
    'ending_detection': '片尾检测',
    'ai_analysis': 'AI 分析',
    'analysis': '视频理解',
    'rendering': '渲染',
    'workflow': '工作流',
}

FRESH_PROGRESS_THRESHOLD_SECONDS = 60
ORPHANED_PROGRESS_THRESHOLD_SECONDS = 180
DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 20


def load_release_metadata() -> Dict[str, Any]:
    return json.loads(VERSION_FILE.read_text(encoding='utf-8'))


def build_artifact_names() -> Dict[str, str]:
    metadata = load_release_metadata()
    version = metadata['version']
    name = metadata['name']
    tarball = f'{name}-v{version}.tar.gz'
    return {
        'name': name,
        'version': version,
        'tarball': tarball,
        'checksum': f'{tarball}.sha256',
        'repository': f"{metadata['repository_base'].rstrip('/')}/{tarball}",
        'skill_url': metadata['skill_url'],
        'compatibility': metadata['compatibility'],
    }


@dataclass
class WorkflowStatus:
    stage: str
    status: str = 'running'
    completed: int = 0
    total: int = 0
    current_item: str = ''
    message: str = ''
    health: str = 'healthy'
    eta_min_seconds: Optional[int] = None
    eta_max_seconds: Optional[int] = None
    started_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    last_progress_at: float = field(default_factory=time.time)
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    heartbeat_count: int = 0
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        percentage = round(self.completed / self.total * 100, 1) if self.total > 0 else 0.0
        details = dict(self.details)
        details.setdefault('run_id', self.run_id)
        return {
            'stage': self.stage,
            'stage_label': STAGE_LABELS.get(self.stage, self.stage),
            'status': self.status,
            'completed': self.completed,
            'total': self.total,
            'percentage': percentage,
            'current_item': self.current_item,
            'message': self.message,
            'health': self.health,
            'eta_min_seconds': self.eta_min_seconds,
            'eta_max_seconds': self.eta_max_seconds,
            'started_at': self.started_at,
            'updated_at': self.updated_at,
            'last_progress_at': self.last_progress_at,
            'timestamp': self.updated_at,
            'run_id': self.run_id,
            'heartbeat_count': self.heartbeat_count,
            'details': details,
        }


def _progress_file(project_name: str, stage: str) -> Path:
    return PROGRESS_DIR / f'{project_name}_{stage}.json'


def new_run_id() -> str:
    return uuid.uuid4().hex


def build_progress_fingerprint(data: Dict[str, Any]) -> str:
    payload = {
        'stage': data.get('stage', ''),
        'status': data.get('status', ''),
        'completed': data.get('completed', 0),
        'total': data.get('total', 0),
        'current_item': data.get('current_item', ''),
        'message': data.get('message', ''),
        'health': data.get('health', ''),
        'run_id': data.get('run_id') or data.get('details', {}).get('run_id', ''),
        'last_progress_at': data.get('last_progress_at'),
        'updated_at': data.get('updated_at'),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()


def get_progress_state(data: Dict[str, Any], now: Optional[float] = None) -> str:
    now = now or time.time()
    updated_at = float(data.get('updated_at') or 0)
    last_progress_at = float(data.get('last_progress_at') or updated_at or now)
    if not updated_at:
        return 'orphaned_stale'
    if now - updated_at > ORPHANED_PROGRESS_THRESHOLD_SECONDS:
        return 'orphaned_stale'
    if now - last_progress_at > FRESH_PROGRESS_THRESHOLD_SECONDS:
        return 'stale_but_alive'
    return 'fresh_running'


def write_progress(
    project_name: str,
    stage: str,
    *,
    status: str = 'running',
    completed: int = 0,
    total: int = 0,
    current_item: str = '',
    message: str = '',
    health: str = 'healthy',
    eta_min_seconds: Optional[int] = None,
    eta_max_seconds: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    started_at: Optional[float] = None,
    last_progress_at: Optional[float] = None,
    updated_at: Optional[float] = None,
    run_id: Optional[str] = None,
    mark_progress: bool = True,
) -> None:
    PROGRESS_DIR.mkdir(parents=True, exist_ok=True)
    now = updated_at or time.time()
    details_payload = dict(details or {})
    progress_file = _progress_file(project_name, stage)
    existing = read_progress(progress_file) or {}
    existing_details = existing.get('details', {})
    if isinstance(existing_details, dict):
        for key, value in existing_details.items():
            details_payload.setdefault(key, value)
    resolved_run_id = run_id or details_payload.get('run_id') or existing.get('run_id') or new_run_id()
    details_payload['run_id'] = resolved_run_id
    previous_last_progress_at = existing.get('last_progress_at') or existing.get('updated_at') or now
    resolved_last_progress_at = last_progress_at
    if resolved_last_progress_at is None:
        resolved_last_progress_at = now if mark_progress else previous_last_progress_at
    heartbeat_count = int(existing.get('heartbeat_count') or 0)
    if not mark_progress:
        heartbeat_count += 1
    payload = WorkflowStatus(
        stage=stage,
        status=status,
        completed=completed,
        total=total,
        current_item=current_item,
        message=message,
        health=health,
        eta_min_seconds=eta_min_seconds,
        eta_max_seconds=eta_max_seconds,
        started_at=started_at or existing.get('started_at') or now,
        updated_at=now,
        last_progress_at=resolved_last_progress_at,
        run_id=resolved_run_id,
        heartbeat_count=heartbeat_count,
        details=details_payload,
    ).to_dict()
    payload['progress_state'] = get_progress_state(payload, now)
    payload['fingerprint'] = build_progress_fingerprint(payload)
    temp_file = progress_file.with_suffix('.json.tmp')
    temp_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    temp_file.replace(progress_file)


def _relay_cursor_file(project_name: str) -> Path:
    return RELAY_DIR / f'{project_name}.json'


def read_relay_cursor(project_name: str) -> Dict[str, Any]:
    cursor_file = _relay_cursor_file(project_name)
    if not cursor_file.exists():
        return {}
    try:
        return json.loads(cursor_file.read_text(encoding='utf-8'))
    except json.JSONDecodeError:
        return {}


def write_relay_cursor(project_name: str, cursor: Dict[str, Any]) -> None:
    RELAY_DIR.mkdir(parents=True, exist_ok=True)
    cursor_file = _relay_cursor_file(project_name)
    temp_file = cursor_file.with_suffix('.json.tmp')
    temp_file.write_text(json.dumps(cursor, ensure_ascii=False, indent=2), encoding='utf-8')
    temp_file.replace(cursor_file)


def clear_relay_cursor(project_name: str) -> None:
    cursor_file = _relay_cursor_file(project_name)
    if cursor_file.exists():
        cursor_file.unlink()


class ProgressHeartbeat:
    def __init__(
        self,
        project_name: str,
        stage: str,
        *,
        interval_seconds: int = DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
        started_at: Optional[float] = None,
        run_id: Optional[str] = None,
        initial_completed: int = 0,
        initial_total: int = 0,
        initial_current_item: str = '',
        message: str = '',
    ):
        self.project_name = project_name
        self.stage = stage
        self.interval_seconds = interval_seconds
        self.started_at = started_at or time.time()
        self.run_id = run_id or new_run_id()
        self.completed = initial_completed
        self.total = initial_total
        self.current_item = initial_current_item
        self.message = message
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def update(self, *, completed: Optional[int] = None, total: Optional[int] = None, current_item: Optional[str] = None, message: Optional[str] = None) -> None:
        if completed is not None:
            self.completed = completed
        if total is not None:
            self.total = total
        if current_item is not None:
            self.current_item = current_item
        if message is not None:
            self.message = message

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        self.thread.join(timeout=1)

    def _run(self) -> None:
        while not self.stop_event.wait(self.interval_seconds):
            write_progress(
                self.project_name,
                self.stage,
                status='running',
                completed=self.completed,
                total=self.total,
                current_item=self.current_item,
                message=self.message,
                started_at=self.started_at,
                run_id=self.run_id,
                mark_progress=False,
                details={'run_id': self.run_id},
            )


def write_pipeline_completed(project_name: str, message: str) -> None:
    """Write a completion marker so wait_and_report can detect pipeline end."""
    PROGRESS_DIR.mkdir(parents=True, exist_ok=True)
    marker = PROGRESS_DIR / f'{project_name}_completed.json'
    payload = {'message': message, 'timestamp': time.time(), 'status': 'completed'}
    temp = marker.with_suffix('.json.tmp')
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(marker)
    # Clean up running progress files (keep the marker)
    for f in PROGRESS_DIR.glob(f'{project_name}_*.json'):
        if f == marker:
            continue
        f.unlink(missing_ok=True)


def read_pipeline_completed(project_name: str) -> Optional[Dict[str, Any]]:
    """Read and consume the completion marker. Returns None if not found."""
    marker = PROGRESS_DIR / f'{project_name}_completed.json'
    if not marker.exists():
        return None
    try:
        data = json.loads(marker.read_text(encoding='utf-8'))
        marker.unlink(missing_ok=True)
        return data
    except (json.JSONDecodeError, OSError):
        return None


def clear_progress(project_name: str, stage: str, *, preserve_final: bool = False) -> None:
    progress_file = _progress_file(project_name, stage)
    if not progress_file.exists():
        return
    if preserve_final:
        data = read_progress(progress_file)
        if data:
            write_progress(
                project_name,
                stage,
                status='completed',
                completed=data.get('completed', 0),
                total=data.get('total', 0),
                current_item=data.get('current_item', ''),
                message=data.get('message', ''),
                health=data.get('health', 'healthy'),
                eta_min_seconds=data.get('eta_min_seconds'),
                eta_max_seconds=data.get('eta_max_seconds'),
                details=data.get('details', {}),
                started_at=data.get('started_at'),
                last_progress_at=data.get('last_progress_at'),
                run_id=data.get('run_id') or data.get('details', {}).get('run_id'),
                mark_progress=False,
            )
    if progress_file.exists():
        progress_file.unlink()


def read_progress(progress_file: Path) -> Optional[Dict[str, Any]]:
    if not progress_file.exists():
        return None
    try:
        return json.loads(progress_file.read_text(encoding='utf-8'))
    except json.JSONDecodeError:
        return None


def list_orphaned_progress(project_name: Optional[str] = None) -> list[Dict[str, Any]]:
    if not PROGRESS_DIR.exists():
        return []
    pattern = f'{project_name}_*.json' if project_name else '*.json'
    now = time.time()
    items: list[Dict[str, Any]] = []
    for progress_file in sorted(PROGRESS_DIR.glob(pattern)):
        data = read_progress(progress_file)
        if not data:
            continue
        state = data.get('progress_state') or get_progress_state(data, now)
        if state != 'orphaned_stale':
            continue
        items.append({
            'path': str(progress_file),
            'project_name': progress_file.stem.rsplit('_', 1)[0],
            'stage': data.get('stage', ''),
            'message': data.get('message', ''),
            'updated_at': data.get('updated_at'),
            'last_progress_at': data.get('last_progress_at'),
            'run_id': data.get('run_id') or data.get('details', {}).get('run_id', ''),
        })
    return items


def clear_orphaned_progress(project_name: Optional[str] = None) -> list[str]:
    removed: list[str] = []
    projects_to_clear: set[str] = set()
    for item in list_orphaned_progress(project_name):
        path = Path(item['path'])
        if path.exists():
            path.unlink()
            removed.append(str(path))
            projects_to_clear.add(item['project_name'])
    for project in projects_to_clear:
        clear_relay_cursor(project)
    return removed


def estimate_eta(started_at: float, completed: int, total: int) -> tuple:
    """Estimate remaining time based on progress ratio.

    Returns:
        (eta_min_seconds, eta_max_seconds) — both int or both None.
        Uses ×0.8 / ×1.3 multipliers to give a range around the linear estimate.
    """
    if completed <= 0 or total <= 0:
        return None, None
    elapsed = time.time() - started_at
    if elapsed < 3:  # not enough data in first 3 seconds
        return None, None
    rate = elapsed / completed
    remaining = (total - completed) * rate
    # Give a range: optimistic 80% – pessimistic 130%
    return int(remaining * 0.8), int(remaining * 1.3)


def format_eta_range(min_seconds: Optional[int], max_seconds: Optional[int]) -> str:
    if min_seconds is None and max_seconds is None:
        return 'ETA 暂无法估算'
    if min_seconds is None:
        min_seconds = max_seconds
    if max_seconds is None:
        max_seconds = min_seconds
    min_minutes = max(1, round(min_seconds / 60))
    max_minutes = max(1, round(max_seconds / 60))
    if min_minutes == max_minutes:
        return f'预计剩余约 {min_minutes} 分钟'
    return f'预计剩余约 {min_minutes}-{max_minutes} 分钟'
