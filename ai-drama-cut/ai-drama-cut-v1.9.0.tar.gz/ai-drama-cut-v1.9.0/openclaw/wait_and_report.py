#!/usr/bin/env python3
"""Production progress reporter for OpenClaw pipeline.

Blocks in foreground, polls progress files every N seconds, prints updates
for the host Agent to relay to users. Detects pipeline completion and exits.

Usage:
    python wait_and_report.py --project "复婚"
    python wait_and_report.py --project "复婚" --interval 30 --timeout 3600
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.check_progress import check_progress
from openclaw.runtime import read_pipeline_completed

DEFAULT_INTERVAL = 30       # seconds between polls
DEFAULT_TIMEOUT = 60 * 60   # 60 minutes max wait
NO_TASK_MARKER = '暂无正在运行的任务'


def wait_and_report(
    project_name: str,
    interval: int = DEFAULT_INTERVAL,
    timeout: int = DEFAULT_TIMEOUT,
) -> None:
    """Poll progress and print updates until the pipeline completes or times out."""
    start = time.time()
    iteration = 0
    last_message = ''

    print(f'开始监听项目 {project_name} 的进度...', flush=True)

    while True:
        elapsed = time.time() - start

        if elapsed > timeout:
            print(
                f'已等待 {int(elapsed // 60)} 分钟，超过最大等待时间，停止轮询。'
                f'请手动检查任务状态。',
                flush=True,
            )
            break

        # Check for pipeline completion marker first
        completed = read_pipeline_completed(project_name)
        if completed:
            message = completed.get('message', '处理完成。')
            print(f'\n{message}', flush=True)
            break

        # Poll running progress
        output = check_progress(project_name)

        # Dedup: only print if message changed
        if output != last_message:
            print(f'\n{output}', flush=True)
            last_message = output

        if NO_TASK_MARKER in output:
            # First check right after start: the background process may not
            # have written its progress file yet. Give it a grace period.
            if iteration == 0:
                print('后台任务刚启动，等待进度文件生成...', flush=True)
                time.sleep(min(interval, 10))
                iteration += 1
                continue
            # Task genuinely finished (no completion marker found above,
            # so it may have been cleaned up already or was a partial run)
            break

        iteration += 1
        time.sleep(interval)

    total_minutes = int((time.time() - start) // 60)
    total_seconds = int((time.time() - start) % 60)
    print(f'\n轮询结束，共等待 {total_minutes}分{total_seconds:02d}秒。', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='监听 AI 短剧剪辑任务进度',
    )
    parser.add_argument('--project', '-p', required=True, help='项目名称')
    parser.add_argument(
        '--interval', '-i',
        type=int,
        default=DEFAULT_INTERVAL,
        help=f'轮询间隔（秒），默认 {DEFAULT_INTERVAL}',
    )
    parser.add_argument(
        '--timeout', '-t',
        type=int,
        default=DEFAULT_TIMEOUT,
        help=f'最大等待时间（秒），默认 {DEFAULT_TIMEOUT}',
    )
    args = parser.parse_args()

    wait_and_report(args.project, args.interval, args.timeout)


if __name__ == '__main__':
    main()
