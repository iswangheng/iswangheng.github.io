"""
视频理解主入口
整合所有模块，实现完整的视频理解流程

V15.9 更新（2026-03-11）：
- 【重要】ASR 并行提取优化：使用 ThreadPoolExecutor 并行提取多集 ASR
- 【重要】缓存复用优化：片尾检测阶段复用已缓存的 ASR，避免重复转录
- 预期效果：ASR 提取时间从 8分钟 → 2分钟（4个worker），片尾检测瞬间完成

V18.6 更新（2026-03-18）：
- 【重要】分析阶段细粒度进度汇报：关键帧提取、ASR提取、片尾检测、AI分析各阶段独立汇报
- 复用 render_clips.py 的进度文件 IPC 机制
"""
import os
import json
import logging
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from scripts.log_config import setup_logging

logger = logging.getLogger(__name__)

# 导入子模块
from scripts.understand.understand_skill import understand_skill
from scripts.understand.extract_segments import extract_all_segments, VideoSegment
from scripts.understand.analyze_segment import analyze_all_segments, SegmentAnalysis
from scripts.understand.generate_clips import generate_clips, save_clips, sort_and_filter_clips
from scripts.understand.quality_filter import apply_quality_pipeline

# 导入数据类和工具函数
from scripts.extract_keyframes import load_existing_keyframes, get_keyframe_output_path, extract_keyframes
from scripts.extract_asr import load_asr_from_file, get_asr_output_path, extract_audio, transcribe_audio, get_audio_output_path

# 导入文件名解析工具
from scripts.utils.filename_parser import parse_episode_number
from scripts.utils.subprocess_utils import run_command
from scripts.config import TrainingConfig, TimeoutConfig
import shutil


def _write_progress(
    project_name: str,
    stage: str,
    completed: int,
    total: int,
    current_item: str = '',
    message: str = '',
    status: str = 'running',
    eta_min_seconds: Optional[int] = None,
    eta_max_seconds: Optional[int] = None,
    started_at: Optional[float] = None,
    last_progress_at: Optional[float] = None,
    run_id: Optional[str] = None,
    mark_progress: bool = True,
):
    """写入统一进度协议供 OpenClaw runtime 读取。"""
    try:
        from openclaw.runtime import write_progress

        write_progress(
            project_name,
            stage,
            status=status,
            completed=completed,
            total=total,
            current_item=current_item,
            message=message,
            eta_min_seconds=eta_min_seconds,
            eta_max_seconds=eta_max_seconds,
            started_at=started_at,
            last_progress_at=last_progress_at,
            run_id=run_id,
            mark_progress=mark_progress,
            details={'run_id': run_id} if run_id else None,
        )
    except Exception:
        pass


def _clear_progress(project_name: str, stage: str):
    """清理进度文件。"""
    try:
        from openclaw.runtime import clear_progress

        clear_progress(project_name, stage)
    except Exception:
        pass


def _estimate_eta(started_at: float, completed: int, total: int):
    """Compute ETA range from progress ratio. Returns (min_s, max_s) or (None, None)."""
    try:
        from openclaw.runtime import estimate_eta
        return estimate_eta(started_at, completed, total)
    except Exception:
        return None, None


def detect_narrative_start(episode_asr: list, max_scan_seconds: float = 60.0) -> float:
    """检测第1集的真正叙事起点（跳过片头预告/闪回）

    分析第1集前60秒的ASR，识别片头预告/闪回结构，
    找到真正的故事叙述开始位置。

    人工剪辑案例：
    - 年猪风波：跳过前29秒预告，从29秒开始
    - 最后一张船票：跳过前8秒背景，从8秒开始
    - 孤独坚守：无预告，从0秒开始

    检测策略：
    1. 寻找前60秒内的最大静音间隔（>2秒）作为预告→正片分界
    2. 检测预告特征：短碎片对话密集、预告关键词
    3. 如果没有明显预告特征，返回0秒

    Args:
        episode_asr: 第1集的ASR片段列表
        max_scan_seconds: 最大扫描范围（秒）

    Returns:
        建议的叙事起点（秒），0表示无需跳过
    """
    if not episode_asr:
        return 0.0

    # 只看前 max_scan_seconds 秒的 ASR
    early_segments = [seg for seg in episode_asr if seg.start < max_scan_seconds]
    if len(early_segments) < 2:
        return 0.0

    # 预告/前情提要关键词
    PREVIEW_KEYWORDS = ["预告", "上集", "前情提要", "接下来", "上回", "之前", "回顾"]

    # 检查是否包含预告关键词
    has_preview_keyword = False
    for seg in early_segments:
        for kw in PREVIEW_KEYWORDS:
            if kw in seg.text:
                has_preview_keyword = True
                break

    # 计算相邻 ASR 片段之间的静音间隔
    gaps = []
    for i in range(len(early_segments) - 1):
        gap_start = early_segments[i].end
        gap_end = early_segments[i + 1].start
        gap_duration = gap_end - gap_start
        if gap_duration > 0:
            gaps.append({
                'index': i,
                'start': gap_start,
                'end': gap_end,
                'duration': gap_duration,
            })

    if not gaps:
        return 0.0

    # 找前60秒内最大的静音间隔
    max_gap = max(gaps, key=lambda g: g['duration'])

    # 分析 max_gap 之前的片段是否有"预告"特征
    segments_before_gap = early_segments[:max_gap['index'] + 1]
    segments_after_gap = early_segments[max_gap['index'] + 1:]

    if not segments_before_gap or not segments_after_gap:
        return 0.0

    # 预告特征判定
    # 特征1: 间隔足够大（>= 2秒）
    gap_large_enough = max_gap['duration'] >= 2.0

    # 特征2: 间隔前的片段平均时长短（碎片化对话，典型预告特征）
    avg_duration_before = sum(s.end - s.start for s in segments_before_gap) / len(segments_before_gap)
    is_fragmented = avg_duration_before < 3.0 and len(segments_before_gap) >= 2

    # 特征3: 间隔前的片段密度高（短时间内很多句话）
    time_span_before = segments_before_gap[-1].end - segments_before_gap[0].start
    density_before = len(segments_before_gap) / max(time_span_before, 1.0)
    is_dense = density_before > 0.3  # 每秒超过0.3句话

    # 特征4: 间隔出现在前40秒内（太靠后不太可能是预告分界）
    gap_in_range = max_gap['end'] <= 45.0

    # 综合判定：需要满足间隔够大 + 至少一个预告特征
    preview_score = 0
    if gap_large_enough:
        preview_score += 1
    if has_preview_keyword:
        preview_score += 2  # 关键词权重最高
    if is_fragmented:
        preview_score += 1
    if is_dense:
        preview_score += 1
    if gap_in_range:
        preview_score += 1

    # 需要间隔够大 + 总分 >= 3 才认为有预告
    if gap_large_enough and preview_score >= 3:
        narrative_start = max_gap['end']
        # 对齐到最近的 ASR 片段起点
        if segments_after_gap:
            narrative_start = segments_after_gap[0].start

        logger.info(f"  🎬 检测到片头预告结构:")
        logger.info(f"     预告段: 0-{max_gap['start']:.1f}秒 ({len(segments_before_gap)}句, 平均{avg_duration_before:.1f}秒/句)")
        logger.info(f"     静音间隔: {max_gap['start']:.1f}-{max_gap['end']:.1f}秒 ({max_gap['duration']:.1f}秒)")
        logger.info(f"     叙事起点: {narrative_start:.1f}秒")
        logger.info(f"     判定依据: 得分{preview_score}/6 (间隔{max_gap['duration']:.1f}s, "
              f"{'有' if has_preview_keyword else '无'}关键词, "
              f"{'碎片化' if is_fragmented else '非碎片'}, "
              f"{'高密度' if is_dense else '低密度'})")
        return narrative_start

    # 没有明显预告特征，但检查是否有短暂的背景介绍（< 10秒）
    # 如果第一个 ASR 片段不是从0秒开始，说明开头有静音/背景音乐
    first_asr_start = early_segments[0].start
    if 3.0 <= first_asr_start <= 15.0:
        # 开头有3-15秒的静音，可能是背景画面/音乐
        logger.info(f"  🎬 检测到开头静音段: 0-{first_asr_start:.1f}秒（可能是背景画面）")
        logger.info(f"     建议叙事起点: 0秒（保留背景画面作为开篇）")
        # 背景画面通常应该保留，不跳过
        return 0.0

    return 0.0


def _extract_single_episode_asr(episode: int, mp4_file: Path, project_name: str) -> tuple:
    """
    提取单集的 ASR（用于并行处理）

    V15.9: 内部函数，用于 ThreadPoolExecutor 并行调用

    Args:
        episode: 集数
        mp4_file: 视频文件路径
        project_name: 项目名称

    Returns:
        (episode, asr_segments, error_message)
    """
    try:
        # 获取 ASR 缓存路径
        asr_path = get_asr_output_path(project_name, episode)

        # 检查缓存是否已存在
        if os.path.exists(asr_path):
            asr_segments = load_asr_from_file(asr_path, episode=episode)
            if asr_segments:
                return (episode, asr_segments, None)

        # 缓存不存在，开始提取
        # 步骤1: 提取音频
        audio_path = get_audio_output_path(project_name, episode)
        extract_audio(str(mp4_file), audio_path)

        # 步骤2: 转录音频
        asr_segments = transcribe_audio(
            audio_path=audio_path,
            output_path=asr_path,
            model=TrainingConfig.ASR_MODEL,
            language=TrainingConfig.ASR_LANGUAGE
        )

        return (episode, asr_segments, None)

    except Exception as e:
        return (episode, [], str(e))


def extract_asr_parallel(episode_files: Dict[int, Path], project_name: str,
                        max_workers: int = 4, progress_callback=None) -> Dict[int, list]:
    """
    并行提取多集的 ASR

    V15.9: 新增并行 ASR 提取功能
    - 使用 ThreadPoolExecutor 并行处理多集
    - 自动检测缓存，跳过已存在的 ASR
    - 提供进度回调支持

    Args:
        episode_files: {集数: mp4文件路径}
        project_name: 项目名称
        max_workers: 最大并行数（默认4，建议不超过4以避免内存不足）
        progress_callback: 进度回调函数 (episode, status, message)

    Returns:
        {集数: ASR片段列表}
    """
    episode_asr = {}
    total = len(episode_files)

    # 检查哪些集需要提取 ASR
    episodes_to_extract = []
    episodes_cached = []

    for episode, mp4_file in episode_files.items():
        asr_path = get_asr_output_path(project_name, episode)
        if os.path.exists(asr_path):
            episodes_cached.append(episode)
        else:
            episodes_to_extract.append(episode)

    if episodes_cached:
        logger.info(f"  📦 已缓存 ASR: {len(episodes_cached)} 集")
        # 加载缓存的 ASR
        for episode in episodes_cached:
            asr_path = get_asr_output_path(project_name, episode)
            asr_segments = load_asr_from_file(asr_path, episode=episode)
            episode_asr[episode] = asr_segments

    if not episodes_to_extract:
        logger.info(f"  ✅ 所有 ASR 均已缓存，无需提取")
        return episode_asr

    logger.info(f"  🔄 需要提取 ASR: {len(episodes_to_extract)} 集")
    logger.info(f"  ⚡ 并行 worker 数: {max_workers}")

    # 过滤出需要提取的文件
    files_to_extract = {ep: episode_files[ep] for ep in episodes_to_extract}

    start_time = time.time()

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_extract_single_episode_asr, ep, mp4, project_name): ep
            for ep, mp4 in files_to_extract.items()
        }

        completed = 0
        for future in as_completed(futures):
            ep = futures[future]
            try:
                episode, asr_segments, error = future.result()
                completed += 1

                if error:
                    logger.error(f"  ❌ [{completed}/{len(episodes_to_extract)}] 第{episode}集 ASR 提取失败: {error}")
                    episode_asr[episode] = []
                else:
                    # V15.4修复: 确保每个 ASRSegment 都有正确的 episode 字段
                    for seg in asr_segments:
                        seg.episode = episode
                    episode_asr[episode] = asr_segments
                    logger.info(f"  ✅ [{completed}/{len(episodes_to_extract)}] 第{episode}集 ASR 完成 ({len(asr_segments)}片段)")

                if progress_callback:
                    status = "error" if error else "success"
                    msg = error if error else f"完成 ({len(asr_segments)}片段)"
                    progress_callback(episode, status, msg)

                # V18.6: 汇报 ASR 提取进度
                _eta_min, _eta_max = _estimate_eta(start_time, completed, len(episodes_to_extract))
                _write_progress(
                    project_name,
                    "asr_extraction",
                    completed,
                    len(episodes_to_extract),
                    current_item=f"第{ep}集",
                    message=f"ASR 已处理 {completed}/{len(episodes_to_extract)} 集",
                    started_at=start_time,
                    eta_min_seconds=_eta_min,
                    eta_max_seconds=_eta_max,
                    run_id=f'{project_name}-asr-{int(start_time)}',
                )

            except Exception as e:
                completed += 1
                logger.error(f"  ❌ [{completed}/{len(episodes_to_extract)}] 第{ep}集 ASR 提取异常: {e}", exc_info=True)
                episode_asr[ep] = []
                _eta_min, _eta_max = _estimate_eta(start_time, completed, len(episodes_to_extract))
                _write_progress(
                    project_name,
                    "asr_extraction",
                    completed,
                    len(episodes_to_extract),
                    current_item=f"第{ep}集",
                    message=f"ASR 已处理 {completed}/{len(episodes_to_extract)} 集",
                    started_at=start_time,
                    eta_min_seconds=_eta_min,
                    eta_max_seconds=_eta_max,
                    run_id=f'{project_name}-asr-{int(start_time)}',
                )

    elapsed = time.time() - start_time
    logger.info(f"  ⏱️  ASR 并行提取完成，耗时: {elapsed:.1f}秒")

    # V18.6: 清理 ASR 提取进度文件
    _clear_progress(project_name, "asr_extraction")

    return episode_asr


def _extract_single_episode_keyframes(episode: int, mp4_file: Path, project_name: str) -> tuple:
    """
    提取单集的关键帧（用于并行处理）

    V19: 内部函数，用于 ThreadPoolExecutor 并行调用

    Args:
        episode: 集数
        mp4_file: 视频文件路径
        project_name: 项目名称

    Returns:
        (episode, keyframes, duration, error_message)
    """
    try:
        keyframe_path = get_keyframe_output_path(project_name, episode)

        # 加载现有关键帧（如果存在且非空）
        keyframes = None
        if os.path.exists(keyframe_path):
            keyframes = load_existing_keyframes(keyframe_path)
            if keyframes:
                pass  # 缓存命中，静默处理

        # 如果没有关键帧，则提取
        if not keyframes:
            # 检测视频实际帧率
            try:
                cmd = [
                    'ffprobe', '-v', 'error',
                    '-select_streams', 'v:0',
                    '-show_entries', 'stream=r_frame_rate',
                    '-of', 'default=noprint_wrappers=1:nokey=1',
                    str(mp4_file)
                ]
                result = run_command(
                    cmd,
                    timeout=TimeoutConfig.FFPROBE_QUICK,
                    retries=2,
                    error_msg="ffprobe获取帧率超时"
                )
                fps_str = result.stdout.strip() if result else ""
                if '/' in fps_str:
                    num, den = fps_str.split('/')
                    actual_fps = float(num) / float(den)
                else:
                    actual_fps = float(fps_str)

                if actual_fps >= 50:
                    extract_fps = 2.0
                elif actual_fps <= 25:
                    extract_fps = 0.5
                else:
                    extract_fps = 1.0
            except (ValueError, AttributeError):
                extract_fps = 1.0

            keyframes = extract_keyframes(
                video_path=str(mp4_file),
                output_dir=keyframe_path,
                fps=extract_fps,
                quality=TrainingConfig.KEYFRAME_QUALITY
            )

        # 获取视频时长
        duration = 0
        try:
            cmd = [
                'ffprobe', '-v', 'error',
                '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                str(mp4_file)
            ]
            result = run_command(
                cmd,
                timeout=TimeoutConfig.FFPROBE_METADATA,
                retries=2,
                error_msg="ffprobe获取视频时长超时"
            )
            if result is not None and result.returncode == 0:
                duration = int(float(result.stdout.strip()))
            else:
                raise ValueError("ffprobe返回失败或超时")
        except (ValueError, AttributeError):
            if keyframes:
                max_ms = max(kf.timestamp_ms for kf in keyframes)
                duration = (max_ms // 1000) + 10

        return (episode, keyframes if keyframes else [], duration, None)
    except Exception as e:
        return (episode, [], 0, str(e))


def load_episode_data(project_path: str, auto_extract: bool = True,
                     parallel_asr: bool = True, max_asr_workers: int = 6) -> tuple:
    """
    加载项目数据（支持多种文件命名格式，支持自动提取）

    V15.9 更新：新增 parallel_asr 参数
    V19 更新：关键帧提取并行化（ThreadPoolExecutor）

    Args:
        project_path: 项目路径
        auto_extract: 是否自动提取缺失的关键帧和ASR（默认True）
        parallel_asr: 是否并行提取 ASR（默认True）
        max_asr_workers: ASR 并行提取的最大 worker 数（默认6，M1 Pro 10核可承受）

    Returns:
        (episode_keyframes, episode_asr, episode_durations)
    """
    from scripts.config import TrainingConfig

    video_dir = Path(project_path)

    episode_keyframes = {}
    episode_asr = {}
    episode_durations = {}

    # 查找所有mp4文件
    mp4_files = sorted(video_dir.glob("*.mp4"))

    # 收集所有需要处理的视频文件
    episode_video_files = {}
    total_episodes = len(mp4_files)

    for mp4_file in mp4_files:
        episode = parse_episode_number(mp4_file.name)
        if episode is None:
            logger.warning(f"⚠️  警告: 无法解析文件名 {mp4_file.name}，跳过")
            continue
        episode_video_files[episode] = mp4_file

    # ===== V19: 关键帧提取并行化（I/O密集型，适合多线程） =====
    if auto_extract and episode_video_files:
        logger.info(f"\n{'='*50}")
        logger.info(f"关键帧提取 + 时长检测阶段 (并行, {min(4, len(episode_video_files))} workers)")
        logger.info(f"{'='*50}")

        completed_count = 0
        _kf_started_at = time.time()
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {
                executor.submit(
                    _extract_single_episode_keyframes, ep, mp4, video_dir.name
                ): ep
                for ep, mp4 in episode_video_files.items()
            }

            for future in as_completed(futures):
                ep = futures[future]
                try:
                    episode, keyframes, duration, error = future.result()
                    completed_count += 1

                    if error:
                        logger.error(f"  ❌ [{completed_count}/{len(episode_video_files)}] 第{episode}集关键帧提取失败: {error}")
                        episode_keyframes[episode] = []
                        episode_durations[episode] = 0
                    else:
                        episode_keyframes[episode] = keyframes
                        episode_durations[episode] = duration
                        logger.info(f"  ✅ [{completed_count}/{len(episode_video_files)}] 第{episode}集: {len(keyframes)}帧, {duration}秒")

                    _eta_min, _eta_max = _estimate_eta(_kf_started_at, completed_count, len(episode_video_files))
                    _write_progress(
                        video_dir.name,
                        "keyframe_extraction",
                        completed_count,
                        len(episode_video_files),
                        current_item=f"第{episode}集",
                        message=f"关键帧已处理 {completed_count}/{len(episode_video_files)} 集",
                        started_at=_kf_started_at,
                        eta_min_seconds=_eta_min,
                        eta_max_seconds=_eta_max,
                        run_id=f'{video_dir.name}-keyframe-{int(_kf_started_at)}',
                    )

                except Exception as e:
                    completed_count += 1
                    logger.error(f"  ❌ [{completed_count}/{len(episode_video_files)}] 第{ep}集异常: {e}", exc_info=True)
                    episode_keyframes[ep] = []
                    episode_durations[ep] = 0
                    _eta_min, _eta_max = _estimate_eta(_kf_started_at, completed_count, len(episode_video_files))
                    _write_progress(
                        video_dir.name,
                        "keyframe_extraction",
                        completed_count,
                        len(episode_video_files),
                        current_item=f"第{episode}集",
                        message=f"关键帧已处理 {completed_count}/{len(episode_video_files)} 集",
                        started_at=_kf_started_at,
                        eta_min_seconds=_eta_min,
                        eta_max_seconds=_eta_max,
                        run_id=f'{video_dir.name}-keyframe-{int(_kf_started_at)}',
                    )

        _clear_progress(video_dir.name, "keyframe_extraction")
    else:
        # 非自动提取模式：只加载缓存
        for episode, mp4_file in episode_video_files.items():
            keyframe_path = get_keyframe_output_path(video_dir.name, episode)
            keyframes = None
            if os.path.exists(keyframe_path):
                keyframes = load_existing_keyframes(keyframe_path)
            episode_keyframes[episode] = keyframes if keyframes else []

            try:
                cmd = [
                    'ffprobe', '-v', 'error',
                    '-show_entries', 'format=duration',
                    '-of', 'default=noprint_wrappers=1:nokey=1',
                    str(mp4_file)
                ]
                result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_METADATA, retries=2)
                if result is not None and result.returncode == 0:
                    episode_durations[episode] = int(float(result.stdout.strip()))
                else:
                    episode_durations[episode] = 0
            except Exception:
                logger.warning(f"  获取第{episode}集时长失败，使用默认值0", exc_info=True)
                episode_durations[episode] = 0

    # ===== V15.9: ASR 并行提取 =====
    if auto_extract:
        logger.info(f"\n{'='*50}")
        logger.info(f"ASR 提取阶段 ({'并行' if parallel_asr else '串行'})")
        logger.info(f"{'='*50}")

        if parallel_asr:
            # 并行提取 ASR
            episode_asr = extract_asr_parallel(
                episode_video_files,
                video_dir.name,
                max_workers=max_asr_workers
            )
        else:
            # 串行提取 ASR（保持向后兼容）
            for episode, mp4_file in episode_video_files.items():
                asr_path = get_asr_output_path(video_dir.name, episode)

                if os.path.exists(asr_path):
                    # ASR已存在，直接加载
                    asr_segments = load_asr_from_file(asr_path, episode=episode)
                    if asr_segments:
                        logger.info(f"  第{episode}集: ASR已加载 ({len(asr_segments)}片段)")
                else:
                    # ASR不存在，自动提取
                    logger.warning(f"  ⚠️  第{episode}集ASR不存在，开始自动转录...")

                    try:
                        # 步骤1: 提取音频
                        audio_path = get_audio_output_path(video_dir.name, episode)
                        logger.info(f"     步骤1/2: 提取音频...")
                        extract_audio(str(mp4_file), audio_path)

                        # 步骤2: 转录音频
                        logger.info(f"     步骤2/2: Whisper转录...")
                        asr_segments = transcribe_audio(
                            audio_path=audio_path,
                            output_path=asr_path,
                            model=TrainingConfig.ASR_MODEL,
                            language=TrainingConfig.ASR_LANGUAGE
                        )
                        logger.info(f"  ✅ 第{episode}集ASR转录完成 ({len(asr_segments)}片段)")
                    except Exception as e:
                        logger.error(f"  ❌ 第{episode}集ASR转录失败: {e}", exc_info=True)
                        asr_segments = []

                # V15.4修复: 确保每个ASRSegment都有正确的episode字段
                for seg in asr_segments:
                    seg.episode = episode

                episode_asr[episode] = asr_segments

    return episode_keyframes, episode_asr, episode_durations


def detect_project_endings_in_understand_phase(
    video_dir: str,
    episode_asr: dict,
    verbose: bool = True
) -> dict:
    """在video_understand阶段检测项目中所有视频的片尾

    使用复杂算法，检测结果保存到缓存供render阶段使用

    Args:
        video_dir: 视频目录路径
        episode_asr: 按集数分组的ASR数据 {集数: [ASR片段列表]}
        verbose: 是否打印详细信息

    Returns:
        片尾检测结果字典 {集数: {has_ending, duration, effective_duration}}
    """
    from pathlib import Path
    import json
    from scripts.detect_ending_credits import EndingCreditsDetector

    video_dir_path = Path(video_dir)
    project_name = video_dir_path.name

    # 输出目录 (与render_clips保持一致: data/ending_credits/)
    output_dir = Path("data/ending_credits")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"{project_name}_ending_credits.json"

    # 检查缓存是否存在
    if output_file.exists():
        with open(output_file, 'r', encoding='utf-8') as f:
            cached = json.load(f)
            # 兼容新旧两种格式
            if 'episodes' in cached:
                # 新格式: {"project": "...", "episodes": [...]}
                results = {ep['episode']: ep for ep in cached['episodes']}
            else:
                # 旧格式: {episode: {...}}
                results = cached
            if verbose:
                logger.info(f"  📦 使用已缓存的片尾检测结果: {len(results)}集")
            return results

    # 获取所有视频文件
    video_files = sorted(video_dir_path.glob("*.mp4"))
    if not video_files:
        return {}

    # 创建检测器
    detector = EndingCreditsDetector()

    # V19: 并行检测每集片尾（I/O密集型，适合多线程）
    def _detect_single_ending(video_path, episode, asr_segments):
        """单集片尾检测（用于并行调用）"""
        result = detector.detect_video_ending(
            video_path=str(video_path),
            episode=episode,
            asr_segments=asr_segments,
            use_complex_method=True
        )
        return episode, {
            'has_ending': result.ending_info.has_ending,
            'duration': result.ending_info.duration,
            'effective_duration': result.effective_duration,
            'confidence': result.ending_info.confidence,
            'method': result.ending_info.method
        }

    results = {}
    total_videos = len(video_files)

    # 收集需要检测的集数
    episodes_to_detect = []
    for video_path in video_files:
        filename = video_path.stem
        episode = None
        for part in filename.split('-'):
            if part.isdigit():
                episode = int(part)
                break
        if episode is None:
            episode = parse_episode_number(filename)
        if episode is not None:
            asr_segments = episode_asr.get(episode, [])
            episodes_to_detect.append((video_path, episode, asr_segments))

    if verbose:
        logger.info(f"  🔄 并行检测 {len(episodes_to_detect)} 集片尾...")

    completed_endings = 0
    _ending_started_at = time.time()
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {
            executor.submit(_detect_single_ending, vp, ep, asr): ep
            for vp, ep, asr in episodes_to_detect
        }

        for future in as_completed(futures):
            ep = futures[future]
            try:
                episode, ep_result = future.result()
                results[episode] = ep_result
                completed_endings += 1

                if verbose:
                    has = "有" if ep_result['has_ending'] else "无"
                    logger.info(f"  [{completed_endings}/{len(episodes_to_detect)}] 第{episode}集: {has}片尾")

                _eta_min, _eta_max = _estimate_eta(_ending_started_at, completed_endings, len(episodes_to_detect))
                _write_progress(
                    project_name,
                    "ending_detection",
                    completed_endings,
                    len(episodes_to_detect),
                    current_item=f"第{ep}集",
                    message=f"片尾检测已处理 {completed_endings}/{len(episodes_to_detect)} 集",
                    started_at=_ending_started_at,
                    eta_min_seconds=_eta_min,
                    eta_max_seconds=_eta_max,
                    run_id=f'{project_name}-ending-{int(_ending_started_at)}',
                )
            except Exception as e:
                completed_endings += 1
                logger.error(f"  ❌ 第{ep}集片尾检测失败: {e}", exc_info=True)
                _eta_min, _eta_max = _estimate_eta(_ending_started_at, completed_endings, len(episodes_to_detect))
                _write_progress(
                    project_name,
                    "ending_detection",
                    completed_endings,
                    len(episodes_to_detect),
                    current_item=f"第{ep}集",
                    message=f"片尾检测已处理 {completed_endings}/{len(episodes_to_detect)} 集",
                    started_at=_ending_started_at,
                    eta_min_seconds=_eta_min,
                    eta_max_seconds=_eta_max,
                    run_id=f'{project_name}-ending-{int(_ending_started_at)}',
                )

    # V18.6: 清理片尾检测进度文件
    _clear_progress(project_name, "ending_detection")

    # 保存到缓存（使用与 render_clips.py 一致的格式）
    cache_data = {
        'project': project_name,
        'episodes': [
            {
                'episode': ep,
                **ep_info
            }
            for ep, ep_info in results.items()
        ]
    }
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(cache_data, f, ensure_ascii=False, indent=2)

    if verbose:
        logger.info(f"  💾 片尾检测结果已保存到: {output_file}")

    return results


def cleanup_project_cache(project_name: str, min_age_hours: float = 3.0) -> dict:
    """清理项目的中间缓存文件（仅清理超过指定小时数的缓存）

    项目分析完成后，清理关键帧、音频、ASR等中间产物。
    为了方便后续测试，只清理超过 min_age_hours 小时的缓存文件。

    Args:
        project_name: 项目名称
        min_age_hours: 最小缓存保留时长（小时），默认3.0小时

    Returns:
        清理结果统计，包含跳过的文件数量
    """
    import time

    cache_dir = TrainingConfig.CACHE_DIR
    cutoff_time = time.time() - (min_age_hours * 3600)  # 计算截止时间戳

    result = {
        "keyframes_cleaned": 0,
        "audio_cleaned": 0,
        "asr_cleaned": 0,
        "skipped": 0,  # 新增：跳过的文件数
        "total_size_freed_mb": 0,
    }

    def clean_directory_with_age_check(dir_path: Path, cache_type: str) -> tuple:
        """清理目录中的文件，只删除超过指定时间的文件

        Args:
            dir_path: 目录路径
            cache_type: 缓存类型（用于日志）

        Returns:
            (清理的文件数, 跳过的文件数, 释放的空间MB)
        """
        if not dir_path.exists():
            return 0, 0, 0.0

        cleaned = 0
        skipped = 0
        size_freed = 0.0

        # 收集所有文件
        all_files = list(dir_path.rglob("*"))
        if not all_files:
            # 空目录，直接删除
            shutil.rmtree(dir_path)
            return 0, 0, 0.0

        for file_path in all_files:
            if not file_path.is_file():
                continue

            # 检查文件修改时间
            file_mtime = file_path.stat().st_mtime
            if file_mtime >= cutoff_time:
                # 文件还在保留期内，跳过
                skipped += 1
                continue

            # 文件超过保留期，删除
            size_freed += file_path.stat().st_size / (1024 * 1024)
            file_path.unlink()
            cleaned += 1

        # 如果所有文件都被删除或跳过，清理空目录
        if cleaned > 0:
            # 尝试删除空目录
            try:
                # 检查是否还有文件
                remaining = list(dir_path.rglob("*"))
                if not any(f.is_file() for f in remaining):
                    shutil.rmtree(dir_path)
            except Exception:
                logger.warning(f"清理空目录失败: {dir_path}", exc_info=True)

    # 清理关键帧缓存
    keyframes_dir = cache_dir / "keyframes" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(keyframes_dir, "关键帧")
    result["keyframes_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    # 清理音频缓存
    audio_dir = cache_dir / "audio" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(audio_dir, "音频")
    result["audio_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    # 清理ASR缓存
    asr_dir = cache_dir / "asr" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(asr_dir, "ASR")
    result["asr_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    return result


def video_understand(
    project_path: str,
    skill_file: str = None,
    force_skill: bool = False,
    output_dir: str = None,
    no_cleanup: bool = False
) -> Dict[str, Any]:
    """视频理解主函数

    Args:
        project_path: 项目路径（包含视频文件）
        skill_file: 技能文件路径
        force_skill: 是否强制重新生成技能框架
        output_dir: 输出目录
        no_cleanup: 是否跳过清理中间缓存

    Returns:
        理解结果dict
    """
    project_name = Path(project_path).name
    logger.info(f"\n{'='*50}")
    logger.info(f"开始视频理解: {project_name}")
    logger.info(f"{'='*50}\n")

    # 1. 理解技能文件
    logger.info("[1/5] 理解技能文件...")
    if skill_file is None:
        skill_file = "data/skills/ai-drama-clipping-thoughts-v0.1.md"
    skill_framework = understand_skill(skill_file, force=force_skill)
    logger.info(f"技能框架加载完成\n")

    # 2. 加载项目数据（自动检查并提取缺失的关键帧和ASR）
    logger.info("[2/5] 加载项目数据（自动检查并提取缺失数据）...")
    episode_keyframes, episode_asr, episode_durations = load_episode_data(project_path, auto_extract=True)

    # 过滤掉None值（提取失败的集）
    episode_keyframes = {k: v for k, v in episode_keyframes.items() if v is not None}
    episode_asr = {k: v for k, v in episode_asr.items() if v is not None}

    # 构建 episode_video_files（用于时间戳优化和智能切割）
    video_dir_path = Path(project_path)
    episode_video_files = {}
    for mp4_file in sorted(video_dir_path.glob("*.mp4")):
        ep = parse_episode_number(mp4_file.name)
        if ep is not None:
            episode_video_files[ep] = mp4_file

    total_keyframes = sum(len(v) for v in episode_keyframes.values())
    total_asr = sum(len(v) for v in episode_asr.values())
    logger.info(f"\n数据加载完成: {len(episode_keyframes)}集, {total_keyframes}关键帧, {total_asr}ASR片段\n")

    # 2.5 片尾检测（使用复杂算法）
    logger.info("[2.5/6] 片尾检测（复杂算法）...")
    ending_results = detect_project_endings_in_understand_phase(
        video_dir=project_path,
        episode_asr=episode_asr,
        verbose=True
    )
    logger.info(f"片尾检测完成: {len(ending_results)}集\n")
    
    # 3. 提取分析片段
    logger.info("[3/5] 提取分析片段...")
    segments = extract_all_segments(
        episode_keyframes,
        episode_asr,
        episode_durations
    )
    logger.info(f"生成了 {len(segments)} 个分析片段\n")

    # 4. 逐段分析
    logger.info("[4/5] 生成全剧ASR摘要...")
    from scripts.understand.analyze_segment import generate_drama_summary
    drama_summary = generate_drama_summary(episode_asr)
    logger.info(f"全剧摘要生成完成（{len(drama_summary)}字）\n")

    logger.info("[4/5] 逐段分析（可能需要几分钟）...")
    analyses = analyze_all_segments(segments, skill_framework, project_name=project_name, drama_summary=drama_summary)

    # 去除完全重复的项（AI可能返回了相同的分析结果）
    unique_analyses = []
    seen = set()

    for analysis in analyses:
        # 创建唯一标识：集数 + 类型 + 时间戳
        if analysis.is_highlight:
            key = (analysis.episode, 'hl', analysis.highlight_timestamp, analysis.highlight_type)
        else:
            key = (analysis.episode, 'hook', analysis.hook_timestamp, analysis.hook_type)

        if key not in seen:
            seen.add(key)
            unique_analyses.append(analysis)

    duplicate_count = len(analyses) - len(unique_analyses)
    if duplicate_count > 0:
        logger.info(f"去除完全重复的项: {len(analyses)} → {len(unique_analyses)} (移除{duplicate_count}个)")

    analyses = unique_analyses

    # 分离高光点和钩子点
    highlights = [a for a in analyses if a.is_highlight]
    hooks = [a for a in analyses if a.is_hook]
    logger.info(f"识别到 {len(highlights)} 个高光点, {len(hooks)} 个钩子点")

    # 5. 质量筛选流程
    logger.info("\n[5/5] 质量筛选...")
    
    # === V18 数据有效率保护机制 ===
    failed_count = sum(1 for a in analyses if a.highlight_desc == "分析失败" or a.hook_desc == "分析失败")
    total_analyses = len(analyses)
    if total_analyses > 0:
        fail_rate = failed_count / total_analyses
        if fail_rate > 0.2:
            logger.error(f"\n❌ [安全拦截] 发现大量分析失败 ({failed_count}/{total_analyses}, 失败率 {fail_rate:.1%})。")
            logger.error("❌ 这通常是由于大面积的网络异常或 API 熔断引起的。")
            logger.error("❌ 为防止毁坏已有的有效 result.json 数据，程序将终止保存并直接抛出异常！")
            raise RuntimeError(f"API 网络异常拦截：检测到 {fail_rate:.1%} 的片段分析失败。")
        elif failed_count > 0:
            logger.error(f"\n⚠️ 发现部分分析失败 ({failed_count}/{total_analyses})，但仍在容忍阈值 (20%) 内，继续执行。")

    analyses = apply_quality_pipeline(
        analyses,
        episode_durations,
        min_confidence=6.5,  # 放宽到6.5，捕获更多候选
        min_distance=10,  # 10秒去重窗口
        max_same_type_per_episode=2  # 每集同类型最多2个
    )

    # 重新统计
    highlights = [a for a in analyses if a.is_highlight]
    hooks = [a for a in analyses if a.is_hook]
    logger.info(f"\n筛选后: {len(highlights)} 个高光点, {len(hooks)} 个钩子点")

    # 5.5. 添加固定的开篇高光点(智能检测叙事起点)
    # V20: 片头预告检测 — 第1集0秒固定高光始终保留，检测到预告时额外添加叙事起点高光
    # V17.2: 修复第1集第0秒重复高光点问题
    logger.info("\n[5.5/6] 添加固定的开篇高光点（智能叙事起点检测）...")

    # V20: 检测第1集是否有片头预告/闪回结构
    ep1_asr = episode_asr.get(1, [])
    narrative_start = detect_narrative_start(ep1_asr)
    if narrative_start > 0:
        logger.info(f"  📍 检测到预告结构，叙事起点: 第1集 {narrative_start:.1f}秒")
    else:
        logger.info(f"  📍 无片头预告，叙事起点: 第1集 0秒")

    from scripts.understand.analyze_segment import SegmentAnalysis

    # 第1集0秒的固定高光点始终保留
    episode1_has_zero = any(
        h.episode == 1 and h.highlight_type == "开篇高光" and h.highlight_timestamp <= 5
        for h in highlights
    )

    if not episode1_has_zero:
        logger.info("  第1集没有0秒开篇高光,自动添加")

        # V17.2修复: 先移除第1集0秒附近的AI检测高光点（避免重复）
        opening_conflict_highlights = [
            h for h in highlights
            if h.episode == 1 and h.highlight_timestamp <= 5
        ]
        if opening_conflict_highlights:
            logger.warning(f"  ⚠️  发现第1集开头有{len(opening_conflict_highlights)}个AI检测高光点，将被固定开篇高光替换")
            for h in opening_conflict_highlights:
                logger.info(f"     - 移除: {h.highlight_type} @ {h.highlight_timestamp}s (置信度: {h.highlight_confidence})")
                highlights.remove(h)
                analyses.remove(h)

        opening_highlight = SegmentAnalysis(
            episode=1,
            start_time=0,
            end_time=30,
            is_highlight=True,
            highlight_timestamp=0.0,
            highlight_type="开篇高光",
            highlight_desc="第1集固定开篇高光点",
            highlight_confidence=10.0,
            is_hook=False,
            hook_timestamp=0.0,
            hook_type="",
            hook_desc="",
            hook_confidence=0.0
        )
        analyses.insert(0, opening_highlight)
        highlights.insert(0, opening_highlight)
        logger.info("  ✅ 已添加开篇高光点 @ 0秒")
    else:
        logger.info("  第1集已有0秒开篇高光点,跳过")

    # V20: 如果检测到预告，额外添加一个"叙事起点"高光点
    if narrative_start > 5:
        # 检查叙事起点附近是否已有高光
        has_narrative_start_hl = any(
            h.episode == 1 and abs(h.highlight_timestamp - narrative_start) <= 5
            for h in highlights
        )
        if not has_narrative_start_hl:
            narrative_highlight = SegmentAnalysis(
                episode=1,
                start_time=int(narrative_start),
                end_time=int(narrative_start) + 30,
                is_highlight=True,
                highlight_timestamp=float(narrative_start),
                highlight_type="叙事起点",
                highlight_desc=f"跳过{narrative_start:.0f}秒片头预告后的叙事起点",
                highlight_confidence=9.5,
                is_hook=False,
                hook_timestamp=0.0,
                hook_type="",
                hook_desc="",
                hook_confidence=0.0
            )
            analyses.insert(1, narrative_highlight)
            highlights.insert(1, narrative_highlight)
            logger.info(f"  ✅ 已添加叙事起点高光 @ {narrative_start:.1f}秒（跳过预告）")

    # 6. 生成剪辑组合（V13: 传入ASR数据进行时间戳优化）
    # V15.2: 传入视频路径和帧率用于智能切割
    # V13时间戳修复: 传递按集分组的ASR数据，而不是平铺的列表
    logger.info("\n生成剪辑组合...")

    # V13时间戳修复: 直接传递按集分组的episode_asr字典
    # 不再需要收集为平铺列表，保留集数信息用于精确匹配
    logger.info(f"已准备 {len(episode_asr)} 集的ASR数据，用于时间戳精度优化")

    # V15.2: 获取视频路径和帧率（用于智能切割）
    # BugFix: 使用已构建的 episode_video_files 映射，确保每集使用正确视频路径
    # 不再使用 mp4_files[0] 一刀切，而是传递 {集数: 视频路径} 字典
    episode_video_paths = {ep: str(fp) for ep, fp in episode_video_files.items()}
    # 用最小集数的视频路径来探测帧率（各集帧率通常一致）
    video_path = str(episode_video_files[min(episode_video_files)]) if episode_video_files else None

    # 获取视频帧率
    video_fps = 30.0
    if video_path:
        try:
            cmd = ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                   '-show_entries', 'stream=r_frame_rate', '-of', 'csv=p=0', video_path]
            result = run_command(
                cmd,
                timeout=TimeoutConfig.FFPROBE_QUICK,
                retries=1,
                error_msg="ffprobe获取视频帧率超时"
            )
            fps_str = result.stdout.strip() if result else ""
            if '/' in fps_str:
                num, denom = fps_str.split('/')
                video_fps = float(num) / float(denom)
            else:
                video_fps = float(fps_str)
            logger.info(f"视频帧率: {video_fps:.2f}fps")
        except Exception as e:
            logger.warning(f"⚠️ 无法获取视频帧率，使用默认值: {video_fps}fps")

    clips = generate_clips(
        analyses,
        episode_durations,
        episode_asr=episode_asr,  # V13时间戳修复: 传入按集分组的ASR字典
        enable_timestamp_optimization=True,  # V13: 启用时间戳优化
        episode_video_paths=episode_video_paths,  # BugFix: 传入每集对应视频路径字典
        video_fps=video_fps  # V15.2: 传入视频帧率
    )

    # 6. V17.1: 剪辑组合排序与智能筛选（Top N 精选）
    logger.info("\n[6/7] 剪辑组合排序与智能筛选...")
    clips = sort_and_filter_clips(
        highlights=highlights,
        hooks=hooks,
        episode_durations=episode_durations,
        max_output=20,
        min_output=10,
        top_highlights=10,
        top_hooks=10,
        max_same_type=3,
        max_point_reuse=6
    )

    # 7. 保存结果
    logger.info("\n保存结果...")
    if output_dir is None:
        output_dir = f"data/analysis/{project_name}"

    os.makedirs(output_dir, exist_ok=True)
    result_path = os.path.join(output_dir, "result.json")

    # === V18.4: 自动修复旧 result.json（clips 数量 > 20） ===
    if os.path.exists(result_path):
        try:
            with open(result_path, 'r', encoding='utf-8') as f:
                old_result = json.load(f)
            old_clips_count = len(old_result.get('clips', []))

            if old_clips_count > 20:
                logger.warning(f"\n⚠️ 检测到旧 result.json 包含 {old_clips_count} 个剪辑（超过20个）")
                logger.info("  自动应用 sort_and_filter_clips 重新筛选...")

                # 重建 SegmentAnalysis 对象
                old_highlights = []
                for h in old_result.get('highlights', []):
                    from scripts.understand.analyze_segment import SegmentAnalysis
                    sa = SegmentAnalysis(
                        episode=h['episode'],
                        start_time=0,
                        end_time=0,
                        is_highlight=True,
                        highlight_timestamp=h['timestamp'],
                        highlight_type=h.get('type'),
                        highlight_desc=h.get('description', ''),
                        highlight_confidence=h.get('confidence', 7.0),
                        is_hook=False,
                        hook_timestamp=0.0,
                        hook_type=None,
                        hook_desc='',
                        hook_confidence=0.0
                    )
                    old_highlights.append(sa)

                old_hooks = []
                for h in old_result.get('hooks', []):
                    from scripts.understand.analyze_segment import SegmentAnalysis
                    sa = SegmentAnalysis(
                        episode=h['episode'],
                        start_time=0,
                        end_time=0,
                        is_highlight=False,
                        highlight_timestamp=0.0,
                        highlight_type=None,
                        highlight_desc='',
                        highlight_confidence=0.0,
                        is_hook=True,
                        hook_timestamp=h['timestamp'],
                        hook_type=h.get('type'),
                        hook_desc=h.get('description', ''),
                        hook_confidence=h.get('confidence', 7.0)
                    )
                    old_hooks.append(sa)

                # 解析 episodeDurations
                old_episode_durations = {
                    int(k): v for k, v in old_result.get('episodeDurations', {}).items()
                }

                # 重新筛选
                repaired_clips = sort_and_filter_clips(
                    highlights=old_highlights,
                    hooks=old_hooks,
                    episode_durations=old_episode_durations,
                    max_output=20,
                    min_output=10,
                    top_highlights=10,
                    top_hooks=10,
                    max_same_type=3,
                    max_point_reuse=6
                )

                logger.info(f"  ✅ 自动修复完成: {old_clips_count} → {len(repaired_clips)} 个剪辑")

                # 更新旧结果
                old_result['clips'] = [c.to_dict() for c in repaired_clips]
                old_result['statistics']['totalClips'] = len(repaired_clips)

                # 备份旧文件
                import time as time_mod
                bak_name = f"result.json.bak.auto_repair.{int(time_mod.time())}"
                bak_path = os.path.join(output_dir, bak_name)
                shutil.copy2(result_path, bak_path)
                logger.info(f"  🔐 已备份原有结果至: {bak_name}")

                # 保存修复后的结果
                with open(result_path, 'w', encoding='utf-8') as f:
                    json.dump(old_result, f, ensure_ascii=False, indent=2)
                logger.info(f"  💾 已保存修复后的 result.json")
        except Exception as e:
            logger.error(f"  ⚠️ 自动修复失败: {e}，将继续正常流程")

    # === V18 备份原 result.json ===
    if os.path.exists(result_path):
        import time as time_mod
        bak_name = f"result.json.bak.{int(time_mod.time())}"
        bak_path = os.path.join(output_dir, bak_name)
        try:
            shutil.copy2(result_path, bak_path)
            logger.info(f"  🔐 已备份原有结果至: {bak_name}")
        except Exception as e:
            logger.error(f"  ⚠️ 备份 result.json 失败: {e}")

    # 构建结果数据结构（V13: 保留毫秒精度）
    def format_timestamp(ts):
        """格式化时间戳：整数值返回整数，浮点数保留3位小数"""
        if isinstance(ts, int):
            return ts
        if isinstance(ts, float) and ts.is_integer():
            return int(ts)
        return round(ts, 3)

    result = {
        "projectName": project_name,
        "episodeDurations": {ep: duration for ep, duration in episode_durations.items()},  # V13.1: 保存每集时长
        "highlights": [
            {
                "timestamp": format_timestamp(a.highlight_timestamp),  # V13: 保留精度
                "episode": a.episode,
                "type": a.highlight_type,
                "confidence": a.highlight_confidence,
                "description": a.highlight_desc
            }
            for a in highlights
        ],
        "hooks": [
            {
                "timestamp": format_timestamp(a.hook_timestamp),  # V13: 保留精度
                "episode": a.episode,
                "type": a.hook_type,
                "confidence": a.hook_confidence,
                "description": a.hook_desc,
                "viewerDesire": getattr(a, 'hook_viewer_desire', 0.0),  # V20: 观众渴望度
                "narrativeStage": getattr(a, 'hook_narrative_stage', ""),  # V20: 叙事阶段
            }
            for a in hooks
        ],
        "clips": [c.to_dict() for c in clips],
        "statistics": {
            "totalHighlights": len(highlights),
            "totalHooks": len(hooks),
            "totalClips": len(clips),
            "averageConfidence": (
                sum(a.highlight_confidence for a in highlights) +
                sum(a.hook_confidence for a in hooks)
            ) / (len(highlights) + len(hooks)) if (len(highlights) + len(hooks)) > 0 else 0
        }
    }
    
    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    logger.info(f"\n结果已保存: {result_path}")
    logger.info(f"高光点: {len(highlights)}")
    logger.info(f"钩子点: {len(hooks)}")
    logger.info(f"剪辑组合: {len(clips)}")

    # 项目分析完成后清理中间缓存
    if not no_cleanup:
        logger.info(f"\n清理项目 {project_name} 的中间缓存（仅清理超过3小时的缓存）...")
        cleanup_result = cleanup_project_cache(project_name)
        logger.info(f"  已清理: 关键帧={cleanup_result['keyframes_cleaned']}, "
              f"音频={cleanup_result['audio_cleaned']}, "
              f"ASR={cleanup_result['asr_cleaned']}")
        if cleanup_result['skipped'] > 0:
            logger.info(f"  ⏭️  跳过（未到3小时）: {cleanup_result['skipped']} 个文件")
        logger.info(f"  释放空间: {cleanup_result['total_size_freed_mb']:.2f} MB")

    return result


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(
        description='视频理解 - 分析短剧并生成剪辑方案'
    )
    parser.add_argument('project_path', help='项目路径（包含视频文件）')
    parser.add_argument('skill_file', nargs='?', help='技能文件路径（可选）')
    parser.add_argument('--force-skill', action='store_true', help='强制重新生成技能框架')
    parser.add_argument('--output-dir', type=str, help='输出目录')
    parser.add_argument('--no-cleanup', action='store_true', help='跳过清理中间缓存（关键帧、音频、ASR）')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable debug logging')

    args = parser.parse_args()

    setup_logging(level=logging.DEBUG if args.verbose else logging.INFO)

    video_understand(
        args.project_path,
        args.skill_file,
        args.force_skill,
        args.output_dir,
        args.no_cleanup
    )


if __name__ == "__main__":
    main()
