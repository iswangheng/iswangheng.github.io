"""
视频剪辑渲染模块
基于FFmpeg实现高光点-钩子点剪辑的生成

V14: 新增结尾视频拼接功能
V14.1: 新增自动片尾检测功能
V14.8: 修复片尾剪切精度和音视频同步问题
V15: 新增视频包装花字叠加功能
V15.6: 修复处理顺序 + 热门短剧位置随机化（左上/右上各50%概率）
V16: 新增并行渲染功能（多进程加速）
V16.3: 智能Worker数调节 + 分辨率自适应输出 + 结尾视频预缓存
V17: 视频自动压缩功能
"""
import os
import json
import subprocess
import random
import statistics
import logging
from pathlib import Path
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
import re
import shutil
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, as_completed
import concurrent.futures.process
import time
from datetime import datetime

from scripts.config import TrainingConfig, TimeoutConfig
from scripts.log_config import setup_logging
from scripts.utils.subprocess_utils import run_command, run_popen_with_timeout
from scripts.understand.video_overlay.video_overlay import validate_subtitle_bottom_y, resolve_overlay_layout

logger = logging.getLogger(__name__)


def _resolve_subtitle_bottom_from_ratio(
    y_ratio: Optional[float],
    clip_height: int,
    context_label: str,
) -> Optional[int]:
    """将缓存/检测得到的 y_ratio 换算为 clip 像素坐标并统一校验。"""
    if y_ratio is None:
        return None
    if clip_height <= 0:
        logger.info(f"[字幕定位] {context_label}: clip_height={clip_height} 无效，跳过字幕避障")
        return None
    if not 0 <= y_ratio < 1:
        logger.info(f"[字幕定位] {context_label}: y_ratio={y_ratio} 越界，跳过字幕避障")
        return None

    subtitle_bottom_y = int(y_ratio * clip_height)
    validated = validate_subtitle_bottom_y(subtitle_bottom_y, clip_height)
    if validated is None:
        logger.info(f"[字幕定位] {context_label}: 换算后坐标 {subtitle_bottom_y}px 无效，跳过字幕避障")
        return None

    logger.info(f"[字幕定位] {context_label}: y_ratio={y_ratio:.3f} × clip_height={clip_height} = {validated}px")
    return validated



def _is_valid_subtitle_ratio(y_ratio: Optional[float]) -> bool:
    return y_ratio is not None and 0.0 <= y_ratio < 1.0



def _resolve_project_subtitle_ratio(
    subtitle_region_cache: Dict[int, float],
    involved_episodes: Optional[List[int]] = None,
) -> Optional[float]:
    """基于多集检测结果聚合项目级稳定字幕底部比例。

    策略（V23.3）：
    1. 过滤掉 >= 0.95 的噪声值（"该帧无字幕"或屏幕底边噪声）
    2. 若剩余 >= 2 个有效值，取 max（保守，避免花字叠字幕）
    3. 若全部 >= 0.95，说明字幕本身就在极底部，取 median 回退

    设计原则（非对称代价）：
    - ratio 偏低 → 花字叠在字幕上（灾难性，用户不可接受）
    - ratio 偏高 → 花字被推到屏幕底部（可接受的降级）
    """
    import statistics

    NOISE_THRESHOLD = 0.92

    episode_scope = set(involved_episodes or [])
    raw_items = []
    for ep, ratio in subtitle_region_cache.items():
        if episode_scope and ep not in episode_scope:
            continue
        if _is_valid_subtitle_ratio(ratio):
            raw_items.append((ep, float(ratio)))

    if not raw_items:
        return None

    raw_items.sort(key=lambda x: x[1])
    all_ratios = [r for _, r in raw_items]

    # Step 1: filter out noise (>= 0.92 = likely not real subtitle bottom)
    valid_items = [(ep, r) for ep, r in raw_items if r < NOISE_THRESHOLD]

    if len(valid_items) >= 2:
        # Step 2: enough real detections, take median (balanced)
        valid_ratios = sorted([r for _, r in valid_items])
        project_ratio = statistics.median(valid_ratios)
        logger.info(
            f"[字幕定位] 项目级轨道(过滤噪声>=0.92后取median): "
            f"all={[round(r, 3) for r in all_ratios]}, "
            f"valid={[round(r, 3) for r in valid_ratios]}, "
            f"project_ratio={project_ratio:.3f}"
        )
    else:
        # Step 3: not enough valid detections — use 0.93 to force
        # overlay layout into "above subtitle" mode (safest when unknown)
        project_ratio = 0.93
        logger.info(
            f"[字幕定位] 项目级轨道(有效值不足,回退0.93强制above模式): "
            f"all={[round(r, 3) for r in all_ratios]}, "
            f"valid_count={len(valid_items)}"
        )

    return project_ratio



def _get_effective_subtitle_ratio(
    episode: Optional[int],
    subtitle_region_cache: Dict[int, float],
    project_subtitle_ratio: Optional[float],
    context_label: str,
) -> Optional[float]:
    """优先使用项目级轨道，单集结果仅在项目级缺失时回退。

    项目级轨道已经过噪声过滤（V23.3），直接使用即可。
    单集 ratio 可能是噪声（>= 0.95），不应用来覆盖项目级结果。
    """
    NOISE_THRESHOLD = 0.92

    episode_ratio = None
    if episode is not None:
        raw_ratio = subtitle_region_cache.get(episode)
        if _is_valid_subtitle_ratio(raw_ratio):
            episode_ratio = float(raw_ratio)

    proj_valid = _is_valid_subtitle_ratio(project_subtitle_ratio)
    ep_valid = episode_ratio is not None

    if proj_valid:
        if ep_valid:
            logger.info(
                f"[字幕定位] {context_label}: 使用项目级轨道 {project_subtitle_ratio:.3f} "
                f"(单集EP{episode}={episode_ratio:.3f})"
            )
        else:
            logger.info(f"[字幕定位] {context_label}: 使用项目级轨道 {project_subtitle_ratio:.3f}")
        return float(project_subtitle_ratio)

    if ep_valid:
        if episode_ratio >= NOISE_THRESHOLD:
            logger.warning(
                f"[字幕定位] {context_label}: 项目级缺失，单集EP{episode}={episode_ratio:.3f} "
                f"疑似噪声(>={NOISE_THRESHOLD})，回退0.93强制above模式"
            )
            return 0.93
        else:
            logger.info(f"[字幕定位] {context_label}: 项目级轨道缺失，回退单集 EP{episode}={episode_ratio:.3f}")
        return episode_ratio

    return None


def format_time(seconds: int) -> str:
    """格式化时间为中文显示

    Args:
        seconds: 秒数

    Returns:
        格式化后的时间字符串（如："3分24秒" 或 "45秒"）
    """
    if seconds < 60:
        return f"{seconds}秒"
    else:
        minutes = seconds // 60
        secs = seconds % 60
        return f"{minutes}分{secs}秒"


def _write_progress(
    project_name: str,
    stage: str,
    completed: int,
    total: int,
    current_item: str = '',
    message: str = '',
    status: str = 'running',
    eta_min_seconds: Optional[int] = None,
    eta_max_seconds: Optional[int] = None,
    started_at: Optional[float] = None,
    last_progress_at: Optional[float] = None,
    run_id: Optional[str] = None,
    mark_progress: bool = True,
):
    """写入统一进度协议供 OpenClaw runtime 读取。"""
    try:
        from openclaw.runtime import write_progress

        write_progress(
            project_name,
            stage,
            status=status,
            completed=completed,
            total=total,
            current_item=current_item,
            message=message,
            eta_min_seconds=eta_min_seconds,
            eta_max_seconds=eta_max_seconds,
            started_at=started_at,
            last_progress_at=last_progress_at,
            run_id=run_id,
            mark_progress=mark_progress,
            details={'run_id': run_id} if run_id else None,
        )
    except Exception as e:
        logger.warning(f"⚠️  进度文件写入失败: {e}", exc_info=True)


def _clear_progress(project_name: str, stage: str):
    """清理进度文件。"""
    try:
        from openclaw.runtime import clear_progress

        clear_progress(project_name, stage)
    except Exception:
        pass


def _estimate_eta(started_at: float, completed: int, total: int):
    """Compute ETA range from progress ratio. Returns (min_s, max_s) or (None, None)."""
    try:
        from openclaw.runtime import estimate_eta
        return estimate_eta(started_at, completed, total)
    except Exception:
        return None, None


def _get_optimal_workers(hwaccel: bool = False) -> int:
    """V16.3: 根据硬件配置自动计算最优worker数

    Args:
        hwaccel: 是否启用GPU加速

    Returns:
        最优的worker数量
    """
    cpu_count = multiprocessing.cpu_count()

    if hwaccel:
        # GPU加速模式：GPU是瓶颈，2个worker足够
        # 过多worker会导致GPU竞争
        return 2
    else:
        # CPU模式：根据CPU核心数动态调整
        # 留一半核心给系统，避免卡顿
        return max(2, cpu_count // 2)


def _cleanup_stale_temp_files(output_dir: Path):
    """清理上次渲染残留的临时文件（进程被 kill 时未清理的）

    扫描输出目录中 temp_overlay_*.mp4、temp_concat_*.mp4 等临时文件并删除。
    只清理超过 5 分钟的文件，避免误删正在使用的临时文件。
    """
    if not output_dir.exists():
        return

    import glob
    patterns = ["temp_overlay_*.mp4", "temp_concat_*.mp4", "temp_seg_*.mp4",
                "temp_ending_*.mp4", "temp_*.mp4"]
    stale_count = 0
    now = time.time()

    for pattern in patterns:
        for f in output_dir.glob(pattern):
            try:
                # 只清理超过 5 分钟的临时文件
                if now - f.stat().st_mtime > 300:
                    f.unlink()
                    stale_count += 1
            except Exception:
                pass

    if stale_count > 0:
        logger.info(f"🧹 已清理 {stale_count} 个上次残留的临时文件")


def _get_output_resolution(input_width: int, input_height: int) -> tuple:
    """V18.8: 计算最佳输出分辨率

    核心要求：最低要求 720x1280（即短边不低于 720）

    优化策略:
    - 较小边 < 720 → 强制 Upscale 到 720p（满足客户硬性标准）
    - 较小边 == 720 → 保持 720p
    - 较小边 > 720 → 降低到 720p（兼顾画质与渲染速度）

    Args:
        input_width: 输入视频宽度
        input_height: 输入视频高度

    Returns:
        (output_width, output_height) 输出分辨率（确保为偶数）
    """
    smaller = min(input_width, input_height)

    # 计算缩放比例，目标是让较小边达到 720
    scale_factor = 720.0 / smaller

    # 计算输出尺寸
    output_width = int(round(input_width * scale_factor))
    output_height = int(round(input_height * scale_factor))

    # FFmpeg 要求分辨率必须是偶数
    if output_width % 2 != 0:
        output_width -= 1
    if output_height % 2 != 0:
        output_height -= 1

    return (output_width, output_height)


@dataclass
class Clip:
    """剪辑组合"""
    start: float           # 起始累积秒（相对于第1集开头）V13: 支持毫秒精度
    end: float           # 结束累积秒（相对于第1集开头）V13: 支持毫秒精度
    duration: float      # 时长（秒）V13: 支持毫秒精度
    highlight: str      # 高光类型
    highlightDesc: str  # 高光描述
    hook: str          # 钩子类型
    hookDesc: str      # 钩子描述
    type: str          # 组合类型
    episode: int        # 起始集数
    hookEpisode: int   # 结束集数

    @property
    def clip_type(self) -> str:
        return self.type

    @property
    def is_cross_episode(self) -> bool:
        """是否跨集剪辑"""
        return self.episode != self.hookEpisode


@dataclass
class VideoFile:
    """视频文件信息"""
    episode: int
    path: str
    duration: int  # 时长（秒）
    fps: float = 30.0  # V14.2: 帧率（默认30.0，实际会自动检测）
    width: int = 0     # V18.8: 宽度
    height: int = 0    # V18.8: 高度


@dataclass
class ClipSegment:
    """剪辑片段"""
    episode: int
    start: float      # 开始秒（在该集内）V13: 支持毫秒精度
    end: float        # 结束秒（在该集内）V13: 支持毫秒精度
    video_path: str


def cleanup_project_cache(project_name: str, min_age_hours: float = 3.0) -> dict:
    """清理项目的中间缓存文件（仅清理超过指定小时数的缓存）

    项目渲染完成后，清理关键帧、音频、ASR等中间产物。
    为了方便后续测试，只清理超过 min_age_hours 小时的缓存文件。

    Args:
        project_name: 项目名称
        min_age_hours: 最小缓存保留时长（小时），默认3.0小时

    Returns:
        清理结果统计，包含跳过的文件数量
    """
    import time

    cache_dir = TrainingConfig.CACHE_DIR
    cutoff_time = time.time() - (min_age_hours * 3600)  # 计算截止时间戳

    result = {
        "keyframes_cleaned": 0,
        "audio_cleaned": 0,
        "asr_cleaned": 0,
        "skipped": 0,  # 新增：跳过的文件数
        "total_size_freed_mb": 0,
    }

    def clean_directory_with_age_check(dir_path: Path, cache_type: str) -> tuple:
        """清理目录中的文件，只删除超过指定时间的文件

        Args:
            dir_path: 目录路径
            cache_type: 缓存类型（用于日志）

        Returns:
            (清理的文件数, 跳过的文件数, 释放的空间MB)
        """
        if not dir_path.exists():
            return 0, 0, 0.0

        cleaned = 0
        skipped = 0
        size_freed = 0.0

        # 收集所有文件
        all_files = list(dir_path.rglob("*"))
        if not all_files:
            # 空目录，直接删除
            shutil.rmtree(dir_path)
            return 0, 0, 0.0

        for file_path in all_files:
            if not file_path.is_file():
                continue

            # 检查文件修改时间
            file_mtime = file_path.stat().st_mtime
            if file_mtime >= cutoff_time:
                # 文件还在保留期内，跳过
                skipped += 1
                continue

            # 文件超过保留期，删除
            size_freed += file_path.stat().st_size / (1024 * 1024)
            file_path.unlink()
            cleaned += 1

        # 如果所有文件都被删除或跳过，清理空目录
        if cleaned > 0:
            # 尝试删除空目录
            try:
                # 检查是否还有文件
                remaining = list(dir_path.rglob("*"))
                if not any(f.is_file() for f in remaining):
                    shutil.rmtree(dir_path)
            except Exception:
                pass

        return cleaned, skipped, size_freed

    # 清理关键帧缓存
    keyframes_dir = cache_dir / "keyframes" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(keyframes_dir, "关键帧")
    result["keyframes_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    # 清理音频缓存
    audio_dir = cache_dir / "audio" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(audio_dir, "音频")
    result["audio_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    # 清理ASR缓存
    asr_dir = cache_dir / "asr" / project_name
    cleaned, skipped, size = clean_directory_with_age_check(asr_dir, "ASR")
    result["asr_cleaned"] = 1 if cleaned > 0 else 0
    result["skipped"] += skipped
    result["total_size_freed_mb"] += size

    return result


class ClipRenderer:
    """剪辑渲染器"""

    def __init__(
        self,
        project_path: str,
        output_dir: str,
        video_dir: Optional[str] = None,
        width: int = 1920,
        height: int = 1080,
        fps: int = 30,
        crf: int = 23,  # V19.2: 从18改回23，已有-b:v 2500k码率保底，CRF实际被架空
        preset: str = "veryfast",  # V19.2: 从faster改为veryfast，编码速度再提升~30%
        project_name: Optional[str] = None,
        add_ending_clip: bool = True,
        auto_detect_ending: bool = True,
        skip_ending: bool = False,
        force_detect: bool = False,
        add_overlay: bool = True,
        overlay_style_id: Optional[str] = None,
        hwaccel: bool = False,
        fast_preset: bool = False,
        force_recache: bool = False,
        compress: bool = True,
        compress_target_mb: int = 100
    ):
        """初始化剪辑渲染器

        Args:
            project_path: 项目路径（包含result.json）
            output_dir: 输出目录
            video_dir: 视频文件目录（默认为project_path）
            width: 输出视频宽度
            height: 输出视频高度
            fps: 输出帧率
            crf: CRF质量（18-28，越小质量越高）
            preset: 编码预设（ultrafast, superfast, veryfast, faster, fast, medium, slow, slower, veryslow）
            project_name: 项目名称（用于文件命名）
            add_ending_clip: 是否添加结尾视频（V14新增）
            auto_detect_ending: 自动检测片尾（V14.1新增）
            skip_ending: 跳过片尾检测（V14.1新增）
            force_detect: 强制重新检测片尾（V14.1新增）
            add_overlay: 是否添加花字叠加（V15新增，V17默认启用）
            overlay_style_id: 花字样式ID（None表示随机，V15新增）
            hwaccel: 启用GPU硬件加速（V16.2新增）
            fast_preset: 使用ultrafast预设（V16.2新增）
            force_recache: 强制重新缓存结尾视频（V16.3新增）
            compress: 是否启用视频压缩（V17新增）
            compress_target_mb: 压缩目标大小（MB，默认100MB，V17新增）
        """
        self.project_path = Path(project_path)
        self.output_dir = Path(output_dir)
        self.video_dir = Path(video_dir) if video_dir else self.project_path

        # 提取项目名称（如果未提供）
        if project_name is None:
            project_name = self.project_path.name

        self.project_name = project_name

        # FFmpeg参数
        self.width = width
        self.height = height
        self.fps = fps
        self.crf = crf

        # V16.2: 性能优化参数
        self.hwaccel = hwaccel
        if fast_preset:
            self.preset = "ultrafast"
        else:
            self.preset = preset

        # V14.1: 片尾检测配置
        self.auto_detect_ending = auto_detect_ending
        self.skip_ending = skip_ending
        self.force_detect = force_detect
        self.ending_credits_cache = {}

        # V14: 结尾视频配置
        self.add_ending_clip = add_ending_clip
        self.ending_videos = self._load_ending_videos() if add_ending_clip else []

        # V16.3: 结尾视频预缓存配置
        self.force_recache = force_recache
        self.cached_endings = {}  # {原始路径: 缓存路径} 映射

        # V17: 视频压缩配置
        self.compress = compress
        self.compress_target_mb = compress_target_mb

        # V15: 花字叠加配置
        self.add_overlay = add_overlay
        self.overlay_style_id = overlay_style_id
        self.overlay_renderer = None
        if add_overlay:
            # 延迟导入花字叠加模块（避免循环依赖）
            try:
                from .video_overlay.video_overlay import VideoOverlayRenderer, OverlayConfig

                # V15.6: 随机选择热门短剧位置（左上角/右上角各50%概率）
                hot_drama_position = random.choice(["top-left", "top-right"])

                self.overlay_config = OverlayConfig(
                    enabled=True,
                    style_id=overlay_style_id,
                    project_name=project_name,
                    drama_title=project_name,
                    hot_drama_position=hot_drama_position  # V15.6: 添加位置参数
                )
                # 不在这里创建渲染器，而是在需要时创建（确保项目级样式统一）
                self._overlay_renderer_class = VideoOverlayRenderer
                logger.info(f"✅ 花字叠加已启用 (热门短剧位置: {hot_drama_position})")
            except ImportError as e:
                logger.warning(f"⚠️  无法导入花字叠加模块: {e}")
                self.add_overlay = False

        # 加载结果
        self.result = self._load_result()

        # V14.1: 自动处理片尾检测（在计算时长前）
        self._handle_ending_detection()

        # 计算各集时长（现在使用有效时长）
        self.episode_durations = self._calculate_episode_durations()
        # V17.2: 同时获取原始总时长（用于跨集clip计算）
        self.raw_episode_durations = self._get_raw_episode_durations()
        self.video_files = self._discover_video_files()

    def _get_raw_episode_durations(self) -> Dict[int, float]:
        """获取各集时长（与result.json中的episodeDurations一致）

        V17.4关键修复！
        result.json中的clip.start/end是基于episodeDurations（整数）计算的累积时间
        所以渲染时必须使用相同的整数时长来计算，否则累积时间不匹配

        Returns:
            集数到时长的映射（与result.json中的episodeDurations一致）
        """
        durations = {}

        # V17.4: 直接使用result.json中的episodeDurations
        # 这是关键！clip.start/end就是基于这些整数计算出来的
        episode_durations = self.result.get('episodeDurations', {})
        for ep, duration in episode_durations.items():
            durations[int(ep)] = float(duration)
            logger.info(f"第{ep}集: 原始时长 {duration}秒 (与result.json一致)")

        return durations

    def _load_result(self) -> dict:
        """加载result.json

        V18.4: 自动修复旧 result.json（clips 数量 > 20）
        """
        result_path = self.project_path / "result.json"
        if not result_path.exists():
            raise FileNotFoundError(f"找不到结果文件: {result_path}")

        with open(result_path, 'r', encoding='utf-8') as f:
            result = json.load(f)

        # === V18.4: 自动修复旧 result.json（clips 数量 > 20） ===
        clips_count = len(result.get('clips', []))
        if clips_count > 20:
            logger.warning(f"⚠️ 检测到 result.json 包含 {clips_count} 个剪辑（超过20个）")
            logger.info("自动应用 sort_and_filter_clips 重新筛选...")

            try:
                from scripts.understand.analyze_segment import SegmentAnalysis
                from scripts.understand.generate_clips import sort_and_filter_clips

                # 重建 SegmentAnalysis 对象
                highlights = []
                for h in result.get('highlights', []):
                    sa = SegmentAnalysis(
                        episode=h['episode'],
                        start_time=0,
                        end_time=0,
                        is_highlight=True,
                        highlight_timestamp=h['timestamp'],
                        highlight_type=h.get('type'),
                        highlight_desc=h.get('description', ''),
                        highlight_confidence=h.get('confidence', 7.0),
                        is_hook=False,
                        hook_timestamp=0.0,
                        hook_type=None,
                        hook_desc='',
                        hook_confidence=0.0
                    )
                    highlights.append(sa)

                hooks = []
                for h in result.get('hooks', []):
                    sa = SegmentAnalysis(
                        episode=h['episode'],
                        start_time=0,
                        end_time=0,
                        is_highlight=False,
                        highlight_timestamp=0.0,
                        highlight_type=None,
                        highlight_desc='',
                        highlight_confidence=0.0,
                        is_hook=True,
                        hook_timestamp=h['timestamp'],
                        hook_type=h.get('type'),
                        hook_desc=h.get('description', ''),
                        hook_confidence=h.get('confidence', 7.0)
                    )
                    hooks.append(sa)

                # 解析 episodeDurations
                episode_durations = {
                    int(k): v for k, v in result.get('episodeDurations', {}).items()
                }

                # 重新筛选
                repaired_clips = sort_and_filter_clips(
                    highlights=highlights,
                    hooks=hooks,
                    episode_durations=episode_durations,
                    max_output=20,
                    min_output=10,
                    top_highlights=10,
                    top_hooks=10,
                    max_same_type=3,
                    max_point_reuse=6
                )

                logger.info(f"✅ 自动修复完成: {clips_count} → {len(repaired_clips)} 个剪辑")

                # 更新结果
                result['clips'] = [c.to_dict() for c in repaired_clips]
                result['statistics']['totalClips'] = len(repaired_clips)

                # 备份旧文件
                import time
                import shutil
                bak_name = f"result.json.bak.auto_repair.{int(time.time())}"
                bak_path = result_path.parent / bak_name
                shutil.copy2(result_path, bak_path)
                logger.info(f"🔐 已备份原有结果至: {bak_name}")

                # 保存修复后的结果
                with open(result_path, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                logger.info(f"💾 已保存修复后的 result.json")

            except Exception as e:
                logger.warning(f"⚠️ 自动修复失败: {e}，将使用原始数据继续", exc_info=True)

        return result

    def _calculate_episode_durations(self) -> Dict[int, float]:
        """计算各集时长

        V14.1: 优先使用有效时长（总时长 - 片尾时长）
        如果没有片尾检测数据，则使用总时长

        V14.7修复: 保持浮点精度，避免int()转换丢失ASR内容

        Returns:
            集数到时长的映射（浮点数精度）
        """
        durations = {}

        # 从highlights和hooks中收集所有集数
        episodes = set()
        for h in self.result.get('highlights', []):
            episodes.add(h['episode'])
        for h in self.result.get('hooks', []):
            episodes.add(h['episode'])

        # 获取每个集的时长
        for ep in sorted(episodes):
            video_path = self._find_video_file(ep)
            if video_path:
                # V14.1: 优先使用有效时长
                if ep in self.ending_credits_cache:
                    ep_info = self.ending_credits_cache[ep]
                    # 使用有效时长（总时长 - 片尾时长）
                    effective_duration = ep_info.get('effective_duration')
                    if effective_duration is not None:
                        durations[ep] = effective_duration  # V14.7: 保持浮点精度
                        logger.info(f"第{ep}集: 有效时长 {effective_duration:.2f}秒 (已去除片尾)")
                        continue

                # 回退到使用总时长
                duration = self._get_video_duration(video_path)
                durations[ep] = duration  # V14.7: 保持浮点精度

        return durations

    def _discover_video_files(self) -> Dict[int, VideoFile]:
        """发现所有视频文件

        V14.2: 自动检测每个视频的帧率，确保剪辑精度
        V18.8: 自动检测分辨率
        """
        video_files = {}

        for ep in self.episode_durations.keys():
            video_path = self._find_video_file(ep)
            if video_path:
                # V14.2: 自动检测视频帧率
                video_fps = self._get_video_fps(str(video_path))
                
                # V18.8: 获取分辨率
                video_width, video_height = self._get_video_resolution(str(video_path))

                logger.info(f"第{ep}集: 检测到帧率 {video_fps:.2f} FPS, 分辨率 {video_width}x{video_height}")

                video_files[ep] = VideoFile(
                    episode=ep,
                    path=str(video_path),
                    duration=self.episode_durations[ep],
                    fps=video_fps,  # V14.2: 存储实际帧率
                    width=video_width, # V18.8
                    height=video_height # V18.8
                )

        return video_files

    def _handle_ending_detection(self) -> None:
        """V14.1: 自动处理片尾检测

        完全自动流程：
        1. 检查是否需要检测
        2. 尝试加载缓存
        3. 如果需要，自动检测并保存
        """
        # 决定是否需要检测片尾
        should_detect = self._should_detect_ending()

        if not should_detect:
            if self.skip_ending:
                logger.warning("⚠️  已跳过片尾检测，将使用总时长")
            return

        # 尝试加载缓存
        cache_loaded = False
        if not self.force_detect:
            cache_loaded = self._load_ending_credits()

        # 如果缓存未加载，自动检测
        if not cache_loaded:
            logger.info("🔍 开始自动检测片尾...")
            self._auto_detect_ending_credits()

    def _should_detect_ending(self) -> bool:
        """决定是否需要检测片尾

        V14.7修复: 当auto_detect_ending=True时，应该加载缓存并应用
        """
        # 1. 用户明确指定跳过
        if self.skip_ending:
            return False

        # 2. 用户明确指定强制检测
        if self.force_detect:
            return True

        # 3. 根据auto_detect_ending决定（无论缓存是否存在）
        # V14.7修复: 如果auto_detect_ending=True，应该加载缓存并应用
        return self.auto_detect_ending

    def _get_ending_cache_file(self) -> Path:
        """获取片尾缓存文件路径"""
        # 缓存文件保存在 data/ending_credits/ 目录下
        cache_dir = self.project_path.parent.parent / "ending_credits"
        return cache_dir / f"{self.project_name}_ending_credits.json"

    def _load_ending_credits(self) -> bool:
        """加载片尾检测结果缓存

        Returns:
            True if cache loaded successfully, False otherwise
        """
        cache_file = self._get_ending_cache_file()

        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # 验证缓存是否匹配当前项目
                if self._validate_cache(data):
                    # 转换为字典格式：episode -> effective_duration
                    self.ending_credits_cache = {}
                    for ep_info in data.get('episodes', []):
                        ep = ep_info['episode']
                        self.ending_credits_cache[ep] = ep_info

                    logger.info(f"✅ 已加载片尾缓存: {len(self.ending_credits_cache)} 集")
                    return True
                else:
                    logger.warning("⚠️  缓存文件与当前项目不匹配，将重新检测")
            except Exception as e:
                logger.warning(f"⚠️  缓存文件损坏: {e}")

        return False

    def _validate_cache(self, cache_data: dict) -> bool:
        """验证缓存数据是否有效

        Args:
            cache_data: 缓存数据

        Returns:
            True if cache is valid, False otherwise
        """
        # 检查项目名称是否匹配
        if cache_data.get('project') != self.project_name:
            return False

        # 检查是否有集数据
        episodes = cache_data.get('episodes', [])
        if not episodes:
            return False

        return True

    def _auto_detect_ending_credits(self) -> None:
        """
        自动检测项目中所有视频的片尾

        V15.9 优化：
        - 复用 ASR 缓存，避免重复转录
        - 片尾检测阶段使用 video_understand 阶段已缓存的 ASR
        - 预期效果：片尾检测从 3分钟 → 瞬间完成

        V1.4.0 PERF-2: 并行化片尾检测（ThreadPoolExecutor）
        - 4个worker并行检测，速度提升约3x
        """
        logger.info(f"📺 检测项目: {self.project_name}")
        logger.info(f"📁 视频目录: {self.video_dir}")

        try:
            # 导入片尾检测模块
            from scripts.detect_ending_credits import EndingCreditsDetector

            # V15.9: 导入 ASR 缓存加载函数
            from scripts.extract_asr import load_asr_from_file, get_asr_output_path
            from concurrent.futures import ThreadPoolExecutor, as_completed

            detector = EndingCreditsDetector()

            # 获取所有视频文件
            video_files = sorted(self.video_dir.glob("*.mp4"))
            total_videos = len(video_files)

            if total_videos == 0:
                logger.warning("⚠️  未找到视频文件")
                return

            logger.info(f"📊 需要检测 {total_videos} 个视频...")

            # V15.9: 检查 ASR 缓存可用性
            asr_cache_available = {}
            for video_path in video_files:
                episode = self._extract_episode_number(video_path.name)
                if episode is None:
                    continue
                asr_path = get_asr_output_path(self.video_dir.name, episode)
                if os.path.exists(asr_path):
                    asr_cache_available[episode] = asr_path

            if asr_cache_available:
                logger.info(f"📦 已缓存 ASR: {len(asr_cache_available)}/{total_videos} 集（将复用缓存）")
                logger.info(f"⏱️  预计耗时: {total_videos * 1}-{total_videos * 3} 秒（使用 ASR 缓存加速 + 并行检测）")
            else:
                logger.info(f"⏱️  预计耗时: {total_videos * 3}-{total_videos * 10} 秒（无 ASR 缓存 + 并行检测）")

            results = {'project': self.project_name, 'episodes': []}

            # V1.4.0 PERF-2: 并行检测（4个worker）
            def detect_single_video(index, video_path):
                """检测单个视频的片尾"""
                episode = self._extract_episode_number(video_path.name)
                if episode is None:
                    return None

                try:
                    # 复用 ASR 缓存
                    asr_segments = None
                    if episode in asr_cache_available:
                        asr_path = asr_cache_available[episode]
                        asr_segments = load_asr_from_file(asr_path, episode=episode)
                        if asr_segments:
                            logger.info(f"[{index}/{total_videos}] 📦 使用缓存的 ASR 数据 ({len(asr_segments)} 片段)")

                    # 传入 ASR 数据（如果有缓存）
                    result = detector.detect_video_ending(str(video_path), episode, asr_segments=asr_segments)

                    if result.ending_info.has_ending:
                        logger.info(f"[{index}/{total_videos}] ✅ {video_path.name}: 检测到片尾 {result.ending_info.duration:.2f}秒")
                    else:
                        logger.info(f"[{index}/{total_videos}] ✅ {video_path.name}: 未检测到片尾")

                    return result.to_dict()

                except Exception as e:
                    logger.error(f"[{index}/{total_videos}] ❌ {video_path.name} 检测失败: {e}")
                    return None

            # 使用线程池并行检测
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    executor.submit(detect_single_video, i, vp): vp
                    for i, vp in enumerate(video_files, 1)
                }

                for future in as_completed(futures):
                    result = future.result()
                    if result:
                        results['episodes'].append(result)

            # V1.4.0 PERF-2: 按集数排序（因为并行执行不保证顺序）
            results['episodes'].sort(key=lambda x: x['episode'])

            # 保存到文件
            self._save_ending_credits(results)

            # 更新缓存
            self.ending_credits_cache = {}
            for ep_info in results['episodes']:
                ep = ep_info['episode']
                self.ending_credits_cache[ep] = ep_info

            logger.info(f"✅ 片尾检测完成，结果已保存")

            # 显示统计
            with_ending = sum(1 for ep in results['episodes'] if ep['ending_info']['has_ending'])
            without_ending = len(results['episodes']) - with_ending
            logger.info(f"📊 检测统计: {len(results['episodes'])}集视频, {with_ending}集有片尾, {without_ending}集无片尾")

        except Exception as e:
            logger.error(f"❌ 片尾检测失败: {e}")
            logger.warning("⚠️  将使用总时长进行渲染")

    def _extract_episode_number(self, filename: str) -> Optional[int]:
        """从文件名提取集数

        Args:
            filename: 视频文件名

        Returns:
            集数，如果无法提取则返回None
        """
        import re

        # 尝试多种命名格式
        patterns = [
            r'第(\d+)集',
            r'EP?(\d+)',
            r'^(\d+)',
            r'[-_](\d+)\.mp4$',  # 支持: 项目名-1.mp4, 项目名_1.mp4
            r'(\d+)(?=\.mp4)',   # 匹配任何 .mp4 前的数字
        ]

        for pattern in patterns:
            match = re.search(pattern, filename, re.IGNORECASE)
            if match:
                return int(match.group(1))

        return None

    def _save_ending_credits(self, results: dict) -> None:
        """保存片尾检测结果到文件

        Args:
            results: 检测结果数据
        """
        cache_file = self._get_ending_cache_file()

        # 确保目录存在
        cache_file.parent.mkdir(parents=True, exist_ok=True)

        # 保存到文件
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

        logger.info(f"💾 缓存已保存: {cache_file}")

    def _load_ending_videos(self) -> List[str]:
        """加载标准结尾视频素材列表

        V14: 从项目根目录的 `标准结尾帧视频素材` 文件夹加载结尾视频

        Returns:
            结尾视频文件路径列表
        """
        # 从项目路径向上查找，直到找到 `标准结尾帧视频素材` 文件夹
        # 或者到达一定层级后停止

        # 首先尝试当前路径的父目录
        current_path = self.project_path

        # 向上查找最多3层
        for _ in range(3):
            parent = current_path.parent
            ending_dir = parent / "标准结尾帧视频素材"

            if ending_dir.exists():
                break

            current_path = parent
        else:
            # 如果没找到，尝试使用当前工作目录
            import os
            cwd = Path(os.getcwd())
            ending_dir = cwd / "标准结尾帧视频素材"

        if not ending_dir.exists():
            logger.warning(f"⚠️  警告: 找不到结尾视频文件夹: {ending_dir}")
            logger.info(f"请确保 `标准结尾帧视频素材` 文件夹在项目根目录下")
            return []

        # 支持的视频格式
        video_extensions = ['.mp4', '.mov', '.avi', '.mkv', '.flv', '.webm']
        ending_videos = []

        for ext in video_extensions:
            pattern = f"*{ext}"
            for video_path in ending_dir.glob(pattern):
                if video_path.is_file():
                    ending_videos.append(str(video_path))

        if not ending_videos:
            logger.warning(f"⚠️  警告: 结尾视频文件夹为空: {ending_dir}")
        else:
            logger.info(f"✅ 加载了 {len(ending_videos)} 个结尾视频")

        return ending_videos

    def _get_random_ending_video(self) -> Optional[str]:
        """随机选择一个结尾视频

        V14: 从已加载的结尾视频中随机选择一个

        Returns:
            结尾视频文件路径，如果没有可用的则返回None
        """
        if not self.ending_videos:
            return None

        return random.choice(self.ending_videos)

    def _get_target_fps(self) -> float:
        """V16.3: 获取项目视频的目标帧率

        使用第一个可用视频的帧率作为目标帧率

        Returns:
            目标帧率（FPS）
        """
        if self.video_files:
            # 使用第一个视频的帧率
            first_ep = min(self.video_files.keys())
            return self.video_files[first_ep].fps
        return float(self.fps)  # 回退到默认值

    def _get_target_resolution(self) -> tuple:
        """V16.3: 获取项目视频的目标分辨率

        使用第一个可用视频的分辨率，并根据V16.3智能分辨率策略调整

        Returns:
            (width, height) 目标分辨率
        """
        if not self.video_files:
            return (self.width, self.height)

        # 获取第一个视频的分辨率
        first_ep = min(self.video_files.keys())
        video_path = self.video_files[first_ep].path

        cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height',
            '-of', 'csv=p=0',
            video_path
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is None or result.returncode != 0:
            return (self.width, self.height)

        parts = result.stdout.strip().split(',')
        input_width = int(parts[0])
        input_height = int(parts[1])

        # 使用V16.3的智能分辨率选择
        return _get_output_resolution(input_width, input_height)

    def _precache_ending_videos(self) -> dict:
        """V16.3: 预缓存结尾视频

        在项目渲染开始时，预先处理所有结尾视频，
        转换为与项目视频相同的参数（帧率、分辨率）。
        这样在后续每个剪辑渲染时可以直接使用缓存的结尾视频，
        避免重复预处理。

        Returns:
            {原始路径: 缓存路径} 映射字典
        """
        if not self.ending_videos:
            return {}

        # 获取项目视频的统一参数
        target_fps = self._get_target_fps()
        target_width, target_height = self._get_target_resolution()

        logger.info(f"目标参数: {target_width}x{target_height}, {target_fps:.2f}fps")

        # 创建缓存目录（按目标参数组织，避免不同项目相同参数时冗余存储）
        # 格式: cache/endings/{width}x{height}_{fps}fps/
        cache_dir = Path(f"cache/endings/{target_width}x{target_height}_{int(target_fps)}fps")
        cache_dir.mkdir(parents=True, exist_ok=True)

        cached_endings = {}

        for ending_path in self.ending_videos:
            ending_path_obj = Path(ending_path)
            cache_filename = f"{ending_path_obj.stem}_{target_width}x{target_height}_{int(target_fps)}fps.mp4"
            cache_path = cache_dir / cache_filename

            # 检查缓存是否已存在且不需要强制更新
            if cache_path.exists() and not self.force_recache:
                cached_endings[ending_path] = str(cache_path)
                logger.info(f"✅ 使用缓存: {ending_path_obj.name}")
                continue

            # 预处理结尾视频
            logger.info(f"🔄 预处理: {ending_path_obj.name}")

            # 获取结尾视频时长
            cmd = [
                'ffprobe', '-v', 'error',
                '-select_streams', 'v:0',
                '-show_entries', 'stream=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                str(ending_path)
            ]
            result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=2)
            video_duration = float(result.stdout.strip()) if (result and result.returncode == 0) else 5.0

            # 转换结尾视频（匹配分辨率和帧率）
            cmd = [
                'ffmpeg', '-y',
                '-i', str(ending_path),
                '-vf', f'scale={target_width}:{target_height}:force_original_aspect_ratio=decrease,pad={target_width}:{target_height}:(ow-iw)/2:(oh-ih)/2,fps={target_fps}',
                '-r', str(target_fps),
                '-c:v', 'libx264',
                '-preset', self.preset,
                '-crf', str(self.crf),
                '-c:a', 'aac',
                '-b:a', '128k',
                '-vsync', 'cfr',  # 确保帧率一致
                '-movflags', '+faststart',
                str(cache_path)
            ]

            result = run_command(
                cmd,
                timeout=TimeoutConfig.FFMPEG_ENDING_PREPROCESS,
                error_msg=f"结尾视频预处理超时: {ending_path_obj.name}"
            )
            if result is not None and result.returncode == 0:
                cached_endings[ending_path] = str(cache_path)
                logger.info(f"✅ 缓存完成: {cache_filename}")
            else:
                err = result.stderr[:200] if result is not None else "超时"
                logger.error(f"❌ 预处理失败: {err}")
                # 预处理失败时，使用原始路径
                cached_endings[ending_path] = ending_path

        return cached_endings

    def _find_video_file(self, episode: int) -> Optional[Path]:
        """查找指定集数的视频文件

        支持多种命名格式：
        - 第1集.mp4
        - EP01.mp4
        - E01.mp4
        - 01.mp4
        """
        patterns = [
            f"第{episode}集.mp4",
            f"第{episode}集.*.mp4",
            f"EP{episode:02d}.mp4",
            f"E{episode:02d}.mp4",
            f"{episode:02d}.mp4",
            f"{episode}.mp4",
            f"*-{episode}.mp4",    # V15.1: 支持 项目名-1.mp4
            f"*_{episode}.mp4",    # V15.1: 支持 项目名_1.mp4
        ]

        for pattern in patterns:
            matches = list(self.video_dir.glob(pattern))
            if matches:
                return matches[0]

        return None

    def _get_video_duration(self, video_path: str) -> float:
        """使用ffprobe获取视频时长（秒）"""
        cmd = [
            'ffprobe',
            '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            str(video_path)
        ]

        result = run_command(
            cmd,
            timeout=TimeoutConfig.FFPROBE_QUICK,
            retries=1,
            raise_on_error=True,
            error_msg=f"无法获取视频时长: {video_path}"
        )
        return float(result.stdout.strip())

    def _clip_to_segments(self, clip: Clip) -> List[ClipSegment]:
        """将剪辑转换为视频片段列表

        处理两种情况：
        1. 同集剪辑：episode == hook_episode，返回1个片段
        2. 跨集剪辑：episode != hook_episode，返回多个片段
        V13: 支持毫秒精度（浮点数时间戳）
        """
        segments = []

        # 起始集
        if clip.episode not in self.video_files:
            raise ValueError(f"找不到第{clip.episode}集视频文件")

        # 计算起始集的开始时间
        start_cumulative = float(clip.start)

        # 从start累积时间推算在该集内的开始时间
        cumulative_before = 0.0
        for ep in sorted(self.episode_durations.keys()):
            if ep < clip.episode:
                cumulative_before += float(self.episode_durations[ep])

        start_in_episode = start_cumulative - cumulative_before

        # 如果是同集剪辑
        if clip.episode == clip.hookEpisode:
            end_in_episode = start_in_episode + float(clip.duration)
            segments.append(ClipSegment(
                episode=clip.episode,
                start=start_in_episode,  # V13: 保持浮点数精度
                end=end_in_episode,      # V13: 保持浮点数精度
                video_path=self.video_files[clip.episode].path
            ))
        else:
            # 跨集剪辑：第一集片段
            first_ep_duration = float(self.episode_durations[clip.episode])
            first_segment_end = first_ep_duration - start_in_episode
            segments.append(ClipSegment(
                episode=clip.episode,
                start=start_in_episode,  # V13: 保持浮点数精度
                end=first_ep_duration,   # V13: 保持浮点数精度
                video_path=self.video_files[clip.episode].path
            ))

            # 中间集的完整片段
            for ep in sorted(self.episode_durations.keys()):
                if clip.episode < ep < clip.hookEpisode:
                    segments.append(ClipSegment(
                        episode=ep,
                        start=0.0,  # V13: 保持浮点数精度
                        end=float(self.episode_durations[ep]),  # V13: 保持浮点数精度
                        video_path=self.video_files[ep].path
                    ))

            # 最后一集片段
            end_cumulative = float(clip.end)
            cumulative_before_last = 0.0
            for ep in sorted(self.episode_durations.keys()):
                if ep < clip.hookEpisode:
                    cumulative_before_last += float(self.episode_durations[ep])

            end_in_last_episode = end_cumulative - cumulative_before_last
            segments.append(ClipSegment(
                episode=clip.hookEpisode,
                start=0.0,  # V13: 保持浮点数精度
                end=end_in_last_episode,  # V13: 保持浮点数精度
                video_path=self.video_files[clip.hookEpisode].path  # V13.1: 修复属性名错误
            ))

        return segments

    def _trim_segment(
        self,
        segment: ClipSegment,
        output_path: str,
        on_progress: Optional[Callable[[float], None]] = None
    ) -> None:
        """裁剪单个视频片段

        V14.2 更新：使用基于帧率的精确剪辑，避免精度问题
        FFmpeg按帧率对齐，使用-frames:v参数而不是-t参数

        V14.8 更新：修复音视频同步问题 - 使用 -t 参数确保音视频时长一致

        Args:
            segment: 视频片段
            output_path: 输出文件路径
            on_progress: 进度回调函数（0.0-1.0）
        """
        import math

        # V13: 支持毫秒精度（浮点数时间戳）
        start_time = segment.start if isinstance(segment.start, float) else float(segment.start)
        end_time = segment.end if isinstance(segment.end, float) else float(segment.end)
        duration = end_time - start_time

        # V14.2: 从VideoFile获取实际帧率（而不是每次都检测）
        if segment.episode in self.video_files:
            fps = self.video_files[segment.episode].fps
        else:
            # 回退到自动检测
            fps = self._get_video_fps(segment.video_path)

        # 计算帧数（向上取整，确保完整）
        total_frames = math.ceil(duration * fps)

        # V14.10: 修复片尾拼接"有声音无画面"BUG
        # 关键修复：移除 -frames:v 参数
        # 问题根源：当使用 -c copy 时，同时使用 -t 和 -frames:v 会导致视频流被截断
        # -t 参数已经足够精确，无需额外的 -frames:v 参数
        cmd = [
            'ffmpeg',
            '-y',  # 覆盖输出文件
            '-ss', f"{start_time:.3f}",  # 起始时间（用于快速定位）
            '-i', segment.video_path,  # 输入文件
            '-t', f"{duration:.3f}",  # V14.8: 明确指定时长，确保音视频同步
            '-c', 'copy',  # 复制流，不重新编码（保持原质量和大小）
            '-movflags', '+faststart',  # 优化Web播放
            output_path
        ]

        # 执行命令（带超时，超时 returncode=-1 → 触发 RuntimeError → 外层跳过该 clip）
        returncode = run_popen_with_timeout(
            cmd,
            timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
            log_prefix="裁剪"
        )
        if returncode != 0:
            raise RuntimeError(
                f"FFmpeg裁剪失败 (返回码: {returncode})\n"
                f"命令: {' '.join(cmd)}\n"
            )

    def _get_video_fps(self, video_path: str) -> float:
        """获取视频帧率

        V14.2 新增方法：用于基于帧的精确剪辑

        Args:
            video_path: 视频文件路径

        Returns:
            视频帧率（FPS）
        """
        cmd = [
            'ffprobe',
            '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=r_frame_rate',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            video_path
        ]

        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is None or result.returncode != 0:
            # 如果无法获取帧率，使用默认值
            return float(self.fps)

        fps_str = result.stdout.strip()
        # 解析帧率（例如 "30/1" 或 "29.97"）
        if '/' in fps_str:
            num, den = fps_str.split('/')
            return float(num) / float(den)
        else:
            return float(fps_str)

    def _get_video_resolution(self, video_path: str) -> tuple:
        """获取视频分辨率 (V18.8 新增)

        Args:
            video_path: 视频文件路径

        Returns:
            (width, height)
        """
        cmd = [
            'ffprobe',
            '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height',
            '-of', 'csv=p=0',
            video_path
        ]

        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is None or result.returncode != 0:
            return 0, 0

        try:
            output = result.stdout.strip()
            if ',' in output:
                width, height = map(int, output.split(','))
                return width, height
        except Exception:
            pass
            
        return 0, 0

    def _concat_segments(
        self,
        segment_files: List[str],
        output_path: str,
        on_progress: Optional[Callable[[float], None]] = None
    ) -> None:
        """拼接多个视频片段

        使用concat demuxer方法（快速，无重编码）

        Args:
            segment_files: 视频片段文件列表
            output_path: 输出文件路径
            on_progress: 进度回调函数
        """
        # 创建临时concat列表文件
        concat_file = self.output_dir / "concat_list.txt"
        with open(concat_file, 'w') as f:
            for segment_file in segment_files:
                # V13.1: 使用相对路径，避免路径重复问题
                segment_path = Path(segment_file)
                relative_path = segment_path.relative_to(self.output_dir)
                f.write(f"file '{relative_path}'\n")

        # FFmpeg命令
        cmd = [
            'ffmpeg',
            '-y',
            '-f', 'concat',  # concat demuxer
            '-safe', '0',  # 允许任意文件路径
            '-i', str(concat_file),  # 输入列表文件
            '-c', 'copy',  # 复制流，不重编码
            output_path
        ]

        # 执行命令（带超时，超时返回-1触发RuntimeError）
        if on_progress:
            on_progress(0.5)

        returncode = run_popen_with_timeout(
            cmd,
            timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
            log_prefix="拼接"
        )

        if on_progress:
            on_progress(1.0)

        if returncode != 0:
            raise RuntimeError(f"FFmpeg拼接失败 (返回码: {returncode})")

        # 删除临时文件
        concat_file.unlink()

    def _append_ending_video(self, clip_path: str) -> str:
        """为剪辑添加结尾视频

        V14: 在剪辑末尾拼接随机选择的结尾视频
        预处理结尾视频以匹配原剪辑的分辨率和编码

        Args:
            clip_path: 原剪辑文件路径

        Returns:
            添加结尾后的文件路径（如果未添加则返回原路径）
        """
        # 随机选择结尾视频
        ending_video = self._get_random_ending_video()
        if not ending_video:
            logger.warning(f"⚠️  无可用结尾视频，跳过拼接")
            return clip_path

        # 生成新的输出文件名（添加 "_带结尾" 标记）
        clip_path_obj = Path(clip_path)
        new_filename = clip_path_obj.stem + "_带结尾" + clip_path_obj.suffix
        new_output_path = str(clip_path_obj.parent / new_filename)

        logger.info(f"🎬 添加结尾视频: {Path(ending_video).name}")
        logger.info(f"输出文件: {new_filename}")

        # 预处理结尾视频（匹配原剪辑的分辨率）
        processed_ending = self._preprocess_ending_video(clip_path, ending_video)

        # 拼接视频
        self._concat_videos([clip_path, processed_ending], new_output_path)

        # 删除临时处理的结尾视频
        Path(processed_ending).unlink()

        # 删除原剪辑文件
        Path(clip_path).unlink()

        return new_output_path

    def _preprocess_ending_video(self, clip_path: str, ending_video: str) -> str:
        """预处理结尾视频，使其与原剪辑兼容

        V14: 将结尾视频转换为与原剪辑相同的分辨率和编码
        V14.8: 修复音视频同步问题 - 使用视频流时长作为参考，确保音视频完全同步

        Args:
            clip_path: 原剪辑文件路径（用于获取分辨率）
            ending_video: 结尾视频文件路径

        Returns:
            处理后的结尾视频文件路径
        """
        # 获取原剪辑的实际分辨率（而不是使用默认的width/height）
        cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height',
            '-of', 'csv=p=0',
            clip_path
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is None or result.returncode != 0:
            # 如果获取失败，使用默认值
            clip_width, clip_height = self.width, self.height
        else:
            parts = result.stdout.strip().split(',')
            clip_width = int(parts[0])
            clip_height = int(parts[1])

        # V14.8: 获取结尾视频的视频流时长（使用视频时长作为参考）
        cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            ending_video
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is None or result.returncode != 0:
            # 如果获取失败，使用ffprobe获取格式时长
            cmd = [
                'ffprobe', '-v', 'error',
                '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                ending_video
            ]
            result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
            video_duration = float(result.stdout.strip()) if (result and result.returncode == 0) else 5.0
        else:
            video_duration = float(result.stdout.strip())

        # 生成临时文件路径
        temp_ending = self.output_dir / f"temp_ending_{Path(ending_video).stem}.mp4"

        # V14.8: 确保输出目录存在
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # V14.10: 修复帧率不一致问题 - 添加帧率转换
        # 问题：原始视频30fps，结尾视频24fps，帧率不一致导致拼接时视频流被截断
        # 解决方案：在预处理时将结尾视频转换为与原视频相同的帧率

        # 获取原剪辑的帧率
        cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=r_frame_rate',
            '-of', 'csv=p=0',
            clip_path
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        if result is not None and result.returncode == 0:
            fps_str = result.stdout.strip()
            # 解析帧率（如 "30/1" -> 30.0）
            if '/' in fps_str:
                num, den = fps_str.split('/')
                clip_fps = float(num) / float(den)
            else:
                clip_fps = float(fps_str)
            logger.info(f"📊 原剪辑帧率: {clip_fps} fps")
        else:
            clip_fps = 30.0  # 默认30fps
            logger.warning(f"⚠️  无法获取帧率，使用默认30fps")

        # V14.9: 修复的FFmpeg命令 - 彻底解决音视频不同步问题
        # 关键修复（Agent Team分析结果）：
        # 1. 移除 -t 参数（时间戳截取精度不够，会导致音视频不同步）
        # 2. 移除 -af apad（过度填充音频，导致音频比视频长）
        # 3. 添加 -vsync 2（保留时间戳，确保帧同步）
        # 4. 添加 -async 1（音频自动同步到视频）
        # 5. V14.10: 添加帧率转换，确保帧率一致
        cmd = [
            'ffmpeg',
            '-y',
            '-i', ending_video,
            '-vf', f'fps={clip_fps},scale={clip_width}:{clip_height}:force_original_aspect_ratio=decrease,pad={clip_width}:{clip_height}:(ow-iw)/2:(oh-ih)/2',  # V14.10: 添加fps转换 + 缩放并添加黑边
            '-r', str(clip_fps),  # V14.10: 明确指定输出帧率（与原视频一致）
            '-c:v', 'libx264',  # 统一使用h264编码
            '-preset', self.preset,
            '-crf', str(self.crf),
            '-c:a', 'aac',  # 统一音频编码
            '-b:a', '128k',
            '-vsync', 'cfr',  # V14.10: 使用CFR模式确保帧率一致
            '-movflags', '+faststart',
            str(temp_ending)
        ]

        # 执行命令（带超时）
        try:
            logger.info(f"🔄 预处理结尾视频（{clip_width}x{clip_height}，时长{video_duration:.3f}秒）...")
            returncode = run_popen_with_timeout(
                cmd,
                timeout=TimeoutConfig.FFMPEG_ENDING_PREPROCESS,
                log_prefix="预处理结尾"
            )

            if returncode != 0:
                raise RuntimeError(f"FFmpeg预处理失败 (返回码: {returncode})")

            logger.info(f"✅ 结尾视频预处理完成")

            # V14.8: 验证音视频同步
            cmd = [
                'ffprobe', '-v', 'error',
                '-show_entries', 'stream=codec_type,duration',
                '-of', 'csv=p=0',
                str(temp_ending)
            ]
            result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
            durations = {}
            if result and result.returncode == 0:
                for line in result.stdout.strip().split('\n'):
                    if line:
                        parts = line.split(',')
                        if len(parts) >= 2:
                            durations[parts[0]] = float(parts[1])

            if 'video' in durations and 'audio' in durations:
                diff = abs(durations['video'] - durations['audio'])
                if diff < 0.01:
                    logger.info(f"✅ 音视频同步（差异: {diff:.3f}秒）")
                else:
                    logger.warning(f"⚠️  音视频略有差异（{diff:.3f}秒），但在可接受范围内")

        except Exception as e:
            raise RuntimeError(f"结尾视频预处理失败: {e}")

        return str(temp_ending)

    def _concat_videos(
        self,
        video_files: List[str],
        output_path: str,
        on_progress: Optional[Callable[[float], None]] = None
    ) -> None:
        """拼接多个视频文件

        V14: 通用视频拼接方法，用于拼接剪辑和结尾视频
        使用 concat demuxer 快速拼接（视频已预处理为相同格式）

        Args:
            video_files: 视频文件路径列表
            output_path: 输出文件路径
            on_progress: 进度回调函数
        """
        # 创建临时concat列表文件
        concat_file = self.output_dir / "concat_list.txt"
        with open(concat_file, 'w', encoding='utf-8') as f:
            for video_file in video_files:
                # 使用绝对路径
                video_path = Path(video_file).resolve()
                f.write(f"file '{video_path}'\n")

        # V14.9: FFmpeg命令 - 使用重新编码拼接（彻底解决流不兼容问题）
        # 关键修复（Agent Team分析结果）：
        # - 原剪辑（copy模式）和结尾视频（重编码）的流不兼容
        # - -c copy 会导致视频流截断，出现"有声音无画面"
        # - 改用重新编码可以确保流完全兼容，音视频完美同步
        cmd = [
            'ffmpeg',
            '-y',
            '-f', 'concat',  # concat demuxer
            '-safe', '0',  # 允许任意文件路径
            '-i', str(concat_file),  # 输入列表文件
            '-c:v', 'libx264',  # V14.9: 重新编码视频（解决流不兼容）
            '-preset', 'ultrafast',  # V14.9: 超快预设（减少处理时间）
            '-crf', '18',  # V14.9: 高质量（几乎无损）
            '-c:a', 'aac',  # V14.9: 重新编码音频
            '-b:a', '192k',  # V14.9: 高质量音频
            '-movflags', '+faststart',  # 优化Web播放
            output_path
        ]

        # 执行命令（带超时）
        try:
            logger.info(f"🔄 拼接视频...")
            logger.info(f"📋 FFmpeg命令: {' '.join(cmd)}")  # V14.9调试：打印完整命令

            returncode = run_popen_with_timeout(
                cmd,
                timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
                log_prefix="视频拼接"
            )

            if returncode != 0:
                raise RuntimeError(f"FFmpeg拼接失败 (返回码: {returncode})")

            logger.info(f"✅ 视频拼接完成")

            if on_progress:
                on_progress(1.0)

        finally:
            # 删除临时文件
            if concat_file.exists():
                concat_file.unlink()

    def _get_subtitle_bottom_y(self, episode: int, video_path: str) -> Optional[float]:
        """检测并缓存指定集数视频的字幕底部 Y 比例（相对视频高度的 0~1 值）。

        每集只检测一次，结果缓存到
        data/cache/subtitle_region/<project_name>/<episode>.json 中。

        返回比例值（y_ratio）而非绝对像素，避免 1080p 原始视频检测值
        被错误地用于降分辨率后的 720p clip（坐标系不匹配问题）。

        调用方需根据 clip 实际高度换算：subtitle_bottom_y = int(y_ratio * clip_height)

        Args:
            episode: 集数（整数）
            video_path: 该集视频文件路径

        Returns:
            字幕底部 Y 比例（0.0~1.0），失败返回 None
        """
        # 初始化缓存字典
        if not hasattr(self, '_subtitle_bottom_cache'):
            self._subtitle_bottom_cache: dict = {}

        if episode in self._subtitle_bottom_cache:
            return self._subtitle_bottom_cache[episode]

        if not hasattr(self, '_project_subtitle_ratio_cache'):
            self._project_subtitle_ratio_cache = None

        # 磁盘缓存路径
        cache_dir = Path("data/cache/subtitle_region") / self.project_name
        cache_file = cache_dir / f"{episode}.json"

        if cache_file.exists():
            try:
                import json as _json
                data = _json.loads(cache_file.read_text(encoding="utf-8"))
                # 优先读取 y_ratio（新格式），兼容旧格式（subtitle_bottom_y + original_height）
                y_ratio = data.get("y_ratio")
                if y_ratio is None and data.get("subtitle_bottom_y") is not None and data.get("original_height"):
                    y_ratio = data["subtitle_bottom_y"] / data["original_height"]
                self._subtitle_bottom_cache[episode] = y_ratio
                logger.info(f"[字幕检测] 从缓存加载 EP{episode}: y_ratio={y_ratio:.3f}" if y_ratio else f"  [字幕检测] EP{episode} 缓存无效")
                return y_ratio
            except Exception as e:
                logger.warning(f"[字幕检测] 缓存读取失败: {e}", exc_info=True)

        # 执行检测，同时获取视频高度以计算比例
        y_ratio = None
        try:
            from scripts.preprocess.subtitle_detector import get_subtitle_bottom_y
            logger.info(f"[字幕检测] 检测 EP{episode} 字幕底部 Y...")
            pixel_value = get_subtitle_bottom_y(video_path, sample_frame_count=5)
            if pixel_value is not None:
                # 获取原始视频高度，计算比例
                probe = run_command(
                    ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                     '-show_entries', 'stream=height', '-of', 'csv=p=0', video_path],
                    timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                )
                original_height = int(probe.stdout.strip()) if probe else 0
                if original_height > 0:
                    y_ratio = pixel_value / original_height
                    logger.info(f"[字幕检测] EP{episode}: pixel={pixel_value}, height={original_height}, y_ratio={y_ratio:.3f}")
                else:
                    logger.warning(f"[字幕检测] EP{episode}: 无法获取视频高度，跳过比例计算")
        except Exception as e:
            logger.warning(f"[字幕检测] 检测失败: {e}", exc_info=True)

        # 写入磁盘缓存（存储比例值）
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
            import json as _json
            cache_file.write_text(
                _json.dumps({"y_ratio": y_ratio}, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception as e:
            logger.warning(f"[字幕检测] 缓存写入失败: {e}", exc_info=True)

        self._subtitle_bottom_cache[episode] = y_ratio
        return y_ratio

    def _get_project_subtitle_ratio(self, involved_episodes: Optional[List[int]] = None) -> Optional[float]:
        """返回项目级稳定字幕底部比例。"""
        if not hasattr(self, '_project_subtitle_ratio_cache'):
            self._project_subtitle_ratio_cache = None

        if self._project_subtitle_ratio_cache is not None:
            return self._project_subtitle_ratio_cache

        subtitle_cache = getattr(self, '_subtitle_bottom_cache', {})
        project_ratio = _resolve_project_subtitle_ratio(subtitle_cache, involved_episodes)
        self._project_subtitle_ratio_cache = project_ratio
        return project_ratio

    def _apply_video_overlay(self, clip_path: str, episode: Optional[int] = None, video_path: Optional[str] = None) -> str:
        """为视频添加花字叠加

        V15: 在视频上叠加"热门短剧"、剧名、免责声明
        项目级样式统一（同一项目使用相同样式）

        Args:
            clip_path: 原视频文件路径
            episode: 来源集数（用于字幕检测缓存）
            video_path: 来源集视频路径（用于字幕检测）

        Returns:
            添加花字后的文件路径
        """
        try:
            # 延迟创建渲染器（确保项目级样式统一）
            if not hasattr(self, '_overlay_renderer_instance'):
                self._overlay_renderer_instance = self._overlay_renderer_class(
                    self.overlay_config
                )

            # 检测字幕底部 Y（每集缓存一次，返回 0~1 比例值）
            subtitle_y_ratio = None
            project_subtitle_ratio = self._get_project_subtitle_ratio()
            if episode is not None and video_path is not None:
                subtitle_y_ratio = self._get_subtitle_bottom_y(episode, video_path)
                if project_subtitle_ratio is None:
                    project_subtitle_ratio = self._get_project_subtitle_ratio([episode])

            effective_ratio = _get_effective_subtitle_ratio(
                episode,
                getattr(self, '_subtitle_bottom_cache', {}),
                project_subtitle_ratio,
                "串行渲染",
            )

            # 将比例值换算为 clip 实际像素坐标（解决 1080p→720p 分辨率不匹配问题）
            subtitle_bottom_y = None
            if effective_ratio is not None:
                probe = run_command(
                    ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                     '-show_entries', 'stream=height', '-of', 'csv=p=0', clip_path],
                    timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                )
                clip_height = int(probe.stdout.strip()) if probe else 0
                subtitle_bottom_y = _resolve_subtitle_bottom_from_ratio(
                    effective_ratio,
                    clip_height,
                    f"串行 EP{episode}",
                )

            # 生成新的输出文件名（添加 "_带花字" 标记）
            clip_path_obj = Path(clip_path)
            new_filename = clip_path_obj.stem + "_带花字" + clip_path_obj.suffix
            new_output_path = str(clip_path_obj.parent / new_filename)

            logger.info(f"🎨 添加花字叠加...")
            logger.info(f"输出文件: {new_filename}")

            # 应用花字叠加
            result_path = self._overlay_renderer_instance.apply_overlay(
                input_video=clip_path,
                output_video=new_output_path,
                subtitle_bottom_y=subtitle_bottom_y,
            )

            # 删除原视频文件
            Path(clip_path).unlink()

            return result_path

        except Exception as e:
            logger.warning(f"⚠️  花字叠加失败: {e}")
            logger.info(f"将保留原视频: {clip_path}")
            # 如果花字叠加失败，返回原视频路径
            return clip_path

    def render_clip(
        self,
        clip: Clip,
        output_path: Optional[str] = None,
        on_progress: Optional[Callable[[float], None]] = None
    ) -> str:
        """渲染单个剪辑

        V17.1优化: 尝试使用单次编码，失败时回退到分步处理

        Args:
            clip: 剪辑对象
            output_path: 输出文件路径（可选，默认自动生成）
            on_progress: 进度回调函数

        Returns:
            输出文件路径
        """
        # V18.8: 获取视频信息以决定是否需要缩放
        need_rescale = False
        if len(self.video_files) > 0:
            first_ep = min(self.video_files.keys())
            input_w = self.video_files[first_ep].width
            input_h = self.video_files[first_ep].height
            if input_w > 0 and input_h > 0:
                out_w, out_h = _get_output_resolution(input_w, input_h)
                if out_w != input_w or out_h != input_h:
                    need_rescale = True

        # V17.1优化: 尝试使用单次编码
        # V18.8: 如果需要缩放分辨率，也必须走单次编码（重新编码路径）
        if (self.add_overlay or self.add_ending_clip or need_rescale) and len(self.video_files) > 0:
            # 构建clip_data
            clip_data = {
                'start': clip.start,
                'end': clip.end,
                'duration': clip.duration,
                'highlight': clip.highlight,
                'highlightDesc': clip.highlightDesc,
                'hook': clip.hook,
                'hookDesc': clip.hookDesc,
                'type': clip.type,
                'episode': clip.episode,
                'hookEpisode': clip.hookEpisode,
            }

            # 预加载字幕区域缓存（串行路径也需要）
            # 缓存存储 y_ratio（0~1 比例值），standalone 根据 clip 实际高度换算
            _subtitle_region_cache = {}
            _subtitle_cache_dir = Path("data/cache/subtitle_region") / self.project_name
            if _subtitle_cache_dir.exists():
                import json as _json
                for _cf in _subtitle_cache_dir.glob("*.json"):
                    try:
                        _ep = int(_cf.stem)
                        _data = _json.loads(_cf.read_text(encoding="utf-8"))
                        # 优先读取 y_ratio，兼容旧格式
                        _val = _data.get("y_ratio")
                        if _val is None and _data.get("subtitle_bottom_y") is not None and _data.get("original_height"):
                            _val = _data["subtitle_bottom_y"] / _data["original_height"]
                        if _val is not None:
                            _subtitle_region_cache[_ep] = _val
                    except Exception:
                        pass

            # 串行单次编码路径也需要预热项目级字幕轨道，避免指定 clip-indices 时退回单集实时检测
            involved_episodes = {clip.episode, clip.hookEpisode}
            missing_episodes = [ep for ep in sorted(involved_episodes) if ep not in _subtitle_region_cache]
            if missing_episodes:
                from scripts.preprocess.subtitle_detector import get_subtitle_bottom_y
                from scripts.utils.filename_parser import parse_episode_number

                video_files = sorted(self.video_dir.glob("*.mp4"))
                ep_to_video = {}
                for vf in video_files:
                    ep_num = parse_episode_number(vf.name)
                    if ep_num is not None:
                        ep_to_video[ep_num] = str(vf)

                for ep in missing_episodes:
                    video_path = ep_to_video.get(ep)
                    if not video_path:
                        continue
                    try:
                        pixel_value = get_subtitle_bottom_y(video_path, sample_frame_count=5)
                        if pixel_value is None:
                            continue
                        probe = run_command(
                            ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries', 'stream=height', '-of', 'csv=p=0', video_path],
                            timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                        )
                        video_height = int(probe.stdout.strip()) if probe else 0
                        if video_height <= 0:
                            continue
                        y_ratio = pixel_value / video_height
                        _subtitle_region_cache[ep] = y_ratio
                        _subtitle_cache_dir.mkdir(parents=True, exist_ok=True)
                        (_subtitle_cache_dir / f"{ep}.json").write_text(
                            json.dumps({
                                "y_ratio": y_ratio,
                                "subtitle_bottom_y": pixel_value,
                                "original_height": video_height,
                            }, ensure_ascii=False),
                            encoding="utf-8",
                        )
                    except Exception as e:
                        logger.warning(f"[字幕定位] 串行预热 EP{ep} 失败: {e}")

            project_subtitle_ratio = _resolve_project_subtitle_ratio(
                _subtitle_region_cache,
                sorted(_subtitle_region_cache.keys()) if _subtitle_region_cache else None,
            )

            # V21: 内置免责声明检测（串行路径）
            _builtin_disclaimer_info = None
            if self.add_overlay:
                try:
                    from scripts.preprocess.subtitle_detector import detect_builtin_disclaimer
                    from scripts.utils.filename_parser import parse_episode_number as _pep
                    _ep1_video = None
                    for _vf in sorted(self.video_dir.glob("*.mp4")):
                        if _pep(_vf.name) == 1:
                            _ep1_video = str(_vf)
                            break
                    if _ep1_video is None:
                        _vfs = sorted(self.video_dir.glob("*.mp4"))
                        if _vfs:
                            _ep1_video = str(_vfs[0])
                    if _ep1_video:
                        _builtin_disclaimer_info = detect_builtin_disclaimer(_ep1_video)
                except Exception as _e:
                    logger.warning(f"⚠️ 内置免责声明检测失败: {_e}")

            # 构建render_params
            render_params = {
                'video_dir': str(self.video_dir),
                'output_dir': str(self.output_dir),
                'episode_durations': self.episode_durations,
                'raw_episode_durations': self.raw_episode_durations,  # V17.2: 原始总时长
                'width': self.width,
                'height': self.height,
                'fps': self.fps,
                'crf': self.crf,
                'preset': self.preset,
                'project_name': self.project_name,
                'add_ending_clip': self.add_ending_clip,
                'ending_videos': self.ending_videos,
                'add_overlay': self.add_overlay,
                'overlay_style_id': self.overlay_style_id,
                'hot_drama_position': 'top-right',
                'hwaccel': self.hwaccel,
                'subtitle_region_cache': _subtitle_region_cache,  # 字幕区域缓存
                'project_subtitle_ratio': project_subtitle_ratio,  # 项目级稳定字幕轨道
                'builtin_disclaimer_info': _builtin_disclaimer_info,  # V21: 内置免责声明
            }

            # 尝试单次编码（传入-1表示串行模式）
            result = _render_clip_single_pass(-1, clip_data, render_params)
            if result:
                logger.info(f"[单次编码] 串行模式单次编码成功: {result}")
                return result

        # 生成输出文件名（中文格式）
        if output_path is None:
            # 计算起始和结束时间（使用原始总时长，与result.json一致）
            start_cumulative = clip.start
            end_cumulative = clip.end

            # V17.2: 使用原始总时长计算
            # 计算起始集内的秒数
            cumulative_before_start = 0
            for ep in sorted(self.raw_episode_durations.keys()):
                if ep < clip.episode:
                    cumulative_before_start += self.raw_episode_durations[ep]

            start_in_episode = start_cumulative - cumulative_before_start

            # 计算结束集内的秒数
            cumulative_before_end = 0
            for ep in sorted(self.raw_episode_durations.keys()):
                if ep < clip.hookEpisode:
                    cumulative_before_end += self.raw_episode_durations[ep]

            end_in_episode = end_cumulative - cumulative_before_end

            # 生成中文文件名
            date_str = datetime.now().strftime("%m%d")
            filename = f"LM-777457-{date_str}-[{self.project_name}]-第{clip.episode}集{format_time(int(start_in_episode))}_第{clip.hookEpisode}集{format_time(int(end_in_episode))}.mp4"
            output_path = str(self.output_dir / filename)

        logger.info(f"渲染剪辑: {filename}")
        logger.info(f"起始: 第{clip.episode}集{format_time(int(start_in_episode))}")
        logger.info(f"结束: 第{clip.hookEpisode}集{format_time(int(end_in_episode))}")
        logger.info(f"时长: {clip.duration:.3f}秒")  # V13: 显示毫秒精度
        logger.info(f"跨集: {'是' if clip.is_cross_episode else '否'}")

        # 转换为视频片段
        segments = self._clip_to_segments(clip)

        logger.info(f"片段数: {len(segments)}")
        for i, seg in enumerate(segments, 1):
            logger.info(f"{i}. 第{seg.episode}集 {seg.start:.3f}-{seg.end:.3f}秒")  # V13: 显示毫秒精度

        # 如果只有1个片段且不是跨集，直接裁剪
        if len(segments) == 1:
            self._trim_segment(segments[0], output_path, on_progress)
        else:
            # 多个片段：先分别裁剪，再拼接
            temp_files = []
            temp_dir = self.output_dir / "temp"
            temp_dir.mkdir(exist_ok=True)

            # 裁剪每个片段
            for i, segment in enumerate(segments):
                temp_file = temp_dir / f"segment_{i}.mp4"
                self._trim_segment(segment, str(temp_file))
                temp_files.append(str(temp_file))

            # 拼接片段
            self._concat_segments(temp_files, output_path, on_progress)

            # 删除临时文件和目录（使用shutil.rmtree处理非空目录）
            import shutil
            for temp_file in temp_files:
                try:
                    Path(temp_file).unlink()
                except:
                    pass
            try:
                shutil.rmtree(temp_dir)
            except:
                pass

        # V15.6: 添加花字叠加（如果配置了）- 先叠加花字
        if self.add_overlay and hasattr(self, '_overlay_renderer_class'):
            # 传入高光点所在集数和视频路径，用于检测字幕底部 Y
            src_episode = clip.episode
            src_video_path = self.video_files[src_episode].path if src_episode in self.video_files else None
            output_path = self._apply_video_overlay(output_path, episode=src_episode, video_path=src_video_path)

        # V14: 添加结尾视频（如果配置了）- 再拼接片尾
        if self.add_ending_clip:
            output_path = self._append_ending_video(output_path)

        # V17: 视频压缩（如果配置了）
        if self.compress:
            output_path = self._compress_video(output_path)

        logger.info(f"✅ 输出: {output_path}")
        return output_path

    def _compress_video(self, video_path: str) -> str:
        """V17: 压缩视频到目标大小

        根据目标大小计算比特率，使用CRF编码压缩视频

        Args:
            video_path: 输入视频路径

        Returns:
            压缩后的视频路径（覆盖原文件）
        """
        import math

        input_path = Path(video_path)

        # 获取文件大小（MB）
        file_size_mb = input_path.stat().st_size / (1024 * 1024)

        # 如果文件已经小于目标大小，不需要压缩
        if file_size_mb <= self.compress_target_mb:
            logger.info(f"[压缩] 文件大小 {file_size_mb:.1f}MB <= 目标 {self.compress_target_mb}MB，跳过压缩")
            return video_path

        # 获取视频时长（秒）
        duration = self._get_video_duration(str(input_path))

        if duration <= 0:
            logger.warning(f"[压缩] 无法获取视频时长，跳过压缩")
            return video_path

        # 计算目标比特率
        # 公式: target_bitrate = target_size_mb * 8 / duration_seconds (Mbps)
        # 预留一些余量给音频（128kbps = 0.128Mbps）
        calculated_bitrate = (self.compress_target_mb * 8 / duration) - 0.128
        
        # V18.8: 强制码率保底 2.5Mbps (满足客户硬性要求)
        target_bitrate = max(2.5, calculated_bitrate)
        
        if target_bitrate > calculated_bitrate:
            logger.warning(f"[压缩] ⚠️ 计算码率 {calculated_bitrate:.2f}Mbps 低于保底线，已锁定为 2.50Mbps (质量优先，体积可能超标)")

        # 计算CRF值（根据目标比特率估算）
        # 经验公式：CRF ≈ 23 + (10 - bitrate) * 2
        # bitrate单位是Mbps
        estimated_crf = 23 + (10 - target_bitrate) * 2
        # V18.8: 将CRF上限从28下调至26，确保极长视频也不至于过于模糊
        crf = max(18, min(26, int(estimated_crf))) 

        logger.info(f"[压缩] 原始: {file_size_mb:.1f}MB, 时长: {duration:.1f}秒")
        logger.info(f"[压缩] 目标: {self.compress_target_mb}MB, 比特率: {target_bitrate:.2f}Mbps, CRF: {crf}")

        # 临时输出文件
        temp_output = input_path.parent / f"{input_path.stem}_compressed{input_path.suffix}"

        # V18.8: 强制码率保底 2500kbps
        bitrate_kbps = int(target_bitrate * 1000)
        bitrate_args = [
            '-b:v', f'{bitrate_kbps}k',
            '-maxrate', f'{bitrate_kbps * 2}k',
            '-bufsize', f'{bitrate_kbps * 2}k'
        ]

        # 使用FFmpeg压缩
        cmd = [
            'ffmpeg',
            '-y',  # 覆盖输出文件
            '-i', str(input_path),
            '-vcodec', 'libx264',
            '-crf', str(crf),
            '-preset', 'medium'] + bitrate_args + [
            '-acodec', 'aac',
            '-b:a', '128k',
            '-movflags', '+faststart',
            str(temp_output)
        ]

        try:
            result = run_command(
                cmd,
                timeout=TimeoutConfig.FFMPEG_COMPRESS,
                error_msg="视频压缩超时"
            )

            if result is None or result.returncode != 0:
                err = result.stderr[:200] if result is not None else "超时"
                logger.error(f"[压缩] FFmpeg错误: {err}")
                return video_path

            # 获取压缩后文件大小
            compressed_size_mb = temp_output.stat().st_size / (1024 * 1024)

            # 验证压缩成功
            if compressed_size_mb > self.compress_target_mb:
                # 如果仍然超过目标，再压缩一次
                logger.info(f"[压缩] 首次压缩后 {compressed_size_mb:.1f}MB，仍超过目标，进行二次压缩...")
                # 增大CRF值
                crf = min(28, crf + 3)
                cmd[-1] = str(temp_output)
                cmd[cmd.index('-crf') + 1] = str(crf)

                result = run_command(
                    cmd,
                    timeout=TimeoutConfig.FFMPEG_COMPRESS,
                    error_msg="视频二次压缩超时"
                )

                if result is not None and result.returncode == 0:
                    compressed_size_mb = temp_output.stat().st_size / (1024 * 1024)

            # 替换原文件
            if compressed_size_mb < file_size_mb:
                shutil.move(str(temp_output), str(input_path))
                saved = file_size_mb - compressed_size_mb
                ratio = (1 - compressed_size_mb / file_size_mb) * 100
                logger.info(f"[压缩] ✅ 完成: {file_size_mb:.1f}MB → {compressed_size_mb:.1f}MB (节省 {saved:.1f}MB, {ratio:.1f}%)")
            else:
                # 压缩后反而变大，删除临时文件
                temp_output.unlink()
                logger.warning(f"[压缩] ⚠️ 压缩后文件变大，保留原文件")

        except Exception as e:
            logger.error(f"[压缩] ❌ 压缩失败: {e}")
            if temp_output.exists():
                temp_output.unlink()

        return video_path

    def _get_video_duration(self, video_path: str) -> float:
        """获取视频时长（秒）

        Args:
            video_path: 视频文件路径

        Returns:
            视频时长（秒），失败返回0
        """
        try:
            cmd = [
                'ffprobe',
                '-v', 'error',
                '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                video_path
            ]
            result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
            if result is not None and result.returncode == 0 and result.stdout.strip():
                return float(result.stdout.strip())
        except Exception:
            pass
        return 0

    def render_all_clips(
        self,
        on_clip_progress: Optional[Callable[[int, int, float], None]] = None,
        max_clips: int = 0,
        clip_indices: Optional[List[int]] = None
    ) -> List[str]:
        """渲染所有剪辑

        Args:
            on_clip_progress: 进度回调函数(current, total, progress)
            max_clips: 最多渲染的剪辑数量（0=全部）
            clip_indices: 指定要渲染的剪辑索引列表（如 [0, 2, 7]）

        Returns:
            输出文件路径列表
        """
        # V19.3: 渲染前清理上次残留的临时文件
        _cleanup_stale_temp_files(self.output_dir)

        # V16.3: 预缓存结尾视频
        if self.add_ending_clip and self.ending_videos:
            logger.info("📁 预缓存结尾视频...")
            self.cached_endings = self._precache_ending_videos()
            logger.info(f"已缓存 {len(self.cached_endings)} 个结尾视频")

        clips_data = self.result.get('clips', [])

        # V15.7: 支持限制剪辑数量
        if clip_indices:
            # 渲染指定索引的剪辑
            clips_to_render = [(i, clips_data[i]) for i in clip_indices if i < len(clips_data)]
            logger.info(f"渲染指定 {len(clips_to_render)} 个剪辑（索引: {clip_indices}）...")
        elif max_clips > 0:
            # 渲染前 max_clips 个剪辑
            clips_to_render = list(enumerate(clips_data[:max_clips]))
            logger.info(f"渲染前 {len(clips_to_render)} 个剪辑（共 {len(clips_data)} 个）...")
        else:
            # 渲染全部
            clips_to_render = list(enumerate(clips_data))
            logger.info(f"渲染全部 {len(clips_to_render)} 个剪辑...")

        total_clips = len(clips_to_render)
        logger.info(f"输出目录: {self.output_dir}")

        self.output_dir.mkdir(parents=True, exist_ok=True)

        output_paths = []
        _render_started_at = time.time()

        for render_idx, (original_idx, clip_data) in enumerate(clips_to_render, 1):
            clip = Clip(**clip_data)

            # V13.1: 修复progress变量未定义的bug
            last_progress = [0.0]  # 使用列表来在闭包中存储进度

            def clip_progress(progress: float):
                last_progress[0] = progress  # 更新进度值
                if on_clip_progress:
                    on_clip_progress(render_idx, total_clips, progress)

            try:
                output_path = self.render_clip(clip, on_progress=clip_progress)
                output_paths.append(output_path)

                # 写入进度文件（供 OpenClaw Agent 实时读取）
                _eta_min, _eta_max = _estimate_eta(_render_started_at, render_idx, total_clips)
                _write_progress(
                    self.project_name,
                    "rendering",
                    render_idx,
                    total_clips,
                    current_item=f"clip {render_idx}/{total_clips}",
                    message=f"正在处理第 {render_idx} 条剪辑",
                    started_at=_render_started_at,
                    eta_min_seconds=_eta_min,
                    eta_max_seconds=_eta_max,
                    run_id=f'{self.project_name}-render-{int(_render_started_at)}',
                )

                # 总体进度 (V15.7: 修复idx变量未定义问题)
                if on_clip_progress:
                    overall_progress = (render_idx - 1 + last_progress[0]) / total_clips
                    on_clip_progress(render_idx, total_clips, overall_progress)

            except Exception as e:
                logger.error(f"❌ 渲染失败: {e}")
                continue

        # 清理进度文件
        _clear_progress(self.project_name, "rendering")

        logger.info(f"✅ 渲染完成: {len(output_paths)}/{total_clips}个剪辑")
        return output_paths

    def render_all_clips_parallel(
        self,
        max_workers: int = 4,
        on_clip_progress: Optional[Callable[[int, int, float], None]] = None,
        max_clips: int = 0,
        clip_indices: Optional[List[int]] = None
    ) -> List[str]:
        """并行渲染所有剪辑 (V16新增)

        使用多进程加速渲染，每个worker独立处理一个剪辑

        Args:
            max_workers: 最大并行worker数（默认4，设为1禁用并行）
            on_clip_progress: 进度回调函数(current, total, progress)
            max_clips: 最多渲染的剪辑数量（0=全部）
            clip_indices: 指定要渲染的剪辑索引列表（如 [0, 2, 7]）

        Returns:
            输出文件路径列表
        """
        # V19.3: 渲染前清理上次残留的临时文件
        _cleanup_stale_temp_files(self.output_dir)

        # V16.3: 预缓存结尾视频
        if self.add_ending_clip and self.ending_videos:
            logger.info("📁 预缓存结尾视频（并行模式）...")
            self.cached_endings = self._precache_ending_videos()
            logger.info(f"已缓存 {len(self.cached_endings)} 个结尾视频")

        clips_data = self.result.get('clips', [])

        # 如果max_workers<=1，回退到串行模式
        if max_workers <= 1:
            return self.render_all_clips(on_clip_progress, max_clips, clip_indices)

        # 支持限制剪辑数量
        if clip_indices:
            clips_to_render = [(i, clips_data[i]) for i in clip_indices if i < len(clips_data)]
            logger.info(f"并行渲染指定 {len(clips_to_render)} 个剪辑（索引: {clip_indices}）...")
        elif max_clips > 0:
            clips_to_render = list(enumerate(clips_data[:max_clips]))
            logger.info(f"并行渲染前 {len(clips_to_render)} 个剪辑（共 {len(clips_data)} 个）...")
        else:
            clips_to_render = list(enumerate(clips_data))
            logger.info(f"并行渲染全部 {len(clips_to_render)} 个剪辑...")

        total_clips = len(clips_to_render)
        logger.info(f"输出目录: {self.output_dir}")
        logger.info(f"并行Worker数: {max_workers}")

        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 限制worker数量不超过CPU核心数
        max_workers = min(max_workers, multiprocessing.cpu_count())

        # 预加载字幕区域缓存（从磁盘读，供 standalone worker 使用）
        # 缓存中存储 y_ratio（0~1 比例值），由 standalone 函数根据 clip 实际高度换算
        subtitle_region_cache = {}
        subtitle_cache_dir = Path("data/cache/subtitle_region") / self.project_name
        if subtitle_cache_dir.exists():
            import json as _json
            for cache_file in subtitle_cache_dir.glob("*.json"):
                try:
                    ep = int(cache_file.stem)
                    data = _json.loads(cache_file.read_text(encoding="utf-8"))
                    # 优先读取 y_ratio（新格式），兼容旧格式（subtitle_bottom_y + original_height）
                    y_ratio = data.get("y_ratio")
                    if y_ratio is None and data.get("subtitle_bottom_y") is not None and data.get("original_height"):
                        y_ratio = data["subtitle_bottom_y"] / data["original_height"]
                    if y_ratio is not None:
                        subtitle_region_cache[ep] = y_ratio
                except Exception:
                    pass

        involved_episodes = set()

        # V19.2: 字幕区域检测缓存预热 — 批量预检测未缓存的集数
        if self.add_overlay:
            # 收集所有涉及的集数
            for _, clip_data in clips_to_render:
                clip = Clip(**clip_data)
                involved_episodes.add(clip.episode)
                if clip.episode != clip.hookEpisode:
                    involved_episodes.add(clip.hookEpisode)

            # 找出未缓存的集数
            uncached_episodes = [ep for ep in sorted(involved_episodes) if ep not in subtitle_region_cache]
            if uncached_episodes:
                logger.info(f"📍 字幕区域预热: {len(uncached_episodes)} 集未缓存 (共 {len(involved_episodes)} 集)")
                try:
                    from scripts.preprocess.subtitle_detector import get_subtitle_bottom_y
                    from scripts.utils.filename_parser import parse_episode_number

                    video_files = sorted(self.video_dir.glob("*.mp4"))
                    ep_to_video = {}
                    for vf in video_files:
                        ep_num = parse_episode_number(vf.name)
                        if ep_num is not None:
                            ep_to_video[ep_num] = str(vf)

                    for ep in uncached_episodes:
                        video_path = ep_to_video.get(ep)
                        if not video_path:
                            continue
                        try:
                            pixel_value = get_subtitle_bottom_y(video_path, sample_frame_count=5)
                            if pixel_value is not None:
                                probe = run_command(
                                    ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                                     '-show_entries', 'stream=height', '-of', 'csv=p=0', video_path],
                                    timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                                )
                                video_height = int(probe.stdout.strip()) if probe else 0
                                if video_height > 0:
                                    y_ratio = pixel_value / video_height
                                    subtitle_region_cache[ep] = y_ratio
                                    # 写入磁盘缓存
                                    subtitle_cache_dir.mkdir(parents=True, exist_ok=True)
                                    cache_data = {"y_ratio": y_ratio, "subtitle_bottom_y": pixel_value, "original_height": video_height}
                                    (subtitle_cache_dir / f"{ep}.json").write_text(
                                        json.dumps(cache_data, ensure_ascii=False), encoding="utf-8"
                                    )
                                    logger.info(f"第{ep}集: y_ratio={y_ratio:.3f} (pixel={pixel_value}, height={video_height})")
                        except Exception as e:
                            logger.warning(f"第{ep}集: 检测失败 ({e})")
                except Exception as e:
                    logger.warning(f"⚠️ 字幕预热失败: {e}")
            else:
                logger.info(f"📍 字幕区域: 全部 {len(involved_episodes)} 集已缓存")

        project_subtitle_ratio = _resolve_project_subtitle_ratio(
            subtitle_region_cache,
            sorted(involved_episodes) if involved_episodes else None,
        )

        # V21: 内置免责声明检测（项目级，只检测第1集）
        builtin_disclaimer_info = None
        if self.add_overlay:
            try:
                from scripts.preprocess.subtitle_detector import detect_builtin_disclaimer, BuiltinDisclaimerInfo
                from scripts.utils.filename_parser import parse_episode_number

                # 找第1集视频
                ep1_video = None
                video_files_sorted = sorted(self.video_dir.glob("*.mp4"))
                for vf in video_files_sorted:
                    ep_num = parse_episode_number(vf.name)
                    if ep_num == 1:
                        ep1_video = str(vf)
                        break
                if ep1_video is None and video_files_sorted:
                    ep1_video = str(video_files_sorted[0])

                if ep1_video:
                    logger.info(f"📋 V21 内置免责声明检测: {Path(ep1_video).name}")
                    builtin_disclaimer_info = detect_builtin_disclaimer(ep1_video)
                    if builtin_disclaimer_info.detected:
                        logger.info(f"✅ 检测到内置免责声明: y={builtin_disclaimer_info.top_y}-{builtin_disclaimer_info.bottom_y}")
                        logger.info(f"📝 文字: {builtin_disclaimer_info.text_sample}")
                    else:
                        logger.info(f"ℹ️ 未检测到内置免责声明，正常添加")
            except Exception as e:
                logger.warning(f"⚠️ 内置免责声明检测失败: {e}")
                builtin_disclaimer_info = None

        # 准备渲染参数
        render_params = {
            'video_dir': str(self.video_dir),
            'output_dir': str(self.output_dir),
            'episode_durations': self.episode_durations,
            'raw_episode_durations': self.raw_episode_durations,  # V17.2: 原始总时长
            'width': self.width,
            'height': self.height,
            'fps': self.fps,
            'crf': self.crf,
            'preset': self.preset,
            'project_name': self.project_name,
            'add_ending_clip': self.add_ending_clip,
            'ending_videos': self.ending_videos,
            'add_overlay': self.add_overlay,
            'overlay_style_id': self.overlay_style_id,
            'hot_drama_position': getattr(self, 'overlay_config', None).hot_drama_position if hasattr(self, 'overlay_config') and self.overlay_config else 'top-right',
            'hwaccel': self.hwaccel,  # V16.2: GPU硬件加速
            'subtitle_region_cache': subtitle_region_cache,  # 字幕区域缓存（供 standalone 用）
            'project_subtitle_ratio': project_subtitle_ratio,  # 项目级稳定字幕轨道
            'builtin_disclaimer_info': builtin_disclaimer_info,  # V21: 内置免责声明检测结果
        }

        output_paths = []
        completed = 0
        _render_started_at = time.time()

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有任务
            futures = {
                executor.submit(
                    render_single_clip_standalone,
                    original_idx,
                    clip_data,
                    render_params
                ): (original_idx, clip_data)
                for original_idx, clip_data in clips_to_render
            }

            # 收集结果
            pool_broken = False
            for future in as_completed(futures):
                original_idx, _ = futures[future]
                completed += 1

                try:
                    output_path = future.result()
                    if output_path:
                        output_paths.append(output_path)
                        logger.info(f"✅ 剪辑 {completed}/{total_clips} (原索引 {original_idx}) 完成")
                    else:
                        logger.warning(f"⚠️  剪辑 {completed}/{total_clips} (原索引 {original_idx}) 无输出")

                    # 写入进度文件（供 OpenClaw Agent 实时读取）
                    _eta_min, _eta_max = _estimate_eta(_render_started_at, completed, total_clips)
                    _write_progress(
                        self.project_name,
                        "rendering",
                        completed,
                        total_clips,
                        current_item=f"clip {completed}/{total_clips}",
                        message=f"并行渲染已完成 {completed}/{total_clips} 条剪辑",
                        started_at=_render_started_at,
                        eta_min_seconds=_eta_min,
                        eta_max_seconds=_eta_max,
                    )

                    # 进度回调
                    if on_clip_progress:
                        on_clip_progress(completed, total_clips, 1.0)

                except concurrent.futures.process.BrokenProcessPool as e:
                    # V19.2: Worker 进程被 OOM kill 或 segfault，进程池已损坏
                    logger.error(f"❌ 进程池损坏（Worker 被系统终止），已完成 {len(output_paths)}/{total_clips}")
                    logger.info(f"错误: {e}")
                    logger.info(f"已渲染的 {len(output_paths)} 个剪辑保留，剩余跳过")
                    pool_broken = True
                    break

                except Exception as e:
                    logger.error(f"❌ 剪辑 {completed}/{total_clips} (原索引 {original_idx}) 失败: {e}")

        # 清理进度文件
        _clear_progress(self.project_name, "rendering")

        logger.info(f"✅ 并行渲染完成: {len(output_paths)}/{total_clips}个剪辑")
        return output_paths


def render_single_clip_standalone(
    clip_index: int,
    clip_data: dict,
    render_params: dict
) -> Optional[str]:
    """独立的单剪辑渲染函数（用于多进程）(V17优化)

    V17优化：优先使用单次编码（filter_complex），失败时回退到分步处理
    - 单集剪辑：1次FFmpeg调用
    - 跨集剪辑：1次FFmpeg调用（原3次）
    - 预期速度提升：跨集剪辑 ~66%

    Args:
        clip_index: 剪辑索引
        clip_data: 剪辑数据字典
        render_params: 渲染参数字典

    Returns:
        输出文件路径，失败返回None
    """
    # V17: 优先使用单次编码
    return _render_clip_single_pass(clip_index, clip_data, render_params)


def _render_clip_unified_standalone(
    clip_index: int,
    clip_data: dict,
    render_params: dict
) -> Optional[str]:
    """分步渲染函数（V17回退方案）

    当单次编码失败时，回退到此分步处理方法。
    这是V16及之前的默认渲染方式。

    Args:
        clip_index: 剪辑索引
        clip_data: 剪辑数据字典
        render_params: 渲染参数字典

    Returns:
        输出文件路径，失败返回None
    """
    try:
        # 创建Clip对象
        clip = Clip(**clip_data)

        # 计算起始和结束时间（在该集内的秒数）
        episode_durations = render_params['episode_durations']
        # V17.2: 使用原始总时长用于跨集计算
        raw_episode_durations = render_params.get('raw_episode_durations', episode_durations)

        # 计算起始集内的秒数
        cumulative_before_start = 0
        for ep in sorted(raw_episode_durations.keys()):
            if ep < clip.episode:
                cumulative_before_start += raw_episode_durations[ep]

        start_in_episode = clip.start - cumulative_before_start

        # 计算结束集内的秒数
        cumulative_before_end = 0
        for ep in sorted(raw_episode_durations.keys()):
            if ep < clip.hookEpisode:
                cumulative_before_end += raw_episode_durations[ep]

        end_in_episode = clip.end - cumulative_before_end

        # 生成唯一输出文件名（添加worker_id避免冲突）
        import os
        worker_id = os.getpid()
        output_dir = Path(render_params['output_dir'])
        output_dir.mkdir(parents=True, exist_ok=True)

        # 使用唯一临时文件名
        date_str = datetime.now().strftime("%m%d")
        filename = f"LM-777457-{date_str}-[{render_params['project_name']}]-第{clip.episode}集{format_time(int(start_in_episode))}_第{clip.hookEpisode}集{format_time(int(end_in_episode))}_tmp{worker_id}.mp4"
        output_path = str(output_dir / filename)

        # 转换为视频片段（使用原始总时长 + 有效时长限制）
        segments = _clip_to_segments_standalone(clip, raw_episode_durations, render_params['video_dir'], episode_durations)

        # 如果只有1个片段且不是跨集，直接裁剪
        if len(segments) == 1:
            _trim_segment_standalone(segments[0], output_path, render_params)
        else:
            # 多个片段：先分别裁剪，再拼接
            temp_files = []
            temp_dir = output_dir / f"temp_{worker_id}"
            temp_dir.mkdir(exist_ok=True)

            # 裁剪每个片段
            for i, segment in enumerate(segments):
                temp_file = temp_dir / f"segment_{i}.mp4"
                _trim_segment_standalone(segment, str(temp_file), render_params)
                temp_files.append(str(temp_file))

            # 拼接片段
            _concat_segments_standalone(temp_files, output_path, output_dir)

            # 删除临时文件和目录（使用shutil.rmtree处理非空目录）
            import shutil
            for temp_file in temp_files:
                try:
                    Path(temp_file).unlink()
                except:
                    pass
            try:
                shutil.rmtree(temp_dir)
            except:
                pass

        # V15: 添加花字叠加（如果配置了）
        if render_params['add_overlay']:
            output_path = _apply_video_overlay_standalone(output_path, render_params, episode=clip.episode)

        # V14: 添加结尾视频（如果配置了）
        if render_params['add_ending_clip'] and render_params['ending_videos']:
            output_path = _append_ending_video_standalone(output_path, render_params)

        # 重命名为最终文件名（V16.1修复：正确处理后缀）
        # output_path 现在可能包含 _overlay 和 _带结尾 后缀
        output_path_obj = Path(output_path)
        final_stem = output_path_obj.stem

        # 移除临时标记
        final_stem = final_stem.replace(f'_tmp{worker_id}', '')

        # 移除 _overlay 后缀（带花字已在文件名中）
        final_stem = final_stem.replace('_overlay', '')

        # 生成最终路径
        final_path = str(output_path_obj.parent / (final_stem + output_path_obj.suffix))
        shutil.move(output_path, final_path)

        return final_path

    except Exception as e:
        logger.error(f"[Worker] 渲染失败: {e}")
        return None


def _clip_to_segments_standalone(clip: Clip, raw_episode_durations: dict, video_dir: str, effective_durations: dict = None) -> List:
    """将剪辑转换为视频片段列表（独立函数）(V16新增)

    V17.3修复：添加有效时长限制，确保不超出每集的有效时长

    Args:
        clip: 剪辑对象
        raw_episode_durations: 原始总时长（用于计算clip.start/end位置）
        video_dir: 视频目录
        effective_durations: 有效时长（可选，用于限制每集结束位置）
    """
    from dataclasses import dataclass

    @dataclass
    class Segment:
        episode: int
        start: float
        end: float

    # V17.3: 如果没有传入有效时长，默认使用原始时长
    if effective_durations is None:
        effective_durations = raw_episode_durations

    segments = []

    # 简单情况：不跨集
    if clip.episode == clip.hookEpisode:
        # 计算在该集内的秒数
        cumulative_before = 0
        for ep in sorted(raw_episode_durations.keys()):
            if ep < clip.episode:
                cumulative_before += raw_episode_durations[ep]

        start_in_episode = clip.start - cumulative_before
        end_in_episode = clip.end - cumulative_before

        # V17.3: 使用有效时长限制结束位置
        ep_effective = effective_durations.get(clip.episode, raw_episode_durations[clip.episode])
        end_in_episode = min(end_in_episode, ep_effective)

        segments.append(Segment(
            episode=clip.episode,
            start=start_in_episode,
            end=end_in_episode
        ))
    else:
        # 跨集情况：分割为多个片段
        current_episode = clip.episode

        # 计算累积时间（使用原始总时长）
        cumulative = 0
        episode_times = {}
        for ep in sorted(raw_episode_durations.keys()):
            episode_times[ep] = {
                'start': cumulative,
                'end': cumulative + raw_episode_durations[ep]
            }
            cumulative += raw_episode_durations[ep]

        # V17.3: 使用有效时长
        # 第一段：从起始时间到该集结束（限制在有效时长内）
        first_episode_end_raw = raw_episode_durations[clip.episode]
        first_episode_end_eff = effective_durations.get(clip.episode, first_episode_end_raw)
        cumulative_before_start = episode_times[clip.episode]['start']
        start_in_first = clip.start - cumulative_before_start
        end_in_first = min(first_episode_end_raw, first_episode_end_eff)

        segments.append(Segment(
            episode=clip.episode,
            start=start_in_first,
            end=end_in_first
        ))

        # 中间段：完整的集（限制在有效时长内）
        for ep in range(clip.episode + 1, clip.hookEpisode):
            ep_end_raw = raw_episode_durations.get(ep, 0)
            ep_end_eff = effective_durations.get(ep, ep_end_raw)
            segments.append(Segment(
                episode=ep,
                start=0,
                end=min(ep_end_raw, ep_end_eff)
            ))

        # 最后一段：从该集开始到结束时间（限制在有效时长内）
        cumulative_before_end = episode_times[clip.hookEpisode]['start']
        end_in_last_raw = clip.end - cumulative_before_end
        last_ep_eff = effective_durations.get(clip.hookEpisode, raw_episode_durations[clip.hookEpisode])
        end_in_last = min(end_in_last_raw, last_ep_eff)

        segments.append(Segment(
            episode=clip.hookEpisode,
            start=0,
            end=end_in_last
        ))

    return segments


def _trim_segment_standalone(segment, output_path: str, render_params: dict) -> None:
    """裁剪单个视频片段（独立函数）(V16.2: 支持跨平台GPU加速)"""
    video_dir = Path(render_params['video_dir'])

    # 查找视频文件
    video_files = sorted(video_dir.glob("*.mp4"))
    video_file = None
    for vf in video_files:
        ep_num = _extract_episode_number_standalone(vf.name)
        if ep_num == segment.episode:
            video_file = vf
            break

    if not video_file:
        raise FileNotFoundError(f"找不到第{segment.episode}集视频")

    # 获取视频帧率
    fps = _get_video_fps_standalone(str(video_file))

    # 计算总帧数（基于实际FPS）
    import math
    total_frames = math.ceil(segment.end * fps)

    # V16.2: 检测最佳GPU编码器
    hwaccel = render_params.get('hwaccel', False)
    hwaccel_config = _detect_gpu_encoder() if hwaccel else None

    # V16.2: 构建FFmpeg命令（支持跨平台GPU加速）
    cmd = ['ffmpeg', '-y']

    # GPU硬件解码加速
    if hwaccel_config:
        hwaccel_method = hwaccel_config.get('hwaccel')
        if hwaccel_method:
            cmd.extend(['-hwaccel', hwaccel_method])

    cmd.extend([
        '-ss', str(segment.start),
        '-i', str(video_file),
        '-t', str(segment.end - segment.start),
    ])

    # V16.2: 选择编码方式
    if hwaccel_config:
        # GPU加速编码
        cmd.extend([
            '-c:v', hwaccel_config['encoder'],
            '-b:v', '8M',  # GPU编码使用码率控制
            '-c:a', 'aac',
            '-b:a', '128k',
        ])
    else:
        # CPU编码
        cmd.extend([
            '-c:v', 'libx264',
            '-crf', str(render_params['crf']),
            '-preset', render_params['preset'],
            '-c:a', 'aac',
            '-b:a', '128k',
        ])

    cmd.append(output_path)

    # 执行命令（静默模式），含超时保护
    result = run_command(
        cmd,
        timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
        raise_on_error=True,
        error_msg="GPU加速片段裁剪超时"
    )


def _detect_gpu_encoder() -> Optional[dict]:
    """检测可用的GPU编码器（跨平台支持）(V16.2新增)

    Returns:
        GPU编码器配置字典，如果不可用返回None

    支持的编码器：
    - macOS: h264_videotoolbox
    - Windows/Linux + NVIDIA: h264_nvenc
    - Windows/Linux + Intel: h264_qsv
    - Windows/Linux + AMD: h264_amf
    """
    import platform
    import subprocess

    system = platform.system()

    # 按优先级尝试不同的编码器
    encoders_to_try = []

    if system == 'Darwin':  # macOS
        encoders_to_try = [
            {'encoder': 'h264_videotoolbox', 'hwaccel': 'videotoolbox', 'name': 'VideoToolbox (macOS)'},
        ]
    elif system == 'Windows':
        encoders_to_try = [
            {'encoder': 'h264_nvenc', 'hwaccel': 'cuda', 'name': 'NVIDIA NVENC'},
            {'encoder': 'h264_qsv', 'hwaccel': 'qsv', 'name': 'Intel QuickSync'},
            {'encoder': 'h264_amf', 'hwaccel': None, 'name': 'AMD AMF'},
        ]
    else:  # Linux
        encoders_to_try = [
            {'encoder': 'h264_nvenc', 'hwaccel': 'cuda', 'name': 'NVIDIA NVENC'},
            {'encoder': 'h264_qsv', 'hwaccel': 'qsv', 'name': 'Intel QuickSync'},
            {'encoder': 'h264_vaapi', 'hwaccel': 'vaapi', 'name': 'VAAPI (Intel/AMD)'},
        ]

    # 检查FFmpeg是否支持这些编码器
    try:
        result = run_command(
            ['ffmpeg', '-encoders'],
            timeout=TimeoutConfig.FFMPEG_HWACCEL_CHECK,
            error_msg="硬件加速检测超时"
        )
        available_encoders = result.stdout if result else ""

        for config in encoders_to_try:
            if config['encoder'] in available_encoders:
                logger.info(f"🎮 GPU加速: {config['name']}")
                return config

    except Exception as e:
        logger.warning(f"⚠️ 检测GPU编码器失败: {e}")

    logger.warning(f"⚠️ 未检测到可用的GPU编码器，使用CPU编码")
    return None


def _concat_segments_standalone(segment_files: List[str], output_path: str, output_dir: Path) -> None:
    """拼接多个视频片段（独立函数）(V16新增)"""
    # 创建临时concat列表文件
    concat_file = output_dir / f"concat_list_{os.getpid()}.txt"
    with open(concat_file, 'w') as f:
        for segment_file in segment_files:
            segment_path = Path(segment_file)
            relative_path = segment_path.relative_to(output_dir)
            f.write(f"file '{relative_path}'\n")

    # FFmpeg命令
    cmd = [
        'ffmpeg',
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', str(concat_file),
        '-c', 'copy',
        output_path
    ]

    result = run_command(
        cmd,
        timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
        raise_on_error=True,
        error_msg="片段拼接超时"
    )

    # 删除临时文件
    concat_file.unlink()


def _apply_video_overlay_standalone(clip_path: str, render_params: dict, episode: int = None) -> str:
    """应用花字叠加（独立函数）(V16新增)"""
    try:
        from .video_overlay.video_overlay import VideoOverlayRenderer, OverlayConfig

        # 创建临时配置
        config = OverlayConfig(
            enabled=True,
            style_id=render_params['overlay_style_id'],
            project_name=render_params['project_name'],
            drama_title=render_params['project_name'],
            hot_drama_position=render_params.get('hot_drama_position', 'top-right')
        )

        renderer = VideoOverlayRenderer(config)

        # 从缓存中获取字幕比例（y_ratio，0~1），换算为当前 clip 的实际像素坐标
        subtitle_bottom_y = None
        if episode is not None:
            subtitle_region_cache = render_params.get('subtitle_region_cache', {})
            effective_ratio = _get_effective_subtitle_ratio(
                episode,
                subtitle_region_cache,
                render_params.get('project_subtitle_ratio'),
                "standalone",
            )
            if effective_ratio is not None:
                # 探测 clip 实际高度，换算为像素（解决 1080p→720p 坐标系不匹配问题）
                try:
                    from scripts.utils.subprocess_utils import run_command
                    from scripts.config import TimeoutConfig
                    probe = run_command(
                        ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                         '-show_entries', 'stream=height', '-of', 'csv=p=0', clip_path],
                        timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                    )
                    clip_height = int(probe.stdout.strip()) if probe else 0
                    subtitle_bottom_y = _resolve_subtitle_bottom_from_ratio(
                        effective_ratio,
                        clip_height,
                        f"standalone 缓存 EP{episode}",
                    )
                except Exception as e:
                    logger.warning(f"[字幕定位] standalone 换算失败: {e}")

        # 没缓存时，优先从源视频（第 episode 集）检测，避免 temp clip 包含片尾或跨集内容干扰
        if subtitle_bottom_y is None:
            try:
                from scripts.preprocess.subtitle_detector import get_subtitle_bottom_y
                from scripts.utils.subprocess_utils import run_command
                from scripts.config import TimeoutConfig
                source_video_path = None

                # 尝试找到源视频（用 video_dir 和 episode 定位）
                if episode is not None:
                    video_dir = render_params.get('video_dir')
                    if video_dir:
                        import glob as _glob
                        candidates = _glob.glob(str(Path(video_dir) / "*.mp4"))
                        for c in sorted(candidates):
                            ep_num = _extract_episode_number_standalone(Path(c).name)
                            if ep_num == episode:
                                source_video_path = c
                                break

                detect_path = source_video_path if source_video_path else clip_path
                detect_label = f"源视频(ep{episode})" if source_video_path else "rendered clip"

                pixel_value = get_subtitle_bottom_y(detect_path, sample_frame_count=5)
                if pixel_value is not None:
                    # 获取检测视频的高度，计算比例
                    probe = run_command(
                        ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                         '-show_entries', 'stream=height', '-of', 'csv=p=0', detect_path],
                        timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                    )
                    detect_height = int(probe.stdout.strip()) if probe else 0

                    if detect_height > 0:
                        # 计算比例
                        y_ratio = pixel_value / detect_height

                        # 获取 clip 实际高度
                        probe_clip = run_command(
                            ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries', 'stream=height', '-of', 'csv=p=0', clip_path],
                            timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                        )
                        clip_height = int(probe_clip.stdout.strip()) if probe_clip else 0

                        if clip_height > 0:
                            # 按比例换算到 clip 高度
                            subtitle_bottom_y = _resolve_subtitle_bottom_from_ratio(
                                y_ratio,
                                clip_height,
                                f"standalone 实时 {detect_label}",
                            )
                            logger.info(f"[字幕检测] 实时检测({detect_label}): pixel={pixel_value}, detect_height={detect_height}, y_ratio={y_ratio:.3f}")
                        else:
                            logger.warning(f"[字幕检测] 无法获取 clip 高度，跳过")
                    else:
                        logger.warning(f"[字幕检测] 无法获取检测视频高度，跳过")
            except Exception as e:
                logger.warning(f"[字幕检测] 实时检测失败: {e}")

        # 生成新的输出路径
        clip_path_obj = Path(clip_path)
        overlay_filename = clip_path_obj.stem + "_overlay" + clip_path_obj.suffix
        overlay_path = str(clip_path_obj.parent / overlay_filename)

        # V21: 从 render_params 获取内置免责声明信息
        skip_disclaimer = False
        builtin_disclaimer_top_y = None
        bd_info = render_params.get('builtin_disclaimer_info')
        if bd_info is not None and bd_info.detected:
            skip_disclaimer = True
            # 按比例换算到 clip 高度
            if bd_info.video_height > 0 and bd_info.top_y is not None:
                try:
                    probe_clip = run_command(
                        ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                         '-show_entries', 'stream=height', '-of', 'csv=p=0', clip_path],
                        timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                    )
                    clip_h = int(probe_clip.stdout.strip()) if probe_clip else 0
                    if clip_h > 0:
                        builtin_disclaimer_top_y = int(bd_info.top_y * clip_h / bd_info.video_height)
                except Exception:
                    pass

        # 应用花字
        renderer.apply_overlay(
            clip_path, overlay_path,
            subtitle_bottom_y=subtitle_bottom_y,
            skip_disclaimer=skip_disclaimer,
            builtin_disclaimer_top_y=builtin_disclaimer_top_y,
        )

        # 删除原文件
        Path(clip_path).unlink()

        return overlay_path

    except Exception as e:
        logger.error(f"[Worker] 花字叠加失败: {e}")
        return clip_path


def _append_ending_video_standalone(clip_path: str, render_params: dict) -> str:
    """添加结尾视频（独立函数）(V16新增)"""
    try:
        # 随机选择结尾视频
        ending_videos = render_params['ending_videos']
        if not ending_videos:
            return clip_path

        import random
        ending_video = random.choice(ending_videos)

        # 预处理结尾视频（匹配原剪辑的分辨率和帧率）
        processed_ending = _preprocess_ending_video_standalone(clip_path, ending_video, render_params)

        # 生成新的输出路径
        clip_path_obj = Path(clip_path)
        new_filename = clip_path_obj.stem + "_带结尾" + clip_path_obj.suffix
        new_output_path = str(clip_path_obj.parent / new_filename)

        # 拼接视频
        _concat_videos_standalone([clip_path, processed_ending], new_output_path)

        # 删除临时文件
        Path(processed_ending).unlink()
        Path(clip_path).unlink()

        return new_output_path

    except Exception as e:
        logger.error(f"[Worker] 添加结尾失败: {e}")
        return clip_path


def _preprocess_ending_video_standalone(clip_path: str, ending_video: str, render_params: dict) -> str:
    """预处理结尾视频（独立函数）(V16新增)"""
    # 获取原剪辑的分辨率
    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,r_frame_rate',
        '-of', 'csv=p=0',
        clip_path
    ]
    result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
    parts = result.stdout.strip().split(',') if result else ['1920', '1080', '30/1']
    clip_width = int(parts[0])
    clip_height = int(parts[1])

    # 解析帧率
    fps_str = parts[2] if len(parts) > 2 else '30/1'
    if '/' in fps_str:
        num, den = fps_str.split('/')
        clip_fps = float(num) / float(den)
    else:
        clip_fps = float(fps_str)

    # 获取结尾视频时长
    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        ending_video
    ]
    result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
    video_duration = float(result.stdout.strip()) if (result and result.returncode == 0) else 5.0

    # 生成临时输出路径
    output_dir = Path(clip_path).parent
    processed_path = str(output_dir / f"processed_ending_{os.getpid()}.mp4")

    # 转换结尾视频（匹配分辨率和帧率）
    cmd = [
        'ffmpeg',
        '-y',
        '-i', ending_video,
        '-t', str(video_duration),
        '-vf', f'scale={clip_width}:{clip_height}:force_original_aspect_ratio=decrease,setsar=1,pad={clip_width}:{clip_height}:(ow-iw)/2:(oh-ih)/2:color=black',
        '-r', str(clip_fps),
        '-vsync', 'cfr',
        '-c:v', 'libx264',
        '-crf', str(render_params['crf']),
        '-preset', render_params['preset'],
        '-c:a', 'aac',
        '-b:a', '128k',
        processed_path
    ]

    result = run_command(
        cmd,
        timeout=TimeoutConfig.FFMPEG_ENDING_PREPROCESS,
        raise_on_error=True,
        error_msg="结尾视频预处理超时"
    )

    return processed_path


def _concat_videos_standalone(video_paths: List[str], output_path: str) -> None:
    """拼接视频文件（独立函数）(V16新增)"""
    output_dir = Path(output_path).parent
    concat_file = output_dir / f"concat_videos_{os.getpid()}.txt"

    with open(concat_file, 'w') as f:
        for vp in video_paths:
            relative_path = Path(vp).relative_to(output_dir)
            f.write(f"file '{relative_path}'\n")

    cmd = [
        'ffmpeg',
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', str(concat_file),
        '-c', 'copy',
        output_path
    ]

    result = run_command(
        cmd,
        timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
        raise_on_error=True,
        error_msg="视频拼接超时"
    )
    concat_file.unlink()


def _extract_episode_number_standalone(filename: str) -> Optional[int]:
    """从文件名提取集数（独立函数）(V16新增)"""
    patterns = [
        r'第(\d+)集',
        r'EP?(\d+)',
        r'^(\d+)',
        r'[-_](\d+)\.mp4$',
        r'(\d+)(?=\.mp4)',
    ]

    for pattern in patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            return int(match.group(1))

    return None


# ============================================================================
# V16.3: 完全单次编码优化 - 一条FFmpeg命令完成所有操作（真正的单次编码）
# ============================================================================

def _render_clip_single_pass(
    clip_index: int,
    clip_data: dict,
    render_params: dict
) -> Optional[str]:
    """V16.3 完全单次编码：一条FFmpeg命令完成裁剪+花字+结尾

    核心优化：
    - 原来：3次FFmpeg调用（裁剪→花字→结尾），每次都要完整编解码
    - 现在：1次FFmpeg调用，使用filter_complex链式处理所有场景
    - 速度提升：预计60-80%

    支持场景：
    - 场景A: 单集 + 无结尾（裁剪 → 分辨率缩放 → 花字）
    - 场景B: 单集 + 有结尾（裁剪 → 分辨率缩放 → 花字 → 结尾拼接）
    - 场景C: 跨集 + 有结尾（多段裁剪 → 拼接 → 分辨率缩放 → 花字 → 结尾拼接）

    Args:
        clip_index: 剪辑索引
        clip_data: 剪辑数据字典
        render_params: 渲染参数字典

    Returns:
        输出文件路径，失败返回None
    """
    import tempfile
    import math
    import random

    temp_files = []

    try:
        # 创建Clip对象
        clip = Clip(**clip_data)

        # 获取参数
        episode_durations = render_params['episode_durations']
        # V17.2: 使用原始总时长用于跨集计算（因为clip.start/end基于总时长）
        raw_episode_durations = render_params.get('raw_episode_durations', episode_durations)
        video_dir = Path(render_params['video_dir'])
        output_dir = Path(render_params['output_dir'])
        output_dir.mkdir(parents=True, exist_ok=True)

        project_name = render_params['project_name']
        add_overlay = render_params['add_overlay']
        add_ending = render_params['add_ending_clip'] and render_params['ending_videos']

        # 计算起始和结束时间（使用原始总时长，与result.json中的clip.start/end一致）
        cumulative_before_start = sum(
            raw_episode_durations[ep] for ep in sorted(raw_episode_durations.keys()) if ep < clip.episode
        )
        start_in_episode = clip.start - cumulative_before_start

        cumulative_before_end = sum(
            raw_episode_durations[ep] for ep in sorted(raw_episode_durations.keys()) if ep < clip.hookEpisode
        )
        end_in_episode = clip.end - cumulative_before_end

        # 生成文件名
        def format_time(seconds):
            if seconds < 60:
                return f"{int(seconds)}秒"
            mins = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{mins}分{secs}秒"

        suffix_parts = []
        if add_overlay:
            suffix_parts.append("带花字")
        if add_ending:
            suffix_parts.append("带结尾")
        suffix = "_" + "_".join(suffix_parts) if suffix_parts else ""

        date_str = datetime.now().strftime("%m%d")
        final_filename = f"LM-777457-{date_str}-[{project_name}]-第{clip.episode}集{format_time(start_in_episode)}_第{clip.hookEpisode}集{format_time(end_in_episode)}{suffix}.mp4"
        final_path = str(output_dir / final_filename)

        # 查找视频文件
        video_files = sorted(video_dir.glob("*.mp4"))

        def find_video_file(episode):
            for vf in video_files:
                ep_num = _extract_episode_number_standalone(vf.name)
                if ep_num == episode:
                    return vf
            return None

        # 判断是否跨集
        is_cross_episode = clip.episode != clip.hookEpisode

        # ===== 核心优化：完全单次FFmpeg调用 =====

        # 获取第一集视频的分辨率和帧率（用于统一处理）
        first_video_file = find_video_file(clip.episode)
        if not first_video_file:
            raise FileNotFoundError(f"找不到第{clip.episode}集视频")

        probe_cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height,r_frame_rate',
            '-of', 'csv=p=0', str(first_video_file)
        ]
        result = run_command(probe_cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
        parts = result.stdout.strip().split(',') if result else ['1920', '1080', '30/1']
        input_width = int(parts[0])
        input_height = int(parts[1])

        # 解析帧率
        fps_str = parts[2] if len(parts) > 2 else '30/1'
        if '/' in fps_str:
            num, den = fps_str.split('/')
            video_fps = float(num) / float(den)
        else:
            video_fps = float(fps_str)

        # V16.3: 智能选择输出分辨率
        output_width, output_height = _get_output_resolution(input_width, input_height)
        need_scale = (output_width != input_width or output_height != input_height)
        if need_scale:
            logger.info(f"📐 分辨率自适应: {input_width}x{input_height} → {output_width}x{output_height}")

        # ===== 构建filter_complex =====
        filter_parts = []
        audio_filter_parts = []

        # 收集所有输入文件
        input_files = []
        input_idx = 0

        # 场景判断和处理
        if not is_cross_episode:
            # ===== 场景A/B: 单集剪辑 =====
            video_file = find_video_file(clip.episode)
            input_files.append(str(video_file))

            # 1. 视频裁剪
            duration = end_in_episode - start_in_episode
            trim_filter = f"[{input_idx}:v]trim=start={start_in_episode}:duration={duration},setpts=PTS-STARTPTS[v_trim]"
            filter_parts.append(trim_filter)

            # 2. 音频裁剪
            atrim_filter = f"[{input_idx}:a]atrim=start={start_in_episode}:duration={duration},asetpts=PTS-STARTPTS[a_trim]"
            audio_filter_parts.append(atrim_filter)

            current_v_stream = "[v_trim]"
            current_a_stream = "[a_trim]"

            # V17.1: 单集场景计算main_duration
            main_duration = duration

        else:
            # ===== 场景C: 跨集剪辑 =====
            # 需要裁剪多个片段然后拼接

            # 计算需要裁剪的片段
            # V17.2: 同时使用原始总时长和有效时长
            # - 使用原始总时长计算clip.start/end对应的位置
            # - 使用有效时长限制每集的实际结束位置
            segments = []
            for ep in range(clip.episode, clip.hookEpisode + 1):
                video_file = find_video_file(ep)
                if not video_file:
                    raise FileNotFoundError(f"找不到第{ep}集视频")

                # 使用当前片段所属集的累积基准计算区间，避免跨集时错误复用起始集基准
                ep_cumulative_before_raw = sum(
                    raw_episode_durations[e] for e in sorted(raw_episode_durations.keys()) if e < ep
                )
                if ep == clip.episode:
                    ep_start = max(0, clip.start - ep_cumulative_before_raw)
                else:
                    ep_start = 0.0
                ep_end_raw = clip.end - ep_cumulative_before_raw

                # V17.3: 使用有效时长限制每集的结束位置（关键修复！）
                # 原始时长可能超出有效时长，需要裁剪到有效时长范围内
                ep_effective = episode_durations.get(ep, raw_episode_durations[ep])
                ep_end = min(ep_effective, ep_end_raw)

                # 确保ep_end >= ep_start
                if ep_start < ep_end:
                    segments.append({
                        'episode': ep,
                        'video_file': str(video_file),
                        'start': ep_start,
                        'end': ep_end,
                        'duration': ep_end - ep_start
                    })

            if not segments:
                raise ValueError("跨集剪辑没有有效的片段")

            # V17.1: 计算main_duration（在segments定义之后）
            main_duration = sum(seg['duration'] for seg in segments)

            # 为每个片段添加裁剪滤镜
            trim_outputs_v = []
            trim_outputs_a = []

            for seg in segments:
                input_files.append(seg['video_file'])

                # 视频裁剪
                trim_filter = f"[{input_idx}:v]trim=start={seg['start']}:duration={seg['duration']},setpts=PTS-STARTPTS[v_trim_{input_idx}]"
                filter_parts.append(trim_filter)

                # 音频裁剪
                atrim_filter = f"[{input_idx}:a]atrim=start={seg['start']}:duration={seg['duration']},asetpts=PTS-STARTPTS[a_trim_{input_idx}]"
                audio_filter_parts.append(atrim_filter)

                trim_outputs_v.append(f"[v_trim_{input_idx}]")
                trim_outputs_a.append(f"[a_trim_{input_idx}]")
                input_idx += 1

            # 拼接所有片段
            if len(trim_outputs_v) > 1:
                concat_v_inputs = ''.join(trim_outputs_v)
                concat_a_inputs = ''.join(trim_outputs_a)
                concat_v_filter = f"{concat_v_inputs}concat=n={len(trim_outputs_v)}:v=1:a=0[v_concat]"
                concat_a_filter = f"{concat_a_inputs}concat=n={len(trim_outputs_a)}:v=0:a=1[a_concat]"
                filter_parts.append(concat_v_filter)
                audio_filter_parts.append(concat_a_filter)
                current_v_stream = "[v_concat]"
                current_a_stream = "[a_concat]"
            else:
                current_v_stream = trim_outputs_v[0]
                current_a_stream = trim_outputs_a[0]

        # 3. V16.3: 分辨率缩放（如果需要）
        if need_scale:
            # setsar=1 确保与结尾视频 SAR 一致，避免 concat 失败
            scale_filter = f"{current_v_stream}scale={output_width}:{output_height}:flags=lanczos,setsar=1[v_scale]"
            filter_parts.append(scale_filter)
            current_v_stream = "[v_scale]"
        elif add_ending:
            # 不需要 scale 但有结尾视频时，显式 setsar=1 确保 concat 参数一致
            filter_parts.append(f"{current_v_stream}setsar=1[v_sar]")
            current_v_stream = "[v_sar]"

        # 4-5. V19.2: 花字叠加合并到 filter_complex（消除二次编码）
        # 在结尾拼接之前，先叠加角标PNG和drawtext
        overlay_info = None
        overlay_png_path = None
        if add_overlay:
            overlay_info = _build_overlay_for_single_pass(
                output_width, output_height, render_params, clip.episode, output_dir
            )

            # 5a. 叠加角标PNG（overlay滤镜）
            if overlay_info.get('badge_png_path') and Path(overlay_info['badge_png_path']).exists():
                overlay_png_path = overlay_info['badge_png_path']
                input_files.append(overlay_png_path)
                png_input_idx = len(input_files) - 1
                temp_files.append(overlay_png_path)  # 渲染完成后清理

                badge_x = overlay_info['badge_x']
                badge_y = overlay_info['badge_y']
                overlay_filter = f"{current_v_stream}[{png_input_idx}:v]overlay=x={badge_x}:y={badge_y}:eof_action=repeat[v_badge]"
                filter_parts.append(overlay_filter)
                current_v_stream = "[v_badge]"

            # 5b. 叠加drawtext（剧名+免责声明）
            if overlay_info.get('drawtext_filters'):
                drawtext_filter = f"{current_v_stream}{overlay_info['drawtext_filters']}[v_text]"
                filter_parts.append(drawtext_filter)
                current_v_stream = "[v_text]"

        # 6. 结尾拼接（如果启用）- 真正的单次编码
        ending_video_path = None
        if add_ending:
            ending_video_path = random.choice(render_params['ending_videos'])
            input_files.append(ending_video_path)

            # V18.2: main_duration已经在前面计算过了
            # 结尾视频输入索引
            ending_input_idx = len(input_files) - 1
            ending_duration = 5.0  # 取片尾前5秒

            # 结尾视频滤镜：保持原始比例缩放 + 黑边填充（避免竖屏结尾在横屏主体中被拉伸变形）
            # force_original_aspect_ratio=decrease: 保持比例缩放，不超过目标尺寸
            # pad: 补黑边居中，确保最终尺寸精确匹配主体（concat 要求分辨率一致）
            ending_v_filter = (
                f"[{ending_input_idx}:v]trim=duration={ending_duration},setpts=PTS-STARTPTS,"
                f"scale={output_width}:{output_height}:force_original_aspect_ratio=decrease:flags=lanczos,"
                f"setsar=1,"
                f"pad={output_width}:{output_height}:(ow-iw)/2:(oh-ih)/2:color=black,"
                f"fps={video_fps:.3f}[v_ending]"
            )
            filter_parts.append(ending_v_filter)

            # V18.2: 直接 concat 音频（无需 apad）
            # 测试验证：[main_audio][ending_audio]concat 音视频差 < 0.1s
            # 结尾音频截取并重置时间戳
            ending_a_filter = f"[{ending_input_idx}:a]atrim=start=0:duration={ending_duration},asetpts=PTS-STARTPTS[a_ending]"
            audio_filter_parts.append(ending_a_filter)

            # 直接拼接主体音频 + 结尾音频
            concat_audio_filter = f"{current_a_stream}[a_ending]concat=n=2:v=0:a=1[a_out]"
            audio_filter_parts.append(concat_audio_filter)

            # 拼接主体视频和结尾视频
            concat_final_v = f"{current_v_stream}[v_ending]concat=n=2:v=1:a=0[v_out]"
            # V17.5修复: 音频已经拼接好了，不需要再做concat
            # 直接使用[current_a_stream]，即[a_out]
            filter_parts.append(concat_final_v)

            final_v_stream = "[v_out]"
            final_a_stream = "[a_out]"  # 使用已经拼接好的音频（a_padded + a_ending_raw）
            input_idx += 1
        else:
            # 无结尾视频，直接使用当前流
            final_v_stream = current_v_stream
            final_a_stream = current_a_stream

        # ===== 构建完整FFmpeg命令 =====

        # 合并所有filter
        all_filters = filter_parts + audio_filter_parts
        filter_complex = ';'.join(all_filters)

        # 构建输入参数
        inputs = []
        for f in input_files:
            inputs.extend(['-i', f])

        # V17.1修复: 当使用-filter_complex时，需要用'-map'指定输出流
        # 正确语法: '-map' '[v_scale]' (带引号和方括号)
        map_outputs = ['-map', final_v_stream]  # 保持方括号，如 '[v_scale]'
        # 音频处理
        if final_a_stream:
            # V18.2: 有结尾视频时音频已经过 concat filter（[a_out]）
            # V17.1: 跨集时音频已经过 concat filter（[a_concat]）
            # V18.8: 有缩放需求时音频已经过 atrim filter（[a_trim]）
            # V19.2: 有花字叠加时也需要用 filter 音频（因为 trim 已在 filter 中）
            if add_ending or is_cross_episode or need_scale or add_overlay:
                # 使用经过 filter 处理的音频
                map_outputs.extend(['-map', final_a_stream])
            else:
                # 无结尾视频 + 单集 + 无缩放：直接使用原始音频，不经过filter
                map_outputs.extend(['-map', '0:a'])

        # V18.2: 有无片尾均执行单次 FFmpeg 编码（测试验证音视频差 < 0.1s）
        # 执行单次 FFmpeg 编码
        # 构建临时输出文件路径（避免与 final_path 冲突）
        temp_output = str(output_dir / f"temp_single_{os.getpid()}_{clip_index}.mp4")
        temp_files.append(temp_output)

        crf = render_params.get('crf', 23)
        preset = render_params.get('preset', 'fast')

        # V18.8: 强制执行码率保底 2500kbps
        # 使用 -b:v 设置平均码率，搭配 -maxrate 和 -bufsize 确保码率平稳且达标
        bitrate_args = [
            '-b:v', '2500k',
            '-maxrate', '5000k',
            '-bufsize', '5000k'
        ]

        cmd = (
            ['ffmpeg', '-y']
            + inputs
            + (['-filter_complex', filter_complex] if filter_complex else [])
            + map_outputs
            + ['-c:v', 'libx264', '-crf', str(crf), '-preset', preset]
            + bitrate_args
            + ['-c:a', 'aac', '-b:a', '128k',
               temp_output]
        )

        returncode = run_popen_with_timeout(cmd, timeout=TimeoutConfig.FFMPEG_CLIP_RENDER)
        if returncode != 0:
            logger.error(f"[单次编码] FFmpeg 失败(returncode={returncode})，回退到分步处理")
            # 清理可能残留的角标PNG
            if overlay_png_path and Path(overlay_png_path).exists():
                try:
                    Path(overlay_png_path).unlink()
                except:
                    pass
            return _render_clip_unified_standalone(clip_index, clip_data, render_params)

        overlay_desc = "+花字" if add_overlay else ""
        logger.info(f"[单次编码] 成功（裁剪+缩放{overlay_desc}，1次FFmpeg调用）")

        # V19.2: 花字已合并到 filter_complex，无需二次编码
        import shutil
        shutil.move(temp_output, final_path)

        # V19.2: 清理临时文件（角标PNG等）
        for tf in temp_files:
            try:
                tf_path = Path(tf) if not isinstance(tf, Path) else tf
                if tf_path.exists() and str(tf_path) != final_path:
                    tf_path.unlink()
            except:
                pass

        return final_path

    except Exception as e:
        logger.error(f"[Worker] V16.3完全单次编码失败: {e}")
        import traceback
        traceback.print_exc()
        # 清理临时文件
        for tf in temp_files:
            try:
                if Path(tf).exists():
                    Path(tf).unlink()
            except:
                pass
        # 回退到分步渲染
        return _render_clip_unified_standalone(clip_index, clip_data, render_params)


def _build_overlay_for_single_pass(
    video_width: int,
    video_height: int,
    render_params: dict,
    episode: int,
    output_dir: Path
) -> dict:
    """V19.2: 为单次编码构建花字叠加参数（PNG路径 + drawtext滤镜字符串）

    将 video_overlay.py 的核心逻辑提取为独立函数，
    返回可直接合并到 filter_complex 的滤镜参数。

    Returns:
        {
            'badge_png_path': str or None,  # 角标PNG路径
            'badge_x': int,                 # 角标X坐标
            'badge_y': int,                 # 角标Y坐标
            'drawtext_filters': str or None,  # drawtext滤镜链（剧名+免责声明）
        }
    """
    result = {
        'badge_png_path': None,
        'badge_x': 0,
        'badge_y': 0,
        'drawtext_filters': None,
    }

    try:
        from .video_overlay.video_overlay import VideoOverlayRenderer, OverlayConfig
        from .video_overlay.overlay_styles import TextLayer, get_random_badge_style
        from .video_overlay.badge_renderer import BadgeRenderer, get_badge_overlay_position

        project_name = render_params['project_name']

        # 创建渲染器（获取样式、字体等）
        config = OverlayConfig(
            enabled=True,
            style_id=render_params.get('overlay_style_id'),
            project_name=project_name,
            drama_title=project_name,
            hot_drama_position=render_params.get('hot_drama_position', 'top-right')
        )
        renderer = VideoOverlayRenderer(config)

        # ===== 1. 生成角标PNG =====
        badge_style = renderer.badge_style
        try:
            badge_renderer = BadgeRenderer()
            badge_text = renderer.style.hot_drama.text

            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                png_path = tmp.name

            png_path = badge_renderer.render(
                style=badge_style,
                text=badge_text,
                video_width=video_width,
                video_height=video_height,
                output_path=png_path,
            )

            import random as _random
            badge_position = badge_style.position or _random.choice(["top-left", "top-right"])

            smaller_dimension = min(video_width, video_height)
            resolution_ratio = smaller_dimension / 360.0

            badge_x, badge_y = get_badge_overlay_position(
                png_path=png_path,
                video_width=video_width,
                video_height=video_height,
                position=badge_position,
                shape=badge_style.shape,
                ratio=resolution_ratio,
            )

            result['badge_png_path'] = png_path
            result['badge_x'] = badge_x
            result['badge_y'] = badge_y
            logger.info(f"[单次编码] 角标PNG: {badge_style.name}, 位置: {badge_position} → ({badge_x}, {badge_y})")

        except Exception as e:
            logger.error(f"[单次编码] 角标生成失败: {e}")

        # ===== 2. 计算字幕位置 =====
        subtitle_bottom_y = None

        # 从缓存获取
        subtitle_region_cache = render_params.get('subtitle_region_cache', {})
        effective_ratio = _get_effective_subtitle_ratio(
            episode,
            subtitle_region_cache,
            render_params.get('project_subtitle_ratio'),
            "单次编码",
        )
        if effective_ratio is not None:
            subtitle_bottom_y = _resolve_subtitle_bottom_from_ratio(
                effective_ratio,
                video_height,
                f"单次编码缓存 EP{episode}",
            )

        # 无缓存时实时检测
        if subtitle_bottom_y is None:
            try:
                from scripts.preprocess.subtitle_detector import get_subtitle_bottom_y
                source_video_path = None
                if episode is not None:
                    video_dir = render_params.get('video_dir')
                    if video_dir:
                        import glob as _glob
                        candidates = _glob.glob(str(Path(video_dir) / "*.mp4"))
                        for c in sorted(candidates):
                            ep_num = _extract_episode_number_standalone(Path(c).name)
                            if ep_num == episode:
                                source_video_path = c
                                break

                detect_path = source_video_path if source_video_path else None
                if detect_path:
                    pixel_value = get_subtitle_bottom_y(detect_path, sample_frame_count=5)
                    if pixel_value is not None:
                        probe = run_command(
                            ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries', 'stream=height', '-of', 'csv=p=0', detect_path],
                            timeout=TimeoutConfig.FFPROBE_QUICK, retries=1
                        )
                        detect_height = int(probe.stdout.strip()) if probe else 0
                        if detect_height > 0:
                            y_ratio = pixel_value / detect_height
                            subtitle_bottom_y = _resolve_subtitle_bottom_from_ratio(
                                y_ratio,
                                video_height,
                                f"单次编码实时 EP{episode}",
                            )
                            logger.info(f"[单次编码] 字幕定位(实时): pixel={pixel_value}, ratio={y_ratio:.3f}")
            except Exception as e:
                logger.warning(f"[单次编码] 字幕检测失败: {e}")

        # ===== 3. 构建drawtext滤镜 =====
        # 计算字体大小（复用 video_overlay.py 的算法）
        is_landscape = video_width > video_height
        smaller_dimension = min(video_width, video_height)
        resolution_ratio = smaller_dimension / 360.0
        base_subtitle_size = int(18 * resolution_ratio)

        drama_title_font_size = int(base_subtitle_size * 0.95)
        disclaimer_font_size = int(base_subtitle_size * 0.85)
        # 确保偶数
        drama_title_font_size = drama_title_font_size if drama_title_font_size % 2 == 0 else drama_title_font_size + 1
        disclaimer_font_size = disclaimer_font_size if disclaimer_font_size % 2 == 0 else disclaimer_font_size + 1

        # 计算Y坐标（复用 video_overlay.py 的统一布局逻辑）
        # V21: 内置免责声明避让
        skip_disclaimer = False
        builtin_disclaimer_top_y = None
        bd_info = render_params.get('builtin_disclaimer_info')
        if bd_info is not None and bd_info.detected:
            skip_disclaimer = True
            if bd_info.video_height > 0 and bd_info.top_y is not None:
                builtin_disclaimer_top_y = int(bd_info.top_y * video_height / bd_info.video_height)

        layout = resolve_overlay_layout(
            video_height=video_height,
            video_width=video_width,
            drama_title_font_size=drama_title_font_size,
            disclaimer_font_size=disclaimer_font_size,
            subtitle_bottom_y=subtitle_bottom_y,
            drama_title_text=renderer.style.drama_title.text,
            disclaimer_text=renderer.style.disclaimer.text,
            skip_disclaimer=skip_disclaimer,
            builtin_disclaimer_top_y=builtin_disclaimer_top_y,
        )
        drama_title_x = layout.drama_title_x
        disclaimer_x = layout.disclaimer_x
        drama_title_y = layout.drama_title_y
        disclaimer_y = layout.disclaimer_y

        # 单行模式强制使用最短免责声明，避免与剧名重叠
        if layout.use_single_row:
            from .video_overlay.overlay_styles import SHORTEST_DISCLAIMER
            shortest = SHORTEST_DISCLAIMER
            if renderer.style.disclaimer.text != shortest:
                logger.info(f"[单次编码] 单行布局：免责声明切换为最短版本 → {shortest!r}")
                renderer.style.disclaimer.text = shortest

        # 查找字体
        font_path = renderer._find_font_file()

        # 构建drawtext滤镜
        drama_title_layer = TextLayer(
            text=renderer.style.drama_title.text,
            font_size=drama_title_font_size,
            font_color=renderer.style.drama_title.font_color,
            font_alpha=renderer.style.drama_title.font_alpha,
            border_color=renderer.style.drama_title.border_color,
            border_width=renderer.style.drama_title.border_width,
            shadow_color=renderer.style.drama_title.shadow_color,
            shadow_x=renderer.style.drama_title.shadow_x,
            shadow_y=renderer.style.drama_title.shadow_y,
            x=drama_title_x,
            y=drama_title_y
        )

        disclaimer_layer = TextLayer(
            text=renderer.style.disclaimer.text,
            font_size=disclaimer_font_size,
            font_color=renderer.style.disclaimer.font_color,
            font_alpha=renderer.style.disclaimer.font_alpha,
            border_color=renderer.style.disclaimer.border_color,
            border_width=renderer.style.disclaimer.border_width,
            shadow_color=renderer.style.disclaimer.shadow_color,
            shadow_x=renderer.style.disclaimer.shadow_x,
            shadow_y=renderer.style.disclaimer.shadow_y,
            x=disclaimer_x,
            y=disclaimer_y
        )

        dt1 = renderer._build_drawtext_filter(drama_title_layer, font_path)
        if layout.skip_disclaimer:
            result['drawtext_filters'] = dt1
            logger.info(f"[单次编码] drawtext: 剧名({drama_title_font_size}px), 跳过免责声明（内置）")
        else:
            dt2 = renderer._build_drawtext_filter(disclaimer_layer, font_path)
            result['drawtext_filters'] = f"{dt1},{dt2}"
            logger.info(f"[单次编码] drawtext: 剧名({drama_title_font_size}px) + 免责({disclaimer_font_size}px)")

    except Exception as e:
        import traceback
        logger.error(f"[单次编码] 花字参数构建失败: {e}")
        traceback.print_exc()

    return result


def _generate_overlay_png_standalone(
    video_width: int,
    video_height: int,
    project_name: str,
    render_params: dict,
    output_dir: Path
) -> Optional[str]:
    """生成倾斜角标PNG（独立函数）"""
    try:
        from .video_overlay.tilted_label import TiltedLabelConfig, TiltedLabelRenderer

        # 计算缩放参数
        smaller_dimension = min(video_width, video_height)
        resolution_ratio = smaller_dimension / 360.0
        scale_factor = resolution_ratio * 0.8

        original_font_size = 28
        original_box_height = 60
        original_corner_offset = 70

        scaled_font_size = int(original_font_size * scale_factor)
        scaled_box_height = int(original_box_height * scale_factor)
        scaled_corner_offset = int(original_corner_offset * scale_factor)

        scaled_font_size = scaled_font_size if scaled_font_size % 2 == 0 else scaled_font_size + 1
        scaled_corner_offset = scaled_corner_offset if scaled_corner_offset % 2 == 0 else scaled_corner_offset + 1

        # 创建配置
        config = TiltedLabelConfig(
            label_text="热门短剧",
            font_size=scaled_font_size,
            label_color="red@0.95",
            text_color="white",
            position=render_params.get('hot_drama_position', 'top-right'),
            box_height=scaled_box_height,
            corner_offset=scaled_corner_offset
        )

        renderer = TiltedLabelRenderer(config)

        # 生成PNG
        png_path = str(output_dir / f"overlay_{os.getpid()}_{hash(project_name)}.png")
        renderer._generate_png(png_path)

        return png_path

    except Exception as e:
        logger.warning(f"⚠️ 生成overlay PNG失败: {e}")
        return None


def _calculate_overlay_position(video_width: int, video_height: int, render_params: dict) -> tuple:
    """计算overlay位置"""
    position = render_params.get('hot_drama_position', 'top-right')

    smaller_dimension = min(video_width, video_height)
    resolution_ratio = smaller_dimension / 360.0
    scale_factor = resolution_ratio * 0.8

    original_corner_offset = 70
    scaled_corner_offset = int(original_corner_offset * scale_factor)
    scaled_corner_offset = scaled_corner_offset if scaled_corner_offset % 2 == 0 else scaled_corner_offset + 1

    if position == 'top-right':
        x = video_width - 200 - scaled_corner_offset  # 200 is canvas_half
        y = -32  # 倾斜角标向上偏移
    else:
        x = -32
        y = -32

    return x, y


def _build_drawtext_filters_standalone(
    video_width: int,
    video_height: int,
    project_name: str,
    render_params: dict
) -> List[str]:
    """构建drawtext滤镜列表（独立函数）"""
    filters = []

    # 计算字体大小
    smaller_dimension = min(video_width, video_height)
    resolution_ratio = smaller_dimension / 360.0
    base_subtitle_size = int(18 * resolution_ratio)

    drama_title_font_size = int(base_subtitle_size * 0.95)
    drama_title_font_size = drama_title_font_size if drama_title_font_size % 2 == 0 else drama_title_font_size + 1

    disclaimer_font_size = int(base_subtitle_size * 0.85)
    disclaimer_font_size = disclaimer_font_size if disclaimer_font_size % 2 == 0 else disclaimer_font_size + 1

    # 动态Y位置
    drama_title_y = f"h-{int(video_height * 0.15)}"
    disclaimer_y = f"h-{int(video_height * 0.06)}"

    # 查找字体
    font_path = "/System/Library/Fonts/Supplemental/Songti.ttc"
    if not Path(font_path).exists():
        font_path = "/System/Library/Fonts/PingFang.ttc"
    if not Path(font_path).exists():
        font_path = None

    # 剧名drawtext
    drama_title = f"《{project_name}》"
    drama_params = {
        'text': drama_title.replace('《', '\\《').replace('》', '\\》'),
        'fontsize': drama_title_font_size,
        'fontcolor': '#E6E6FA',
        'alpha': '1.0',
        'x': '(w-tw)/2',
        'y': drama_title_y,
        'borderw': 1.0,
        'bordercolor': '#000000',
        'shadowx': 1,
        'shadowy': 1,
        'shadowcolor': '#000000'
    }
    if font_path:
        drama_params['fontfile'] = font_path

    drama_str = 'drawtext=' + ':'.join(f"{k}='{v}'" if k in ['x', 'y', 'fontfile', 'text'] else f"{k}={v}" for k, v in drama_params.items())
    filters.append(drama_str)

    # 免责声明drawtext
    disclaimer = "本剧内容虚构 仅供娱乐参考"
    disc_params = {
        'text': disclaimer,
        'fontsize': disclaimer_font_size,
        'fontcolor': '#FFFFFF',
        'alpha': '0.7',
        'x': '(w-tw)/2',
        'y': disclaimer_y,
        'borderw': 0.5,
        'bordercolor': '#808080',
        'shadowx': 1,
        'shadowy': 1,
        'shadowcolor': '#000000'
    }
    if font_path:
        disc_params['fontfile'] = font_path

    disc_str = 'drawtext=' + ':'.join(f"{k}='{v}'" if k in ['x', 'y', 'fontfile'] else f"{k}={v}" for k, v in disc_params.items())
    filters.append(disc_str)

    return filters


# ============================================================================
# V16.1: 合并编码优化 - 一次完成裁剪+花字+结尾（保留作为fallback）
# ============================================================================

def _render_clip_unified_standalone(
    clip_index: int,
    clip_data: dict,
    render_params: dict
) -> Optional[str]:
    """V16.1 合并渲染：一次性完成裁剪+花字+结尾（单次编码）

    相比原来的3次编码，这个函数只进行1次编码，大幅提升渲染速度。

    Args:
        clip_index: 剪辑索引
        clip_data: 剪辑数据字典
        render_params: 渲染参数字典

    Returns:
        输出文件路径，失败返回None
    """
    import tempfile
    import math
    import shutil

    try:
        # 创建Clip对象
        clip = Clip(**clip_data)

        # 获取参数
        episode_durations = render_params['episode_durations']
        # V17.2: 使用原始总时长用于跨集计算（因为clip.start/end基于总时长）
        raw_episode_durations = render_params.get('raw_episode_durations', episode_durations)
        video_dir = Path(render_params['video_dir'])
        output_dir = Path(render_params['output_dir'])
        output_dir.mkdir(parents=True, exist_ok=True)

        project_name = render_params['project_name']
        add_overlay = render_params['add_overlay']
        add_ending = render_params['add_ending_clip'] and render_params['ending_videos']

        # 计算起始和结束时间（使用原始总时长，与result.json中的clip.start/end一致）
        cumulative_before_start = sum(
            raw_episode_durations[ep] for ep in sorted(raw_episode_durations.keys()) if ep < clip.episode
        )
        start_in_episode = clip.start - cumulative_before_start

        cumulative_before_end = sum(
            raw_episode_durations[ep] for ep in sorted(raw_episode_durations.keys()) if ep < clip.hookEpisode
        )
        end_in_episode = clip.end - cumulative_before_end

        # 生成最终输出文件名
        def format_time(seconds):
            if seconds < 60:
                return f"{int(seconds)}秒"
            else:
                mins = int(seconds // 60)
                secs = int(seconds % 60)
                return f"{mins}分{secs}秒"

        # 构建后缀
        suffix_parts = []
        if add_overlay:
            suffix_parts.append("带花字")
        if add_ending:
            suffix_parts.append("带结尾")
        suffix = "_" + "_".join(suffix_parts) if suffix_parts else ""

        date_str = datetime.now().strftime("%m%d")
        final_filename = f"LM-777457-{date_str}-[{project_name}]-第{clip.episode}集{format_time(start_in_episode)}_第{clip.hookEpisode}集{format_time(end_in_episode)}{suffix}.mp4"
        final_path = str(output_dir / final_filename)

        # ===== 查找视频文件 =====
        video_files = sorted(video_dir.glob("*.mp4"))

        def find_video_file(episode):
            for vf in video_files:
                ep_num = _extract_episode_number_standalone(vf.name)
                if ep_num == episode:
                    return vf
            return None

        # ===== 判断是否跨集 =====
        is_cross_episode = clip.episode != clip.hookEpisode

        # ===== 步骤1：准备裁剪的视频片段 =====
        temp_files = []

        if not is_cross_episode:
            # 不跨集：直接处理单个视频
            video_file = find_video_file(clip.episode)
            if not video_file:
                raise FileNotFoundError(f"找不到第{clip.episode}集视频")

            # 获取视频帧率
            fps = _get_video_fps_standalone(str(video_file))
            total_frames = math.ceil(end_in_episode * fps)

            # V16.3: 获取视频分辨率并计算输出分辨率
            probe_cmd = [
                'ffprobe', '-v', 'error',
                '-select_streams', 'v:0',
                '-show_entries', 'stream=width,height',
                '-of', 'csv=p=0', str(video_file)
            ]
            probe_result = run_command(probe_cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
            probe_output = probe_result.stdout.strip() if probe_result else ""
            if not probe_output or ',' not in probe_output:
                raise ValueError(f"无法获取视频分辨率: {video_file}")
            video_width, video_height = map(int, probe_output.split(','))
            output_width, output_height = _get_output_resolution(video_width, video_height)
            need_scale = (output_width != video_width or output_height != video_height)
            if need_scale:
                logger.info(f"📐 分辨率自适应: {video_width}x{video_height} → {output_width}x{output_height}")

            # 裁剪后的临时文件
            temp_trim = output_dir / f"temp_trim_{os.getpid()}_{clip_index}.mp4"
            temp_files.append(temp_trim)

            # V18.8: 裁剪时同时进行分辨率缩放（保底720p）并保证码率
            if need_scale:
                # 使用filter_complex同时进行裁剪和缩放
                trim_cmd = [
                    'ffmpeg', '-y',
                    '-ss', str(start_in_episode),
                    '-i', str(video_file),
                    '-t', str(end_in_episode - start_in_episode),
                    '-vf', f'scale={output_width}:{output_height}:flags=lanczos',
                    '-c:v', 'libx264',
                    '-crf', str(render_params['crf']),
                    '-preset', render_params['preset'],
                    '-b:v', '2500k',
                    '-maxrate', '5000k',
                    '-bufsize', '5000k',
                    '-c:a', 'aac', '-b:a', '128k',
                    str(temp_trim)
                ]
            else:
                trim_cmd = [
                    'ffmpeg', '-y',
                    '-ss', str(start_in_episode),
                    '-i', str(video_file),
                    '-t', str(end_in_episode - start_in_episode),
                    '-c:v', 'libx264',
                    '-crf', str(render_params['crf']),
                    '-preset', render_params['preset'],
                    '-b:v', '2500k',
                    '-maxrate', '5000k',
                    '-bufsize', '5000k',
                    '-c:a', 'aac', '-b:a', '128k',
                    str(temp_trim)
                ]
            result = run_command(
                trim_cmd,
                timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
                raise_on_error=True,
                error_msg="视频裁剪超时"
            )

            clip_input = str(temp_trim)

        else:
            # 跨集：需要拼接多个片段
            # 计算每个片段（使用原始总时长 + 有效时长限制）
            segments = _clip_to_segments_standalone(clip, raw_episode_durations, str(video_dir), episode_durations)

            segment_files = []
            temp_dir = output_dir / f"temp_segments_{os.getpid()}_{clip_index}"
            temp_dir.mkdir(exist_ok=True)

            # V16.3: 获取第一个视频的分辨率作为统一输出分辨率
            first_video_file = find_video_file(segments[0].episode)
            if first_video_file:
                probe_cmd = [
                    'ffprobe', '-v', 'error',
                    '-select_streams', 'v:0',
                    '-show_entries', 'stream=width,height',
                    '-of', 'csv=p=0', str(first_video_file)
                ]
                probe_result = run_command(probe_cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
                probe_output = probe_result.stdout.strip() if probe_result else ""
                if probe_output and ',' in probe_output:
                    video_width, video_height = map(int, probe_output.split(','))
                    output_width, output_height = _get_output_resolution(video_width, video_height)
                    need_scale = (output_width != video_width or output_height != video_height)
                    if need_scale:
                        logger.info(f"📐 分辨率自适应: {video_width}x{video_height} → {output_width}x{output_height}")
                else:
                    need_scale = False
            else:
                need_scale = False

            for i, segment in enumerate(segments):
                video_file = find_video_file(segment.episode)
                if not video_file:
                    raise FileNotFoundError(f"找不到第{segment.episode}集视频")

                fps = _get_video_fps_standalone(str(video_file))
                total_frames = math.ceil((segment.end - segment.start) * fps)

                seg_file = temp_dir / f"segment_{i}.mp4"
                segment_files.append(str(seg_file))
                temp_files.append(seg_file)

                # V18.8: 裁剪时统一缩放到相同的输出分辨率并保证码率
                if need_scale:
                    seg_cmd = [
                        'ffmpeg', '-y',
                        '-ss', str(segment.start),
                        '-i', str(video_file),
                        '-t', str(segment.end - segment.start),
                        '-vf', f'scale={output_width}:{output_height}:flags=lanczos',
                        '-c:v', 'libx264',
                        '-crf', str(render_params['crf']),
                        '-preset', render_params['preset'],
                        '-b:v', '2500k',
                        '-maxrate', '5000k',
                        '-bufsize', '5000k',
                        '-c:a', 'aac', '-b:a', '128k',
                        str(seg_file)
                    ]
                else:
                    seg_cmd = [
                        'ffmpeg', '-y',
                        '-ss', str(segment.start),
                        '-i', str(video_file),
                        '-t', str(segment.end - segment.start),
                        '-c:v', 'libx264',
                        '-crf', str(render_params['crf']),
                        '-preset', render_params['preset'],
                        '-b:v', '2500k',
                        '-maxrate', '5000k',
                        '-bufsize', '5000k',
                        '-c:a', 'aac', '-b:a', '128k',
                        str(seg_file)
                    ]
                result = run_command(
                    seg_cmd,
                    timeout=TimeoutConfig.FFMPEG_CLIP_RENDER,
                    raise_on_error=True,
                    error_msg=f"片段{i}裁剪超时"
                )

            # 拼接片段
            temp_concat = output_dir / f"temp_concat_{os.getpid()}_{clip_index}.mp4"
            temp_files.append(temp_concat)
            _concat_segments_standalone(segment_files, str(temp_concat), output_dir)

            # 清理segment文件和目录（使用shutil.rmtree处理非空目录）
            import shutil
            for sf in segment_files:
                try:
                    Path(sf).unlink()
                except:
                    pass
            try:
                shutil.rmtree(temp_dir)
            except:
                pass

            clip_input = str(temp_concat)

        # ===== 步骤2：应用花字叠加（如果启用）=====
        if add_overlay:
            # 使用 _apply_video_overlay_standalone，支持字幕区域缓存（subtitle_bottom_y）
            result = _apply_video_overlay_standalone(clip_input, render_params, episode=clip.episode)
            if result and result != clip_input:
                clip_input = result

        # ===== 步骤3：添加结尾视频（如果启用）=====
        if add_ending:
            # 随机选择结尾视频
            import random
            ending_video = random.choice(render_params['ending_videos'])

            # 预处理结尾视频（匹配分辨率和帧率）
            processed_ending = _preprocess_ending_video_standalone(clip_input, ending_video, render_params)
            temp_files.append(processed_ending)

            # 拼接
            _concat_videos_standalone([clip_input, processed_ending], final_path)

            # 删除中间文件
            Path(clip_input).unlink()
            Path(processed_ending).unlink()
        else:
            # 直接重命名
            shutil.move(clip_input, final_path)

        # ===== 清理所有临时文件 =====
        for tf in temp_files:
            if Path(tf).exists():
                Path(tf).unlink()

        return final_path

    except Exception as e:
        logger.error(f"[Worker] V16.1合并渲染失败: {e}")
        # 清理临时文件
        for tf in temp_files:
            try:
                if Path(tf).exists():
                    Path(tf).unlink()
            except:
                pass
        return None


def _get_video_fps_standalone(video_path: str) -> float:
    """获取视频帧率（独立函数）(V16新增)"""
    cmd = [
        'ffprobe',
        '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=r_frame_rate',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        video_path
    ]

    result = run_command(cmd, timeout=TimeoutConfig.FFPROBE_QUICK, retries=1)
    if result is None or result.returncode != 0:
        return 30.0

    fps_str = result.stdout.strip()
    if '/' in fps_str:
        num, den = fps_str.split('/')
        return float(num) / float(den)
    else:
        return float(fps_str)


def main():
    """命令行入口"""
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description='渲染AI短剧剪辑（V16: 支持并行渲染、花字叠加、结尾视频拼接和片尾检测）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 基础渲染（自动检测片尾，默认自动并行worker）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就

  # 并行渲染（指定worker数）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --parallel 8

  # 串行渲染（调试用）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --parallel 1

  # 不添加结尾视频
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --no-ending

  # 添加花字叠加
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --add-overlay

  # 指定花字样式
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --add-overlay --overlay-style gold_luxury

  # 强制重新检测片尾
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --force-detect

  # 跳过片尾检测（使用完整时长）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --skip-ending

  # V17: 启用视频压缩（默认压缩到100MB以内）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --compress

  # V17: 压缩到50MB以内（适合社交媒体分享）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --compress --compress-target 50

  # V17: 压缩到200MB以内（更高画质）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --compress --compress-target 200

  # 完整功能（片尾检测 + 结尾视频 + 花字叠加 + 并行渲染 + 视频压缩）
  python -m scripts.understand.render_clips data/analysis/百里将就 漫剧素材/百里将就 --add-ending --add-overlay --parallel 4 --compress
        '''
    )

    parser.add_argument('project_path', help='项目路径（包含result.json）')
    parser.add_argument('video_dir', nargs='?', help='视频文件目录（可选，默认为项目路径）')

    # V14: 结尾视频参数
    parser.add_argument('--add-ending', action='store_true', help='添加随机结尾视频（默认启用）')
    parser.add_argument('--no-ending', action='store_true', help='不添加结尾视频')

    # V14.1: 片尾检测参数
    parser.add_argument('--auto-detect-ending', action='store_true', help='自动检测片尾（默认启用）')
    parser.add_argument('--skip-ending', action='store_true', help='跳过片尾检测，使用完整时长')
    parser.add_argument('--force-detect', action='store_true', help='强制重新检测片尾（覆盖缓存）')

    # V15: 花字叠加参数（V17默认启用）
    parser.add_argument('--add-overlay', action='store_true', default=True, help='添加花字叠加（默认启用）')
    parser.add_argument('--no-overlay', action='store_true', help='禁用花字叠加')
    parser.add_argument('--overlay-style', type=str, help='花字样式ID（默认随机选择）')

    # V16: 并行渲染参数
    # V17.6: 默认值改为1，强制串行渲染（并行模式实际更慢）
    parser.add_argument('--parallel', type=int, default=1,
                        help='并行渲染的worker数量（默认1=串行渲染）')

    # V16.2: 性能优化参数
    # V19: macOS 默认启用 VideoToolbox 硬件加速
    import platform as _platform
    _default_hwaccel = (_platform.system() == 'Darwin')
    parser.add_argument('--hwaccel', action='store_true', default=_default_hwaccel,
                        help='启用GPU硬件加速（macOS默认启用videotoolbox, Linux: cuda）')
    parser.add_argument('--no-hwaccel', dest='hwaccel', action='store_false',
                        help='禁用GPU硬件加速')
    parser.add_argument('--fast-preset', action='store_true',
                        help='使用ultrafast预设（速度提升30%%，质量略降）')

    # 缓存清理参数
    parser.add_argument('--no-cleanup', action='store_true', help='渲染完成后跳过清理中间缓存')

    # V16.3: 结尾视频缓存参数
    parser.add_argument('--force-recache', action='store_true', help='强制重新缓存结尾视频（素材更新后使用）')

    # V15.7: 剪辑数量限制
    parser.add_argument('--max-clips', type=int, default=0, help='最多渲染的剪辑数量（0=全部渲染）')
    parser.add_argument('--clip-indices', type=str, default='', help='指定要渲染的剪辑索引（逗号分隔，如：0,2,7）')

    # V17: 视频压缩参数（V18.5: 默认启用）
    parser.add_argument('--compress', action='store_true', default=True, help='启用视频压缩（默认启用）')
    parser.add_argument('--no-compress', dest='compress', action='store_false', help='禁用视频压缩')
    parser.add_argument('--compress-target', type=int, default=100,
                       choices=[50, 100, 150, 200],
                       help='压缩目标大小（MB，默认100MB，可选50/100/150/200）')

    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")

    args = parser.parse_args()

    setup_logging(level=logging.DEBUG if args.verbose else logging.INFO)

    # 确定是否添加结尾视频 (V18: 默认启用)
    add_ending = True
    if args.no_ending:
        add_ending = False
    elif args.add_ending:
        add_ending = True

    # 确定片尾检测参数
    auto_detect_ending = args.auto_detect_ending
    skip_ending = args.skip_ending
    force_detect = args.force_detect

    # 如果没有指定任何选项，默认启用自动检测
    if not skip_ending and not force_detect:
        auto_detect_ending = True

    # V15: 花字叠加参数（V17默认启用）
    add_overlay = args.add_overlay
    if args.no_overlay:
        add_overlay = False
    overlay_style = args.overlay_style

    project_path = args.project_path
    video_dir = args.video_dir

    # 从项目路径提取项目名称
    project_name = Path(project_path).name

    # 新的输出目录：clips/{项目名}/
    output_dir = f"clips/{project_name}"

    # 创建渲染器
    renderer = ClipRenderer(
        project_path=project_path,
        output_dir=output_dir,
        video_dir=video_dir,
        project_name=project_name,
        add_ending_clip=add_ending,       # V14: 传递结尾视频配置
        auto_detect_ending=auto_detect_ending,  # V14.1: 传递片尾检测配置
        skip_ending=skip_ending,
        force_detect=force_detect,
        add_overlay=add_overlay,          # V15: 传递花字叠加配置
        overlay_style_id=overlay_style,   # V15: 传递花字样式
        hwaccel=args.hwaccel,             # V16.2: GPU硬件加速
        fast_preset=args.fast_preset,     # V16.2: 快速预设
        force_recache=args.force_recache,  # V16.3: 强制重新缓存结尾视频
        compress=args.compress,            # V17: 视频压缩
        compress_target_mb=args.compress_target  # V17: 压缩目标大小
    )

    # 显示配置信息
    logger.info(f"{'='*60}")
    logger.info(f"项目名称: {project_name}")
    logger.info(f"项目路径: {project_path}")
    logger.info(f"输出目录: {output_dir}")
    logger.info(f"结尾视频拼接: {'✅ 启用' if add_ending else '❌ 禁用'}")
    logger.info(f"片尾检测: {'✅ 自动检测' if auto_detect_ending else '⚠️ 跳过' if skip_ending else '✅ 正常'}")
    logger.info(f"花字叠加: {'✅ 启用' if add_overlay else '❌ 禁用'}")
    # V17: 显示压缩配置
    logger.info(f"视频压缩: {'✅ 启用 (目标 {}MB)'.format(args.compress_target) if args.compress else '❌ 禁用'}")
    if overlay_style:
        logger.info(f"花字样式: {overlay_style}")
    if force_detect:
        logger.info(f"片尾检测模式: 🔃 强制重新检测")
    # V16.3: 智能Worker数计算
    # 0表示自动计算，1表示禁用并行，>1表示使用指定值
    parallel_workers = args.parallel
    if parallel_workers == 0:
        # 自动计算最优worker数
        parallel_workers = _get_optimal_workers(args.hwaccel)
        auto_calculated = True
    else:
        auto_calculated = False

    # V16: 显示并行配置
    if parallel_workers > 1:
        source = "（自动计算）" if auto_calculated else ""
        logger.info(f"渲染模式: ⚡ 并行（{parallel_workers} 个worker{source}）")
    else:
        logger.info(f"渲染模式: 🐢 串行（调试模式）")

    # V17.7: 显示硬件加速配置
    if args.hwaccel:
        # 检测是否真正启用了硬件加速
        test_config = _detect_gpu_encoder()
        if test_config:
            logger.info(f"硬件加速: 🎮 {test_config['name']} (启用)")
        else:
            logger.warning(f"硬件加速: ⚠️ 未检测到可用GPU，回退到CPU编码")
    else:
        logger.info(f"硬件加速: ❌ 禁用 (使用CPU编码)")
    logger.info(f"{'='*60}")

    # 渲染所有剪辑
    def on_progress(current: int, total: int, progress: float):
        """进度回调"""
        percent = progress * 100
        print(f"\r进度: [{current}/{total}] {percent:.1f}%", end='', flush=True)

    # V15.7: 解析剪辑索引参数
    clip_indices = None
    if args.clip_indices:
        try:
            clip_indices = [int(x.strip()) for x in args.clip_indices.split(',')]
            logger.info(f"指定渲染剪辑索引: {clip_indices}")
        except ValueError:
            logger.warning(f"⚠️ 无效的剪辑索引格式: {args.clip_indices}")

    # V16: 根据parallel参数选择渲染模式
    if parallel_workers > 1:
        output_paths = renderer.render_all_clips_parallel(
            max_workers=parallel_workers,
            on_clip_progress=on_progress,
            max_clips=args.max_clips,
            clip_indices=clip_indices
        )
    else:
        output_paths = renderer.render_all_clips(
            on_clip_progress=on_progress,
            max_clips=args.max_clips,
            clip_indices=clip_indices
        )

    logger.info(f"完成！输出文件:")
    for path in output_paths:
        logger.info(f"- {path}")

    # 渲染完成后清理中间缓存
    if not args.no_cleanup:
        logger.info(f"清理项目 {project_name} 的中间缓存（仅清理超过3小时的缓存）...")
        cleanup_result = cleanup_project_cache(project_name)
        logger.info(f"已清理: 关键帧={cleanup_result['keyframes_cleaned']}, "
                    f"音频={cleanup_result['audio_cleaned']}, "
                    f"ASR={cleanup_result['asr_cleaned']}")
        if cleanup_result['skipped'] > 0:
            logger.info(f"⏭️  跳过（未到3小时）: {cleanup_result['skipped']} 个文件")
        logger.info(f"释放空间: {cleanup_result['total_size_freed_mb']:.2f} MB")


if __name__ == "__main__":
    main()
