"""
Rerender 5 projects with fixed overlay logic + upload to Baidu Pan + email notifications.

Usage:
    python -m scripts.rerender_5projects
"""
import json
import logging
import shutil
import sys
import time
from pathlib import Path

from scripts.log_config import setup_logging, get_logger
from scripts.batch_pipeline_324 import (
    run_render_clips,
    upload_to_baidu,
    send_progress_email,
    send_final_email,
    PROJECT_ROOT,
    CLIPS_DIR,
)

logger = get_logger(__name__)

PROJECTS = [
    {"name": "餐冷情亦淡", "source_dir": PROJECT_ROOT / "3.24漫剧素材2", "baidu_base": "/AI-Drama-Clips/3.24漫剧素材2"},
    {"name": "台风劫后重生,我将逆转结局", "source_dir": PROJECT_ROOT / "3.24漫剧素材2", "baidu_base": "/AI-Drama-Clips/3.24漫剧素材2"},
    {"name": "重生拒绝恋爱脑后我转身嫁给总裁", "source_dir": PROJECT_ROOT / "3.24漫剧素材1", "baidu_base": "/AI-Drama-Clips/3.24漫剧素材1"},
    {"name": "混沌仙棺：废柴被拒婚后逆天改命", "source_dir": PROJECT_ROOT / "3.24漫剧素材2", "baidu_base": "/AI-Drama-Clips/3.24漫剧素材2"},
    {"name": "我在国际会议现场，被开除了", "source_dir": PROJECT_ROOT / "3.24漫剧素材2", "baidu_base": "/AI-Drama-Clips/3.24漫剧素材2"},
]


def clear_old_clips(project_name: str):
    """Delete old rendered clips and upload records so re-render is fresh."""
    clips_path = CLIPS_DIR / project_name
    if clips_path.exists():
        count = len(list(clips_path.glob("*.mp4")))
        shutil.rmtree(clips_path)
        logger.info(f"[清理] 删除旧剪辑: {project_name} ({count} files)")

    # Clear upload progress record
    upload_record = PROJECT_ROOT / ".progress" / f"uploaded_{project_name}.json"
    if upload_record.exists():
        upload_record.unlink()
        logger.info(f"[清理] 删除上传记录: {project_name}")


def main():
    setup_logging(level=logging.DEBUG)
    logger.info("=" * 60)
    logger.info("V23.3 花字修复 - 5个项目重渲染+上传")
    logger.info("修复内容: 字幕检测噪声过滤 + 剧名不截断 + 免责声明不跳过")
    logger.info("=" * 60)

    total = len(PROJECTS)
    all_results = []
    pipeline_start = time.time()

    for idx, proj in enumerate(PROJECTS, 1):
        name = proj["name"]
        start = time.time()
        logger.info(f"\n{'='*60}")
        logger.info(f"[{idx}/{total}] {name}")
        logger.info(f"{'='*60}")

        # Step 1: Clear old clips
        clear_old_clips(name)

        # Step 2: Re-render
        clips_count = run_render_clips(name, proj["source_dir"])
        elapsed = time.time() - start

        if clips_count == 0:
            result = {
                "name": name,
                "status": "failed",
                "clips": 0,
                "elapsed": elapsed,
                "error": "render failed",
            }
            all_results.append(result)
            send_progress_email(name, idx, total, 0, {}, elapsed, all_results)
            continue

        # Step 3: Upload to Baidu Pan
        logger.info(f"[上传] 开始上传: {name}")
        upload_result = upload_to_baidu(name, proj["baidu_base"])
        elapsed = time.time() - start

        result = {
            "name": name,
            "status": "success",
            "clips": clips_count,
            "elapsed": elapsed,
            "share_link": upload_result.get("share_link", ""),
            "share_pwd": upload_result.get("share_pwd", ""),
        }
        all_results.append(result)

        # Step 4: Send email notification
        send_progress_email(name, idx, total, clips_count, upload_result, elapsed, all_results)
        logger.info(f"[完成] {name}: {clips_count} clips, {elapsed/60:.1f}min")

    # Final summary email
    total_time = time.time() - pipeline_start
    send_final_email(all_results, total_time, total)

    logger.info(f"\n{'='*60}")
    logger.info(f"全部完成! 耗时 {total_time/60:.1f} 分钟")
    for r in all_results:
        status = "OK" if r["status"] == "success" else "FAIL"
        logger.info(f"  [{status}] {r['name']}: {r.get('clips', 0)} clips")
    logger.info(f"{'='*60}")


if __name__ == "__main__":
    main()
