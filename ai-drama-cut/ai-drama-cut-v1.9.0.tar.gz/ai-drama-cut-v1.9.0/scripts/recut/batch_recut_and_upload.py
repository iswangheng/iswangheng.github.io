"""
Batch recut pipeline: recut all projects → upload to Baidu Pan → email notification.

Usage:
    python -m scripts.recut.batch_recut_and_upload "测试二创"
"""
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import List, Dict

from scripts.log_config import setup_logging, get_logger
from scripts.recut.recut_main import process_video, scan_videos

logger = get_logger(__name__)


def _collect_output_files(output_dir: str) -> List[Path]:
    """Collect all rendered mp4 files from output directory."""
    out = Path(output_dir)
    if not out.exists():
        return []
    return sorted(out.glob("*.mp4"))


def _upload_to_baidu(files: List[Path], remote_base: str) -> Dict:
    """Upload files to Baidu Pan. Returns summary dict."""
    from scripts.baidu_pan.config import BaiduPanConfig
    from scripts.baidu_pan.client import BaiduPanClient

    config = BaiduPanConfig()
    valid, msg = config.validate()
    if not valid:
        logger.error(f"百度网盘配置无效: {msg}")
        return {"success": False, "error": msg}

    client = BaiduPanClient(config)

    uploaded = []
    failed = []
    fs_ids = []

    for f in files:
        remote_path = f"{remote_base}/{f.name}"
        try:
            result = client.upload_file(f, remote_path)
            fs_id = result.get("fs_id")
            uploaded.append({"file": f.name, "fs_id": fs_id, "size_mb": round(f.stat().st_size / 1024 / 1024, 1)})
            if fs_id:
                fs_ids.append(fs_id)
            logger.info(f"  上传成功: {f.name} (fs_id={fs_id})")
        except Exception as e:
            failed.append({"file": f.name, "error": str(e)})
            logger.error(f"  上传失败: {f.name}: {e}")

    # Create share link if any files uploaded
    share_info = {}
    if fs_ids:
        try:
            share_info = client.create_share_link(fs_ids, period=7)
            logger.info(f"  分享链接: {share_info.get('link')} 提取码: {share_info.get('pwd')}")
        except Exception as e:
            logger.error(f"  创建分享链接失败: {e}")

    return {
        "success": len(failed) == 0,
        "uploaded": len(uploaded),
        "failed": len(failed),
        "fs_ids": fs_ids,
        "share_link": share_info.get("link", ""),
        "share_pwd": share_info.get("pwd", ""),
        "details": uploaded,
        "errors": failed,
    }


def _send_email_report(projects_summary: List[Dict], upload_result: Dict, total_time: float):
    """Send email report with results."""
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from scripts.rpa.config import (
        ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
        ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
    )

    total_clips = sum(p["clips"] for p in projects_summary)
    total_videos = sum(p["videos"] for p in projects_summary)

    subject = f"Recut 二创完成: {total_clips}个短版本 (ASR对齐修复版)"
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

    # Build plain text
    lines = [
        f"Recut 二创批量处理完成",
        f"时间: {timestamp}",
        f"总计: {total_videos} 个视频 -> {total_clips} 个短版本",
        f"总耗时: {total_time / 60:.1f} 分钟",
        "",
    ]
    for p in projects_summary:
        lines.append(f"  {p['name']}: {p['videos']}个视频 -> {p['clips']}个短版本")
    lines.append("")

    if upload_result.get("share_link"):
        lines.append(f"百度网盘分享链接: {upload_result['share_link']}")
        lines.append(f"提取码: {upload_result['share_pwd']}")
        lines.append(f"上传: {upload_result['uploaded']} 成功, {upload_result['failed']} 失败")
    else:
        lines.append("百度网盘上传失败或未执行")

    if upload_result.get("errors"):
        lines.append("\n上传失败文件:")
        for err in upload_result["errors"]:
            lines.append(f"  - {err['file']}: {err['error']}")

    lines.append(f"\n本次改进: 修复钩子点切在句子中间的问题，集成ASR时间戳对齐")
    body = "\n".join(lines)

    if not ALERT_EMAIL_SMTP_PASSWORD:
        logger.warning(f"SMTP 密码未配置，邮件无法发送。内容:\n{body}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        logger.info(f"邮件已发送: {subject} -> {ALERT_EMAIL_TO}")
    except Exception as e:
        logger.error(f"邮件发送失败: {e}")
        logger.info(f"邮件内容:\n{body}")


def main():
    setup_logging(level=logging.INFO)

    input_dir = sys.argv[1] if len(sys.argv) > 1 else "测试二创"
    base_path = Path(input_dir)

    if not base_path.exists():
        logger.error(f"目录不存在: {input_dir}")
        sys.exit(1)

    # Discover projects (subdirectories with mp4 files)
    projects = sorted([
        d for d in base_path.iterdir()
        if d.is_dir() and any(d.glob("*.mp4"))
    ])

    if not projects:
        logger.error(f"未找到包含视频的子目录: {input_dir}")
        sys.exit(1)

    logger.info(f"{'='*60}")
    logger.info(f"Recut 二创批量处理 (ASR对齐修复版)")
    logger.info(f"{'='*60}")
    logger.info(f"项目数: {len(projects)}")
    for p in projects:
        video_count = len(list(p.glob("*.mp4")))
        logger.info(f"  {p.name}: {video_count} 个视频")
    logger.info("")

    total_start = time.time()
    all_results = []
    projects_summary = []
    output_dirs = []

    for proj_idx, project_dir in enumerate(projects, 1):
        project_name = project_dir.name
        output_dir = os.path.join("clips", "recut", project_name)
        output_dirs.append(output_dir)
        os.makedirs(output_dir, exist_ok=True)

        videos = scan_videos(str(project_dir))
        logger.info(f"\n{'='*60}")
        logger.info(f"[{proj_idx}/{len(projects)}] {project_name} ({len(videos)} 个视频)")
        logger.info(f"{'='*60}")

        proj_results = []
        for vid_idx, video_path in enumerate(videos, 1):
            logger.info(f"\n--- [{vid_idx}/{len(videos)}] {Path(video_path).name} ---")
            try:
                results = process_video(
                    video_path=video_path,
                    output_dir=output_dir,
                    max_clips=3,
                    min_duration=60,
                    add_badge=True,
                    add_ending=True,
                    project_name=project_name,
                )
                proj_results.extend(results)
            except Exception as e:
                logger.error(f"处理失败: {e}", exc_info=True)

        # Save per-project result.json
        result_path = os.path.join(output_dir, "result.json")
        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump({"project": project_name, "clips": proj_results}, f, ensure_ascii=False, indent=2)

        projects_summary.append({
            "name": project_name,
            "videos": len(videos),
            "clips": len(proj_results),
        })
        all_results.extend(proj_results)
        logger.info(f"\n{project_name}: {len(videos)} 个视频 → {len(proj_results)} 个短版本")

    recut_time = time.time() - total_start
    logger.info(f"\n{'='*60}")
    logger.info(f"Recut 完成: {len(all_results)} 个短版本, 耗时 {recut_time/60:.1f} 分钟")
    logger.info(f"{'='*60}")

    # Collect all output files
    all_files = []
    for d in output_dirs:
        all_files.extend(_collect_output_files(d))

    if not all_files:
        logger.error("没有生成任何输出文件，跳过上传")
        return

    logger.info(f"\n共 {len(all_files)} 个文件待上传")

    # Upload to Baidu Pan
    logger.info(f"\n{'='*60}")
    logger.info("上传到百度网盘...")
    logger.info(f"{'='*60}")

    today = time.strftime("%m%d")
    remote_base = f"/AI-Drama-Downloads/recut-{today}"
    upload_result = _upload_to_baidu(all_files, remote_base)

    # Save upload record
    record_path = "temp/recut_fs_ids.json"
    os.makedirs("temp", exist_ok=True)
    with open(record_path, 'w', encoding='utf-8') as f:
        json.dump(upload_result, f, ensure_ascii=False, indent=2)
    logger.info(f"上传记录: {record_path}")

    total_time = time.time() - total_start

    # Send email
    logger.info(f"\n{'='*60}")
    logger.info("发送邮件通知...")
    logger.info(f"{'='*60}")

    try:
        _send_email_report(projects_summary, upload_result, total_time)
    except Exception as e:
        logger.error(f"邮件发送失败: {e}", exc_info=True)

    # Final summary
    logger.info(f"\n{'='*60}")
    logger.info(f"全部完成!")
    logger.info(f"  Recut: {len(all_results)} 个短版本")
    logger.info(f"  上传: {upload_result.get('uploaded', 0)} 成功, {upload_result.get('failed', 0)} 失败")
    if upload_result.get("share_link"):
        logger.info(f"  分享: {upload_result['share_link']} 提取码: {upload_result['share_pwd']}")
    logger.info(f"  总耗时: {total_time/60:.1f} 分钟")
    logger.info(f"{'='*60}")


if __name__ == "__main__":
    main()
