"""
3.24 batch pipeline: video_understand + render_clips + upload to Baidu Pan + email report.

Usage:
    python -m scripts.batch_pipeline_324
"""
import json
import logging
import os
import smtplib
import subprocess
import sys
import threading
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Dict, List

from scripts.log_config import setup_logging, get_logger

logger = get_logger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIRS = [
    PROJECT_ROOT / "3.24漫剧素材1",
    PROJECT_ROOT / "3.24漫剧素材2",
]
CLIPS_DIR = PROJECT_ROOT / "clips"
ANALYSIS_DIR = PROJECT_ROOT / "data" / "analysis"
MAX_CLIPS = 20
BAIDU_REMOTE_BASE = "/AI-Drama-Clips"


def get_all_projects() -> List[Dict]:
    """Get all project directories across all source dirs.
    Returns list of {"name": str, "source_dir": Path, "baidu_base": str}."""
    projects = []
    for source_dir in SOURCE_DIRS:
        if not source_dir.exists():
            continue
        batch_name = source_dir.name  # e.g. "3.24漫剧素材1"
        for d in sorted(source_dir.iterdir()):
            if d.is_dir() and not d.name.startswith("."):
                videos = list(d.glob("*.mp4")) + list(d.glob("*.MP4"))
                if videos:
                    projects.append({
                        "name": d.name,
                        "source_dir": source_dir,
                        "baidu_base": f"{BAIDU_REMOTE_BASE}/{batch_name}",
                    })
                else:
                    logger.warning(f"跳过无视频项目: {d.name}")
    return projects


def has_result_json(project_name: str) -> bool:
    """Check if result.json already exists for a project."""
    result_file = ANALYSIS_DIR / project_name / "result.json"
    return result_file.exists()


def has_rendered_clips(project_name: str) -> int:
    """Check if clips already exist. Returns count (excluding temp files)."""
    clips_path = CLIPS_DIR / project_name
    if clips_path.exists():
        return len([f for f in clips_path.glob("*.mp4") if not f.name.startswith("temp")])
    return 0


def run_video_understand(project_name: str, source_dir: Path) -> bool:
    """Run video understanding pipeline. Returns True if result.json exists after."""
    # Skip if already analyzed
    if has_result_json(project_name):
        logger.info(f"[理解] 已有 result.json，跳过分析: {project_name}")
        return True

    project_path = str(source_dir / project_name)
    cmd = [
        sys.executable, "-m", "scripts.understand.video_understand",
        project_path,
    ]
    logger.info(f"[理解] 开始分析: {project_name}")

    try:
        result = subprocess.run(
            cmd, cwd=str(PROJECT_ROOT),
            capture_output=True, text=True, timeout=7200,
        )
        if result.returncode != 0:
            # Check if result.json was generated despite non-zero exit
            if has_result_json(project_name):
                logger.warning(f"[理解] 进程退出码非零({result.returncode})，但 result.json 已生成，视为成功: {project_name}")
                return True
            stderr_tail = (result.stderr or "")[-500:]
            logger.error(f"[理解] 分析失败: {project_name} (exit={result.returncode})\n  stderr: {stderr_tail}")
            return False
    except subprocess.TimeoutExpired:
        logger.error(f"[理解] 分析超时(2h): {project_name}")
        if has_result_json(project_name):
            return True
        return False

    logger.info(f"[理解] 分析完成: {project_name}")
    return True


def run_render_clips(project_name: str, source_dir: Path) -> int:
    """Render clips. Returns number of clips rendered."""
    # Skip only if already reached MAX_CLIPS
    existing = has_rendered_clips(project_name)
    if existing >= MAX_CLIPS:
        logger.info(f"[渲染] 已有 {existing} 个剪辑(>={MAX_CLIPS})，跳过渲染: {project_name}")
        return existing

    result_file = ANALYSIS_DIR / project_name / "result.json"
    if not result_file.exists():
        logger.error(f"[渲染] result.json 不存在: {result_file}")
        return 0

    analysis_path = str(ANALYSIS_DIR / project_name)
    video_dir = str(source_dir / project_name)

    cmd = [
        sys.executable, "-m", "scripts.understand.render_clips",
        analysis_path, video_dir,
        "--max-clips", str(MAX_CLIPS),
    ]
    logger.info(f"[渲染] 开始渲染: {project_name} (最多{MAX_CLIPS}个)")

    try:
        result = subprocess.run(
            cmd, cwd=str(PROJECT_ROOT),
            capture_output=True, text=True, timeout=7200,
        )
        if result.returncode != 0:
            # Check if clips were generated despite error
            count = has_rendered_clips(project_name)
            if count > 0:
                logger.warning(f"[渲染] 退出码非零({result.returncode})，但已生成 {count} 个剪辑: {project_name}")
                return count
            stderr_tail = (result.stderr or "")[-500:]
            logger.error(f"[渲染] 渲染失败: {project_name} (exit={result.returncode})\n  stderr: {stderr_tail}")
            return 0
    except subprocess.TimeoutExpired:
        count = has_rendered_clips(project_name)
        if count > 0:
            logger.warning(f"[渲染] 超时但已生成 {count} 个剪辑: {project_name}")
            return count
        logger.error(f"[渲染] 渲染超时(2h): {project_name}")
        return 0

    # Clean up temp files left by render process
    clips_path = CLIPS_DIR / project_name
    if clips_path.exists():
        for tmp in clips_path.glob("temp*.mp4"):
            tmp.unlink(missing_ok=True)
            logger.info(f"[渲染] 清理临时文件: {tmp.name}")
        for tmp_dir in clips_path.glob("temp_*"):
            if tmp_dir.is_dir():
                import shutil
                shutil.rmtree(tmp_dir, ignore_errors=True)
                logger.info(f"[渲染] 清理临时目录: {tmp_dir.name}")

    count = has_rendered_clips(project_name)
    logger.info(f"[渲染] 渲染完成: {project_name}, {count} 个剪辑")
    return count


def _load_uploaded_files(project_name: str) -> set:
    """Load set of already-uploaded filenames for a project."""
    record_file = PROJECT_ROOT / ".progress" / f"uploaded_{project_name}.json"
    if record_file.exists():
        return set(json.load(open(record_file, "r")))
    return set()


def _save_uploaded_file(project_name: str, filename: str):
    """Record a successfully uploaded filename."""
    record_file = PROJECT_ROOT / ".progress" / f"uploaded_{project_name}.json"
    existing = _load_uploaded_files(project_name)
    existing.add(filename)
    with open(record_file, "w") as f:
        json.dump(sorted(existing), f, ensure_ascii=False)


def upload_to_baidu(project_name: str, baidu_base: str) -> Dict:
    """Upload project clips to Baidu Pan. Skips already-uploaded files."""
    from scripts.baidu_pan.config import BaiduPanConfig
    from scripts.baidu_pan.client import BaiduPanClient

    clips_path = CLIPS_DIR / project_name
    if not clips_path.exists():
        return {"success": False, "error": "clips目录不存在", "uploaded": 0, "failed": 0}

    files = sorted([f for f in clips_path.glob("*.mp4") if not f.name.startswith("temp")])
    if not files:
        return {"success": False, "error": "无mp4文件", "uploaded": 0, "failed": 0}

    config = BaiduPanConfig()
    valid, msg = config.validate()
    if not valid:
        logger.error(f"百度网盘配置无效: {msg}")
        return {"success": False, "error": msg, "uploaded": 0, "failed": 0}

    client = BaiduPanClient(config)
    remote_base = f"{baidu_base}/{project_name}"

    # Skip already-uploaded files
    already_uploaded = _load_uploaded_files(project_name)
    to_upload = [f for f in files if f.name not in already_uploaded]
    skipped = len(files) - len(to_upload)
    if skipped > 0:
        logger.info(f"  跳过已上传: {skipped}个, 待上传: {len(to_upload)}个")

    uploaded = []
    failed = []
    fs_ids = []

    for f in to_upload:
        remote_path = f"{remote_base}/{f.name}"
        try:
            result = client.upload_file(f, remote_path)
            fs_id = result.get("fs_id")
            uploaded.append({"file": f.name, "fs_id": fs_id, "size_mb": round(f.stat().st_size / 1024 / 1024, 1)})
            if fs_id:
                fs_ids.append(fs_id)
            _save_uploaded_file(project_name, f.name)
            logger.info(f"  上传成功: {f.name} ({round(f.stat().st_size / 1024 / 1024, 1)}MB)")
        except Exception as e:
            failed.append({"file": f.name, "error": str(e)})
            logger.error(f"  上传失败: {f.name}: {e}")

    share_info = {}
    if fs_ids:
        try:
            share_info = client.create_share_link(fs_ids, period=7)
            logger.info(f"  分享链接: {share_info.get('link')} 提取码: {share_info.get('pwd')}")
        except Exception as e:
            logger.error(f"  创建分享链接失败: {e}")

    return {
        "success": len(failed) == 0,
        "uploaded": len(uploaded) + skipped,  # include previously uploaded
        "failed": len(failed),
        "fs_ids": fs_ids,
        "share_link": share_info.get("link", ""),
        "share_pwd": share_info.get("pwd", ""),
    }


def send_progress_email(project_name: str, project_idx: int, total_projects: int,
                         clips_count: int, upload_result: Dict, elapsed: float,
                         all_results: List[Dict]):
    """Send progress email after each project."""
    from scripts.rpa.config import (
        ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
        ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
    )

    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    completed = len([r for r in all_results if r["status"] == "success"])
    failed_count = len([r for r in all_results if r["status"] == "failed"])
    status_text = "成功" if clips_count > 0 else "失败"

    subject = f"[3.24素材] {completed}/{total_projects}完成 {project_name} {status_text} ({clips_count}个剪辑)"

    lines = [
        f"3.24批量剪辑进度报告",
        f"时间: {timestamp}",
        f"总进度: {completed}/{total_projects} 完成",
        f"",
        f"--- 本次: {project_name} ---",
        f"状态: {status_text}",
        f"剪辑数: {clips_count}",
        f"耗时: {elapsed / 60:.1f} 分钟",
    ]

    if upload_result.get("share_link"):
        lines.append(f"百度网盘: {upload_result['share_link']}")
        lines.append(f"提取码: {upload_result['share_pwd']}")
        lines.append(f"上传: {upload_result['uploaded']} 成功, {upload_result['failed']} 失败")
    elif upload_result.get("error"):
        lines.append(f"上传状态: {upload_result['error']}")
    elif upload_result.get("uploaded", 0) > 0:
        lines.append(f"上传: {upload_result['uploaded']} 成功 (分享链接创建失败)")

    lines.extend([
        "",
        f"--- 总体进度 ---",
        f"已完成: {completed} 成功, {failed_count} 失败, 剩余 {total_projects - project_idx}",
    ])

    for r in all_results:
        status = "OK" if r["status"] == "success" else "FAIL"
        lines.append(f"  [{status}] {r['name']}: {r.get('clips', 0)}个剪辑, {r.get('elapsed', 0) / 60:.1f}分钟")

    body = "\n".join(lines)

    if not ALERT_EMAIL_SMTP_PASSWORD:
        logger.warning(f"SMTP 密码未配置，邮件内容:\n{body}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        logger.info(f"进度邮件已发送: {subject}")
    except Exception as e:
        logger.error(f"邮件发送失败: {e}")


def send_final_email(all_results: List[Dict], total_time: float, total_projects: int):
    """Send final summary email."""
    from scripts.rpa.config import (
        ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
        ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
    )

    completed = len([r for r in all_results if r["status"] == "success"])
    failed_count = len([r for r in all_results if r["status"] == "failed"])
    total_clips = sum(r.get("clips", 0) for r in all_results)

    subject = f"[3.24素材] 全部完成: {completed}/{total_projects} 成功, 共{total_clips}个剪辑"

    lines = [
        f"3.24漫剧素材1 批量剪辑 - 最终报告",
        f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"总耗时: {total_time / 3600:.1f} 小时",
        f"",
        f"成功: {completed}, 失败: {failed_count}, 总剪辑: {total_clips}",
        f"",
        f"--- 详细结果 ---",
    ]

    for r in all_results:
        status = "OK" if r["status"] == "success" else "FAIL"
        share = ""
        if r.get("share_link"):
            share = f" | {r['share_link']} 提取码: {r['share_pwd']}"
        lines.append(f"  [{status}] {r['name']}: {r.get('clips', 0)}个剪辑, {r.get('elapsed', 0) / 60:.1f}分钟{share}")

    if failed_count > 0:
        lines.extend(["", "--- 失败项目 ---"])
        for r in all_results:
            if r["status"] == "failed":
                lines.append(f"  {r['name']}: {r.get('error', '未知错误')}")

    body = "\n".join(lines)

    if not ALERT_EMAIL_SMTP_PASSWORD:
        logger.warning(f"SMTP 密码未配置，邮件内容:\n{body}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        logger.info(f"最终报告邮件已发送: {subject}")
    except Exception as e:
        logger.error(f"邮件发送失败: {e}")


def save_progress(all_results: List[Dict]):
    """Save progress to JSON for resumption."""
    progress_file = PROJECT_ROOT / ".progress" / "batch_324.json"
    progress_file.parent.mkdir(parents=True, exist_ok=True)
    with open(progress_file, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)


def load_progress() -> List[Dict]:
    """Load progress from JSON."""
    progress_file = PROJECT_ROOT / ".progress" / "batch_324.json"
    if progress_file.exists():
        with open(progress_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def main():
    import queue

    setup_logging(level=logging.DEBUG)
    logger.info("=" * 60)
    logger.info("3.24批量剪辑流程启动 (v4 - 多批次三阶段流水线)")
    logger.info("=" * 60)

    projects = get_all_projects()
    total = len(projects)
    logger.info(f"共发现 {total} 个项目 (跨 {len(SOURCE_DIRS)} 个素材目录)")

    # Load existing progress
    existing = load_progress()
    done_names = {r["name"] for r in existing if r["status"] == "success"}
    all_results = [r for r in existing if r["status"] == "success"]
    progress_lock = threading.Lock()
    pipeline_start = time.time()

    # Stage status tracking (for heartbeat emails)
    stage_status = {
        "analyze": {"current": "", "done": 0},
        "render": {"current": "", "done": 0},
        "upload": {"current": "", "done": 0},
        "finished": False,
    }

    # --- Heartbeat: send status email every 10 minutes ---
    def heartbeat_worker():
        from scripts.rpa.config import (
            ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
            ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
        )
        INTERVAL = 600  # 10 minutes
        while not stage_status["finished"]:
            time.sleep(INTERVAL)
            if stage_status["finished"]:
                break

            with progress_lock:
                s = sum(1 for r in all_results if r["status"] == "success")
                f = sum(1 for r in all_results if r["status"] == "failed")
                tc = sum(r.get("clips", 0) for r in all_results)

            elapsed_h = (time.time() - pipeline_start) / 3600
            ts = time.strftime("%H:%M:%S")
            a_cur = stage_status["analyze"]["current"] or "空闲"
            r_cur = stage_status["render"]["current"] or "空闲"
            u_cur = stage_status["upload"]["current"] or "空闲"

            subject = f"[3.24素材] 心跳 {s}/40完成 已运行{elapsed_h:.1f}h"
            lines = [
                f"3.24批量剪辑 - 定时状态报告 ({ts})",
                f"已运行: {elapsed_h:.1f} 小时",
                f"",
                f"=== 总进度 ===",
                f"完成: {s}/40 ({f}失败), 共{tc}个剪辑",
                f"",
                f"=== 三阶段并行状态 ===",
                f"分析: {a_cur}",
                f"渲染: {r_cur}",
                f"上传: {u_cur}",
            ]
            body = "\n".join(lines)

            if not ALERT_EMAIL_SMTP_PASSWORD:
                logger.info(f"[心跳] {body}")
                continue

            try:
                msg = MIMEMultipart("alternative")
                msg["Subject"] = subject
                msg["From"] = ALERT_EMAIL_FROM
                msg["To"] = ALERT_EMAIL_TO
                msg.attach(MIMEText(body, "plain", "utf-8"))
                with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
                    server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
                    server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
                logger.info(f"[心跳] 状态邮件已发送: {subject}")
            except Exception as e:
                logger.error(f"[心跳] 邮件发送失败: {e}")

    heartbeat_thread = threading.Thread(target=heartbeat_worker, name="heartbeat", daemon=True)
    heartbeat_thread.start()

    # Build lookup: project_name -> project info
    proj_info = {p["name"]: p for p in projects}

    # Three-stage pipeline queues
    render_q = queue.Queue()   # items: (idx, name, source_dir, baidu_base, proj_start) or None
    upload_q = queue.Queue()   # items: (idx, name, baidu_base, clips_count, elapsed, entry) or None

    # --- Stage 2: Render worker ---
    def render_worker():
        while True:
            item = render_q.get()
            if item is None:
                upload_q.put(None)
                break
            idx, name, source_dir, baidu_base, proj_start = item
            stage_status["render"]["current"] = f"[{idx}/{total}] {name}"
            try:
                clips_count = run_render_clips(name, source_dir)
                stage_status["render"]["done"] += 1
                elapsed = time.time() - proj_start
                if clips_count == 0:
                    entry = {"name": name, "status": "failed", "clips": 0, "elapsed": elapsed, "error": "渲染产出 0 个剪辑"}
                    with progress_lock:
                        all_results.append(entry)
                        save_progress(all_results)
                    send_progress_email(name, idx, total, 0, {}, elapsed, all_results)
                else:
                    entry = {"name": name, "status": "success", "clips": clips_count, "elapsed": elapsed}
                    with progress_lock:
                        all_results.append(entry)
                        save_progress(all_results)
                    logger.info(f"[{idx}/{total}] {name} 渲染完成! {clips_count}个剪辑, {elapsed / 60:.1f}分钟")
                    upload_q.put((idx, name, baidu_base, clips_count, elapsed, entry))
            except Exception as e:
                elapsed = time.time() - proj_start
                entry = {"name": name, "status": "failed", "clips": 0, "elapsed": elapsed, "error": str(e)}
                with progress_lock:
                    all_results.append(entry)
                    save_progress(all_results)
                logger.error(f"[渲染] {name} 异常: {e}", exc_info=True)

    # --- Stage 3: Upload worker ---
    def upload_worker():
        while True:
            item = upload_q.get()
            if item is None:
                break
            idx, name, baidu_base, clips_count, elapsed, entry = item
            stage_status["upload"]["current"] = f"[{idx}/{total}] {name} ({clips_count}个文件)"
            try:
                logger.info(f"[上传] 开始: {name} ({clips_count}个文件)")
                upload_result = upload_to_baidu(name, baidu_base)
                with progress_lock:
                    entry.update({
                        "share_link": upload_result.get("share_link", ""),
                        "share_pwd": upload_result.get("share_pwd", ""),
                        "upload_success": upload_result.get("uploaded", 0),
                        "upload_failed": upload_result.get("failed", 0),
                    })
                    save_progress(all_results)
                send_progress_email(name, idx, total, clips_count, upload_result, elapsed, all_results)
                stage_status["upload"]["done"] += 1
                stage_status["upload"]["current"] = ""
                logger.info(f"[上传] 完成: {name}")
            except Exception as e:
                logger.error(f"[上传] {name} 异常: {e}")
                send_progress_email(name, idx, total, clips_count, {"error": str(e)}, elapsed, all_results)

    # Start stage 2 & 3 workers
    render_thread = threading.Thread(target=render_worker, name="render-worker", daemon=True)
    upload_thread = threading.Thread(target=upload_worker, name="upload-worker", daemon=True)
    render_thread.start()
    upload_thread.start()

    # --- Stage 0: Re-upload incomplete uploads from previous run ---
    for r in all_results:
        if r["status"] == "success" and not r.get("upload_success"):
            name = r["name"]
            clips_count = r.get("clips", 0)
            if clips_count > 0 and name in proj_info:
                baidu_base = proj_info[name]["baidu_base"]
                logger.info(f"[补传] 检测到未完成上传: {name} ({clips_count}个剪辑)")
                upload_q.put((0, name, baidu_base, clips_count, r.get("elapsed", 0), r))

    # --- Stage 1: Analyze (main thread) ---
    for idx, proj in enumerate(projects, 1):
        name = proj["name"]
        source_dir = proj["source_dir"]
        baidu_base = proj["baidu_base"]

        if name in done_names:
            logger.info(f"[{idx}/{total}] 跳过已完成: {name}")
            continue

        logger.info(f"")
        logger.info(f"{'=' * 60}")
        logger.info(f"[{idx}/{total}] [分析] 开始: {name} ({source_dir.name})")
        logger.info(f"{'=' * 60}")

        stage_status["analyze"]["current"] = f"[{idx}/{total}] {name}"
        proj_start = time.time()

        try:
            if not run_video_understand(name, source_dir):
                elapsed = time.time() - proj_start
                entry = {"name": name, "status": "failed", "clips": 0, "elapsed": elapsed, "error": "video_understand 失败"}
                with progress_lock:
                    all_results.append(entry)
                    save_progress(all_results)
                send_progress_email(name, idx, total, 0, {}, elapsed, all_results)
                continue

            # Push to render queue
            stage_status["analyze"]["done"] += 1
            logger.info(f"[{idx}/{total}] [分析] 完成: {name}, 推入渲染队列")
            render_q.put((idx, name, source_dir, baidu_base, proj_start))

        except Exception as e:
            elapsed = time.time() - proj_start
            entry = {"name": name, "status": "failed", "clips": 0, "elapsed": elapsed, "error": str(e)}
            with progress_lock:
                all_results.append(entry)
                save_progress(all_results)
            logger.error(f"[{idx}/{total}] {name} 分析异常: {e}", exc_info=True)
            send_progress_email(name, idx, total, 0, {"error": str(e)}, elapsed, all_results)

    # Signal end: analyze done -> render done -> upload done
    stage_status["analyze"]["current"] = "全部完成"
    render_q.put(None)
    logger.info("所有项目分析完成，等待渲染和上传队列清空...")
    render_thread.join()
    upload_thread.join()
    stage_status["finished"] = True

    # Final summary
    total_time = time.time() - pipeline_start
    completed = len([r for r in all_results if r["status"] == "success"])
    total_clips = sum(r.get("clips", 0) for r in all_results)

    logger.info(f"")
    logger.info(f"{'=' * 60}")
    logger.info(f"全部完成! 成功: {completed}/{total}, 总剪辑: {total_clips}, 总耗时: {total_time / 3600:.1f}小时")
    logger.info(f"{'=' * 60}")

    send_final_email(all_results, total_time, total)


if __name__ == "__main__":
    main()
