"""
Monitor batch_pipeline_324 progress. Send alert if process dies.

Usage:
    nohup python3 -m scripts.monitor_batch_324 &
"""
import json
import os
import smtplib
import sys
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROGRESS_FILE = PROJECT_ROOT / ".progress" / "batch_324.json"
PID_FILE = PROJECT_ROOT / ".progress" / "batch_324.pid"
TOTAL_PROJECTS = 28
CHECK_INTERVAL = 300  # 5 minutes


def is_process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def load_progress():
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, "r") as f:
            return json.load(f)
    return []


def send_alert(subject: str, body: str):
    from scripts.rpa.config import (
        ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
        ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
    )
    if not ALERT_EMAIL_SMTP_PASSWORD:
        print(f"[ALERT] {subject}\n{body}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        print(f"[ALERT] 邮件已发送: {subject}")
    except Exception as e:
        print(f"[ALERT] 邮件发送失败: {e}")


def main():
    print(f"监控启动 - 检查间隔 {CHECK_INTERVAL}秒")

    last_count = 0

    while True:
        time.sleep(CHECK_INTERVAL)

        progress = load_progress()
        current_count = len(progress)
        success = sum(1 for r in progress if r["status"] == "success")
        failed = sum(1 for r in progress if r["status"] == "failed")

        # Check if process is still alive
        pid = 0
        if PID_FILE.exists():
            pid = int(PID_FILE.read_text().strip())

        alive = is_process_alive(pid) if pid else False

        ts = time.strftime("%H:%M:%S")
        print(f"[{ts}] PID={pid} alive={alive} progress={current_count}/{TOTAL_PROJECTS} (success={success} failed={failed})")

        # Process died before completion
        if not alive and current_count < TOTAL_PROJECTS:
            body = (
                f"批量剪辑进程已停止！\n"
                f"PID: {pid}\n"
                f"进度: {current_count}/{TOTAL_PROJECTS}\n"
                f"成功: {success}, 失败: {failed}\n"
                f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"请检查 logs/batch_324_nohup.log 和 logs/app.log"
            )
            send_alert(f"[3.24素材] 警告: 批量流程异常停止 ({current_count}/{TOTAL_PROJECTS})", body)
            break

        # All done
        if current_count >= TOTAL_PROJECTS:
            print("全部完成，监控退出")
            break

        # Progress stalled (no new results in 30 minutes = 6 checks)
        if current_count == last_count:
            # Don't alert on first check
            pass

        last_count = current_count


if __name__ == "__main__":
    main()
