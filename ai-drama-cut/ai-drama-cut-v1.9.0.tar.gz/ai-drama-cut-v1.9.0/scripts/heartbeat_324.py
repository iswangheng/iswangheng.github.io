"""
Standalone heartbeat: send detailed status email every 30 minutes.
Does not interfere with the main pipeline.

Usage:
    nohup python3 -m scripts.heartbeat_324 &
"""
import json
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROGRESS_FILE = PROJECT_ROOT / ".progress" / "batch_324.json"
CLIPS_DIR = PROJECT_ROOT / "clips"
ANALYSIS_DIR = PROJECT_ROOT / "data" / "analysis"
INTERVAL = 1800  # 30 minutes
TOTAL = 40


def send_heartbeat():
    from scripts.rpa.config import (
        ALERT_EMAIL_TO, ALERT_EMAIL_FROM,
        ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, ALERT_EMAIL_SMTP_PASSWORD,
    )

    data = json.load(open(PROGRESS_FILE)) if PROGRESS_FILE.exists() else []
    s = sum(1 for r in data if r["status"] == "success")
    f = sum(1 for r in data if r["status"] == "failed")
    tc = sum(r.get("clips", 0) for r in data)
    up = sum(r.get("upload_success", 0) for r in data)

    ts = time.strftime("%Y-%m-%d %H:%M:%S")

    # Check incomplete projects
    incomplete = []
    for clips_dir in sorted(CLIPS_DIR.iterdir()) if CLIPS_DIR.exists() else []:
        if not clips_dir.is_dir():
            continue
        name = clips_dir.name
        rf = ANALYSIS_DIR / name / "result.json"
        if not rf.exists():
            continue
        planned = min(len(json.load(open(rf)).get("clips", [])), 20)
        actual = len([f for f in clips_dir.glob("*.mp4") if not f.name.startswith("temp")])
        if actual < planned:
            done_in_progress = any(r["name"] == name and r["status"] == "success" for r in data)
            incomplete.append((name, actual, planned, done_in_progress))

    subject = f"[3.24素材] 进展报告 {s}/40完成 共{tc}个剪辑"

    lines = [
        f"3.24批量剪辑 - 详细进展报告",
        f"时间: {ts}",
        f"",
        f"=== 总进度 ===",
        f"完成: {s}/{TOTAL} ({f}失败)",
        f"总剪辑: {tc}个, 已上传网盘: {up}个",
        f"",
    ]

    if incomplete:
        lines.append(f"=== 渲染不完整 ({len(incomplete)}个) ===")
        for name, actual, planned, done in incomplete:
            status = "已标记完成,需修复" if done else "排队中"
            lines.append(f"  {name}: {actual}/{planned}个 ({status})")
        lines.append("")

    lines.append(f"=== 已完成项目 ({s}个) ===")
    for r in data:
        if r["status"] == "success":
            up_count = r.get("upload_success", 0)
            lines.append(f"  {r['name']}: {r.get('clips',0)}个剪辑, 上传{up_count}个")

    if f > 0:
        lines.append(f"\n=== 失败项目 ({f}个) ===")
        for r in data:
            if r["status"] == "failed":
                lines.append(f"  {r['name']}: {r.get('error','')[:50]}")

    body = "\n".join(lines)

    if not ALERT_EMAIL_SMTP_PASSWORD:
        print(f"[heartbeat] SMTP未配置\n{body}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        print(f"[{ts}] 邮件已发送: {subject}")
    except Exception as e:
        print(f"[{ts}] 邮件发送失败: {e}")


def main():
    print(f"详细心跳启动 - 每{INTERVAL // 60}分钟发送一次")
    while True:
        try:
            send_heartbeat()
        except Exception as e:
            print(f"心跳异常: {e}")

        # Check if all done
        if PROGRESS_FILE.exists():
            data = json.load(open(PROGRESS_FILE))
            s = sum(1 for r in data if r["status"] == "success")
            if s >= TOTAL:
                print("全部完成，心跳退出")
                break

        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
