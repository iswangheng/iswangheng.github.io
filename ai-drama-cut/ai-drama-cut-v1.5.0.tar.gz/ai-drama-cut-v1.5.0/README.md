# AI 短剧剪辑服务 - OpenClaw Skill

面向 OpenClaw 的 AI 短剧剪辑 workflow。目标不是暴露底层脚本，而是提供一个更稳定、可观测、适合演示的 agent 工作流入口。

## 当前版本

- Skill: `1.5.0`
- 重点能力：合并远程runtime/orchestrator与本地性能优化、远程更新机制

## 快速开始

### 1. 安装依赖

```bash
cd openclaw
bash install.sh
```

### 2. 配置 API Key

```bash
python setup_api.py
```

### 3. 检查依赖

```bash
python check_dependencies.py
```

### 4. 开始剪辑

```bash
# 完整流程（预处理 → 分析 → 渲染）
python skill.py --input "../漫剧素材/项目名"

# 跳过预处理（视频已经干净）
python skill.py --input "../漫剧素材/项目名" --skip-preprocess

# 仅渲染（使用已有分析结果）
python skill.py --input "../漫剧素材/项目名" --render-only

# 演示模式
python skill.py --input "../漫剧素材/项目名" --skip-preprocess --demo-mode
```

## 这次改造后的重点

### 1. 运行时可观测性

- 开始前输出统一计划摘要
- 每个阶段持续输出状态更新
- 长任务有 heartbeat，避免“像死机”
- 结束时输出统一结果摘要

### 2. 恢复能力

- 复用 keyframes / ASR / subtitle region / analysis 缓存
- 复用或自动修复已有 `result.json`
- 根据现有输出做阶段级软 resume

### 3. 演示友好

- demo mode 优先稳定性与可讲述性
- 更快进入可见阶段更新
- 输出推荐先看的 clip 与演示摘要

## 运行阶段

标准流程分为三段：

1. 预处理
2. AI 分析
3. 渲染输出

每个阶段至少会输出：
- `stage`
- `status`
- `completed / total`
- `current_item`
- `message`
- `timestamp`

如果一段时间没有完成数变化，runtime 会输出 heartbeat，告诉用户系统仍在处理哪个对象。

## 输出结果

默认输出目录：

```text
clips/项目名/
```

结束摘要会包含：
- 生成数量
- 总耗时
- 输出目录
- 推荐优先查看的结果
- demo mode 下的演示话术素材

## 环境要求

- Python 3.8+
- FFmpeg（支持 `drawtext`）
- 中文字体（Songti.ttc 或等效字体）
- Gemini API Key

## 文档

- `openclaw/SKILL.md`: skill 契约与对外能力描述
- `docs/progress-reporting.md`: progress IPC 设计
- `docs/V18.4_AUTO_REPAIR_FEATURE.md`: result 自动修复设计

## 发布信息

- Skill URL: `http://43.163.220.15:8000/ai-drama-cut.md`
- Tarball: `http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.4.0.tar.gz`

## 说明

这里的承诺以实际 runtime 能稳定保证的能力为准，不再保留“必须发送文件给用户”“安装失败一定自动修好到成功”这类不稳定承诺。
