---
name: ai-drama-cut
version: "1.8.4"
description: 'AI 短剧智能剪辑工具。自动分析短剧视频并生成可用于投放测试的剪辑素材。V1.8.4: progress relay、heartbeat/stale治理与orphaned清理。'
license: Apache-2.0
compatibility: "Claude Code ≥1.0, OpenClaw ≥1.0"
metadata:
  openclaw:
    requires:
      env: ["GEMINI_API_KEY"]
      bins: ["ffmpeg", "python3"]
    primaryEnv: GEMINI_API_KEY
  author: ai-drama-cut
  version: "1.8.4"
  repository: "http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.8.4.tar.gz"
  tags:
    - video-editing
    - ai-analysis
    - drama-cutting
    - short-video
  triggers:
    - "剪辑短剧"
    - "分析短剧视频"
    - "生成短剧片段"
    - "短剧自动剪辑"
    - "AI剪辑视频"
    - "pan.baidu.com"
---

# AI 短剧智能剪辑 Skill

> 重要：以自然语言和用户沟通，不展示命令行日志、错误堆栈或安装细节。重点是让用户始终知道系统正在做什么、已经完成什么、下一步是什么。

## Skill 契约

这个 skill 的承诺以运行时可稳定兑现为准，核心保证有五类：

1. 开始前会给出执行计划
   - 说明项目名、是否预处理、预计生成数量、主要阶段。
2. 最佳努力主动汇报进展，让用户有掌控感
   - 优先通过短命令 progress relay 查询并转述最新状态，而不是依赖长命令 stdout 流式送达。
   - 渲染阶段分批执行，每批完成后主动汇报已完成数量和新生成的文件。
   - 若宿主支持后台任务后的定时再次调用，可持续主动汇报；否则降级为“后台执行 + 可查询最新进度 + 下次可运行时补发最新状态”。
3. 每个阶段都会有状态更新
   - 预处理、分析、渲染都会输出阶段状态。
4. 长任务会有 heartbeat / stale 治理
   - `last_progress_at` 只代表真实推进，`updated_at` 代表进程仍在活动。
   - relay 会区分 fresh running、stale but alive、orphaned stale，避免把残留进度误报成仍在运行。
5. 失败时会给出恢复信息
   - 说明失败分类、已完成阶段、保留的中间结果、建议下一步。

以下内容不再作为硬保证：
- 不承诺一定能自动修复所有安装失败。
- 不承诺一定能把生成文件直接发送给用户。
- 不承诺 ETA 绝对精确，ETA 只用于降低不确定感。
- 不承诺长命令 stdout 一定会被宿主实时转发到用户对话。

## 识别百度网盘链接

当用户消息中包含 `pan.baidu.com/s/` 时，视为下载请求：
- 自动提取链接和提取码
- 提取码可能在 URL 参数中（`?pwd=abcd`）、在同一消息中（”提取码: abcd”、”提取码：abcd”）、或在后续消息中
- 如果缺少提取码，向用户索要

链接格式示例：
- `https://pan.baidu.com/s/1xxx?pwd=abcd`（URL 自带提取码）
- `https://pan.baidu.com/s/1xxx 提取码: abcd`（文本中包含提取码）
- `链接: https://pan.baidu.com/s/1xxx 提取码: abcd`（带前缀）

## 用户交互准则

当用户问”怎么剪辑””怎么使用”时：
- 不解释底层命令和技术细节。
- 直接引导用户提供百度网盘分享链接（最简单）或本地视频目录。
- 用自然语言说明会自动完成下载、分析、剪辑、花字、片尾和结果汇总。

可使用的简短回复模板：

“你只需要把短剧的百度网盘分享链接发给我就行，我会自动下载、分析、剪辑，全程不用你操作。

具体来说：
1. 你发百度网盘链接（带提取码）
2. 我自动下载视频 → AI 分析高光和钩子点 → 渲染剪辑视频 → 上传成品到百度网盘
3. 每一步完成我都会告诉你进展，最后把成品的网盘链接发给你

如果视频已经在本地，告诉我目录路径也行。”

## 使用流程

### 1. 安装

```bash
cd openclaw
bash install.sh
python check_dependencies.py
```

### 2. 配置 API Key

```bash
python setup_api.py
```

### 3. 执行（重要：必须分步执行）

> **核心规则：禁止用一条命令跑完整流程。** 必须分三步（或四步）执行，每步完成后先向用户汇报结果，再执行下一步。这样用户能实时感知进展，而不是等 30-60 分钟后才收到一大堆结果。

> **长任务必须后台执行 + 自动轮询**：预处理和 AI 分析通常需要 5-15 分钟，同步执行会阻塞 Agent。这两步必须用 `exec background=true` 后台启动，然后执行 `wait_and_report.py` 自动轮询进度（每 60 秒输出一次，完成后自动退出）。

**第零步：下载素材（如果用户提供了百度网盘链接，后台执行）**

当用户发送百度网盘分享链接时，**立即告知用户收到了链接、即将开始下载**，然后后台启动下载：

```bash
# 后台启动下载（链接中自带提取码）
exec background=true python skill.py --download-url "https://pan.baidu.com/s/1xxx?pwd=abcd" --download-only

# 链接和提取码分开
exec background=true python skill.py --download-url "https://pan.baidu.com/s/1xxx" --download-pwd "abcd" --download-only

# 限制下载集数
exec background=true python skill.py --download-url "https://pan.baidu.com/s/1xxx?pwd=abcd" --download-only --max-episodes 15
```

**启动后立即向用户汇报**（不要等下载完再说话）：
> 📥 收到百度网盘链接，开始下载短剧素材，预计需要 2-5 分钟。我会持续告诉你进展。

然后执行自动轮询（脚本每 60 秒输出进度，完成后自动退出）：
```bash
exec python wait_and_report.py --project "项目名"
```

轮询结束后，向用户汇报：
- 短剧名
- 下载了多少集、总大小
- 素材保存路径

然后用下载的目录作为后续步骤的 `--input` 参数继续执行。

汇报示例：
> ✅ 素材下载完成！短剧名：复婚，已下载 10 集视频（共 1.8 GB），保存在 漫剧素材/复婚/。
> 接下来开始预处理，扫描敏感内容。

**第一步：预处理（后台执行）**

```bash
# 后台启动预处理
exec background=true python skill.py --input "视频目录路径" --preprocess-only
```

启动后，立即向用户汇报：
> ⏳ 预处理已开始，正在扫描敏感内容，预计需要 5-10 分钟。

然后执行自动轮询：
```bash
exec python wait_and_report.py --project "项目名"
```

轮询结束后，汇报预处理结果，进入下一步。

**第二步：AI 分析（后台执行）**

```bash
# 后台启动 AI 分析
exec background=true python skill.py --input "视频目录路径" --analysis-only
```

启动后，立即向用户汇报：
> ⏳ AI 视频分析已开始，预计需要 10-15 分钟。

然后执行自动轮询：
```bash
exec python wait_and_report.py --project "项目名"
```

轮询结束后，汇报分析结果，进入渲染阶段。

**第三步：渲染（必须分批执行）**

分析完成后，输出会提示剪辑总数和建议的批次划分（如 `渲染建议：共 20 条，建议分 4 批渲染：0-4, 5-9, 10-14, 15-19`）。

**按批次逐批渲染，每批完成后向用户汇报，然后上传到百度网盘**：

```bash
# 第 1 批（第 1-5 条）
python skill.py --input "视频目录路径" --render-batch "0-4"
# → 向用户汇报：已完成 5/20 条渲染
python skill.py --input "视频目录路径" --upload-only
# → 向用户汇报：已上传到百度网盘，附分享链接

# 第 2 批（第 6-10 条）
python skill.py --input "视频目录路径" --render-batch "5-9"
# → 向用户汇报：已完成 10/20 条渲染
python skill.py --input "视频目录路径" --upload-only
# → 向用户汇报：已上传到百度网盘，附更新的分享链接

# 第 3 批（第 11-15 条）
python skill.py --input "视频目录路径" --render-batch "10-14"
# → 向用户汇报：已完成 15/20 条渲染
python skill.py --input "视频目录路径" --upload-only
# → 向用户汇报：已上传到百度网盘

# 第 4 批（第 16-20 条）
python skill.py --input "视频目录路径" --render-batch "15-19"
# → 向用户汇报：全部 20 条渲染完成
python skill.py --input "视频目录路径" --upload-only
# → 向用户汇报：全部上传完成，附最终分享链接
```

每批完成后，向用户汇报：
- 当前已完成多少条 / 总共多少条
- 本批新增的视频文件名和大小
- 如果是最后一批，给出完成总结和推荐先看的视频

每次上传完成后，向用户汇报：
- 上传了多少个文件、总大小
- **百度网盘分享链接和提取码**（用户可直接点击查看视频）
- 链接有效期

> **重要**：渲染和上传必须是两条独立命令。渲染用 `--render-batch`，上传用 `--upload-only`。这样用户在每一步之间都能收到进展消息，不会出现长时间无反馈的情况。
> 如果百度网盘未配置（缺少 BAIDU_BDUSS / BAIDU_STOKEN），`--upload-only` 会提示未配置并跳过，不影响流程。

> **不要使用** `--render-only`，那会一次渲染全部 20 条，用户要等 10-30 分钟才能收到反馈。

**快捷组合示例**：

```bash
# 视频已经干净，跳过预处理，分两步执行：
python skill.py --input "视频目录路径" --analysis-only
# → 汇报分析结果，获取批次建议
python skill.py --input "视频目录路径" --render-batch "0-4"
# → 汇报第 1 批渲染结果
python skill.py --input "视频目录路径" --upload-only
# → 汇报上传结果 + 百度网盘链接
python skill.py --input "视频目录路径" --render-batch "5-9"
# → 汇报第 2 批渲染结果
python skill.py --input "视频目录路径" --upload-only
# → 汇报上传结果...（依此类推）
```

> **绝对不要使用** `python skill.py --input "..."` 不带 `--xxx-only` 或 `--render-batch` 参数的命令。那会导致整个流程在一个命令中阻塞执行，用户将在 30-60 分钟内看不到任何进展。

## 进度轮询规则

### 哪些步骤需要后台执行 + relay 轮询

| 步骤 | 执行方式 | 原因 |
|------|---------|------|
| 下载素材 | `exec background=true` + `--progress-tick` | 耗时 2-10 分钟 |
| 预处理 | `exec background=true` + `--progress-tick` | 耗时 5-10 分钟 |
| AI 分析 | `exec background=true` + `--progress-tick` | 耗时 10-15 分钟 |
| 渲染（每批） | 同步 `exec` | 每批 1-3 分钟，可接受 |
| 上传 | 同步 `exec` | 每批 1-2 分钟，可接受 |

> `wait_and_report.py` 仍可用于本地调试或手工观察 stdout，但它不再是宿主对用户送达进度的主契约。

### 推荐 relay 流程（2 步完成）

后台启动长任务后，宿主优先走短命令 progress relay：

**步骤 1：后台启动任务 + 立即汇报**
```bash
exec background=true python skill.py --input "漫剧素材/复婚" --analysis-only
```
→ 向用户发消息，告知任务已开始、预计耗时。

**步骤 2：重复调用短命令 relay**
```bash
python skill.py --progress-tick "复婚"
python skill.py --progress-status "复婚"
```
- `--progress-tick`：返回 JSON，表示“是否有一条新的、尚未送达给用户的消息”。
- `--progress-status`：返回当前最新的人类可读进度摘要，适合显式查询。
- 若宿主支持定时再次调用，就循环执行 `--progress-tick` 并在 `has_update=true` 时转述 `message`。
- 若宿主不支持可靠调度，则降级为后台执行 + 用户可随时查询 `--progress-status`。

**完整示例（AI 分析阶段）：**

```bash
# 1. 后台启动 AI 分析
exec background=true python skill.py --input "漫剧素材/复婚" --analysis-only

# 2. 立即告诉用户
# → 发消息："⏳ AI 视频分析已开始，预计需要 10-15 分钟。"

# 3. 后续由宿主周期性调用 progress relay
python skill.py --progress-tick "复婚"
# 首次可能返回：
# {"status":"running","has_update":true,"message":"📊 复婚 - AI 分析：8/50个片段 (16.0%)，当前：第3集 60.0-120.0秒。预计剩余约 8-12 分钟（已运行 2分05秒）","reason":"initial_state"}

python skill.py --progress-tick "复婚"
# 若无新进展，返回：
# {"status":"running","has_update":false,"message":"","reason":"no_change"}

python skill.py --progress-status "复婚"
# 显式查询时返回当前最新的人类可读摘要：
# 📊 复婚 - AI 分析：25/50个片段 (50.0%)，当前：第6集 0.0-60.0秒。预计剩余约 5-8 分钟（已运行 4分10秒）

python skill.py --progress-tick "复婚"
# 任务完成后返回：
# {"status":"idle","has_update":true,"message":"⏳ 复婚：暂无正在运行的任务。","reason":"completed_or_idle"}
```

### 进度状态语义

- `fresh_running`：最近有真实推进，`last_progress_at` 与 `updated_at` 都较新。
- `stale_but_alive`：最近没有真实推进，但进程仍在 heartbeat，`updated_at` 继续刷新。
- `orphaned_stale`：`updated_at` 也已过旧，说明大概率是上一次异常退出留下的残留状态。

### 进度汇报原则

`--progress-status` 的输出来自 `check_progress.py`，已包含正确的阶段名、数量和单位。Agent 汇报时**直接转述**，**严禁自己编造进度数字或单位**。

输出示例：
- 运行中：`📊 复婚 - AI 分析：15/50个片段 (30.0%)，当前：第8集 120.0-180.0秒。预计剩余约 5-8 分钟（已运行 3分20秒）`
- 停滞但进程仍存活：`📊 复婚 - AI 分析：15/50个片段 (30.0%)，当前：第8集。预计剩余约 5 分钟（已运行 5分00秒）  ⚠️ 已 2分30秒 无真实推进，但最近仍有 heartbeat`
- 残留状态：`📊 复婚 - AI 分析：15/50个片段 (30.0%)。预计剩余约 5 分钟（已运行 5分00秒）  ⚠️ 该进度已离线 4分10秒，疑似上次残留状态`
- 无任务：`⏳ 复婚：暂无正在运行的任务。`

### orphaned 残留治理

宿主或维护脚本可以定期检查并清理异常残留的 `.progress` 文件：

```bash
python skill.py --list-orphaned-progress
python skill.py --cleanup-orphaned-progress
```

输出示例：
- 列出残留：`⚠️ 发现 2 个 orphaned .progress 残留文件：...`
- 清理完成：`🧹 已清理 2 个 orphaned .progress 残留文件：...`
- 无残留：`✅ 没有发现 orphaned .progress 残留文件。`

> `--cleanup-orphaned-progress` 只清理已判定为 `orphaned_stale` 的残留文件，不会删除 fresh running 或 stale but alive 的正在运行任务。

## 运行时行为

### 分步汇报（最重要的交互原则）

每执行完一步命令后，**必须立即用自然语言向用户汇报当前进展**，然后再执行下一步。

汇报示例：

**预处理完成后**：
> ✅ 预处理完成！已扫描并处理 11 个视频文件，其中 3 个发现敏感内容并已自动遮罩。
> 接下来我开始分析视频内容，预计需要 10-15 分钟。

**分析完成后**：
> ✅ AI 视频分析完成！在 11 集中发现了 11 个高光点和 23 个钩子点，已生成 20 个剪辑组合。
> 接下来开始分批渲染剪辑视频，每 5 条一批，共 4 批。

**每批渲染完成后**：
> 🎬 第 1 批渲染完成（5/20 条）。已生成：
> - LM-777457-0323-xxx-第1集0秒_第2集180秒.mp4 (85 MB)
> - ...
> 接下来上传到百度网盘，稍等片刻...

**上传完成后**：
> ✅ 已上传到百度网盘！查看视频：
> 📎 链接: https://pan.baidu.com/s/1xxxx
> 🔑 提取码: abcd（7天有效）
> 继续渲染下一批...

**最后一批渲染 + 上传完成后**：
> 🎉 全部完成！共生成 20 条剪辑视频，总大小 2.34 GB。
> 📎 百度网盘链接: https://pan.baidu.com/s/1xxxx 提取码: abcd（7天有效）
> 推荐先看这几条：
> 1. 第1集0秒→第3集58秒（5分01秒）
> 2. 第1集0秒→第5集120秒（8分23秒）
> 3. 第2集45秒→第4集90秒（6分15秒）

### 开始阶段

开始时会输出一段简短计划，至少包含：
- 项目名
- 输入目录
- 是否启用预处理
- 预计阶段
- 预计输出数量

### 阶段更新

运行时会持续输出：
- 当前阶段
- 当前对象（例如第几集、第几个片段、第几个 clip）
- 已完成数量 / 总量
- 简短说明

### Heartbeat

如果某个阶段较慢，系统不会沉默。

典型 heartbeat 类似：
- “仍在进行 AI 分析，当前处理第 8/11 集。”
- “仍在渲染，当前编码 clip 3/5。”

### 完成摘要

结束时会输出统一摘要，至少包含：
- 成功生成的 clip 数量
- 总耗时
- 输出目录
- 推荐优先查看的结果
- 百度网盘分享链接和提取码（如已配置）

### 视频交付（百度网盘）

渲染完成的视频通过百度网盘交付给用户，避免飞书 20MB 文件大小限制。

**工作流程**：
1. 每批渲染完成后，agent 先汇报渲染结果
2. 然后执行 `--upload-only` 命令，上传当前所有已渲染的视频到百度网盘
3. 上传完成后 agent 汇报上传结果和分享链接
4. 用户点击链接即可在线查看视频

> **关键**：渲染和上传必须是两条独立命令，这样 agent 在两步之间都能主动 push 消息到 channel，用户始终知道进展。

**前提条件**：
- 需要配置 `BAIDU_BDUSS` 和 `BAIDU_STOKEN` 环境变量
- 如果未配置，上传会提示未配置并跳过，不影响渲染流程

**上传完成后 agent 汇报示例**：
> ✅ 已上传 5 个视频到百度网盘（共 420 MB）
> 📎 分享链接: https://pan.baidu.com/s/1xxxx
> 🔑 提取码: abcd（7天有效）

### 失败摘要

失败时会输出：
- 失败阶段
- 失败分类：环境 / 输入 / 资源 / 外部 API / 内部异常
- 已完成阶段
- 是否保留中间结果
- 可直接重试的建议

## Resume 与恢复

该 skill 优先提供“软 resume”能力，而不是完整 checkpoint 引擎。

可复用的内容包括：
- `data/cache/keyframes`
- `data/cache/asr`
- `data/cache/subtitle_region`
- `data/analysis/<项目名>/result.json`
- 自动修复旧 `result.json`

如果检测到已有中间结果，运行时会明确告知：
- 哪些阶段会跳过
- 哪些阶段会继续
- 本次是否从已有分析或缓存继续

## 输出目录

默认输出到：
- macOS / Linux: `clips/<项目名>/`
- Windows: `%USERPROFILE%\Documents\AI-Drama-Cut\clips\<项目名>\`

## 故障处理原则

遇到错误时：
1. 优先给用户可理解的状态说明，不沉默。
2. 尝试复用已有缓存和中间结果。
3. 只在确有必要时请求用户配合，例如补 API Key、释放磁盘空间、检查输入路径。
4. 不向用户倾倒原始堆栈和安装日志。

## 安装指南

### 系统要求
- **Python**: 3.10 或更高版本（编译模块依赖）
- **FFmpeg**: 支持视频处理和文本叠加
- **磁盘空间**: 建议 10GB+（视频缓存和渲染输出）
- **API Key**: Google Gemini API Key（用于AI分析）

### 快速安装

#### 1. 下载并解压
```bash
# 下载 skill 包
wget http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.8.1.tar.gz

# 或使用 curl
curl -O http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.8.1.tar.gz

# 解压
tar -xzf ai-drama-cut-v1.8.1.tar.gz
cd ai-drama-cut-v1.8.1
```

#### 2. 运行安装脚本（自动配置环境）
```bash
# 自动安装所有依赖
bash openclaw/install.sh
```

**安装脚本会自动**：
- ✅ 检查 Python 版本（要求 3.10+）
- ✅ 检测 FFmpeg 是否安装
- ✅ 安装 Python 依赖包
- ✅ 配置虚拟环境（如需要）

#### 3. 配置 API Key
```bash
python openclaw/setup_api.py
# 输入你的 Gemini API Key
```

### 依赖来源说明

**Python 依赖**（通过 pip 安装）：
- 来自 PyPI 官方源
- 使用清华大学镜像加速（中国区）
- 自动处理版本兼容性

**FFmpeg**（视频处理）：
- macOS: `brew install ffmpeg`
- Linux: `sudo apt install ffmpeg` 或 `yum install ffmpeg`
- 需要启用 `--enable-libfreetype` 和 `--enable-libfontconfig`

**可选依赖**（功能增强）：
- PyTorch: GPU 加速（可选）
- PaddlePaddle: OCR 功能

### 版本兼容性

**Python 版本**：
- ✅ Python 3.10.x - 推荐
- ⚠️ Python 3.9.x - 不兼容编译模块
- ❌ Python 3.8 及以下 - 不支持

**操作系统**：
- ✅ macOS 11+ (Intel + Apple Silicon)
- ✅ Ubuntu 20.04+ / CentOS 7+
- ⚠️ Windows - 需要 WSL2

### 故障排除

**问题 1: Python 版本不兼容**
```bash
# 检查 Python 版本
python3 --version

# 如果是 3.9 或更低，升级 Python
# macOS:
brew install python@3.10

# Linux:
sudo apt install python3.10
```

**问题 2: FFmpeg 缺失**
```bash
# macOS:
brew install ffmpeg

# Linux:
sudo apt install ffmpeg
```

**问题 3: 编译模块加载失败**
```bash
# 确认 Python 版本
python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"

# 如果是 3.9 或更低，需要升级
```

### 验证安装

```bash
# 检查依赖
python openclaw/check_dependencies.py

# 测试导入
python -c "from openclaw.skill import AIDramaCutter; print('✅ 导入成功')"
```

