#!/usr/bin/env python3
"""Structured dependency checks for OpenClaw installation and runtime."""
import importlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
ENV_PATH = PROJECT_ROOT / '.env'
FONT_PATHS = [
    '/System/Library/Fonts/Supplemental/Songti.ttc',
    '/System/Library/Fonts/STHeiti Medium.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
]
PYTHON_PACKAGES = [
    ('torch', 'torch'),
    ('paddleocr', 'paddleocr'),
    ('openai-whisper', 'whisper'),
    ('google-generativeai', 'google.generativeai'),
    ('opencv-python', 'cv2'),
    ('ffmpeg-python', 'ffmpeg'),
    ('pandas', 'pandas'),
]


def check_python() -> dict:
    version = sys.version_info
    ok = version >= (3, 8)
    return {
        'name': 'python',
        'ok': ok,
        'detail': f'{version.major}.{version.minor}.{version.micro}',
        'fix': '安装 Python 3.8+ 并确保 python3 可用。',
    }


def check_ffmpeg() -> dict:
    try:
        version = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True, timeout=5)
        filters = subprocess.run(['ffmpeg', '-filters'], capture_output=True, text=True, timeout=5)
        drawtext_ok = 'drawtext' in filters.stdout
        return {
            'name': 'ffmpeg',
            'ok': version.returncode == 0 and drawtext_ok,
            'detail': version.stdout.splitlines()[0] if version.stdout else 'ffmpeg detected',
            'fix': '安装支持 drawtext 的 FFmpeg，例如 macOS 使用 brew install ffmpeg。',
            'drawtext': drawtext_ok,
        }
    except Exception:
        return {
            'name': 'ffmpeg',
            'ok': False,
            'detail': '未检测到 ffmpeg',
            'fix': '安装 FFmpeg，并确认 ffmpeg -filters 中包含 drawtext。',
            'drawtext': False,
        }


def check_package(package_name: str, import_name: str) -> dict:
    try:
        module = importlib.import_module(import_name)
        version = getattr(module, '__version__', 'unknown')
        return {'name': package_name, 'ok': True, 'detail': version, 'fix': f'pip install {package_name}'}
    except ImportError:
        return {'name': package_name, 'ok': False, 'detail': '未安装', 'fix': f'pip install {package_name}'}


def check_font() -> dict:
    for font_path in FONT_PATHS:
        if Path(font_path).exists():
            return {'name': 'font', 'ok': True, 'detail': font_path, 'fix': '已找到字体'}
    return {
        'name': 'font',
        'ok': False,
        'detail': '未找到中文字体',
        'fix': 'Linux 可安装 fonts-wqy-zenhei；macOS 请确认系统字体存在。',
    }


def check_env() -> dict:
    if not ENV_PATH.exists():
        return {'name': 'env', 'ok': False, 'detail': '.env 不存在', 'fix': '运行 python setup_api.py 配置 GEMINI_API_KEY。'}
    content = ENV_PATH.read_text(encoding='utf-8')
    if 'GEMINI_API_KEY' not in content or 'your_key_here' in content:
        return {'name': 'env', 'ok': False, 'detail': 'GEMINI_API_KEY 未配置', 'fix': '运行 python setup_api.py 配置 GEMINI_API_KEY。'}
    return {'name': 'env', 'ok': True, 'detail': 'GEMINI_API_KEY 已配置', 'fix': '已配置'}


def check_disk() -> dict:
    total, used, free = shutil.disk_usage('/')
    free_gb = free // (2 ** 30)
    ok = free_gb >= 10
    return {
        'name': 'disk',
        'ok': ok,
        'detail': f'{free_gb}GB free',
        'fix': '至少预留 10GB 空间，建议保留更多缓存空间。',
    }


def run_checks() -> dict:
    checks = [check_python(), check_ffmpeg(), check_font(), check_env(), check_disk()]
    checks.extend(check_package(name, module) for name, module in PYTHON_PACKAGES)
    return {
        'ok': all(item['ok'] for item in checks if item['name'] not in {'font'}),
        'checks': checks,
    }


def main() -> None:
    result = run_checks()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result['ok'] else 1)


if __name__ == '__main__':
    main()
