#!/usr/bin/env python3
"""CLI tool to query progress of running AI drama cutting tasks.

Usage:
    python check_progress.py --project "复婚"

Reads progress files from ~/.Documents/AI-Drama-Cut/.progress/ and outputs
a human-readable summary suitable for an agent to relay to users.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.runtime import (
    PROGRESS_DIR,
    STAGE_LABELS,
    build_progress_fingerprint,
    clear_orphaned_progress,
    clear_relay_cursor,
    format_eta_range,
    get_progress_state,
    list_orphaned_progress,
    read_progress,
    read_relay_cursor,
    write_relay_cursor,
)

# Unit suffix per stage so the agent does not confuse "episodes" with "segments"
STAGE_UNITS = {
    'downloading': '集',
    'preprocessing': '集',
    'keyframe_extraction': '集',
    'asr_extraction': '集',
    'ending_detection': '集',
    'ai_analysis': '个片段',
    'rendering': '条',
}


def format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as human-readable string."""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    if minutes == 0:
        return f"{secs}秒"
    return f"{minutes}分{secs:02d}秒"


def _load_project_progress(project_name: str) -> list[dict]:
    if not PROGRESS_DIR.exists():
        return []
    progress_files = sorted(PROGRESS_DIR.glob(f'{project_name}_*.json'))
    rows = []
    now = time.time()
    for pf in progress_files:
        data = read_progress(pf)
        if not data:
            continue
        status = data.get('status', 'running')
        if status in ('completed', 'failed'):
            continue
        stage = data.get('stage', '')
        stage_label = data.get('stage_label', STAGE_LABELS.get(stage, stage))
        started_at = data.get('started_at', now)
        updated_at = data.get('updated_at', now)
        last_progress_at = data.get('last_progress_at', updated_at)
        progress_state = data.get('progress_state') or get_progress_state(data, now)
        fingerprint = data.get('fingerprint') or build_progress_fingerprint(data)
        rows.append({
            'path': str(pf),
            'stage': stage,
            'stage_label': stage_label,
            'status': status,
            'completed': data.get('completed', 0),
            'total': data.get('total', 0),
            'percentage': data.get('percentage', 0.0),
            'current_item': data.get('current_item', ''),
            'message': data.get('message', ''),
            'started_at': started_at,
            'updated_at': updated_at,
            'last_progress_at': last_progress_at,
            'run_id': data.get('run_id') or data.get('details', {}).get('run_id', ''),
            'progress_state': progress_state,
            'fingerprint': fingerprint,
            'eta_min_seconds': data.get('eta_min_seconds'),
            'eta_max_seconds': data.get('eta_max_seconds'),
            'details': data.get('details', {}),
        })
    return rows


def _format_stage_summary(project_name: str, row: dict, now: float) -> str:
    parts = [f'📊 {project_name} - {row["stage_label"]}']
    total = row['total']
    if total > 0:
        unit = STAGE_UNITS.get(row['stage'], '')
        parts.append(f'：{row["completed"]}/{total}{unit} ({row["percentage"]}%)')
    if row['current_item']:
        parts.append(f'，当前：{row["current_item"]}')
    eta_text = format_eta_range(row['eta_min_seconds'], row['eta_max_seconds'])
    elapsed = now - row['started_at']
    parts.append(f'。{eta_text}（已运行 {format_elapsed(elapsed)}）')
    idle_seconds = now - row['last_progress_at']
    stale_seconds = now - row['updated_at']
    progress_state = row['progress_state']
    if progress_state == 'stale_but_alive':
        parts.append(f'  ⚠️ 已 {format_elapsed(idle_seconds)} 无真实推进，但最近仍有 heartbeat')
    elif progress_state == 'orphaned_stale':
        parts.append(f'  ⚠️ 该进度已离线 {format_elapsed(stale_seconds)}，疑似上次残留状态')
    if row['message']:
        parts.append(f'  💬 {row["message"]}')
    return ''.join(parts)


def get_progress_snapshot(project_name: str) -> dict:
    now = time.time()
    rows = _load_project_progress(project_name)
    summaries = [_format_stage_summary(project_name, row, now) for row in rows]
    active_rows = [row for row in rows if row['progress_state'] != 'orphaned_stale']
    latest_row = max(rows, key=lambda item: item['updated_at']) if rows else None
    if active_rows:
        status = 'running'
        message = '\n'.join(summaries)
    elif rows:
        status = 'stale'
        message = '\n'.join(summaries)
    else:
        status = 'idle'
        message = f'⏳ {project_name}：暂无正在运行的任务。'
    return {
        'project_name': project_name,
        'status': status,
        'message': message,
        'progress_items': rows,
        'active_count': len(active_rows),
        'has_orphaned': any(row['progress_state'] == 'orphaned_stale' for row in rows),
        'latest_run_id': latest_row['run_id'] if latest_row else '',
        'latest_fingerprint': latest_row['fingerprint'] if latest_row else '',
    }


def check_progress(project_name: str) -> str:
    """Read progress files for a project and return a human-readable summary."""
    return get_progress_snapshot(project_name)['message']


def progress_relay_tick(project_name: str) -> dict:
    snapshot = get_progress_snapshot(project_name)
    cursor = read_relay_cursor(project_name)
    latest_fingerprint = snapshot.get('latest_fingerprint', '')
    latest_run_id = snapshot.get('latest_run_id', '')
    status = snapshot['status']

    if status == 'idle':
        if cursor.get('status') == 'idle':
            return {
                'status': 'idle',
                'has_update': False,
                'message': '',
                'reason': 'no_running_task',
            }
        clear_relay_cursor(project_name)
        return {
            'status': 'idle',
            'has_update': True,
            'message': snapshot['message'],
            'reason': 'completed_or_idle',
        }

    if (
        cursor.get('latest_fingerprint') == latest_fingerprint
        and cursor.get('latest_run_id') == latest_run_id
        and cursor.get('status') == status
    ):
        return {
            'status': status,
            'has_update': False,
            'message': '',
            'reason': 'no_change',
        }

    write_relay_cursor(project_name, {
        'project_name': project_name,
        'status': status,
        'latest_fingerprint': latest_fingerprint,
        'latest_run_id': latest_run_id,
        'updated_at': time.time(),
    })
    return {
        'status': status,
        'has_update': True,
        'message': snapshot['message'],
        'reason': 'state_changed' if cursor else 'initial_state',
    }


def describe_orphaned_progress(project_name: str | None = None) -> dict:
    items = list_orphaned_progress(project_name)
    if not items:
        return {
            'count': 0,
            'message': '✅ 没有发现 orphaned .progress 残留文件。',
            'items': [],
        }
    lines = [f'⚠️ 发现 {len(items)} 个 orphaned .progress 残留文件：']
    for item in items:
        lines.append(f'- {item["project_name"]} / {item["stage"]} / {item["path"]}')
    return {
        'count': len(items),
        'message': '\n'.join(lines),
        'items': items,
    }


def cleanup_orphaned_progress(project_name: str | None = None) -> dict:
    removed = clear_orphaned_progress(project_name)
    if not removed:
        return {
            'count': 0,
            'message': '✅ 没有需要清理的 orphaned .progress 残留文件。',
            'removed': [],
        }
    lines = [f'🧹 已清理 {len(removed)} 个 orphaned .progress 残留文件：']
    for path in removed:
        lines.append(f'- {path}')
    return {
        'count': len(removed),
        'message': '\n'.join(lines),
        'removed': removed,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description='查询 AI 短剧剪辑任务进度')
    parser.add_argument('--project', '-p', help='项目名称')
    parser.add_argument('--relay-tick', action='store_true', help='以 relay 模式返回是否有新消息')
    parser.add_argument('--list-orphaned', action='store_true', help='列出 orphaned .progress 残留文件')
    parser.add_argument('--cleanup-orphaned', action='store_true', help='清理 orphaned .progress 残留文件')
    args = parser.parse_args()

    if args.relay_tick:
        if not args.project:
            parser.error('--relay-tick 需要 --project')
        result = progress_relay_tick(args.project)
        print(json.dumps(result, ensure_ascii=False), flush=True)
        return

    if args.list_orphaned:
        result = describe_orphaned_progress(args.project)
        print(result['message'], flush=True)
        return

    if args.cleanup_orphaned:
        result = cleanup_orphaned_progress(args.project)
        print(result['message'], flush=True)
        return

    if not args.project:
        parser.error('默认查询需要 --project')
    result = check_progress(args.project)
    print(result, flush=True)


if __name__ == "__main__":
    main()
