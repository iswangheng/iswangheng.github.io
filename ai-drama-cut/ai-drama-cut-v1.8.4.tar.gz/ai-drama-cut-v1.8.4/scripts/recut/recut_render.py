"""
Render recut clips — trim video to hook point + optional badge overlay + ending video.

When badge overlay is disabled, uses stream copy (extremely fast).
When enabled, uses FFmpeg filter_complex with re-encoding.
Ending video is randomly selected from 标准结尾帧视频素材/ and concatenated.
"""
import os
import random
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, List

from scripts.log_config import get_logger
from scripts.utils.subprocess_utils import run_command
from scripts.config import TimeoutConfig

logger = get_logger(__name__)

# Module-level ending video cache
_ending_videos_cache: Optional[List[str]] = None


def _load_ending_videos() -> List[str]:
    """Load ending videos from 标准结尾帧视频素材/ directory.

    Searches CWD and up to 3 parent levels.
    Results are cached at module level.
    """
    global _ending_videos_cache
    if _ending_videos_cache is not None:
        return _ending_videos_cache

    cwd = Path(os.getcwd())
    search_paths = [cwd] + [cwd.parents[i] for i in range(3) if i < len(cwd.parents)]

    ending_dir = None
    for base in search_paths:
        candidate = base / "标准结尾帧视频素材"
        if candidate.exists():
            ending_dir = candidate
            break

    if not ending_dir:
        logger.warning("  ⚠️ 找不到 标准结尾帧视频素材/ 文件夹")
        _ending_videos_cache = []
        return _ending_videos_cache

    videos = []
    for ext in ('.mp4', '.mov', '.avi', '.mkv'):
        videos.extend(str(p) for p in ending_dir.glob(f"*{ext}") if p.is_file())

    if videos:
        logger.info(f"  🎬 加载了 {len(videos)} 个结尾视频素材")
    else:
        logger.warning(f"  ⚠️ 结尾视频文件夹为空: {ending_dir}")

    _ending_videos_cache = videos
    return _ending_videos_cache


def render_recut(
    video_path: str,
    end_time: float,
    output_path: str,
    start_time: float = 0.0,
    add_hot_drama_badge: bool = True,
    add_ending: bool = True,
    project_name: str = "",
    # Backward compatibility alias
    hook_timestamp: Optional[float] = None,
) -> bool:
    """Render a recut clip from [start_time, end_time], optionally with badge and ending.

    Args:
        video_path: Source video path
        end_time: End timestamp in seconds
        output_path: Output file path
        start_time: Start timestamp in seconds (0 = original start)
        add_hot_drama_badge: Whether to overlay the hot drama badge
        add_ending: Whether to append a random ending video
        project_name: Project name (for badge style caching)
        hook_timestamp: Deprecated alias for end_time (backward compat)

    Returns:
        True if rendering succeeded
    """
    # Backward compat: hook_timestamp overrides end_time if provided
    if hook_timestamp is not None:
        end_time = hook_timestamp

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    if add_hot_drama_badge:
        success = _render_with_badge(video_path, start_time, end_time, output_path, project_name)
    else:
        success = _render_stream_copy(video_path, start_time, end_time, output_path)

    if not success:
        return False

    # Append ending video
    if add_ending:
        _append_ending_video(output_path)

    return True


def _render_stream_copy(video_path: str, start_time: float, end_time: float, output_path: str) -> bool:
    """Fast render using stream copy (no re-encoding)."""
    duration = end_time - start_time
    cmd = ['ffmpeg']

    if start_time > 0:
        cmd.extend(['-ss', f'{start_time:.3f}'])

    cmd.extend([
        '-i', video_path,
        '-t', f'{duration:.3f}',
        '-c', 'copy',
        '-avoid_negative_ts', 'make_zero',
        '-loglevel', 'error',
        output_path,
        '-y',
    ])

    logger.info(f"  🚀 Stream copy: {start_time:.1f}-{end_time:.1f}s ({duration:.0f}s)")
    result = run_command(cmd, timeout=TimeoutConfig.FFMPEG_CLIP_RENDER, retries=1)
    if result is None or result.returncode != 0:
        err = result.stderr[:300] if result else "timeout"
        logger.error(f"  Stream copy failed: {err}")
        return False
    return True


def _render_with_badge(
    video_path: str,
    start_time: float,
    end_time: float,
    output_path: str,
    project_name: str,
) -> bool:
    """Render with hot drama badge overlay (requires re-encoding)."""
    try:
        from scripts.understand.video_overlay.video_overlay import VideoOverlayRenderer, OverlayConfig
        from scripts.understand.video_overlay.overlay_styles import get_random_badge_style
        from scripts.understand.video_overlay.badge_renderer import BadgeRenderer, get_badge_overlay_position
    except ImportError as e:
        logger.warning(f"  Cannot import overlay module: {e}, falling back to stream copy")
        return _render_stream_copy(video_path, start_time, end_time, output_path)

    # Probe video dimensions
    from scripts.recut.find_hooks import probe_video
    info = probe_video(video_path)
    video_width = info['width']
    video_height = info['height']

    if video_width == 0 or video_height == 0:
        logger.warning("  Cannot detect video dimensions, falling back to stream copy")
        return _render_stream_copy(video_path, start_time, end_time, output_path)

    # Calculate effective dimensions after downscale (badge must match output resolution)
    effective_width = video_width
    effective_height = video_height
    if min(video_width, video_height) > 720:
        if video_height > video_width:
            # Portrait: width scales to 720, height proportional
            effective_width = 720
            effective_height = int(video_height * 720 / video_width)
            if effective_height % 2 != 0:
                effective_height += 1
        else:
            # Landscape: height scales to 720, width proportional
            effective_height = 720
            effective_width = int(video_width * 720 / video_height)
            if effective_width % 2 != 0:
                effective_width += 1

    # Generate badge PNG using effective (output) dimensions
    badge_png_path = None
    try:
        badge_style = get_random_badge_style()
        badge_renderer = BadgeRenderer()

        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
            badge_png_path = tmp.name

        # Use "热门短剧" as badge text (same as main pipeline)
        badge_png_path = badge_renderer.render(
            style=badge_style,
            text="热门短剧",
            video_width=effective_width,
            video_height=effective_height,
            output_path=badge_png_path,
        )

        badge_position = badge_style.position or random.choice(["top-left", "top-right"])
        smaller_dimension = min(effective_width, effective_height)
        resolution_ratio = smaller_dimension / 360.0

        badge_x, badge_y = get_badge_overlay_position(
            png_path=badge_png_path,
            video_width=effective_width,
            video_height=effective_height,
            position=badge_position,
            shape=badge_style.shape,
            ratio=resolution_ratio,
        )
        logger.info(f"  🏷️ Badge: {badge_style.name}, pos=({badge_x}, {badge_y}), effective={effective_width}x{effective_height}")

    except Exception as e:
        logger.error(f"  Badge generation failed: {e}, falling back to stream copy")
        if badge_png_path and os.path.exists(badge_png_path):
            os.unlink(badge_png_path)
        return _render_stream_copy(video_path, start_time, end_time, output_path)

    # Build FFmpeg command with filter_complex
    try:
        # Smart resolution: keep original if <=720p, downscale to 720p if higher
        scale_filter = ""
        if min(video_width, video_height) > 720:
            if video_height > video_width:
                # Portrait: scale width to 720
                scale_filter = "scale=720:-2,"
            else:
                # Landscape: scale height to 720
                scale_filter = "scale=-2:720,"
            logger.info(f"  📐 Downscale to 720p")

        clip_duration = end_time - start_time
        filter_complex = (
            f"[0:v]{scale_filter}trim={start_time:.3f}:{end_time:.3f},setpts=PTS-STARTPTS[trimmed];"
            f"[trimmed][1:v]overlay={badge_x}:{badge_y}[out]"
        )

        cmd = ['ffmpeg']
        if start_time > 0:
            cmd.extend(['-ss', f'{start_time:.3f}'])
        cmd.extend([
            '-i', video_path,
            '-i', badge_png_path,
            '-filter_complex', filter_complex,
            '-map', '[out]',
            '-map', '0:a?',
            '-t', f'{clip_duration:.3f}',
            '-c:v', 'libx264',
            '-crf', '23',
            '-preset', 'veryfast',
            '-c:a', 'aac',
            '-b:a', '128k',
            '-movflags', '+faststart',
            '-loglevel', 'error',
            output_path,
            '-y',
        ])

        logger.info(f"  🎬 Rendering with badge: {start_time:.1f}-{end_time:.1f}s ({clip_duration:.0f}s)")
        result = run_command(cmd, timeout=TimeoutConfig.FFMPEG_CLIP_RENDER, retries=1)

        if result is None or result.returncode != 0:
            err = result.stderr[:300] if result else "timeout"
            logger.error(f"  Render failed: {err}")
            return False

        return True

    finally:
        # Clean up temp badge PNG
        if badge_png_path and os.path.exists(badge_png_path):
            os.unlink(badge_png_path)


# ========== Ending video ==========

def _append_ending_video(clip_path: str) -> None:
    """Append a random ending video to the rendered clip (in-place).

    Preprocesses the ending video to match clip resolution/fps,
    then concatenates via ffmpeg concat demuxer.
    """
    ending_videos = _load_ending_videos()
    if not ending_videos:
        return

    ending_video = random.choice(ending_videos)
    logger.info(f"  🎬 拼接结尾: {Path(ending_video).name}")

    output_dir = Path(clip_path).parent
    processed_ending = None
    concat_file = None

    try:
        # Probe clip dimensions and fps
        from scripts.recut.find_hooks import probe_video
        clip_info = probe_video(clip_path)
        clip_width = clip_info['width']
        clip_height = clip_info['height']
        clip_fps = clip_info['fps']

        if clip_width == 0 or clip_height == 0:
            logger.warning("  Cannot probe clip, skipping ending")
            return

        # Get ending video duration
        ending_info = probe_video(ending_video)
        ending_duration = ending_info['duration']

        # Preprocess ending: match resolution, fps, codec
        processed_ending = str(output_dir / f"_ending_tmp_{os.getpid()}.mp4")
        cmd = [
            'ffmpeg', '-y',
            '-i', ending_video,
            '-t', str(ending_duration),
            '-vf', (
                f'scale={clip_width}:{clip_height}:'
                f'force_original_aspect_ratio=decrease,'
                f'setsar=1,'
                f'pad={clip_width}:{clip_height}:(ow-iw)/2:(oh-ih)/2:color=black'
            ),
            '-r', str(clip_fps),
            '-vsync', 'cfr',
            '-c:v', 'libx264',
            '-crf', '23',
            '-preset', 'veryfast',
            '-c:a', 'aac',
            '-b:a', '128k',
            '-loglevel', 'error',
            processed_ending,
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFMPEG_CLIP_RENDER, retries=1)
        if result is None or result.returncode != 0:
            logger.warning(f"  结尾视频预处理失败, 跳过")
            return

        # Concat via demuxer
        concat_file = output_dir / f"_concat_{os.getpid()}.txt"
        with open(concat_file, 'w') as f:
            # Use absolute paths to avoid path issues
            f.write(f"file '{os.path.abspath(clip_path)}'\n")
            f.write(f"file '{os.path.abspath(processed_ending)}'\n")

        concat_output = str(output_dir / f"_concat_out_{os.getpid()}.mp4")
        cmd = [
            'ffmpeg', '-y',
            '-f', 'concat',
            '-safe', '0',
            '-i', str(concat_file),
            '-c', 'copy',
            '-loglevel', 'error',
            concat_output,
        ]
        result = run_command(cmd, timeout=TimeoutConfig.FFMPEG_CLIP_RENDER, retries=1)
        if result is None or result.returncode != 0:
            logger.warning(f"  结尾视频拼接失败, 跳过")
            if os.path.exists(concat_output):
                os.unlink(concat_output)
            return

        # Replace original clip with concatenated version
        os.replace(concat_output, clip_path)
        logger.info(f"  ✅ 结尾拼接完成")

    except Exception as e:
        logger.warning(f"  结尾拼接异常: {e}, 跳过")
    finally:
        if processed_ending and os.path.exists(processed_ending):
            os.unlink(processed_ending)
        if concat_file and concat_file.exists():
            concat_file.unlink()
