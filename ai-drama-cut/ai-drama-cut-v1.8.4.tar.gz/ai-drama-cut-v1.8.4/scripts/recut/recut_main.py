"""
Recut main entry point — 爆款素材长剪短

Usage:
    # Single video
    python -m scripts.recut.recut_main "测试二创/战神归来，这个保镖有亿点强/战神归来，这个保镖有亿点强 (1).mp4"

    # Entire project
    python -m scripts.recut.recut_main "测试二创/下山后我横扫一切"

    # With options
    python -m scripts.recut.recut_main "测试二创/下山后我横扫一切" --max-hooks 2 --min-duration 90 --verbose
"""
import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import List, Optional

from scripts.log_config import setup_logging, get_logger
from scripts.recut.find_hooks import find_hooks_in_video, find_recut_clips, probe_video, HookPoint, RecutClip
from scripts.recut.recut_render import render_recut

logger = get_logger(__name__)


def scan_videos(input_path: str) -> List[str]:
    """Scan for video files from input path (file or directory).

    Returns:
        Sorted list of absolute video file paths
    """
    p = Path(input_path)

    if p.is_file() and p.suffix.lower() in ('.mp4', '.mkv', '.avi', '.mov'):
        return [str(p.resolve())]

    if p.is_dir():
        videos = []
        for ext in ('*.mp4', '*.mkv', '*.avi', '*.mov'):
            videos.extend(p.glob(ext))
        return sorted(str(v.resolve()) for v in videos)

    logger.error(f"路径不存在或不是视频/目录: {input_path}")
    return []


def _sanitize_filename(name: str) -> str:
    """Remove or replace characters that cause filesystem issues."""
    # Replace problematic chars but keep Chinese chars
    for ch in ['/', '\\', ':', '*', '?', '"', '<', '>', '|']:
        name = name.replace(ch, '_')
    return name


def process_video(
    video_path: str,
    output_dir: str,
    max_clips: int = 3,
    min_duration: int = 60,
    skip_existing: bool = False,
    add_badge: bool = True,
    add_ending: bool = True,
    project_name: str = "",
    # Backward compat alias
    max_hooks: Optional[int] = None,
) -> List[dict]:
    """Process a single video: find highlight×hook combos and render recut clips.

    Returns:
        List of result dicts for each rendered clip
    """
    if max_hooks is not None:
        max_clips = max_hooks

    video_name = Path(video_path).stem
    safe_name = _sanitize_filename(video_name)
    results = []

    # Check if already processed
    if skip_existing:
        existing = list(Path(output_dir).glob(f"{safe_name}_recut_*.mp4"))
        if existing:
            logger.info(f"⏭️  跳过已处理: {video_name} ({len(existing)} clips exist)")
            return []

    # Find recut clips (highlight × hook combinations)
    analysis_start = time.time()
    clips = find_recut_clips(
        video_path=video_path,
        max_clips=max_clips,
        min_duration=min_duration,
    )

    analysis_time = time.time() - analysis_start
    logger.info(f"  ⏱️ 分析耗时: {analysis_time:.1f}s")

    if not clips:
        logger.warning(f"  未找到合适的剪辑组合: {video_name}")
        return []

    # Render clips
    info = probe_video(video_path)
    for i, clip in enumerate(clips, 1):
        output_path = os.path.join(output_dir, f"{safe_name}_recut_{i}.mp4")

        logger.info(f"  🎬 渲染 recut_{i}: {clip.start:.1f}-{clip.end:.1f}s ({clip.duration:.0f}s)")
        render_start = time.time()
        success = render_recut(
            video_path=video_path,
            start_time=clip.start,
            end_time=clip.end,
            output_path=output_path,
            add_hot_drama_badge=add_badge,
            add_ending=add_ending,
            project_name=project_name,
        )
        render_time = time.time() - render_start

        if success and os.path.exists(output_path):
            file_size_mb = os.path.getsize(output_path) / (1024 * 1024)
            logger.info(f"  ✅ recut_{i}: {file_size_mb:.1f}MB, 渲染{render_time:.1f}s")
            results.append({
                'source': Path(video_path).name,
                'output': Path(output_path).name,
                'start_time': round(clip.start, 1),
                'end_time': round(clip.end, 1),
                'duration': round(clip.duration, 1),
                'highlight': clip.highlight.to_dict(),
                'hook': clip.hook.to_dict(),
                'original_duration': round(info['duration'], 1),
                'file_size_mb': round(file_size_mb, 1),
            })
        else:
            logger.error(f"  ❌ recut_{i} 渲染失败")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="爆款素材长剪短 — 高光点×钩子点组合生成更短二创版本"
    )
    parser.add_argument(
        "input",
        help="视频文件或项目目录路径",
    )
    parser.add_argument(
        "--max-clips", type=int, default=3,
        help="每个视频最多产出N个短版本 (default: 3)",
    )
    parser.add_argument(
        "--max-hooks", type=int, default=None,
        help="(已废弃，请用 --max-clips) 每个视频最多产出N个短版本",
    )
    parser.add_argument(
        "--min-duration", type=int, default=60,
        help="最短结果时长秒数 (default: 60)",
    )
    parser.add_argument(
        "--output", type=str, default=None,
        help="输出目录 (default: clips/recut/{项目名}/)",
    )
    parser.add_argument(
        "--skip-existing", action="store_true",
        help="跳过已处理的视频",
    )
    parser.add_argument(
        "--no-badge", action="store_true",
        help="不添加热门短剧角标",
    )
    parser.add_argument(
        "--no-ending", action="store_true",
        help="不拼接结尾视频",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="DEBUG日志",
    )

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logging(level=log_level)

    # Determine project name and output dir
    input_path = Path(args.input)
    if input_path.is_file():
        project_name = input_path.parent.name
    else:
        project_name = input_path.name

    output_dir = args.output or os.path.join("clips", "recut", _sanitize_filename(project_name))
    os.makedirs(output_dir, exist_ok=True)

    # Scan videos
    videos = scan_videos(args.input)
    if not videos:
        logger.error("未找到视频文件")
        sys.exit(1)

    logger.info(f"🎬 项目: {project_name}")
    logger.info(f"📁 视频数: {len(videos)}")
    logger.info(f"📂 输出: {output_dir}")
    # Resolve max_clips (--max-hooks is deprecated alias)
    max_clips = args.max_clips
    if args.max_hooks is not None:
        max_clips = args.max_hooks
        logger.warning("⚠️ --max-hooks 已废弃，请使用 --max-clips")

    logger.info(f"⚙️  参数: max_clips={max_clips}, min_duration={args.min_duration}s, badge={'OFF' if args.no_badge else 'ON'}, ending={'OFF' if args.no_ending else 'ON'}")
    logger.info("")

    # Process videos
    all_results = []
    total_start = time.time()

    for idx, video_path in enumerate(videos, 1):
        logger.info(f"{'='*60}")
        logger.info(f"[{idx}/{len(videos)}] {Path(video_path).name}")
        logger.info(f"{'='*60}")

        try:
            results = process_video(
                video_path=video_path,
                output_dir=output_dir,
                max_clips=max_clips,
                min_duration=args.min_duration,
                skip_existing=args.skip_existing,
                add_badge=not args.no_badge,
                add_ending=not args.no_ending,
                project_name=project_name,
            )
            all_results.extend(results)
        except Exception as e:
            logger.error(f"处理失败: {e}", exc_info=True)
            continue

        logger.info("")

    # Save summary result.json
    total_time = time.time() - total_start
    summary = {
        'project': project_name,
        'total_videos': len(videos),
        'total_clips': len(all_results),
        'total_time_seconds': round(total_time, 1),
        'settings': {
            'max_clips': max_clips,
            'min_duration': args.min_duration,
            'badge': not args.no_badge,
            'ending': not args.no_ending,
        },
        'clips': all_results,
    }

    result_path = os.path.join(output_dir, "result.json")
    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    # Final summary
    logger.info(f"{'='*60}")
    logger.info(f"📊 完成汇总")
    logger.info(f"  视频: {len(videos)} 个")
    logger.info(f"  产出: {len(all_results)} 个短版本")
    logger.info(f"  耗时: {total_time:.0f}s")
    logger.info(f"  结果: {result_path}")
    logger.info(f"{'='*60}")


if __name__ == "__main__":
    main()
