"""
Hook point discovery for recut module.

Analyzes an already-edited video to find strong hook points
that can serve as earlier endings for shorter versions.
"""
import json
import os
import re
import time
import logging
import hashlib
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from scripts.log_config import get_logger
from scripts.data_models import KeyFrame, ASRSegment
from scripts.extract_keyframes import extract_keyframes
from scripts.extract_asr import extract_audio, transcribe_audio
from scripts.understand.extract_segments import (
    extract_segments_for_episode,
    VideoSegment,
    SEGMENT_DURATION,
    SEGMENT_OVERLAP,
)
from scripts.understand.analyze_segment import (
    smart_select_keyframes,
    encode_image,
    truncate_asr_by_lines,
    parse_analysis_response,
    _get_next_api_endpoint,
    _api_key_manager,
)
from scripts.type_definitions import (
    HOOK_TYPES, HIGHLIGHT_TYPES,
    get_type_names_for_prompt, match_hook_type, match_highlight_type,
)
from scripts.config import TrainingConfig

logger = get_logger(__name__)


@dataclass
class HookPoint:
    """A discovered hook point in a video."""
    timestamp: float       # precise second
    type: str             # hook type ID
    confidence: float     # 0-10
    viewer_desire: float  # 0-10
    reasoning: str        # AI analysis reason
    score: float = 0.0    # composite score

    def to_dict(self) -> dict:
        return {
            'timestamp': self.timestamp,
            'type': self.type,
            'confidence': self.confidence,
            'viewer_desire': self.viewer_desire,
            'reasoning': self.reasoning,
            'score': round(self.score, 3),
        }


@dataclass
class HighlightPoint:
    """A discovered highlight point in a video (alternative start)."""
    timestamp: float       # precise second
    type: str             # highlight type ID
    confidence: float     # 0-10
    reasoning: str
    score: float = 0.0    # composite score

    def to_dict(self) -> dict:
        return {
            'timestamp': self.timestamp,
            'type': self.type,
            'confidence': self.confidence,
            'reasoning': self.reasoning,
            'score': round(self.score, 3),
        }


@dataclass
class RecutClip:
    """A highlight × hook combination for recut."""
    start: float           # highlight timestamp (0 = original start)
    end: float             # hook timestamp
    duration: float        # end - start
    highlight: HighlightPoint
    hook: HookPoint
    score: float = 0.0     # combo score

    def to_dict(self) -> dict:
        return {
            'start_time': self.start,
            'end_time': self.end,
            'duration': round(self.duration, 1),
            'highlight': self.highlight.to_dict(),
            'hook': self.hook.to_dict(),
            'score': round(self.score, 3),
        }


# ========== Prompt loading ==========

_PROMPT_CACHE: Optional[str] = None


def _load_prompt() -> str:
    """Load the hook finding prompt from file."""
    global _PROMPT_CACHE
    if _PROMPT_CACHE is not None:
        return _PROMPT_CACHE

    prompt_path = Path(__file__).parent / "prompts" / "find-hooks.md"
    if prompt_path.exists():
        with open(prompt_path, 'r', encoding='utf-8') as f:
            _PROMPT_CACHE = f.read()
    else:
        logger.warning(f"Prompt file not found: {prompt_path}, using fallback")
        _PROMPT_CACHE = _FALLBACK_PROMPT

    return _PROMPT_CACHE


_FALLBACK_PROMPT = """分析视频片段，找到强钩子点作为短视频结尾。

时间范围：{START}-{END}秒（窗口时长{DURATION}秒）
ASR文本：{ASR_TEXT}
钩子类型：{HOOK_TYPES}

返回JSON：
{{"hooks": [{{"exists": true, "preciseSecond": 155, "type": "类型", "confidence": 9.0, "viewerDesire": 8, "reasoning": "理由"}}]}}
只返回JSON。
"""


_RECUT_PROMPT_CACHE: Optional[str] = None


def _load_recut_prompt() -> str:
    """Load the combined highlight+hook prompt from file."""
    global _RECUT_PROMPT_CACHE
    if _RECUT_PROMPT_CACHE is not None:
        return _RECUT_PROMPT_CACHE

    prompt_path = Path(__file__).parent / "prompts" / "find-recut-points.md"
    if prompt_path.exists():
        with open(prompt_path, 'r', encoding='utf-8') as f:
            _RECUT_PROMPT_CACHE = f.read()
    else:
        logger.warning(f"Recut prompt not found: {prompt_path}, falling back to hook-only")
        _RECUT_PROMPT_CACHE = _load_prompt()

    return _RECUT_PROMPT_CACHE


# ========== Video probing ==========

def probe_video(video_path: str) -> dict:
    """Get video metadata via ffprobe.

    Returns:
        dict with keys: duration, width, height, fps
    """
    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,r_frame_rate,duration',
        '-show_entries', 'format=duration',
        '-of', 'json',
        video_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    data = json.loads(result.stdout)

    stream = data.get('streams', [{}])[0]
    fmt = data.get('format', {})

    # Duration: prefer format duration, fallback to stream
    duration = float(fmt.get('duration', 0)) or float(stream.get('duration', 0))

    # FPS
    fps_str = stream.get('r_frame_rate', '30/1')
    if '/' in fps_str:
        num, den = fps_str.split('/')
        fps = float(num) / float(den) if float(den) > 0 else 30.0
    else:
        fps = float(fps_str)

    return {
        'duration': duration,
        'width': int(stream.get('width', 0)),
        'height': int(stream.get('height', 0)),
        'fps': round(fps, 2),
    }


# ========== Segment analysis ==========

def _build_hook_prompt(segment: VideoSegment) -> dict:
    """Build Gemini API payload for hook detection in a segment."""
    # ASR text with timestamps
    asr_text_parts = []
    for seg in segment.asr_segments:
        asr_text_parts.append(f"[{seg.start:.1f}-{seg.end:.1f}秒] {seg.text}")
    asr_text = '\n'.join(asr_text_parts) or "(无语音)"

    duration = segment.end_time - segment.start_time
    hook_types_text = get_type_names_for_prompt('hook')

    prompt_template = _load_prompt()
    prompt = prompt_template.format(
        START=segment.start_time,
        END=segment.end_time,
        DURATION=duration,
        ASR_TEXT=truncate_asr_by_lines(asr_text, max_chars=1000),
        HOOK_TYPES=hook_types_text,
    )

    # Smart keyframe selection
    selected_keyframes = smart_select_keyframes(
        keyframes=segment.keyframes,
        asr_segments=segment.asr_segments,
        change_threshold=0.4,
    )

    # Ensure 5-24 keyframes
    if len(selected_keyframes) < 5 and len(segment.keyframes) >= 5:
        all_kf = segment.keyframes
        step = max(1, len(all_kf) // 5)
        additional = [all_kf[i * step] for i in range(5) if i * step < len(all_kf)]
        seen = {kf.frame_path for kf in selected_keyframes}
        for kf in additional:
            if kf.frame_path not in seen:
                selected_keyframes.append(kf)
                seen.add(kf.frame_path)
    elif len(selected_keyframes) > 24:
        step = len(selected_keyframes) // 24
        selected_keyframes = [selected_keyframes[i * step] for i in range(24)]

    # Encode keyframes
    keyframe_parts = []
    for kf in selected_keyframes:
        try:
            img_b64 = encode_image(kf.frame_path)
            keyframe_parts.append({
                "inline_data": {
                    "mime_type": "image/jpeg",
                    "data": img_b64,
                }
            })
        except Exception as e:
            logger.warning(f"  Cannot encode frame {kf.frame_path}: {e}")

    parts = [{"text": prompt}]
    parts.extend(keyframe_parts)

    return {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": TrainingConfig.GEMINI_TEMPERATURE,
            "maxOutputTokens": 1024,
        }
    }


def _analyze_segment_for_hooks(
    segment: VideoSegment,
    max_retries: int = 6,
) -> List[dict]:
    """Analyze a single segment for hook points via Gemini API.

    Returns:
        List of raw hook dicts from API response.
    """
    import requests

    url = _get_next_api_endpoint()
    headers = {"Content-Type": "application/json"}
    payload = _build_hook_prompt(segment)

    for attempt in range(max_retries):
        try:
            if attempt > 0:
                url = _get_next_api_endpoint()

            response = requests.post(url, headers=headers, json=payload, timeout=90)

            if 400 <= response.status_code < 500 and response.status_code != 429:
                logger.error(f"[{segment.start_time}-{segment.end_time}s] Client error {response.status_code}")
                return []

            response.raise_for_status()
            data = response.json()

            candidates = data.get('candidates', [])
            if not candidates:
                block_reason = data.get('promptFeedback', {}).get('blockReason', 'unknown')
                logger.warning(f"Segment {segment.start_time}-{segment.end_time}s blocked: {block_reason}")
                return []

            candidate = candidates[0]
            content = candidate.get('content')
            if not content or not content.get('parts'):
                return []

            response_text = content['parts'][0]['text']

            # Track API key health
            current_key = url.split('?key=')[-1] if '?key=' in url else ''
            if current_key:
                _api_key_manager.mark_success(current_key)

            # Parse response
            result = parse_analysis_response(
                response_text,
                segment.start_time,
                segment.end_time,
            )
            return result.get('hooks', [])

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 429:
                wait = min(30 * (attempt + 1), 120)
                logger.warning(f"Rate limited, waiting {wait}s...")
                current_key = url.split('?key=')[-1] if '?key=' in url else ''
                if current_key:
                    _api_key_manager.mark_failure(current_key)
                time.sleep(wait)
            else:
                logger.error(f"HTTP error: {e}")
                return []
        except Exception as e:
            wait = min(10 * (attempt + 1), 60)
            logger.warning(f"Attempt {attempt + 1} failed: {e}, retrying in {wait}s")
            current_key = url.split('?key=')[-1] if '?key=' in url else ''
            if current_key:
                _api_key_manager.mark_failure(current_key)
            time.sleep(wait)

    logger.error(f"All retries exhausted for segment {segment.start_time}-{segment.end_time}s")
    return []


# ========== Recut analysis (highlight + hook) ==========

def _build_recut_prompt(segment: VideoSegment) -> dict:
    """Build Gemini API payload for combined highlight+hook detection."""
    asr_text_parts = []
    for seg in segment.asr_segments:
        asr_text_parts.append(f"[{seg.start:.1f}-{seg.end:.1f}秒] {seg.text}")
    asr_text = '\n'.join(asr_text_parts) or "(无语音)"

    duration = segment.end_time - segment.start_time
    highlight_types_text = get_type_names_for_prompt('highlight')
    hook_types_text = get_type_names_for_prompt('hook')

    prompt_template = _load_recut_prompt()
    prompt = prompt_template.format(
        START=segment.start_time,
        END=segment.end_time,
        DURATION=duration,
        ASR_TEXT=truncate_asr_by_lines(asr_text, max_chars=1000),
        HIGHLIGHT_TYPES=highlight_types_text,
        HOOK_TYPES=hook_types_text,
    )

    # Smart keyframe selection (same as hook-only)
    selected_keyframes = smart_select_keyframes(
        keyframes=segment.keyframes,
        asr_segments=segment.asr_segments,
        change_threshold=0.4,
    )

    if len(selected_keyframes) < 5 and len(segment.keyframes) >= 5:
        all_kf = segment.keyframes
        step = max(1, len(all_kf) // 5)
        additional = [all_kf[i * step] for i in range(5) if i * step < len(all_kf)]
        seen = {kf.frame_path for kf in selected_keyframes}
        for kf in additional:
            if kf.frame_path not in seen:
                selected_keyframes.append(kf)
                seen.add(kf.frame_path)
    elif len(selected_keyframes) > 24:
        step = len(selected_keyframes) // 24
        selected_keyframes = [selected_keyframes[i * step] for i in range(24)]

    keyframe_parts = []
    for kf in selected_keyframes:
        try:
            img_b64 = encode_image(kf.frame_path)
            keyframe_parts.append({
                "inline_data": {
                    "mime_type": "image/jpeg",
                    "data": img_b64,
                }
            })
        except Exception as e:
            logger.warning(f"  Cannot encode frame {kf.frame_path}: {e}")

    parts = [{"text": prompt}]
    parts.extend(keyframe_parts)

    return {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": TrainingConfig.GEMINI_TEMPERATURE,
            "maxOutputTokens": 1024,
        }
    }


def _analyze_segment(
    segment: VideoSegment,
    max_retries: int = 6,
) -> tuple:
    """Analyze a single segment for both highlights and hooks via Gemini API.

    Returns:
        (List[dict], List[dict]) — (highlights, hooks)
    """
    import requests

    url = _get_next_api_endpoint()
    headers = {"Content-Type": "application/json"}
    payload = _build_recut_prompt(segment)

    for attempt in range(max_retries):
        try:
            if attempt > 0:
                url = _get_next_api_endpoint()

            response = requests.post(url, headers=headers, json=payload, timeout=90)

            if 400 <= response.status_code < 500 and response.status_code != 429:
                logger.error(f"[{segment.start_time}-{segment.end_time}s] Client error {response.status_code}")
                return ([], [])

            response.raise_for_status()
            data = response.json()

            candidates = data.get('candidates', [])
            if not candidates:
                block_reason = data.get('promptFeedback', {}).get('blockReason', 'unknown')
                logger.warning(f"Segment {segment.start_time}-{segment.end_time}s blocked: {block_reason}")
                return ([], [])

            candidate = candidates[0]
            content = candidate.get('content')
            if not content or not content.get('parts'):
                return ([], [])

            response_text = content['parts'][0]['text']

            current_key = url.split('?key=')[-1] if '?key=' in url else ''
            if current_key:
                _api_key_manager.mark_success(current_key)

            result = parse_analysis_response(
                response_text,
                segment.start_time,
                segment.end_time,
            )
            return (result.get('highlights', []), result.get('hooks', []))

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 429:
                wait = min(30 * (attempt + 1), 120)
                logger.warning(f"Rate limited, waiting {wait}s...")
                current_key = url.split('?key=')[-1] if '?key=' in url else ''
                if current_key:
                    _api_key_manager.mark_failure(current_key)
                time.sleep(wait)
            else:
                logger.error(f"HTTP error: {e}")
                return ([], [])
        except Exception as e:
            wait = min(10 * (attempt + 1), 60)
            logger.warning(f"Attempt {attempt + 1} failed: {e}, retrying in {wait}s")
            current_key = url.split('?key=')[-1] if '?key=' in url else ''
            if current_key:
                _api_key_manager.mark_failure(current_key)
            time.sleep(wait)

    logger.error(f"All retries exhausted for segment {segment.start_time}-{segment.end_time}s")
    return ([], [])


# ========== Main hook finding ==========

def find_hooks_in_video(
    video_path: str,
    max_hooks: int = 3,
    min_duration: int = 60,
    cache_dir: str = "data/cache",
    max_workers: int = 6,
) -> List[HookPoint]:
    """Find hook points in a video for creating shorter versions.

    Args:
        video_path: Path to the video file
        max_hooks: Maximum number of hooks to return
        min_duration: Minimum clip duration in seconds (hooks before this are excluded)
        cache_dir: Cache directory for keyframes/ASR
        max_workers: Max concurrent Gemini API calls

    Returns:
        Sorted list of top hook points
    """
    video_path = str(Path(video_path).resolve())
    video_name = Path(video_path).stem

    # Probe video
    logger.info(f"🎬 分析视频: {Path(video_path).name}")
    info = probe_video(video_path)
    duration = info['duration']
    fps = info['fps']
    logger.info(f"  时长: {duration:.1f}s, 分辨率: {info['width']}x{info['height']}, 帧率: {fps}")

    if duration < min_duration + 30:
        logger.warning(f"  视频太短 ({duration:.0f}s), 跳过")
        return []

    # Cache paths
    video_hash = hashlib.md5(video_path.encode()).hexdigest()[:8]
    project_name = Path(video_path).parent.name
    kf_dir = os.path.join(cache_dir, "keyframes", "recut", project_name, video_hash)
    audio_dir = os.path.join(cache_dir, "audio", "recut", project_name)
    asr_dir = os.path.join(cache_dir, "asr", "recut", project_name)

    os.makedirs(kf_dir, exist_ok=True)
    os.makedirs(audio_dir, exist_ok=True)
    os.makedirs(asr_dir, exist_ok=True)

    # Step 1: Extract keyframes
    logger.info("📸 提取关键帧...")
    # Adjust extraction FPS based on video FPS
    extraction_fps = 1.0
    if fps >= 50:
        extraction_fps = 2.0
    elif fps <= 25:
        extraction_fps = 0.5

    keyframes = extract_keyframes(
        video_path=video_path,
        output_dir=kf_dir,
        fps=extraction_fps,
        quality=5,
        video_actual_fps=fps,
    )
    logger.info(f"  提取了 {len(keyframes)} 帧")

    # Step 2: Extract ASR
    logger.info("🎤 提取ASR...")
    audio_path = os.path.join(audio_dir, f"{video_name}.wav")
    asr_output = os.path.join(asr_dir, f"{video_name}.json")

    extract_audio(video_path, audio_path)
    asr_segments = transcribe_audio(audio_path, asr_output)
    logger.info(f"  识别了 {len(asr_segments)} 段语音")

    # Step 3: Segment the video
    logger.info("📐 分段分析...")
    video_duration_int = int(duration)

    # Exclude last 15% (too close to original ending)
    exclude_tail = max(int(duration * 0.15), 30)
    effective_end = video_duration_int - exclude_tail

    # Filter keyframes and ASR to effective range
    effective_keyframes = [
        kf for kf in keyframes
        if kf.timestamp_ms <= effective_end * 1000
    ]
    effective_asr = [
        seg for seg in asr_segments
        if seg.end <= effective_end
    ]

    segments = extract_segments_for_episode(
        episode=1,  # treat as single episode
        keyframes=effective_keyframes,
        asr_segments=effective_asr,
        video_duration=effective_end,
        segment_duration=SEGMENT_DURATION,
        segment_overlap=SEGMENT_OVERLAP,
    )

    # Filter out segments that would result in clips shorter than min_duration
    valid_segments = [
        seg for seg in segments
        if seg.end_time >= min_duration
    ]
    logger.info(f"  有效分析窗口: {len(valid_segments)} 个 (排除前{min_duration}s和后{exclude_tail}s)")

    if not valid_segments:
        logger.warning("  没有有效分析窗口")
        return []

    # Step 4: AI analysis (concurrent)
    logger.info(f"🤖 AI分析钩子点 (并发={min(max_workers, len(valid_segments))})...")
    all_raw_hooks = []

    with ThreadPoolExecutor(max_workers=min(max_workers, len(valid_segments))) as executor:
        future_to_seg = {
            executor.submit(_analyze_segment_for_hooks, seg): seg
            for seg in valid_segments
        }
        for future in as_completed(future_to_seg):
            seg = future_to_seg[future]
            try:
                hooks = future.result()
                for h in hooks:
                    if h.get('exists'):
                        all_raw_hooks.append(h)
                        logger.info(
                            f"  🪝 [{seg.start_time}-{seg.end_time}s] "
                            f"hook@{h.get('preciseSecond')}s "
                            f"conf={h.get('confidence')}, desire={h.get('viewerDesire')}"
                        )
            except Exception as e:
                logger.error(f"  Segment {seg.start_time}-{seg.end_time}s failed: {e}")

    logger.info(f"  共发现 {len(all_raw_hooks)} 个候选钩子点")

    # Step 5: Filter and rank
    hooks = _filter_and_rank_hooks(
        raw_hooks=all_raw_hooks,
        max_hooks=max_hooks,
        min_duration=min_duration,
        video_duration=duration,
    )

    logger.info(f"✅ 最终选择 {len(hooks)} 个钩子点:")
    for i, h in enumerate(hooks, 1):
        logger.info(f"  {i}. @{h.timestamp:.1f}s (score={h.score:.2f}, conf={h.confidence}, desire={h.viewer_desire})")

    return hooks


def _filter_and_rank_hooks(
    raw_hooks: List[dict],
    max_hooks: int,
    min_duration: int,
    video_duration: float,
) -> List[HookPoint]:
    """Filter, deduplicate, and rank hook points.

    Criteria:
    - confidence >= 7.5 and viewerDesire >= 7
    - timestamp >= min_duration
    - timestamp <= video_duration * 0.85 (exclude last 15%)
    - At least 60s apart from each other
    - Ranked by composite score: confidence * 0.6 + viewerDesire * 0.4
    """
    max_timestamp = video_duration * 0.85

    # Filter by thresholds
    candidates = []
    for h in raw_hooks:
        ts = h.get('preciseSecond', 0)
        conf = h.get('confidence', 0)
        desire = h.get('viewerDesire', 0)

        if conf < 7.5 or desire < 7:
            continue
        if ts < min_duration or ts > max_timestamp:
            continue

        score = conf * 0.6 + desire * 0.4
        hook_type = match_hook_type(h.get('type', ''))

        candidates.append(HookPoint(
            timestamp=float(ts),
            type=hook_type,
            confidence=conf,
            viewer_desire=desire,
            reasoning=h.get('reasoning', ''),
            score=score,
        ))

    # Sort by score descending
    candidates.sort(key=lambda x: x.score, reverse=True)

    # Deduplicate: at least 60s apart
    MIN_GAP = 60
    selected = []
    for c in candidates:
        too_close = False
        for s in selected:
            if abs(c.timestamp - s.timestamp) < MIN_GAP:
                too_close = True
                break
        if not too_close:
            selected.append(c)
        if len(selected) >= max_hooks:
            break

    # Sort by timestamp for output clarity
    selected.sort(key=lambda x: x.timestamp)
    return selected


# ========== Highlight filtering ==========

def _filter_and_rank_highlights(
    raw_highlights: List[dict],
    max_highlights: int = 2,
    video_duration: float = 0,
) -> List[HighlightPoint]:
    """Filter, deduplicate, and rank highlight points.

    Criteria:
    - confidence >= 7.0
    - timestamp <= video_duration * 0.5 (must be in first half)
    - At least 30s apart from each other
    """
    max_timestamp = video_duration * 0.5

    candidates = []
    for h in raw_highlights:
        ts = h.get('preciseSecond', 0)
        conf = h.get('confidence', 0)

        if conf < 7.0:
            continue
        if ts > max_timestamp or ts < 5:
            continue

        hl_type = match_highlight_type(h.get('type', ''))
        candidates.append(HighlightPoint(
            timestamp=float(ts),
            type=hl_type,
            confidence=conf,
            reasoning=h.get('reasoning', ''),
            score=conf,
        ))

    candidates.sort(key=lambda x: x.score, reverse=True)

    # Deduplicate: at least 30s apart
    MIN_GAP = 30
    selected = []
    for c in candidates:
        too_close = any(abs(c.timestamp - s.timestamp) < MIN_GAP for s in selected)
        if not too_close:
            selected.append(c)
        if len(selected) >= max_highlights:
            break

    selected.sort(key=lambda x: x.timestamp)
    return selected


# ========== Combined recut clip finding ==========

def find_recut_clips(
    video_path: str,
    max_clips: int = 3,
    min_duration: int = 60,
    cache_dir: str = "data/cache",
    max_workers: int = 6,
) -> List[RecutClip]:
    """Find highlight × hook combinations for recut clips.

    Args:
        video_path: Path to the video file
        max_clips: Maximum number of clips to return
        min_duration: Minimum clip duration in seconds
        cache_dir: Cache directory for keyframes/ASR
        max_workers: Max concurrent Gemini API calls

    Returns:
        Sorted list of top RecutClip combinations (at least 1 with start=0)
    """
    video_path = str(Path(video_path).resolve())
    video_name = Path(video_path).stem

    # Probe video
    logger.info(f"🎬 分析视频: {Path(video_path).name}")
    info = probe_video(video_path)
    duration = info['duration']
    fps = info['fps']
    logger.info(f"  时长: {duration:.1f}s, 分辨率: {info['width']}x{info['height']}, 帧率: {fps}")

    if duration < min_duration + 30:
        logger.warning(f"  视频太短 ({duration:.0f}s), 跳过")
        return []

    # Cache paths
    video_hash = hashlib.md5(video_path.encode()).hexdigest()[:8]
    project_name = Path(video_path).parent.name
    kf_dir = os.path.join(cache_dir, "keyframes", "recut", project_name, video_hash)
    audio_dir = os.path.join(cache_dir, "audio", "recut", project_name)
    asr_dir = os.path.join(cache_dir, "asr", "recut", project_name)

    os.makedirs(kf_dir, exist_ok=True)
    os.makedirs(audio_dir, exist_ok=True)
    os.makedirs(asr_dir, exist_ok=True)

    # Step 1: Extract keyframes
    logger.info("📸 提取关键帧...")
    extraction_fps = 1.0
    if fps >= 50:
        extraction_fps = 2.0
    elif fps <= 25:
        extraction_fps = 0.5

    keyframes = extract_keyframes(
        video_path=video_path,
        output_dir=kf_dir,
        fps=extraction_fps,
        quality=5,
        video_actual_fps=fps,
    )
    logger.info(f"  提取了 {len(keyframes)} 帧")

    # Step 2: Extract ASR
    logger.info("🎤 提取ASR...")
    audio_path = os.path.join(audio_dir, f"{video_name}.wav")
    asr_output = os.path.join(asr_dir, f"{video_name}.json")

    extract_audio(video_path, audio_path)
    asr_segments = transcribe_audio(audio_path, asr_output)
    logger.info(f"  识别了 {len(asr_segments)} 段语音")

    # Step 3: Segment the video
    logger.info("📐 分段分析...")
    video_duration_int = int(duration)

    exclude_tail = max(int(duration * 0.15), 30)
    effective_end = video_duration_int - exclude_tail

    effective_keyframes = [
        kf for kf in keyframes
        if kf.timestamp_ms <= effective_end * 1000
    ]
    effective_asr = [
        seg for seg in asr_segments
        if seg.end <= effective_end
    ]

    segments = extract_segments_for_episode(
        episode=1,
        keyframes=effective_keyframes,
        asr_segments=effective_asr,
        video_duration=effective_end,
        segment_duration=SEGMENT_DURATION,
        segment_overlap=SEGMENT_OVERLAP,
    )

    valid_segments = [
        seg for seg in segments
        if seg.end_time >= min_duration
    ]
    logger.info(f"  有效分析窗口: {len(valid_segments)} 个 (排除前{min_duration}s和后{exclude_tail}s)")

    if not valid_segments:
        logger.warning("  没有有效分析窗口")
        return []

    # Step 4: AI analysis — combined highlight+hook (concurrent)
    logger.info(f"🤖 AI分析高光+钩子点 (并发={min(max_workers, len(valid_segments))})...")
    all_raw_highlights = []
    all_raw_hooks = []

    with ThreadPoolExecutor(max_workers=min(max_workers, len(valid_segments))) as executor:
        future_to_seg = {
            executor.submit(_analyze_segment, seg): seg
            for seg in valid_segments
        }
        for future in as_completed(future_to_seg):
            seg = future_to_seg[future]
            try:
                highlights, hooks = future.result()
                for hl in highlights:
                    if hl.get('exists'):
                        all_raw_highlights.append(hl)
                        logger.info(
                            f"  ✨ [{seg.start_time}-{seg.end_time}s] "
                            f"highlight@{hl.get('preciseSecond')}s "
                            f"conf={hl.get('confidence')}"
                        )
                for h in hooks:
                    if h.get('exists'):
                        all_raw_hooks.append(h)
                        logger.info(
                            f"  🪝 [{seg.start_time}-{seg.end_time}s] "
                            f"hook@{h.get('preciseSecond')}s "
                            f"conf={h.get('confidence')}, desire={h.get('viewerDesire')}"
                        )
            except Exception as e:
                logger.error(f"  Segment {seg.start_time}-{seg.end_time}s failed: {e}")

    logger.info(f"  候选: {len(all_raw_highlights)} 高光点, {len(all_raw_hooks)} 钩子点")

    # Step 5: Filter highlights and hooks
    highlights = _filter_and_rank_highlights(
        raw_highlights=all_raw_highlights,
        max_highlights=2,
        video_duration=duration,
    )

    hooks = _filter_and_rank_hooks(
        raw_hooks=all_raw_hooks,
        max_hooks=max_clips + 2,  # extra candidates for combo generation
        min_duration=min_duration,
        video_duration=duration,
    )

    if not hooks:
        logger.warning("  未找到合格钩子点")
        return []

    # Step 6: Add fixed 0s highlight
    zero_highlight = HighlightPoint(
        timestamp=0.0,
        type="opening",
        confidence=10.0,
        reasoning="原始开头（固定保留）",
        score=10.0,
    )
    all_highlights = [zero_highlight] + highlights
    logger.info(f"  高光点: {len(all_highlights)} 个 (含0s固定开头)")
    for hl in all_highlights:
        logger.info(f"    @{hl.timestamp:.1f}s type={hl.type} conf={hl.confidence}")

    # Step 7: Cartesian product → combo generation
    combos = []
    for hl in all_highlights:
        for hk in hooks:
            clip_duration = hk.timestamp - hl.timestamp
            if clip_duration < min_duration:
                continue
            if clip_duration > duration * 0.85:
                continue

            # Score: hook weight 0.7, highlight weight 0.3
            combo_score = hl.score * 0.3 + hk.score * 0.7
            # Bonus for 0s start (ensure at least one gets selected)
            if hl.timestamp == 0:
                combo_score += 0.5

            combos.append(RecutClip(
                start=hl.timestamp,
                end=hk.timestamp,
                duration=clip_duration,
                highlight=hl,
                hook=hk,
                score=combo_score,
            ))

    if not combos:
        logger.warning("  没有有效的高光×钩子组合")
        return []

    # Step 8: Rank and select top N
    combos.sort(key=lambda x: x.score, reverse=True)

    # Deduplicate: same hook point should not appear more than twice
    selected = []
    hook_usage = {}
    for c in combos:
        hook_key = round(c.end, 1)
        if hook_usage.get(hook_key, 0) >= 2:
            continue
        selected.append(c)
        hook_usage[hook_key] = hook_usage.get(hook_key, 0) + 1
        if len(selected) >= max_clips:
            break

    # Step 9: Guarantee at least one 0s start
    has_zero = any(c.start == 0 for c in selected)
    if not has_zero and selected:
        # Find best combo with 0s start
        zero_combos = [c for c in combos if c.start == 0]
        if zero_combos:
            # Replace lowest-scoring clip
            selected[-1] = zero_combos[0]

    # Sort by start time, then end time
    selected.sort(key=lambda x: (x.start, x.end))

    logger.info(f"✅ 最终选择 {len(selected)} 个剪辑组合:")
    for i, c in enumerate(selected, 1):
        logger.info(
            f"  {i}. {c.start:.1f}s → {c.end:.1f}s "
            f"(dur={c.duration:.0f}s, score={c.score:.2f}, "
            f"hl={c.highlight.type}, hk={c.hook.type})"
        )

    return selected
