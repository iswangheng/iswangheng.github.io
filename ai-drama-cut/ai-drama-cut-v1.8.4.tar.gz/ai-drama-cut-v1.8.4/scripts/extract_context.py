"""
上下文提取模块 - 为标记点提取关键帧和ASR上下文
"""
import os
from typing import List, Dict, Tuple, Optional

from .data_models import Marking, KeyFrame, ASRSegment, MarkingContext
from .config import TrainingConfig
from .extract_keyframes import extract_keyframes, load_existing_keyframes, get_keyframe_output_path
from .extract_asr import (
    extract_audio, transcribe_audio,
    load_asr_from_file, get_asr_output_path, get_audio_output_path
)


def prepare_episode_data(
    video_path: str,
    project_name: str,
    episode_number: int,
    force_reextract: bool = False
) -> Tuple[List[KeyFrame], List[ASRSegment]]:
    """Prepare keyframes and ASR data for an episode.

    Args:
        video_path: Path to the video file
        project_name: Project name
        episode_number: Episode number
        force_reextract: Whether to force re-extraction

    Returns:
        Tuple of (keyframes, asr_segments)
    """
    # Extract keyframes
    keyframe_dir = get_keyframe_output_path(project_name, episode_number)
    keyframes = extract_keyframes(
        video_path, keyframe_dir,
        force_reextract=force_reextract
    )

    # Extract ASR
    audio_path = get_audio_output_path(project_name, episode_number)
    asr_path = get_asr_output_path(project_name, episode_number)

    # Ensure audio directory exists
    os.makedirs(os.path.dirname(audio_path), exist_ok=True)
    os.makedirs(os.path.dirname(asr_path), exist_ok=True)

    # Extract audio if needed
    if force_reextract or not os.path.exists(audio_path):
        extract_audio(video_path, audio_path)

    # Transcribe
    asr_segments = transcribe_audio(
        audio_path, asr_path,
        force_retranscribe=force_reextract
    )

    return keyframes, asr_segments


def extract_contexts_for_markings(
    markings: List[Marking],
    project_name: str,
    episode_data: Dict[int, Tuple[List[KeyFrame], List[ASRSegment]]]
) -> List[MarkingContext]:
    """Extract context for each marking point.

    For highlights: take keyframes and ASR from marking time forward (30s)
    For hooks: take keyframes and ASR from before marking time (30s)

    Args:
        markings: List of markings
        project_name: Project name
        episode_data: Dict of {episode_number: (keyframes, asr_segments)}

    Returns:
        List of MarkingContext
    """
    contexts = []
    context_window = 30.0  # V23: expanded to ±30s

    for marking in markings:
        ep = marking.episode_number
        if ep not in episode_data:
            print(f"  Warning: episode {ep} data not available, skipping marking {marking.id}")
            continue

        keyframes, asr_segments = episode_data[ep]

        # Determine time window based on marking type
        if marking.type == "钩子点":
            # Hook: context before the marking point
            start_time = max(0, marking.seconds - context_window)
            end_time = marking.seconds
        else:
            # Highlight: context after the marking point
            start_time = marking.seconds
            end_time = marking.seconds + context_window

        # Filter keyframes within window
        context_keyframes = [
            kf for kf in keyframes
            if start_time * 1000 <= kf.timestamp_ms <= end_time * 1000
        ]

        # Filter ASR segments within window
        context_asr = [
            seg for seg in asr_segments
            if seg.start >= start_time and seg.end <= end_time
        ]

        # Build ASR text
        asr_text = " ".join([seg.text for seg in context_asr]) if context_asr else ""

        context = MarkingContext(
            project_name=project_name,
            marking=marking,
            keyframes=context_keyframes[:10],  # V23: up to 10 frames
            asr_segments=context_asr,
            asr_text=asr_text
        )
        contexts.append(context)

    return contexts


def filter_valid_contexts(contexts: List[MarkingContext]) -> List[MarkingContext]:
    """Filter contexts that have sufficient data for analysis.

    A valid context must have at least 1 keyframe OR non-empty ASR text.

    Args:
        contexts: All contexts

    Returns:
        Filtered valid contexts
    """
    valid = []
    for ctx in contexts:
        if ctx.keyframes or ctx.asr_text.strip():
            valid.append(ctx)
        else:
            print(f"  Warning: marking {ctx.marking.id} ({ctx.marking.episode} @ "
                  f"{ctx.marking.timestamp}) has no keyframes or ASR, skipping")
    return valid
