"""
Predefined type definitions for highlight and hook points.

This module defines a fixed set of highlight and hook types to eliminate
type fragmentation from AI free-form generation. Training and understanding
pipelines should map their results to these predefined types.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class TypeDefinition:
    """A predefined type definition."""
    id: str
    name: str
    description: str
    keywords: List[str] = field(default_factory=list)


# ============================================================
# Highlight Types (8 types, merged from ~12 fragmented types)
# ============================================================

HIGHLIGHT_TYPES: List[TypeDefinition] = [
    TypeDefinition(
        id="story_setup",
        name="故事设定开端",
        description="世界观交代、核心人物关系建立、主要矛盾引入（全剧仅1-3个，通常在前3集）",
        keywords=["世界观", "设定", "人物关系", "背景", "开端", "起源"]
    ),
    TypeDefinition(
        id="plot_reversal",
        name="剧情反转",
        description="意外转折、真相揭露、身份反转、关系反转",
        keywords=["反转", "转折", "真相", "揭露", "身份", "意外"]
    ),
    TypeDefinition(
        id="emotional_explosion",
        name="情感爆发",
        description="情绪剧烈爆发：愤怒、崩溃、痛哭、震惊、感动",
        keywords=["愤怒", "崩溃", "痛哭", "震惊", "爆发", "情感"]
    ),
    TypeDefinition(
        id="conflict_escalation",
        name="冲突升级",
        description="对抗加剧、矛盾激化、争吵升级、势力对抗",
        keywords=["冲突", "对抗", "争吵", "矛盾", "升级", "对峙"]
    ),
    TypeDefinition(
        id="visual_impact",
        name="视觉冲击",
        description="画面冲击力强、特效、动作场面、夸张表情",
        keywords=["视觉", "冲击", "特效", "动作", "表情", "画面"]
    ),
    TypeDefinition(
        id="suspense_trigger",
        name="悬念抛出",
        description="预警文字、疑问抛出、未知危险、悬念设置",
        keywords=["悬念", "预警", "疑问", "未知", "危险", "暗示"]
    ),
    TypeDefinition(
        id="information_reveal",
        name="信息揭示",
        description="关键信息公开、秘密暴露、重要发现",
        keywords=["信息", "秘密", "揭示", "发现", "公开", "暴露"]
    ),
    TypeDefinition(
        id="opening",
        name="开篇高光",
        description="第1集开头默认高光点（系统自动添加）",
        keywords=["开篇", "开场", "第1集"]
    ),
]


# ============================================================
# Hook Types (6 types, classified by underlying mechanism)
# ============================================================

HOOK_TYPES: List[TypeDefinition] = [
    TypeDefinition(
        id="time_node",
        name="时间节点型",
        description="明确未来时间 + 未完成事件（如'婚礼三天后举行'、'今晚'）",
        keywords=["三天后", "今晚", "明天", "即将", "马上", "时间", "倒计时", "期限"]
    ),
    TypeDefinition(
        id="unfinished_event",
        name="未完成事件型",
        description="冲突/事件未完成，想知道结果（如'还没给'、'还没说'）",
        keywords=["还没", "未完成", "继续", "结果", "然后", "怎么办", "困境", "险境",
                  "逃脱", "脱离", "关系", "建立", "加深"]
    ),
    TypeDefinition(
        id="dialogue_suspension",
        name="对话留白型",
        description="对话进行中被切断，只给开头不给结局",
        keywords=["你好", "我说", "其实", "告诉你", "留白", "切断", "对话", "说"]
    ),
    TypeDefinition(
        id="suspense_climax",
        name="悬念结束时刻",
        description="关键行动高潮时画面停住：要、即将、正要做某事时",
        keywords=["要", "即将", "正要", "高潮", "停住", "画面定格", "悬念", "制造",
                  "伏笔", "暗示", "设置"]
    ),
    TypeDefinition(
        id="major_twist",
        name="情节重大转折",
        description="反转、突变、意外、命运改变、人物关系剧变",
        keywords=["反转", "突变", "意外", "命运", "转折", "变化", "剧情转折",
                  "人物关系", "身份", "揭露", "暴露"]
    ),
    TypeDefinition(
        id="visual_freeze",
        name="纯画面型",
        description="无字幕 + 人物定格 + BGM停止/戛然而止",
        keywords=["定格", "静音", "BGM", "无字幕", "画面", "停止"]
    ),
]


# ============================================================
# Lookup helpers
# ============================================================

HIGHLIGHT_TYPE_MAP: Dict[str, TypeDefinition] = {t.id: t for t in HIGHLIGHT_TYPES}
HOOK_TYPE_MAP: Dict[str, TypeDefinition] = {t.id: t for t in HOOK_TYPES}

# Name-to-ID mapping for fuzzy matching from AI output
_HIGHLIGHT_NAME_MAP: Dict[str, str] = {t.name: t.id for t in HIGHLIGHT_TYPES}
_HOOK_NAME_MAP: Dict[str, str] = {t.name: t.id for t in HOOK_TYPES}


def match_highlight_type(name: str) -> str:
    """Match a free-form highlight type name to a predefined type ID.

    Uses keyword matching as fallback when exact name match fails.

    Args:
        name: Free-form type name from AI output

    Returns:
        Predefined type ID (defaults to 'visual_impact' if no match)
    """
    if not name:
        return 'visual_impact'

    # Exact name match
    if name in _HIGHLIGHT_NAME_MAP:
        return _HIGHLIGHT_NAME_MAP[name]

    # Keyword matching
    name_lower = name.lower()
    best_match = None
    best_score = 0

    for type_def in HIGHLIGHT_TYPES:
        score = sum(1 for kw in type_def.keywords if kw in name_lower)
        if score > best_score:
            best_score = score
            best_match = type_def.id

    return best_match if best_score > 0 else 'visual_impact'


def match_hook_type(name: str) -> str:
    """Match a free-form hook type name to a predefined type ID.

    Args:
        name: Free-form type name from AI output

    Returns:
        Predefined type ID (defaults to 'unfinished_event' if no match)
    """
    if not name:
        return 'unfinished_event'

    # Exact name match
    if name in _HOOK_NAME_MAP:
        return _HOOK_NAME_MAP[name]

    # Keyword matching
    name_lower = name.lower()
    best_match = None
    best_score = 0

    for type_def in HOOK_TYPES:
        score = sum(1 for kw in type_def.keywords if kw in name_lower)
        if score > best_score:
            best_score = score
            best_match = type_def.id

    return best_match if best_score > 0 else 'unfinished_event'


def get_type_names_for_prompt(category: str = 'both') -> str:
    """Generate type enumeration text for injection into prompts.

    Args:
        category: 'highlight', 'hook', or 'both'

    Returns:
        Formatted type list text
    """
    lines = []

    if category in ('highlight', 'both'):
        lines.append("### 高光类型（必须从以下类型中选择）")
        for t in HIGHLIGHT_TYPES:
            if t.id == 'opening':
                continue  # System auto-adds, skip in prompt
            lines.append(f"- **{t.name}**（{t.id}）: {t.description}")
        lines.append("")

    if category in ('hook', 'both'):
        lines.append("### 钩子类型（必须从以下类型中选择）")
        for t in HOOK_TYPES:
            lines.append(f"- **{t.name}**（{t.id}）: {t.description}")
        lines.append("")

    return '\n'.join(lines)
