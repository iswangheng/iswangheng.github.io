#!/bin/bash
# ============================================================
# AI 短剧剪辑服务 - 打包脚本
# 用法：bash openclaw/package.sh
# ============================================================

set -euo pipefail

cd "$(dirname "$0")/.."
PROJECT_ROOT=$(pwd)
VERSION_FILE="$PROJECT_ROOT/openclaw/version.json"
DIST_DIR="$PROJECT_ROOT/dist"

read_json() {
  python3 - "$VERSION_FILE" "$1" <<'PY'
import json
import sys
from pathlib import Path
path = Path(sys.argv[1])
key = sys.argv[2]
data = json.loads(path.read_text(encoding='utf-8'))
print(data[key])
PY
}

NAME=$(read_json name)
VERSION=$(read_json version)
REPOSITORY_BASE=$(read_json repository_base)
PACKAGE_NAME="${NAME}-v${VERSION}"
OUTPUT_FILE="${PACKAGE_NAME}.tar.gz"
CHECKSUM_FILE="${OUTPUT_FILE}.sha256"
TEMP_DIR="/tmp/${PACKAGE_NAME}"

mkdir -p "$DIST_DIR"
rm -rf "$TEMP_DIR"
rm -f "$DIST_DIR/$OUTPUT_FILE" "$DIST_DIR/$CHECKSUM_FILE"
mkdir -p "$TEMP_DIR"

cp -r openclaw "$TEMP_DIR/"
cp -r scripts "$TEMP_DIR/"
mkdir -p "$TEMP_DIR/config"
cp config/sensitive_words.txt "$TEMP_DIR/config/"
cp -r 标准结尾帧视频素材 "$TEMP_DIR/"
mkdir -p "$TEMP_DIR/data/skills"
cp data/skills/ai-drama-clipping-thoughts-latest.* "$TEMP_DIR/data/skills/"
cp .gitignore "$TEMP_DIR/" 2>/dev/null || true
mkdir -p "$TEMP_DIR/data/cache/keyframes"
mkdir -p "$TEMP_DIR/data/cache/audio"
mkdir -p "$TEMP_DIR/data/cache/asr"
mkdir -p "$TEMP_DIR/data/cache/subtitle_region"
mkdir -p "$TEMP_DIR/data/analysis"
mkdir -p "$TEMP_DIR/data/ending_credits"
mkdir -p "$TEMP_DIR/clips"
cp openclaw/README.md "$TEMP_DIR/README.md"

python3 - "$PROJECT_ROOT" <<'PY'
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
version = json.loads((root / 'openclaw/version.json').read_text(encoding='utf-8'))['version']
skill = (root / 'openclaw/SKILL.md').read_text(encoding='utf-8')
readme = (root / 'openclaw/README.md').read_text(encoding='utf-8')
for path, text in [('SKILL.md', skill), ('README.md', readme)]:
    if version not in text:
        raise SystemExit(f'{path} 未包含版本号 {version}')
if f'ai-drama-cut-v{version}.tar.gz' not in skill:
    raise SystemExit('SKILL.md 中的 tarball 名称与 version.json 不一致')
print('release metadata check passed')
PY

find "$TEMP_DIR" -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null || true
find "$TEMP_DIR" -name '.DS_Store' -delete 2>/dev/null || true
find "$TEMP_DIR" -name '*.pyc' -delete 2>/dev/null || true

# ============================================================
# 编译核心模块为 .so 文件（代码保护）
# ============================================================
echo "🔒 编译核心模块（代码保护）..."

# 在 TEMP_DIR 中创建编译配置
cat > "$TEMP_DIR/setup_cython_build.py" <<'PY_END'
"""Cython 编译配置（自动生成）"""
from setuptools import setup, Extension
from Cython.Build import cythonize
import os

# 需要编译的核心模块
CORE_MODULES = [
    "scripts/understand/analyze_segment.py",
    "scripts/understand/generate_clips.py",
    "scripts/understand/quality_filter.py",
    "scripts/understand/smart_cut_finder.py",
    "scripts/understand/video_understand.py",
    "scripts/understand/render_clips.py",
    "scripts/understand/video_overlay/__init__.py",
    "scripts/understand/video_overlay/overlay_styles.py",
    "scripts/understand/video_overlay/tilted_label.py",
    "scripts/understand/video_overlay/video_overlay.py",
    "scripts/preprocess/__init__.py",
    "scripts/preprocess/sensitive_mask_workflow.py",
    "scripts/preprocess/ocr_subtitle.py",
    "scripts/preprocess/sensitive_detector.py",
    "scripts/preprocess/subtitle_detector.py",
    "scripts/preprocess/video_cleaner.py",
    "scripts/data_models.py",
    "scripts/config.py",
    "scripts/extract_keyframes.py",
    "scripts/extract_asr.py",
    "scripts/detect_ending_credits.py",
    "scripts/asr_analyzer.py",
    "scripts/log_config.py",
    "scripts/manage_version.py",
    "scripts/remote_update.py",
]

extensions = []
for module_path in CORE_MODULES:
    if os.path.exists(module_path):
        module_name = module_path.replace('/', '.').replace('.py', '')
        extensions.append(Extension(module_name, [module_path], include_dirs=["."]))

setup(
    name="ai-drama-cut-protected",
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            'language_level': "3",
            'embedsignature': False,
            'emit_code_comments': False,
            'infer_types': None,  # 禁用类型推断
            'binding': True,  # 启用绑定以支持动态类型
        },
        annotate=False,
    ),
)
PY_END

# 编译
cd "$TEMP_DIR"
python3 setup_cython_build.py build_ext --inplace 2>/dev/null || {
    echo "⚠️  编译失败（可能未安装 Cython），使用源码打包"
    rm -f setup_cython_build.py
}

# 删除 .py 源文件（只保留编译后的 .so）
for py_file in $(find "$TEMP_DIR/scripts" -name "*.py" ! -name "__init__.py"); do
    base="${py_file%.py}"
    # 如果存在对应的 .so 文件，删除 .py 文件
    if [ -f "${base}.so" ] || [ -f "${base}".cpython-*.so ]; then
        rm -f "$py_file"
    fi
done

# 删除编译中间文件
rm -rf "$TEMP_DIR/build"
rm -f "$TEMP_DIR/setup_cython_build.py"
find "$TEMP_DIR" -name "*.c" -delete 2>/dev/null || true

echo "✅ 核心模块已编译保护"
echo "   - 源代码已从 tarball 中移除"
echo "   - 编译产物（.so 文件）已包含"

cd /tmp
tar -czf "$OUTPUT_FILE" "$PACKAGE_NAME"
mv "$OUTPUT_FILE" "$DIST_DIR/"
shasum -a 256 "$DIST_DIR/$OUTPUT_FILE" > "$DIST_DIR/$CHECKSUM_FILE"
rm -rf "$TEMP_DIR"

cat <<EOF
打包完成
- 版本: $VERSION
- 产物: $DIST_DIR/$OUTPUT_FILE
- 校验: $DIST_DIR/$CHECKSUM_FILE
- 仓库地址: ${REPOSITORY_BASE}/${OUTPUT_FILE}
EOF
