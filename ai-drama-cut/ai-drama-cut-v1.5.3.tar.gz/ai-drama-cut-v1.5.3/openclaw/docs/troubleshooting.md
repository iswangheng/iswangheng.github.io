# 故障排除指南

## 常见问题和解决方案

### 1. 安装问题

#### 问题：Python 版本过低

**错误信息**：
```
❌ Python 版本过低: 3.7
   需要 Python 3.8+
```

**解决方案**：
```bash
# macOS
brew install python@3.11

# Ubuntu/Debian
sudo apt-get install python3.11

# 验证版本
python3 --version
```

#### 问题：FFmpeg 未安装

**错误信息**：
```
❌ FFmpeg 未安装
```

**解决方案**：
```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt-get update
sudo apt-get install ffmpeg

# 验证安装
ffmpeg -version
```

#### 问题：FFmpeg 缺少 drawtext 滤镜

**错误信息**：
```
⚠️  drawtext 滤镜不支持（花字功能不可用）
```

**解决方案**：
```bash
# macOS：重新安装 FFmpeg
brew uninstall ffmpeg
brew install ffmpeg

# Ubuntu/Debian：安装完整版
sudo apt-get install ffmpeg libfreetype6-dev

# 验证 drawtext 支持
ffmpeg -filters | grep drawtext
```

#### 问题：PyTorch 安装失败

**错误信息**：
```
ERROR: Could not find a version that satisfies the requirement torch
```

**解决方案**：
```bash
# CPU 版本
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu

# GPU 版本（NVIDIA）
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu118

# 使用国内镜像
pip install torch torchaudio -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 2. 配置问题

#### 问题：API Key 未配置

**错误信息**：
```
❌ .env 文件不存在
   运行: python setup_api.py
```

**解决方案**：
```bash
# 运行配置向导
python setup_api.py

# 或手动创建 .env
cp .env.example .env
nano .env  # 填写 GEMINI_API_KEY
```

#### 问题：API Key 无效

**错误信息**：
```
❌ API Key 测试失败: Invalid API key
```

**解决方案**：
1. 检查 API Key 是否完整复制（没有多余空格）
2. 确认 API Key 格式正确（以 `AIza` 开头）
3. 重新生成 API Key：https://makersuite.google.com/app/apikey

#### 问题：中文字体缺失

**错误信息**：
```
⚠️  未找到中文字体（花字文字可能显示为方块）
```

**解决方案**：
```bash
# macOS：系统自带中文字体，无需安装

# Ubuntu/Debian
sudo apt-get install fonts-wqy-zenhei

# 验证字体
fc-list :lang=zh
```

### 3. 运行问题

#### 问题：输入目录不存在

**错误信息**：
```
❌ 错误：输入目录不存在: 漫剧素材/项目名
```

**解决方案**：
1. 检查路径是否正确
2. 使用绝对路径：
   ```bash
   python ai_drama_cutter.py --input "/Users/username/漫剧素材/项目名"
   ```
3. 确认目录中有视频文件（.mp4/.mov/.avi）

#### 问题：视频理解失败

**错误信息**：
```
RuntimeError: 视频理解失败
```

**可能原因和解决方案**：

1. **API 配额超限**
   ```bash
   # 检查 API 使用情况
   # 等待配额重置或升级到付费方案
   ```

2. **网络连接问题**
   ```bash
   # 测试网络连接
   curl https://generativelanguage.googleapis.com

   # 使用代理（如果在国内）
   export HTTP_PROXY=http://127.0.0.1:7890
   export HTTPS_PROXY=http://127.0.0.1:7890
   ```

3. **视频文件损坏**
   ```bash
   # 验证视频文件
   ffmpeg -v error -i "视频文件.mp4" -f null -

   # 如果有错误，尝试重新编码
   ffmpeg -i "损坏的视频.mp4" -c copy "修复后的视频.mp4"
   ```

#### 问题：剪辑渲染失败

**错误信息**：
```
RuntimeError: 剪辑渲染失败
```

**可能原因和解决方案**：

1. **磁盘空间不足**
   ```bash
   # 检查磁盘空间
   df -h

   # 清理缓存
   rm -rf data/cache/*
   ```

2. **FFmpeg 编码错误**
   ```bash
   # 查看详细错误日志
   python ai_drama_cutter.py --input "项目目录" 2>&1 | tee error.log

   # 尝试使用不同的编码器
   # 编辑 scripts/understand/render_clips.py
   # 将 libx264 改为 h264_videotoolbox（macOS）
   ```

3. **花字渲染失败**
   ```bash
   # 跳过花字叠加
   python -m scripts.understand.render_clips \
       data/analysis/项目名 \
       漫剧素材/项目名 \
       --no-overlay
   ```

### 4. 性能问题

#### 问题：处理速度太慢

**症状**：
- 预处理耗时 > 5 分钟/集
- 视频理解耗时 > 10 分钟/集
- 剪辑渲染耗时 > 2 分钟/剪辑

**解决方案**：

1. **使用 GPU 加速**
   ```bash
   # 检查 GPU
   nvidia-smi

   # 安装 GPU 版本的 PyTorch 和 PaddlePaddle
   pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu118
   pip install paddlepaddle-gpu
   ```

2. **减少采样率**
   ```python
   # 编辑 ai_drama_cutter.py
   # 修改 sample_fps 从 5.0 降到 3.0
   workflow = SensitiveMaskWorkflow(
       sensitive_words_path=...,
       sample_fps=3.0,  # 降低采样率
       ...
   )
   ```

3. **跳过预处理**（如果视频已经干净）
   ```bash
   python ai_drama_cutter.py --input "项目目录" --skip-preprocess
   ```

#### 问题：内存不足

**错误信息**：
```
MemoryError: Unable to allocate array
```

**解决方案**：

1. **减少并行处理数量**
   ```bash
   # 编辑 scripts/understand/render_clips.py
   # 修改 parallel 参数
   --parallel 2  # 从 4 降到 2
   ```

2. **关闭其他程序**
   ```bash
   # 释放内存
   # 关闭浏览器、IDE 等占用内存的程序
   ```

3. **使用交换空间**
   ```bash
   # Linux：增加交换空间
   sudo fallocate -l 8G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

### 5. 输出问题

#### 问题：生成的剪辑数量少于 20 个

**可能原因**：
- AI 识别的高光点/钩子点数量不足
- 置信度阈值过高
- 去重过于严格

**解决方案**：

1. **降低置信度阈值**
   ```python
   # 编辑 scripts/understand/quality_filter.py
   # 修改 confidence_threshold 从 7.0 降到 6.5
   ```

2. **增加分析窗口**
   ```python
   # 编辑 scripts/understand/extract_segments.py
   # 修改 window_size 从 30 增加到 45
   ```

3. **检查分析结果**
   ```bash
   # 查看分析结果
   cat data/analysis/项目名/result.json | jq '.highlights | length'
   cat data/analysis/项目名/result.json | jq '.hooks | length'
   ```

#### 问题：花字显示为方块

**症状**：
- 视频中的中文文字显示为 □□□

**解决方案**：

1. **安装中文字体**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install fonts-wqy-zenhei

   # 验证字体
   fc-list :lang=zh
   ```

2. **指定字体路径**
   ```python
   # 编辑 scripts/understand/video_overlay/video_overlay.py
   # 修改 font_path
   font_path = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
   ```

#### 问题：视频压缩后画质太差

**症状**：
- 视频模糊、有马赛克

**解决方案**：

1. **提高压缩质量**
   ```bash
   # 增加目标大小
   python -m scripts.understand.render_clips \
       data/analysis/项目名 \
       漫剧素材/项目名 \
       --compress-target 200  # 从 100MB 增加到 200MB
   ```

2. **禁用压缩**
   ```bash
   # 不压缩视频
   python -m scripts.understand.render_clips \
       data/analysis/项目名 \
       漫剧素材/项目名 \
       --no-compress
   ```

### 6. 调试技巧

#### 启用详细日志

```bash
# 设置环境变量
export DEBUG=1

# 运行脚本
python ai_drama_cutter.py --input "项目目录"
```

#### 查看中间结果

```bash
# 查看关键帧
ls -lh data/cache/keyframes/项目名/

# 查看 ASR 结果
cat data/cache/asr/项目名/第1集.json | jq

# 查看分析结果
cat data/analysis/项目名/result.json | jq
```

#### 单步调试

```bash
# 仅执行预处理
python ai_drama_cutter.py --input "项目目录" --preprocess-only

# 仅执行分析
python ai_drama_cutter.py --input "项目目录" --skip-preprocess --skip-render

# 仅执行渲染
python ai_drama_cutter.py --input "项目目录" --render-only
```

## 获取帮助

如果以上方法都无法解决问题，请：

1. **查看完整错误日志**
   ```bash
   python ai_drama_cutter.py --input "项目目录" 2>&1 | tee error.log
   ```

2. **检查系统信息**
   ```bash
   python check_dependencies.py > system_info.txt
   ```

3. **提交 Issue**
   - 访问：https://github.com/hangzhou-leiming/ai-drama-cutter-skill/issues
   - 附上错误日志和系统信息
   - 描述复现步骤

4. **联系支持**
   - 邮箱：support@hangzhou-leiming.com
   - 提供详细的错误信息和环境配置
