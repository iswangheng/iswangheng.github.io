#!/bin/bash
# ============================================================
# 杭州雷鸣 AI 短剧剪辑服务 - 一键安装脚本
# ============================================================

set -euo pipefail

info() { echo "[INFO] $1"; }
warn() { echo "[WARN] $1"; }

cd "$(dirname "$0")/.."
PROJECT_ROOT=$(pwd)
OPENCLAW_DIR="$PROJECT_ROOT/openclaw"

info "检查 Python 版本..."
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit('需要 Python 3.10（当前版本已编译优化，依赖 3.10 运行时）')
print('Python version ok')
PY

if ! command -v ffmpeg >/dev/null 2>&1; then
  warn "未检测到 ffmpeg，请先安装支持 drawtext 的 FFmpeg。"
fi

info "升级 pip..."
python3 -m pip install --upgrade pip -q

info "安装 PyTorch..."
if ! python3 -c "import torch" >/dev/null 2>&1; then
  if command -v nvidia-smi >/dev/null 2>&1; then
    python3 -m pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu118
  else
    python3 -m pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
  fi
fi

info "安装 PaddlePaddle..."
if ! python3 -c "import paddle" >/dev/null 2>&1; then
  if command -v nvidia-smi >/dev/null 2>&1; then
    python3 -m pip install paddlepaddle-gpu -i https://pypi.tuna.tsinghua.edu.cn/simple
  else
    python3 -m pip install paddlepaddle -i https://pypi.tuna.tsinghua.edu.cn/simple
  fi
fi

info "安装其余 Python 依赖..."
python3 -m pip install -r "$OPENCLAW_DIR/requirements.txt" --ignore-requires-python -q \
  --extra-index-url https://pypi.tuna.tsinghua.edu.cn/simple

info "预下载 Whisper 模型..."
python3 - <<'PY'
import whisper
try:
    whisper.load_model('base')
    print('Whisper model ok')
except Exception as exc:
    print(f'Whisper model preload skipped: {exc}')
PY

if [ ! -f "$PROJECT_ROOT/.env" ]; then
  warn "未检测到 .env，接下来将启动 API 配置向导。"
  (cd "$OPENCLAW_DIR" && python3 setup_api.py)
fi

info "运行结构化依赖检查..."
(cd "$OPENCLAW_DIR" && python3 check_dependencies.py)

cat <<EOF
安装完成
- 项目目录: $PROJECT_ROOT
- 下一步: cd openclaw && python3 skill.py --input <项目目录>
EOF
