#!/usr/bin/env python3
"""OpenClaw skill runtime for AI drama cutting."""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
import sys
import threading
import time

# Force line-buffered stdout so that OpenClaw (or any parent process capturing
# our stdout) receives progress messages in real time instead of waiting for
# the 8 KB block buffer to fill up.
if not sys.stdout.line_buffering:
    sys.stdout.reconfigure(line_buffering=True)
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.runtime import (
    PROGRESS_DIR,
    STAGE_LABELS,
    build_artifact_names,
    format_eta_range,
    read_progress,
)
from scripts.log_config import get_logger, setup_logging
from scripts.preprocess.sensitive_mask_workflow import SensitiveMaskWorkflow
from scripts.baidu_pan.config import BaiduPanConfig

logger = get_logger(__name__)

HEARTBEAT_INTERVAL = 20
POLL_INTERVAL = 2
STAGE_BASELINE_SECONDS = {
    'downloading': 5 * 60,
    'preprocessing': 8 * 60,
    'keyframe_extraction': 3 * 60,
    'asr_extraction': 5 * 60,
    'ending_detection': 2 * 60,
    'ai_analysis': 8 * 60,
    'rendering': 10 * 60,
}
ERROR_CATEGORY_HINTS = {
    'gemini': '外部 API',
    'api key': '外部 API',
    'ffmpeg': '环境',
    'font': '环境',
    'disk': '资源',
    'space': '资源',
    'not found': '输入',
    'missing': '输入',
    'permission': '环境',
}


@dataclass
class StageWatch:
    stage: str
    current_item: str = ''
    completed: int = 0
    total: int = 0
    last_progress_at: float = 0.0
    last_heartbeat_at: float = 0.0
    last_status: str = ''
    started_at: float = 0.0


class RuntimeMonitor:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.stage_state: Dict[str, StageWatch] = {}

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        self.thread.join(timeout=1)

    def _run(self) -> None:
        while not self.stop_event.is_set():
            if PROGRESS_DIR.exists():
                for progress_file in PROGRESS_DIR.glob(f'{self.project_name}_*.json'):
                    data = read_progress(progress_file)
                    if not data:
                        continue
                    stage = data.get('stage', progress_file.stem.removeprefix(f'{self.project_name}_'))
                    state = self.stage_state.setdefault(stage, StageWatch(stage=stage))
                    completed = data.get('completed', 0)
                    total = data.get('total', 0)
                    current_item = data.get('current_item', '')
                    status = data.get('status', 'running')
                    timestamp = data.get('timestamp', time.time())
                    last_progress_at = data.get('last_progress_at', timestamp)
                    started_at = data.get('started_at', timestamp)
                    message = data.get('message', '')
                    eta_text = format_eta_range(data.get('eta_min_seconds'), data.get('eta_max_seconds'))
                    stage_label = STAGE_LABELS.get(stage, stage)

                    if state.started_at == 0.0:
                        state.started_at = started_at
                        print(f'\n🧭 进入阶段：{stage_label}。{message or "开始处理。"}', flush=True)

                    progress_advanced = completed > state.completed or total != state.total
                    item_changed = current_item and current_item != state.current_item

                    if progress_advanced or item_changed or status != state.last_status:
                        extra = f'，当前对象：{current_item}' if current_item else ''
                        progress = f'{completed}/{total}' if total else str(completed)
                        print(f'\n📊 {stage_label}：{progress}{extra}。{message or eta_text}', flush=True)
                        state.completed = completed
                        state.total = total
                        state.current_item = current_item
                        state.last_status = status
                        state.last_progress_at = last_progress_at
                        state.last_heartbeat_at = time.time()
                    else:
                        now = time.time()
                        state.last_progress_at = max(state.last_progress_at, last_progress_at)
                        idle_seconds = now - (state.last_progress_at or now)
                        if idle_seconds >= HEARTBEAT_INTERVAL and now - state.last_heartbeat_at >= HEARTBEAT_INTERVAL:
                            extra = f'，当前对象：{current_item}' if current_item else ''
                            print(f'\n💓 {stage_label}仍在处理中{extra}。{message or eta_text}', flush=True)
                            state.last_heartbeat_at = now
            time.sleep(POLL_INTERVAL)


def monitor_progress(progress_file: Path, project_name: str, stop_event: threading.Event):
    monitor = RuntimeMonitor(project_name)
    monitor.stop_event = stop_event
    monitor._run()


def monitor_progress_multi(project_name: str, stop_event: threading.Event):
    monitor = RuntimeMonitor(project_name)
    monitor.stop_event = stop_event
    monitor._run()


class AIDramaCutter:
    def __init__(
        self,
        input_dir: str,
        output_dir: Optional[str] = None,
        max_clips: int = 20,
        demo_mode: bool = False,
        upload: bool = False,
        download_url: Optional[str] = None,
        download_pwd: Optional[str] = None,
    ):
        self.input_dir = Path(input_dir).resolve()
        self.project_name = self.input_dir.name
        self.demo_mode = demo_mode
        self.upload_enabled = upload
        self.max_clips = max_clips
        self.output_dir = Path(output_dir).resolve() if output_dir else PROJECT_ROOT / 'clips' / self.project_name
        self.clean_dir = PROJECT_ROOT / 'data' / 'clean' / self.project_name
        self.analysis_dir = PROJECT_ROOT / 'data' / 'analysis' / self.project_name
        self.release = build_artifact_names()
        self.completed_stages: List[str] = []
        self.download_url = download_url
        self.download_pwd = download_pwd or ''

    @staticmethod
    def _parse_baidu_input(raw_text: str) -> Tuple[str, str]:
        """Parse various formats of Baidu Pan share link + extraction code.

        Supported formats:
          - https://pan.baidu.com/s/1xxx?pwd=abcd
          - https://pan.baidu.com/s/1xxx 提取码: abcd
          - https://pan.baidu.com/s/1xxx 提取码：abcd
          - 链接: https://pan.baidu.com/s/1xxx 提取码: abcd
          - https://pan.baidu.com/s/1xxx pwd=abcd

        Returns:
            (url, pwd) tuple
        """
        import re as _re
        # Extract URL
        url_match = _re.search(r'https?://pan\.baidu\.com/s/[A-Za-z0-9_-]+(?:\?[^\s]*)?', raw_text)
        if not url_match:
            raise ValueError(f'未找到百度网盘链接: {raw_text}')
        url = url_match.group(0)

        # Extract pwd from URL query param
        pwd = ''
        pwd_in_url = _re.search(r'[?&]pwd=([A-Za-z0-9]+)', url)
        if pwd_in_url:
            pwd = pwd_in_url.group(1)

        # Extract pwd from surrounding text (提取码/pwd)
        if not pwd:
            pwd_match = _re.search(r'(?:提取码|密码|pwd)\s*[:：=]\s*([A-Za-z0-9]{4})', raw_text)
            if pwd_match:
                pwd = pwd_match.group(1)

        return url, pwd

    def _run_download(self, max_episodes: int = 10) -> Path:
        """Download drama from Baidu Pan and return the local directory path."""
        from scripts.baidu_pan.downloader import BaiduPanDownloader

        url = self.download_url
        pwd = self.download_pwd
        if not url:
            raise ValueError('未提供百度网盘下载链接')

        downloader = BaiduPanDownloader()
        local_dir = PROJECT_ROOT / '漫剧素材'
        local_dir.mkdir(parents=True, exist_ok=True)

        print(f'📥 开始从百度网盘下载短剧素材...', flush=True)
        drama_name, downloaded_files = downloader.download_drama(
            share_url=url,
            pwd=pwd,
            local_dir=local_dir,
            max_episodes=max_episodes,
            progress_project_name=self.project_name,
        )
        drama_dir = local_dir / drama_name
        total_size_mb = sum(f.stat().st_size for f in downloaded_files) / (1024 ** 2) if downloaded_files else 0
        print(f'✅ 下载完成：{len(downloaded_files)} 集视频已保存到 漫剧素材/{drama_name}/（共 {total_size_mb:.0f} MB）', flush=True)
        return drama_dir

    def _update_paths_for_project(self, new_input_dir: Path) -> None:
        """Update all project-dependent paths after download resolves the actual project name."""
        self.input_dir = new_input_dir
        self.project_name = new_input_dir.name
        self.output_dir = PROJECT_ROOT / 'clips' / self.project_name
        self.clean_dir = PROJECT_ROOT / 'data' / 'clean' / self.project_name
        self.analysis_dir = PROJECT_ROOT / 'data' / 'analysis' / self.project_name

    def run_full_pipeline(self, skip_preprocess: bool = False, skip_analysis: bool = False, max_episodes: int = 10) -> None:
        start_time = time.time()
        source_dir = self.input_dir

        try:
            # Download stage: if a Baidu Pan URL was provided, download first
            if self.download_url:
                self._announce_stage('downloading', '开始从百度网盘下载短剧素材。')
                download_dir = self._run_download(max_episodes)
                self._update_paths_for_project(download_dir)
                source_dir = self.input_dir
                self.completed_stages.append('downloading')

            resume_notes = self._detect_resume(skip_preprocess, skip_analysis)
            self._print_plan(skip_preprocess, skip_analysis, resume_notes)

            if not skip_preprocess:
                self._announce_stage('preprocessing', '开始扫描和处理敏感内容。')
                self._run_preprocess()
                source_dir = self.clean_dir
                self.completed_stages.append('preprocessing')
            else:
                print('\n⏭️ 跳过预处理，直接使用原始素材。')

            if not skip_analysis:
                self._announce_stage('analysis', '开始视频理解，包含关键帧、ASR、片尾检测和 AI 分析。')
                self._run_analysis(source_dir)
                self.completed_stages.append('analysis')
            else:
                print('\n⏭️ 跳过分析，直接复用已有结果。')

            self._announce_stage('rendering', '开始生成剪辑结果。')
            self._run_render(source_dir)
            self.completed_stages.append('rendering')
            self._print_completion_summary(start_time)
        except Exception as exc:
            self._print_failure_summary(exc)
            raise

    def _detect_resume(self, skip_preprocess: bool, skip_analysis: bool) -> List[str]:
        notes: List[str] = []
        if self.clean_dir.exists() and any(self.clean_dir.glob('*.mp4')) and not skip_preprocess:
            notes.append('检测到已存在的预处理输出，可复用 clean 素材。')
        if (self.analysis_dir / 'result.json').exists() and not skip_analysis:
            notes.append('检测到已有 result.json，本次会优先复用分析结果并触发自动修复。')
        return notes

    def _print_plan(self, skip_preprocess: bool, skip_analysis: bool, resume_notes: List[str]) -> None:
        print('=' * 60)
        print('AI 短剧剪辑 workflow runtime')
        print('=' * 60)
        print(f'项目名: {self.project_name}')
        print(f'输入目录: {self.input_dir}')
        print(f'输出目录: {self.output_dir}')
        print(f'目标剪辑数: {self.max_clips}')
        print('阶段计划:')
        if not skip_preprocess:
            print('- 预处理：敏感内容扫描与遮罩')
        if not skip_analysis:
            print('- 视频理解：关键帧、ASR、片尾检测、AI 分析')
        print('- 渲染：花字、片尾、压缩与结果摘要')
        if resume_notes:
            print('恢复与复用:')
            for note in resume_notes:
                print(f'- {note}')
        print()

    def _announce_stage(self, stage: str, message: str) -> None:
        eta_text = format_eta_range(*self._estimate_eta(stage, 0, 0))
        print(f'\n[{STAGE_LABELS.get(stage, stage)}] {message} {eta_text}')
        logger.info('Stage start | stage=%s project=%s message=%s', stage, self.project_name, message)

    def _estimate_eta(self, stage: str, completed: int, total: int) -> Tuple[Optional[int], Optional[int]]:
        baseline = STAGE_BASELINE_SECONDS.get(stage)
        if baseline is None:
            return None, None
        if total <= 0 or completed <= 0:
            return int(baseline * 0.7), int(baseline * 1.3)
        remaining_ratio = max(0.05, (total - completed) / total)
        estimate = baseline * remaining_ratio
        return int(estimate * 0.8), int(estimate * 1.4)

    def _run_preprocess(self) -> None:
        workflow = SensitiveMaskWorkflow(
            sensitive_words_path=str(PROJECT_ROOT / 'config' / 'sensitive_words.txt'),
            sample_fps=5.0,
            time_buffer=0.6,
            verbose=True,
        )
        self.clean_dir.mkdir(parents=True, exist_ok=True)
        results = workflow.process_directory(
            input_dir=str(self.input_dir),
            output_dir=str(self.clean_dir),
            skip_existing=True,
            progress_project_name=self.project_name,
            eta_range=self._estimate_eta('preprocessing', 0, 0),
        )
        success_count = sum(1 for result in results if result.success)
        print(f'✅ 预处理完成：{success_count}/{len(results)} 个视频处理成功。')

    def _run_analysis(self, source_dir: Path) -> None:
        cmd = [sys.executable, '-u', '-m', 'scripts.understand.video_understand', str(source_dir)]
        self._run_subprocess_with_monitor(cmd, stage='analysis', error_message='视频理解失败')
        print(f'✅ 视频理解完成，结果保存至: {self.analysis_dir}')
        self._print_analysis_summary()

    def _print_analysis_summary(self) -> None:
        """Print a human-readable summary of analysis results for agent to relay."""
        result_file = self.analysis_dir / 'result.json'
        if not result_file.exists():
            return
        try:
            data = json.loads(result_file.read_text(encoding='utf-8'))
            stats = data.get('statistics', {})
            highlights = stats.get('totalHighlights', len(data.get('highlights', [])))
            hooks = stats.get('totalHooks', len(data.get('hooks', [])))
            clips = stats.get('totalClips', len(data.get('clips', [])))
            episodes = len(data.get('episodeDurations', {}))
            print(f'分析摘要：共 {episodes} 集，发现 {highlights} 个高光点、{hooks} 个钩子点，生成 {clips} 个剪辑组合。')
            # Guide agent on how to batch-render
            if clips > 0:
                batch_size = 5
                batches = []
                for i in range(0, clips, batch_size):
                    end = min(i + batch_size - 1, clips - 1)
                    batches.append(f'{i}-{end}')
                print(f'渲染建议：共 {clips} 条，建议分 {len(batches)} 批渲染：{", ".join(batches)}')
        except Exception:
            pass

    def _run_render(self, source_dir: Path) -> None:
        cmd = [
            sys.executable,
            '-u',
            '-m',
            'scripts.understand.render_clips',
            str(self.analysis_dir),
            str(source_dir),
            '--add-ending',
            '--max-clips',
            str(self.max_clips),
        ]
        self._run_subprocess_with_monitor(cmd, stage='rendering', error_message='剪辑渲染失败')
        print(f'✅ 剪辑渲染完成，输出目录: {self.output_dir}')
        self._print_render_summary()
        self._try_upload_clips()

    def _run_render_batch(self, source_dir: Path, batch_range: str) -> None:
        """Render a specific batch of clips by index range (e.g. '0-4')."""
        parts = batch_range.split('-')
        if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
            print(f'❌ 无效的批次范围格式: "{batch_range}"，应为 "起始-结束"（如 "0-4"）')
            return
        start, end = int(parts[0]), int(parts[1])
        indices = list(range(start, end + 1))
        indices_str = ','.join(str(i) for i in indices)
        cmd = [
            sys.executable,
            '-u',
            '-m',
            'scripts.understand.render_clips',
            str(self.analysis_dir),
            str(source_dir),
            '--add-ending',
            '--clip-indices',
            indices_str,
        ]
        self._run_subprocess_with_monitor(cmd, stage='rendering', error_message=f'批次 {batch_range} 渲染失败')
        print(f'✅ 批次 {batch_range} 渲染完成（第 {start+1}-{end+1} 条）。')
        self._print_render_summary()
        self._try_upload_clips()

    def _print_render_summary(self) -> None:
        """Print a human-readable summary of rendered clips for agent to relay."""
        clip_files = sorted(self.output_dir.glob('*.mp4')) if self.output_dir.exists() else []
        if not clip_files:
            return
        total_size_mb = sum(f.stat().st_size for f in clip_files) / (1024 ** 2)
        print(f'渲染摘要：共生成 {len(clip_files)} 条剪辑视频，总大小 {total_size_mb:.0f} MB。')
        print('推荐先看：')
        for f in clip_files[:3]:
            size_mb = f.stat().st_size / (1024 ** 2)
            print(f'  - {f.name} ({size_mb:.0f} MB)')

    def _get_upload_record_path(self) -> Path:
        """Path to the JSON file tracking already-uploaded clips."""
        return self.output_dir / '.baidu_upload_record.json'

    def _load_upload_record(self) -> Dict:
        """Load the upload record: {filename: fs_id, ...}."""
        record_path = self._get_upload_record_path()
        if record_path.exists():
            try:
                return json.loads(record_path.read_text(encoding='utf-8'))
            except Exception:
                pass
        return {}

    def _save_upload_record(self, record: Dict) -> None:
        """Persist the upload record."""
        record_path = self._get_upload_record_path()
        record_path.parent.mkdir(parents=True, exist_ok=True)
        record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')

    def _upload_to_baidu_pan(self, clip_files: Optional[List[Path]] = None) -> Optional[Dict]:
        """Upload rendered clips to Baidu Pan incrementally and create a share link.

        Only uploads files that haven't been uploaded yet (tracked via a local
        record file).  The share link always covers ALL uploaded files so far.

        Args:
            clip_files: candidate files; if None, use all clips in output_dir.

        Returns:
            Share link dict {"link": ..., "pwd": ...} or None if skipped/failed.
        """
        pan_config = BaiduPanConfig()
        valid, err = pan_config.validate()
        if not valid:
            logger.info('Baidu Pan not configured, skipping upload: %s', err)
            print('⚠️ 百度网盘未配置（缺少 BAIDU_BDUSS / BAIDU_STOKEN），跳过上传。', flush=True)
            return None

        if clip_files is None:
            clip_files = sorted(self.output_dir.glob('*.mp4')) if self.output_dir.exists() else []

        if not clip_files:
            print('⚠️ 没有找到需要上传的剪辑视频。', flush=True)
            return None

        # Determine which files are new (not yet uploaded)
        record = self._load_upload_record()
        new_files = [f for f in clip_files if f.name not in record]

        if not new_files:
            # Nothing new — just regenerate share link for all known fs_ids
            all_fs_ids = list(record.values())
            if all_fs_ids:
                print(f'所有 {len(record)} 个视频已上传过，重新生成分享链接。', flush=True)
                return self._create_share_link_safe(all_fs_ids)
            print('⚠️ 没有需要上传的新视频。', flush=True)
            return None

        try:
            from scripts.baidu_pan.client import BaiduPanClient
            client = BaiduPanClient(pan_config)

            remote_dir = f'/AI-Drama-Clips/{self.project_name}'
            client.create_dir(remote_dir)

            total_new = len(new_files)
            total_size_mb = sum(f.stat().st_size for f in new_files) / (1024 ** 2)
            already = len(record)
            if already:
                print(f'\n☁️ 发现 {total_new} 个新视频需要上传（共 {total_size_mb:.0f} MB），'
                      f'此前已上传 {already} 个。', flush=True)
            else:
                print(f'\n☁️ 开始上传 {total_new} 个视频到百度网盘（共 {total_size_mb:.0f} MB）...', flush=True)

            for idx, clip_file in enumerate(new_files, 1):
                file_size_mb = clip_file.stat().st_size / (1024 ** 2)
                print(f'📤 上传中 ({idx}/{total_new}): {clip_file.name} ({file_size_mb:.0f} MB)...', flush=True)

                remote_path = f'{remote_dir}/{clip_file.name}'

                def _progress_callback(uploaded: int, total: int,
                                       _name: str = clip_file.name) -> None:
                    if total > 0:
                        pct = uploaded * 100 // total
                        if pct in (25, 50, 75) and abs(uploaded - total * pct // 100) < pan_config.chunk_size:
                            print(f'  ⬆️ {_name}: {pct}%', flush=True)

                result = client.upload_file(clip_file, remote_path, callback=_progress_callback)
                fs_id = result.get('fs_id')
                if fs_id:
                    record[clip_file.name] = fs_id
                    self._save_upload_record(record)
                print(f'  ✅ 上传完成 ({idx}/{total_new})', flush=True)

            # Create share link covering ALL uploaded files
            all_fs_ids = list(record.values())
            if not all_fs_ids:
                print('⚠️ 上传完成但未获取到文件 ID，无法生成分享链接。', flush=True)
                return None

            return self._create_share_link_safe(all_fs_ids, client)

        except Exception as exc:
            # Save whatever we managed to upload so far
            self._save_upload_record(record)
            logger.warning('Baidu Pan upload failed: %s', exc, exc_info=True)
            print(f'\n⚠️ 百度网盘上传失败: {exc}', flush=True)
            print('已上传的文件已记录，下次执行 --upload-only 会跳过已上传的部分。', flush=True)
            return None

    def _create_share_link_safe(self, fs_ids: List[int], client=None) -> Optional[Dict]:
        """Create a share link, handling errors gracefully."""
        try:
            if client is None:
                from scripts.baidu_pan.client import BaiduPanClient
                client = BaiduPanClient(BaiduPanConfig())

            print(f'\n🔗 正在生成分享链接（{len(fs_ids)} 个文件）...', flush=True)
            share_result = client.create_share_link(fs_ids, period=7)
            link = share_result.get('link', '')
            pwd = share_result.get('pwd', '')

            print(f'\n✅ 百度网盘上传完成！', flush=True)
            print(f'📎 分享链接: {link}', flush=True)
            print(f'🔑 提取码: {pwd}', flush=True)
            print(f'📁 网盘路径: /AI-Drama-Clips/{self.project_name}', flush=True)
            print(f'⏰ 链接有效期: 7 天', flush=True)
            return share_result
        except Exception as exc:
            logger.warning('Failed to create share link: %s', exc, exc_info=True)
            print(f'\n⚠️ 生成分享链接失败: {exc}', flush=True)
            print('文件已上传到网盘，可手动在百度网盘中找到并分享。', flush=True)
            return None

    def _try_upload_clips(self, new_clip_files: Optional[List[Path]] = None) -> None:
        """Attempt to upload clips to Baidu Pan if credentials are available."""
        if not self.upload_enabled:
            return
        self._upload_to_baidu_pan(new_clip_files)

    def run_upload_only(self) -> None:
        """Standalone upload: upload new clips to Baidu Pan and print share link."""
        clip_files = sorted(self.output_dir.glob('*.mp4')) if self.output_dir.exists() else []
        if not clip_files:
            print(f'❌ 输出目录中没有找到视频文件: {self.output_dir}')
            return
        total_size_mb = sum(f.stat().st_size for f in clip_files) / (1024 ** 2)
        print(f'发现 {len(clip_files)} 个剪辑视频（共 {total_size_mb:.0f} MB）。')
        self._upload_to_baidu_pan(clip_files)

    def _run_subprocess_with_monitor(self, cmd: List[str], stage: str, error_message: str) -> None:
        stop_event = threading.Event()
        monitor = RuntimeMonitor(self.project_name)
        monitor.stop_event = stop_event
        monitor.start()
        logger.info('Run subprocess | stage=%s cmd=%s', stage, cmd)
        result = subprocess.run(cmd, cwd=PROJECT_ROOT)
        stop_event.set()
        monitor.thread.join(timeout=1)
        if result.returncode != 0:
            raise RuntimeError(error_message)

    def _print_completion_summary(self, started_at: float) -> None:
        elapsed = time.time() - started_at
        clip_files = sorted(self.output_dir.glob('*.mp4'))
        total_size_gb = sum(file.stat().st_size for file in clip_files) / (1024 ** 3) if clip_files else 0.0
        print('\n' + '=' * 60)
        print('完成摘要')
        print('=' * 60)
        print(f'项目名: {self.project_name}')
        print(f'生成剪辑: {len(clip_files)} 个')
        print(f'总耗时: {int(elapsed // 60)}分{int(elapsed % 60)}秒')
        print(f'总大小: {total_size_gb:.2f} GB')
        print(f'输出目录: {self.output_dir}')
        if clip_files:
            print('推荐先看:')
            for file in clip_files[: min(3, len(clip_files))]:
                print(f'- {file.name}')
        print('=' * 60)

    def _print_failure_summary(self, exc: Exception) -> None:
        text = str(exc).lower()
        category = '内部异常'
        for hint, mapped in ERROR_CATEGORY_HINTS.items():
            if hint in text:
                category = mapped
                break
        print('\n' + '=' * 60)
        print('失败摘要')
        print('=' * 60)
        print(f'失败分类: {category}')
        print(f'错误摘要: {exc}')
        print(f'已完成阶段: {"、".join(self.completed_stages) if self.completed_stages else "无"}')
        print('中间结果: 已保留现有缓存与输出，可直接用于重试或 resume。')
        print('建议下一步:')
        print('- 检查输入目录、API Key、FFmpeg 和磁盘空间。')
        print('- 重新执行同一命令，runtime 会优先复用已有缓存。')
        print('=' * 60)
        logger.exception('Pipeline failed | project=%s', self.project_name)


def main() -> None:
    parser = argparse.ArgumentParser(description='AI 短剧剪辑服务 - workflow runtime')
    parser.add_argument('--input', '-i', default='', help='输入视频目录（有 --download-url 时可省略）')
    parser.add_argument('--output', '-o', help='输出目录（默认：clips/<项目名>）')
    parser.add_argument('--max-clips', type=int, default=20, help='最大剪辑数量（默认20）')
    parser.add_argument('--skip-preprocess', action='store_true', help='跳过敏感词预处理')
    parser.add_argument('--skip-analysis', action='store_true', help='跳过视频分析')
    parser.add_argument('--preprocess-only', action='store_true', help='仅执行预处理')
    parser.add_argument('--analysis-only', action='store_true', help='仅执行视频分析（跳过预处理和渲染）')
    parser.add_argument('--render-only', action='store_true', help='仅执行渲染')
    parser.add_argument('--render-batch', type=str, default='',
                        help='分批渲染：指定剪辑索引范围（如 "0-4" 或 "5-9" 或 "10-19"）')
    parser.add_argument('--upload', action='store_true',
                        help='渲染完成后自动上传到百度网盘并生成分享链接')
    parser.add_argument('--upload-only', action='store_true',
                        help='仅上传已渲染的视频到百度网盘（不渲染）')
    parser.add_argument('--download-url', type=str, default='',
                        help='百度网盘分享链接（支持各种格式）')
    parser.add_argument('--download-pwd', type=str, default='',
                        help='百度网盘提取码（链接中有 pwd= 时可省略）')
    parser.add_argument('--download-only', action='store_true',
                        help='仅下载素材，不执行后续流程')
    parser.add_argument('--max-episodes', type=int, default=10,
                        help='最多下载集数（默认10）')
    parser.add_argument('--demo-mode', action='store_true', help='（保留参数，暂无特殊行为）')
    parser.add_argument('--verbose', action='store_true', help='输出 DEBUG 日志')
    args = parser.parse_args()

    setup_logging(level=logging.DEBUG if args.verbose else logging.INFO)

    # Parse download URL if provided (may contain pwd inline)
    download_url = args.download_url
    download_pwd = args.download_pwd
    if download_url:
        download_url, parsed_pwd = AIDramaCutter._parse_baidu_input(download_url)
        if not download_pwd:
            download_pwd = parsed_pwd

    # Validate: need either --input or --download-url
    if not args.input and not download_url:
        print('❌ 请提供 --input 或 --download-url 参数')
        sys.exit(1)

    # When download-only or full pipeline with download, input_dir can be a placeholder
    input_dir = args.input or str(PROJECT_ROOT / '漫剧素材' / '_pending_download')
    if not download_url and not Path(args.input).exists():
        print(f'❌ 输入目录不存在: {args.input}')
        sys.exit(1)

    cutter = AIDramaCutter(
        input_dir, args.output, args.max_clips,
        demo_mode=args.demo_mode, upload=args.upload,
        download_url=download_url or None,
        download_pwd=download_pwd or None,
    )

    if args.download_only:
        if not download_url:
            print('❌ --download-only 需要同时提供 --download-url')
            sys.exit(1)
        cutter._announce_stage('downloading', '仅执行下载。')
        download_dir = cutter._run_download(args.max_episodes)
        print(f'下载目录: {download_dir}')
    elif args.preprocess_only:
        cutter._announce_stage('preprocessing', '仅执行预处理。')
        cutter._run_preprocess()
    elif args.analysis_only:
        source_dir = cutter.clean_dir if cutter.clean_dir.exists() else cutter.input_dir
        cutter._announce_stage('analysis', '仅执行视频分析。')
        cutter._run_analysis(source_dir)
    elif args.upload_only:
        cutter.run_upload_only()
    elif args.render_only:
        source_dir = cutter.clean_dir if cutter.clean_dir.exists() else cutter.input_dir
        cutter._announce_stage('rendering', '仅执行渲染。')
        cutter._run_render(source_dir)
    elif args.render_batch:
        source_dir = cutter.clean_dir if cutter.clean_dir.exists() else cutter.input_dir
        cutter._announce_stage('rendering', f'渲染批次 {args.render_batch}。')
        cutter._run_render_batch(source_dir, args.render_batch)
    else:
        cutter.run_full_pipeline(
            skip_preprocess=args.skip_preprocess,
            skip_analysis=args.skip_analysis,
            max_episodes=args.max_episodes,
        )


if __name__ == '__main__':
    main()
