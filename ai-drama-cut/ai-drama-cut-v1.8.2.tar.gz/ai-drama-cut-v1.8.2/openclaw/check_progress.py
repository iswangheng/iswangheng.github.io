#!/usr/bin/env python3
"""CLI tool to query progress of running AI drama cutting tasks.

Usage:
    python check_progress.py --project "复婚"

Reads progress files from ~/.Documents/AI-Drama-Cut/.progress/ and outputs
a human-readable summary suitable for an agent to relay to users.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.runtime import PROGRESS_DIR, STAGE_LABELS, format_eta_range, read_progress

STALE_THRESHOLD_SECONDS = 60

# Unit suffix per stage so the agent does not confuse "episodes" with "segments"
STAGE_UNITS = {
    'downloading': '集',
    'preprocessing': '集',
    'keyframe_extraction': '集',
    'asr_extraction': '集',
    'ending_detection': '集',
    'ai_analysis': '个片段',
    'rendering': '条',
}


def format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as human-readable string."""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    if minutes == 0:
        return f"{secs}秒"
    return f"{minutes}分{secs:02d}秒"


def check_progress(project_name: str) -> str:
    """Read progress files for a project and return a human-readable summary."""
    if not PROGRESS_DIR.exists():
        return f"⏳ {project_name}：暂无正在运行的任务。"

    progress_files = sorted(PROGRESS_DIR.glob(f"{project_name}_*.json"))
    if not progress_files:
        return f"⏳ {project_name}：暂无正在运行的任务。"

    now = time.time()
    summaries = []

    for pf in progress_files:
        data = read_progress(pf)
        if not data:
            continue

        status = data.get("status", "running")
        # Skip completed/failed tasks
        if status in ("completed", "failed"):
            continue

        stage = data.get("stage", "")
        stage_label = data.get("stage_label", STAGE_LABELS.get(stage, stage))
        completed = data.get("completed", 0)
        total = data.get("total", 0)
        percentage = data.get("percentage", 0.0)
        current_item = data.get("current_item", "")
        message = data.get("message", "")
        started_at = data.get("started_at", now)
        last_progress_at = data.get("last_progress_at", now)

        # Build progress string
        parts = [f"📊 {project_name} - {stage_label}"]

        if total > 0:
            unit = STAGE_UNITS.get(stage, '')
            parts.append(f"：{completed}/{total}{unit} ({percentage}%)")

        if current_item:
            parts.append(f"，当前：{current_item}")

        # ETA
        eta_text = format_eta_range(
            data.get("eta_min_seconds"),
            data.get("eta_max_seconds"),
        )
        elapsed = now - started_at
        parts.append(f"。{eta_text}（已运行 {format_elapsed(elapsed)}）")

        # Stale detection
        idle_seconds = now - last_progress_at
        if idle_seconds > STALE_THRESHOLD_SECONDS:
            parts.append(f"  ⚠️ 已 {format_elapsed(idle_seconds)} 未更新进度")

        if message:
            parts.append(f"  💬 {message}")

        summaries.append("".join(parts))

    if not summaries:
        return f"⏳ {project_name}：暂无正在运行的任务。"

    return "\n".join(summaries)


def main() -> None:
    parser = argparse.ArgumentParser(description="查询 AI 短剧剪辑任务进度")
    parser.add_argument("--project", "-p", required=True, help="项目名称")
    args = parser.parse_args()

    result = check_progress(args.project)
    print(result, flush=True)


if __name__ == "__main__":
    main()
