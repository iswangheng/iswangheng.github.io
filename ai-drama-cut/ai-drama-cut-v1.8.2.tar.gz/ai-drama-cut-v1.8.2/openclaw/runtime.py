"""OpenClaw runtime helpers for workflow state, telemetry, and release metadata."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Union

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OPENCLAW_DIR = PROJECT_ROOT / 'openclaw'
PROGRESS_DIR = Path.home() / 'Documents' / 'AI-Drama-Cut' / '.progress'
VERSION_FILE = OPENCLAW_DIR / 'version.json'


STAGE_LABELS = {
    'downloading': '下载素材',
    'preprocessing': '预处理',
    'keyframe_extraction': '关键帧提取',
    'asr_extraction': 'ASR 语音识别',
    'ending_detection': '片尾检测',
    'ai_analysis': 'AI 分析',
    'analysis': '视频理解',
    'rendering': '渲染',
    'workflow': '工作流',
}


def load_release_metadata() -> Dict[str, Any]:
    return json.loads(VERSION_FILE.read_text(encoding='utf-8'))


def build_artifact_names() -> Dict[str, str]:
    metadata = load_release_metadata()
    version = metadata['version']
    name = metadata['name']
    tarball = f'{name}-v{version}.tar.gz'
    return {
        'name': name,
        'version': version,
        'tarball': tarball,
        'checksum': f'{tarball}.sha256',
        'repository': f"{metadata['repository_base'].rstrip('/')}/{tarball}",
        'skill_url': metadata['skill_url'],
        'compatibility': metadata['compatibility'],
    }


@dataclass
class WorkflowStatus:
    stage: str
    status: str = 'running'
    completed: int = 0
    total: int = 0
    current_item: str = ''
    message: str = ''
    health: str = 'healthy'
    eta_min_seconds: Optional[int] = None
    eta_max_seconds: Optional[int] = None
    started_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    last_progress_at: float = field(default_factory=time.time)
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        percentage = round(self.completed / self.total * 100, 1) if self.total > 0 else 0.0
        return {
            'stage': self.stage,
            'stage_label': STAGE_LABELS.get(self.stage, self.stage),
            'status': self.status,
            'completed': self.completed,
            'total': self.total,
            'percentage': percentage,
            'current_item': self.current_item,
            'message': self.message,
            'health': self.health,
            'eta_min_seconds': self.eta_min_seconds,
            'eta_max_seconds': self.eta_max_seconds,
            'started_at': self.started_at,
            'updated_at': self.updated_at,
            'last_progress_at': self.last_progress_at,
            'timestamp': self.updated_at,
            'details': self.details,
        }


def _progress_file(project_name: str, stage: str) -> Path:
    return PROGRESS_DIR / f'{project_name}_{stage}.json'


def write_progress(
    project_name: str,
    stage: str,
    *,
    status: str = 'running',
    completed: int = 0,
    total: int = 0,
    current_item: str = '',
    message: str = '',
    health: str = 'healthy',
    eta_min_seconds: Optional[int] = None,
    eta_max_seconds: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    started_at: Optional[float] = None,
    last_progress_at: Optional[float] = None,
) -> None:
    PROGRESS_DIR.mkdir(parents=True, exist_ok=True)
    now = time.time()
    payload = WorkflowStatus(
        stage=stage,
        status=status,
        completed=completed,
        total=total,
        current_item=current_item,
        message=message,
        health=health,
        eta_min_seconds=eta_min_seconds,
        eta_max_seconds=eta_max_seconds,
        started_at=started_at or now,
        updated_at=now,
        last_progress_at=last_progress_at or now,
        details=details or {},
    ).to_dict()
    progress_file = _progress_file(project_name, stage)
    temp_file = progress_file.with_suffix('.json.tmp')
    temp_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    temp_file.replace(progress_file)


def clear_progress(project_name: str, stage: str) -> None:
    progress_file = _progress_file(project_name, stage)
    if progress_file.exists():
        progress_file.unlink()


def read_progress(progress_file: Path) -> Optional[Dict[str, Any]]:
    if not progress_file.exists():
        return None
    try:
        return json.loads(progress_file.read_text(encoding='utf-8'))
    except json.JSONDecodeError:
        return None


def estimate_eta(started_at: float, completed: int, total: int) -> tuple:
    """Estimate remaining time based on progress ratio.

    Returns:
        (eta_min_seconds, eta_max_seconds) — both int or both None.
        Uses ×0.8 / ×1.3 multipliers to give a range around the linear estimate.
    """
    if completed <= 0 or total <= 0:
        return None, None
    elapsed = time.time() - started_at
    if elapsed < 3:  # not enough data in first 3 seconds
        return None, None
    rate = elapsed / completed
    remaining = (total - completed) * rate
    # Give a range: optimistic 80% – pessimistic 130%
    return int(remaining * 0.8), int(remaining * 1.3)


def format_eta_range(min_seconds: Optional[int], max_seconds: Optional[int]) -> str:
    if min_seconds is None and max_seconds is None:
        return 'ETA 暂无法估算'
    if min_seconds is None:
        min_seconds = max_seconds
    if max_seconds is None:
        max_seconds = min_seconds
    min_minutes = max(1, round(min_seconds / 60))
    max_minutes = max(1, round(max_seconds / 60))
    if min_minutes == max_minutes:
        return f'预计剩余约 {min_minutes} 分钟'
    return f'预计剩余约 {min_minutes}-{max_minutes} 分钟'
