#!/usr/bin/env python3
"""Blocking progress reporter for long-running AI drama cutting tasks.

Agent executes this as a single synchronous command after starting a
background task.  The script polls check_progress every 60 seconds,
prints each update to stdout, and exits when the task finishes (or
after a maximum wait time).

Usage:
    python wait_and_report.py --project "复婚"
    python wait_and_report.py --project "复婚" --interval 30 --timeout 1800
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.check_progress import check_progress

DEFAULT_INTERVAL = 60       # seconds between polls
DEFAULT_TIMEOUT = 30 * 60   # 30 minutes max wait
NO_TASK_MARKER = '暂无正在运行的任务'


def wait_and_report(
    project_name: str,
    interval: int = DEFAULT_INTERVAL,
    timeout: int = DEFAULT_TIMEOUT,
) -> None:
    """Poll progress and print updates until the task completes or times out."""
    start = time.time()
    iteration = 0

    while True:
        elapsed = time.time() - start

        if elapsed > timeout:
            print(
                f'⚠️ 已等待 {int(elapsed // 60)} 分钟，超过最大等待时间，停止轮询。'
                f'请手动检查任务状态。',
                flush=True,
            )
            break

        output = check_progress(project_name)
        print(output, flush=True)

        if NO_TASK_MARKER in output:
            # First check right after start may catch "no task" if the
            # background process hasn't written its progress file yet.
            # Give it one grace period before treating it as "done".
            if iteration == 0:
                print(
                    '⏳ 后台任务刚启动，等待进度文件生成...',
                    flush=True,
                )
                time.sleep(min(interval, 10))
                iteration += 1
                continue
            # Task genuinely finished
            break

        iteration += 1
        time.sleep(interval)

    total_minutes = int((time.time() - start) // 60)
    total_seconds = int((time.time() - start) % 60)
    print(f'🏁 轮询结束，共等待 {total_minutes}分{total_seconds:02d}秒。', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='阻塞式等待并汇报 AI 短剧剪辑任务进度',
    )
    parser.add_argument('--project', '-p', required=True, help='项目名称')
    parser.add_argument(
        '--interval', '-i',
        type=int,
        default=DEFAULT_INTERVAL,
        help=f'轮询间隔（秒），默认 {DEFAULT_INTERVAL}',
    )
    parser.add_argument(
        '--timeout', '-t',
        type=int,
        default=DEFAULT_TIMEOUT,
        help=f'最大等待时间（秒），默认 {DEFAULT_TIMEOUT}',
    )
    args = parser.parse_args()

    wait_and_report(args.project, args.interval, args.timeout)


if __name__ == '__main__':
    main()
