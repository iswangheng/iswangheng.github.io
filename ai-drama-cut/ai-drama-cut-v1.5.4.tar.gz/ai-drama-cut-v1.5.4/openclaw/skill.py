#!/usr/bin/env python3
"""OpenClaw skill runtime for AI drama cutting."""
from __future__ import annotations

import argparse
import logging
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from openclaw.runtime import (
    PROGRESS_DIR,
    STAGE_LABELS,
    build_artifact_names,
    format_eta_range,
    read_progress,
)
from scripts.log_config import get_logger, setup_logging
from scripts.preprocess.sensitive_mask_workflow import SensitiveMaskWorkflow

logger = get_logger(__name__)

HEARTBEAT_INTERVAL = 20
POLL_INTERVAL = 2
STAGE_BASELINE_SECONDS = {
    'preprocessing': 8 * 60,
    'keyframe_extraction': 3 * 60,
    'asr_extraction': 5 * 60,
    'ending_detection': 2 * 60,
    'ai_analysis': 8 * 60,
    'rendering': 10 * 60,
}
ERROR_CATEGORY_HINTS = {
    'gemini': '外部 API',
    'api key': '外部 API',
    'ffmpeg': '环境',
    'font': '环境',
    'disk': '资源',
    'space': '资源',
    'not found': '输入',
    'missing': '输入',
    'permission': '环境',
}


@dataclass
class StageWatch:
    stage: str
    current_item: str = ''
    completed: int = 0
    total: int = 0
    last_progress_at: float = 0.0
    last_heartbeat_at: float = 0.0
    last_status: str = ''
    started_at: float = 0.0


class RuntimeMonitor:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.stage_state: Dict[str, StageWatch] = {}

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        self.thread.join(timeout=1)

    def _run(self) -> None:
        while not self.stop_event.is_set():
            if PROGRESS_DIR.exists():
                for progress_file in PROGRESS_DIR.glob(f'{self.project_name}_*.json'):
                    data = read_progress(progress_file)
                    if not data:
                        continue
                    stage = data.get('stage', progress_file.stem.removeprefix(f'{self.project_name}_'))
                    state = self.stage_state.setdefault(stage, StageWatch(stage=stage))
                    completed = data.get('completed', 0)
                    total = data.get('total', 0)
                    current_item = data.get('current_item', '')
                    status = data.get('status', 'running')
                    timestamp = data.get('timestamp', time.time())
                    last_progress_at = data.get('last_progress_at', timestamp)
                    started_at = data.get('started_at', timestamp)
                    message = data.get('message', '')
                    eta_text = format_eta_range(data.get('eta_min_seconds'), data.get('eta_max_seconds'))
                    stage_label = STAGE_LABELS.get(stage, stage)

                    if state.started_at == 0.0:
                        state.started_at = started_at
                        print(f'\n🧭 进入阶段：{stage_label}。{message or "开始处理。"}')

                    progress_advanced = completed > state.completed or total != state.total
                    item_changed = current_item and current_item != state.current_item

                    if progress_advanced or item_changed or status != state.last_status:
                        extra = f'，当前对象：{current_item}' if current_item else ''
                        progress = f'{completed}/{total}' if total else str(completed)
                        print(f'\n📊 {stage_label}：{progress}{extra}。{message or eta_text}')
                        state.completed = completed
                        state.total = total
                        state.current_item = current_item
                        state.last_status = status
                        state.last_progress_at = last_progress_at
                        state.last_heartbeat_at = time.time()
                    else:
                        now = time.time()
                        state.last_progress_at = max(state.last_progress_at, last_progress_at)
                        idle_seconds = now - (state.last_progress_at or now)
                        if idle_seconds >= HEARTBEAT_INTERVAL and now - state.last_heartbeat_at >= HEARTBEAT_INTERVAL:
                            extra = f'，当前对象：{current_item}' if current_item else ''
                            print(f'\n💓 {stage_label}仍在处理中{extra}。{message or eta_text}')
                            state.last_heartbeat_at = now
            time.sleep(POLL_INTERVAL)


def monitor_progress(progress_file: Path, project_name: str, stop_event: threading.Event):
    monitor = RuntimeMonitor(project_name)
    monitor.stop_event = stop_event
    monitor._run()


def monitor_progress_multi(project_name: str, stop_event: threading.Event):
    monitor = RuntimeMonitor(project_name)
    monitor.stop_event = stop_event
    monitor._run()


class AIDramaCutter:
    def __init__(
        self,
        input_dir: str,
        output_dir: Optional[str] = None,
        max_clips: int = 20,
        demo_mode: bool = False,
    ):
        self.input_dir = Path(input_dir).resolve()
        self.project_name = self.input_dir.name
        self.demo_mode = demo_mode
        self.max_clips = min(max_clips, 5) if demo_mode else max_clips
        self.output_dir = Path(output_dir).resolve() if output_dir else PROJECT_ROOT / 'clips' / self.project_name
        self.clean_dir = PROJECT_ROOT / 'data' / 'clean' / self.project_name
        self.analysis_dir = PROJECT_ROOT / 'data' / 'analysis' / self.project_name
        self.release = build_artifact_names()
        self.completed_stages: List[str] = []

    def run_full_pipeline(self, skip_preprocess: bool = False, skip_analysis: bool = False) -> None:
        start_time = time.time()
        source_dir = self.input_dir
        resume_notes = self._detect_resume(skip_preprocess, skip_analysis)
        self._print_plan(skip_preprocess, skip_analysis, resume_notes)

        try:
            if not skip_preprocess:
                self._announce_stage('preprocessing', '开始扫描和处理敏感内容。')
                self._run_preprocess()
                source_dir = self.clean_dir
                self.completed_stages.append('preprocessing')
            else:
                print('\n⏭️ 跳过预处理，直接使用原始素材。')

            if not skip_analysis:
                self._announce_stage('analysis', '开始视频理解，包含关键帧、ASR、片尾检测和 AI 分析。')
                self._run_analysis(source_dir)
                self.completed_stages.append('analysis')
            else:
                print('\n⏭️ 跳过分析，直接复用已有结果。')

            self._announce_stage('rendering', '开始生成剪辑结果。')
            self._run_render(source_dir)
            self.completed_stages.append('rendering')
            self._print_completion_summary(start_time)
        except Exception as exc:
            self._print_failure_summary(exc)
            raise

    def _detect_resume(self, skip_preprocess: bool, skip_analysis: bool) -> List[str]:
        notes: List[str] = []
        if self.clean_dir.exists() and any(self.clean_dir.glob('*.mp4')) and not skip_preprocess:
            notes.append('检测到已存在的预处理输出，可复用 clean 素材。')
        if (self.analysis_dir / 'result.json').exists() and not skip_analysis:
            notes.append('检测到已有 result.json，本次会优先复用分析结果并触发自动修复。')
        if self.demo_mode:
            notes.append('demo mode 已启用：优先稳定性、缓存复用和结果摘要。')
        return notes

    def _print_plan(self, skip_preprocess: bool, skip_analysis: bool, resume_notes: List[str]) -> None:
        print('=' * 60)
        print('AI 短剧剪辑 workflow runtime')
        print('=' * 60)
        print(f'项目名: {self.project_name}')
        print(f'输入目录: {self.input_dir}')
        print(f'输出目录: {self.output_dir}')
        print(f'目标剪辑数: {self.max_clips}')
        print(f'demo mode: {"开启" if self.demo_mode else "关闭"}')
        print('阶段计划:')
        if not skip_preprocess:
            print('- 预处理：敏感内容扫描与遮罩')
        if not skip_analysis:
            print('- 视频理解：关键帧、ASR、片尾检测、AI 分析')
        print('- 渲染：花字、片尾、压缩与结果摘要')
        if resume_notes:
            print('恢复与复用:')
            for note in resume_notes:
                print(f'- {note}')
        print()

    def _announce_stage(self, stage: str, message: str) -> None:
        eta_text = format_eta_range(*self._estimate_eta(stage, 0, 0))
        print(f'\n[{STAGE_LABELS.get(stage, stage)}] {message} {eta_text}')
        logger.info('Stage start | stage=%s project=%s message=%s', stage, self.project_name, message)

    def _estimate_eta(self, stage: str, completed: int, total: int) -> Tuple[Optional[int], Optional[int]]:
        baseline = STAGE_BASELINE_SECONDS.get(stage)
        if baseline is None:
            return None, None
        if total <= 0 or completed <= 0:
            return int(baseline * 0.7), int(baseline * 1.3)
        remaining_ratio = max(0.05, (total - completed) / total)
        estimate = baseline * remaining_ratio
        return int(estimate * 0.8), int(estimate * 1.4)

    def _run_preprocess(self) -> None:
        workflow = SensitiveMaskWorkflow(
            sensitive_words_path=str(PROJECT_ROOT / 'config' / 'sensitive_words.txt'),
            sample_fps=5.0,
            time_buffer=0.6,
            verbose=True,
        )
        self.clean_dir.mkdir(parents=True, exist_ok=True)
        results = workflow.process_directory(
            input_dir=str(self.input_dir),
            output_dir=str(self.clean_dir),
            skip_existing=True,
            progress_project_name=self.project_name,
            eta_range=self._estimate_eta('preprocessing', 0, 0),
        )
        success_count = sum(1 for result in results if result.success)
        print(f'✅ 预处理完成：{success_count}/{len(results)} 个视频处理成功。')

    def _run_analysis(self, source_dir: Path) -> None:
        cmd = [sys.executable, '-m', 'scripts.understand.video_understand', str(source_dir)]
        self._run_subprocess_with_monitor(cmd, stage='analysis', error_message='视频理解失败')
        print(f'✅ 视频理解完成，结果保存至: {self.analysis_dir}')

    def _run_render(self, source_dir: Path) -> None:
        cmd = [
            sys.executable,
            '-m',
            'scripts.understand.render_clips',
            str(self.analysis_dir),
            str(source_dir),
            '--add-ending',
            '--max-clips',
            str(self.max_clips),
        ]
        self._run_subprocess_with_monitor(cmd, stage='rendering', error_message='剪辑渲染失败')
        print(f'✅ 剪辑渲染完成，输出目录: {self.output_dir}')

    def _run_subprocess_with_monitor(self, cmd: List[str], stage: str, error_message: str) -> None:
        stop_event = threading.Event()
        monitor = RuntimeMonitor(self.project_name)
        monitor.stop_event = stop_event
        monitor.start()
        logger.info('Run subprocess | stage=%s cmd=%s', stage, cmd)
        result = subprocess.run(cmd, cwd=PROJECT_ROOT)
        stop_event.set()
        monitor.thread.join(timeout=1)
        if result.returncode != 0:
            raise RuntimeError(error_message)

    def _print_completion_summary(self, started_at: float) -> None:
        elapsed = time.time() - started_at
        clip_files = sorted(self.output_dir.glob('*.mp4'))
        total_size_gb = sum(file.stat().st_size for file in clip_files) / (1024 ** 3) if clip_files else 0.0
        print('\n' + '=' * 60)
        print('完成摘要')
        print('=' * 60)
        print(f'项目名: {self.project_name}')
        print(f'生成剪辑: {len(clip_files)} 个')
        print(f'总耗时: {int(elapsed // 60)}分{int(elapsed % 60)}秒')
        print(f'总大小: {total_size_gb:.2f} GB')
        print(f'输出目录: {self.output_dir}')
        if clip_files:
            print('推荐先看:')
            for file in clip_files[: min(3, len(clip_files))]:
                print(f'- {file.name}')
        if self.demo_mode:
            print('演示摘要:')
            print(f'- 系统已自动完成阶段: {"、".join(self.completed_stages) if self.completed_stages else "无"}')
            print(f'- 建议展示路径: {self.output_dir}')
            print('- 建议话术: 已自动复用缓存、完成分析并输出可直接预览的剪辑结果。')
        print('=' * 60)

    def _print_failure_summary(self, exc: Exception) -> None:
        text = str(exc).lower()
        category = '内部异常'
        for hint, mapped in ERROR_CATEGORY_HINTS.items():
            if hint in text:
                category = mapped
                break
        print('\n' + '=' * 60)
        print('失败摘要')
        print('=' * 60)
        print(f'失败分类: {category}')
        print(f'错误摘要: {exc}')
        print(f'已完成阶段: {"、".join(self.completed_stages) if self.completed_stages else "无"}')
        print('中间结果: 已保留现有缓存与输出，可直接用于重试或 resume。')
        print('建议下一步:')
        print('- 检查输入目录、API Key、FFmpeg 和磁盘空间。')
        print('- 重新执行同一命令，runtime 会优先复用已有缓存。')
        print('=' * 60)
        logger.exception('Pipeline failed | project=%s', self.project_name)


def main() -> None:
    parser = argparse.ArgumentParser(description='AI 短剧剪辑服务 - workflow runtime')
    parser.add_argument('--input', '-i', required=True, help='输入视频目录')
    parser.add_argument('--output', '-o', help='输出目录（默认：clips/<项目名>）')
    parser.add_argument('--max-clips', type=int, default=20, help='最大剪辑数量（默认20）')
    parser.add_argument('--skip-preprocess', action='store_true', help='跳过敏感词预处理')
    parser.add_argument('--skip-analysis', action='store_true', help='跳过视频分析')
    parser.add_argument('--preprocess-only', action='store_true', help='仅执行预处理')
    parser.add_argument('--render-only', action='store_true', help='仅执行渲染')
    parser.add_argument('--demo-mode', action='store_true', help='启用演示模式')
    parser.add_argument('--verbose', action='store_true', help='输出 DEBUG 日志')
    args = parser.parse_args()

    setup_logging(level=logging.DEBUG if args.verbose else logging.INFO)

    if not Path(args.input).exists():
        print(f'❌ 输入目录不存在: {args.input}')
        sys.exit(1)

    cutter = AIDramaCutter(args.input, args.output, args.max_clips, demo_mode=args.demo_mode)

    if args.preprocess_only:
        cutter._announce_stage('preprocessing', '仅执行预处理。')
        cutter._run_preprocess()
    elif args.render_only:
        source_dir = cutter.clean_dir if cutter.clean_dir.exists() else cutter.input_dir
        cutter._announce_stage('rendering', '仅执行渲染。')
        cutter._run_render(source_dir)
    else:
        cutter.run_full_pipeline(
            skip_preprocess=args.skip_preprocess,
            skip_analysis=args.skip_analysis,
        )


if __name__ == '__main__':
    main()
