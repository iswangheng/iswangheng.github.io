#!/usr/bin/env python3
"""
测试 Whisper 模型下载功能
"""
import whisper
import sys
from pathlib import Path

print("=" * 60)
print("测试 Whisper 模型下载")
print("=" * 60)
print()

try:
    print("正在加载 Whisper base 模型...")
    model = whisper.load_model('base')
    print("✅ 模型加载成功！")
    print()

    # 检查模型缓存位置
    cache_dir = Path.home() / ".cache" / "whisper"
    if cache_dir.exists():
        model_files = list(cache_dir.glob("*.pt"))
        print(f"模型缓存位置: {cache_dir}")
        print(f"已下载的模型文件:")
        for f in model_files:
            size_mb = f.stat().st_size / (1024**2)
            print(f"  - {f.name} ({size_mb:.1f} MB)")

    print()
    print("=" * 60)
    print("✅ Whisper 模型测试通过")
    print("=" * 60)
    sys.exit(0)

except Exception as e:
    print(f"❌ 模型加载失败: {e}")
    sys.exit(1)
