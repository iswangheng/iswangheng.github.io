---
name: ai-drama-cut
version: "1.5.4"
description: 'AI 短剧智能剪辑工具。自动分析短剧视频并生成可用于演示与投放测试的剪辑素材。V1.5.4: 确保编译产物正确打包，验证花字叠加完整功能。'
license: Apache-2.0
compatibility: "Claude Code ≥1.0, OpenClaw ≥1.0"
metadata:
  openclaw:
    requires:
      env: ["GEMINI_API_KEY"]
      bins: ["ffmpeg", "python3"]
    primaryEnv: GEMINI_API_KEY
  author: ai-drama-cut
  version: "1.5.4"
  repository: "http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.5.4.tar.gz"
  tags:
    - video-editing
    - ai-analysis
    - drama-cutting
    - short-video
  triggers:
    - "剪辑短剧"
    - "分析短剧视频"
    - "生成短剧片段"
    - "短剧自动剪辑"
    - "AI剪辑视频"
---

# AI 短剧智能剪辑 Skill

> 重要：以自然语言和用户沟通，不展示命令行日志、错误堆栈或安装细节。重点是让用户始终知道系统正在做什么、已经完成什么、下一步是什么。

## Skill 契约

这个 skill 的承诺以运行时可稳定兑现为准，核心保证只有四类：

1. 开始前会给出执行计划
   - 说明项目名、是否预处理、预计生成数量、主要阶段。
2. 每个阶段都会有状态更新
   - 预处理、分析、渲染都会输出阶段状态。
3. 长任务会有 heartbeat
   - 如果一段时间没有离散进度，也会主动说明仍在处理哪个阶段、哪个对象。
4. 失败时会给出恢复信息
   - 说明失败分类、已完成阶段、保留的中间结果、建议下一步。

以下内容不再作为硬保证：
- 不承诺一定能自动修复所有安装失败。
- 不承诺一定能把生成文件直接发送给用户。
- 不承诺 ETA 绝对精确，ETA 只用于降低不确定感。

## 演示模式

演示模式用于下周 VC demo，目标是稳定、可观测、好讲述，而不是极限吞吐。

演示模式的行为：
- 默认优先复用已有缓存与分析结果。
- 默认更保守的输出规模，优先更快产出首批结果。
- 输出更强的阶段摘要、推荐先看的 clip 和演示话术素材。
- 如果检测到可 resume，会明确告知“本次从哪里继续”。

## 用户交互准则

当用户问“怎么剪辑”“怎么使用”时：
- 不解释底层命令和技术细节。
- 直接引导用户提供视频目录或视频文件。
- 用自然语言说明会自动完成分析、剪辑、花字、片尾和结果汇总。

可使用的简短回复模板：

“请把短剧视频发给我，或者直接告诉我视频目录。

我会按阶段帮你完成分析和剪辑，并在过程中持续汇报当前状态、进度和结果摘要。”

## 使用流程

### 1. 安装

```bash
cd openclaw
bash install.sh
python check_dependencies.py
```

### 2. 配置 API Key

```bash
python setup_api.py
```

### 3. 执行

```bash
# 完整流程
python skill.py --input "视频目录路径"

# 跳过预处理（视频已经干净）
python skill.py --input "视频目录路径" --skip-preprocess

# 仅渲染已有分析结果
python skill.py --input "视频目录路径" --render-only

# 演示模式（优先复用缓存）
python skill.py --input "视频目录路径" --skip-preprocess --demo-mode
```

## 运行时行为

### 开始阶段

开始时会输出一段简短计划，至少包含：
- 项目名
- 输入目录
- 是否启用预处理
- 是否启用 demo mode
- 预计阶段
- 预计输出数量

### 阶段更新

运行时会持续输出：
- 当前阶段
- 当前对象（例如第几集、第几个片段、第几个 clip）
- 已完成数量 / 总量
- 简短说明

### Heartbeat

如果某个阶段较慢，系统不会沉默。

典型 heartbeat 类似：
- “仍在进行 AI 分析，当前处理第 8/11 集。”
- “仍在渲染，当前编码 clip 3/5。”

### 完成摘要

结束时会输出统一摘要，至少包含：
- 成功生成的 clip 数量
- 总耗时
- 输出目录
- 推荐优先查看的结果
- 如果是 demo mode，会额外补充演示摘要

### 失败摘要

失败时会输出：
- 失败阶段
- 失败分类：环境 / 输入 / 资源 / 外部 API / 内部异常
- 已完成阶段
- 是否保留中间结果
- 可直接重试的建议

## Resume 与恢复

该 skill 优先提供“软 resume”能力，而不是完整 checkpoint 引擎。

可复用的内容包括：
- `data/cache/keyframes`
- `data/cache/asr`
- `data/cache/subtitle_region`
- `data/analysis/<项目名>/result.json`
- 自动修复旧 `result.json`

如果检测到已有中间结果，运行时会明确告知：
- 哪些阶段会跳过
- 哪些阶段会继续
- 本次是否从已有分析或缓存继续

## 输出目录

默认输出到：
- macOS / Linux: `clips/<项目名>/`
- Windows: `%USERPROFILE%\Documents\AI-Drama-Cut\clips\<项目名>\`

## 故障处理原则

遇到错误时：
1. 优先给用户可理解的状态说明，不沉默。
2. 尝试复用已有缓存和中间结果。
3. 只在确有必要时请求用户配合，例如补 API Key、释放磁盘空间、检查输入路径。
4. 不向用户倾倒原始堆栈和安装日志。

## 安装指南

### 系统要求
- **Python**: 3.10 或更高版本（编译模块依赖）
- **FFmpeg**: 支持视频处理和文本叠加
- **磁盘空间**: 建议 10GB+（视频缓存和渲染输出）
- **API Key**: Google Gemini API Key（用于AI分析）

### 快速安装

#### 1. 下载并解压
```bash
# 下载 skill 包
wget http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.5.4.tar.gz

# 或使用 curl
curl -O http://43.163.220.15:8000/ai-drama-cut/ai-drama-cut-v1.5.4.tar.gz

# 解压
tar -xzf ai-drama-cut-v1.5.4.tar.gz
cd ai-drama-cut-v1.5.4
```

#### 2. 运行安装脚本（自动配置环境）
```bash
# 自动安装所有依赖
bash openclaw/install.sh
```

**安装脚本会自动**：
- ✅ 检查 Python 版本（要求 3.10+）
- ✅ 检测 FFmpeg 是否安装
- ✅ 安装 Python 依赖包
- ✅ 配置虚拟环境（如需要）

#### 3. 配置 API Key
```bash
python openclaw/setup_api.py
# 输入你的 Gemini API Key
```

### 依赖来源说明

**Python 依赖**（通过 pip 安装）：
- 来自 PyPI 官方源
- 使用清华大学镜像加速（中国区）
- 自动处理版本兼容性

**FFmpeg**（视频处理）：
- macOS: `brew install ffmpeg`
- Linux: `sudo apt install ffmpeg` 或 `yum install ffmpeg`
- 需要启用 `--enable-libfreetype` 和 `--enable-libfontconfig`

**可选依赖**（功能增强）：
- PyTorch: GPU 加速（可选）
- PaddlePaddle: OCR 功能

### 版本兼容性

**Python 版本**：
- ✅ Python 3.10.x - 推荐
- ⚠️ Python 3.9.x - 不兼容编译模块
- ❌ Python 3.8 及以下 - 不支持

**操作系统**：
- ✅ macOS 11+ (Intel + Apple Silicon)
- ✅ Ubuntu 20.04+ / CentOS 7+
- ⚠️ Windows - 需要 WSL2

### 故障排除

**问题 1: Python 版本不兼容**
```bash
# 检查 Python 版本
python3 --version

# 如果是 3.9 或更低，升级 Python
# macOS:
brew install python@3.10

# Linux:
sudo apt install python3.10
```

**问题 2: FFmpeg 缺失**
```bash
# macOS:
brew install ffmpeg

# Linux:
sudo apt install ffmpeg
```

**问题 3: 编译模块加载失败**
```bash
# 确认 Python 版本
python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"

# 如果是 3.9 或更低，需要升级
```

### 验证安装

```bash
# 检查依赖
python openclaw/check_dependencies.py

# 测试导入
python -c "from openclaw.skill import AIDramaCutter; print('✅ 导入成功')"
```

