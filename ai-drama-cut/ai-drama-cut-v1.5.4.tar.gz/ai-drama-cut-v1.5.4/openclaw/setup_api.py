#!/usr/bin/env python3
"""
API 配置向导
交互式配置 Gemini API Key
"""

import sys
from pathlib import Path

# 颜色输出
class Colors:
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    NC = '\033[0m'

def main():
    print()
    print("=" * 60)
    print("  AI 短剧剪辑服务 - API 配置向导")
    print("=" * 60)
    print()

    # .env 文件保存在项目根目录（openclaw/ 的父目录）
    env_path = Path(__file__).parent.parent / ".env"

    # 检查是否已有配置
    if env_path.exists():
        with open(env_path, 'r') as f:
            content = f.read()

        if "GEMINI_API_KEY" in content and "your_key_here" not in content:
            print(f"{Colors.GREEN}✅ 检测到已有 API Key 配置{Colors.NC}")
            print()
            response = input("是否要重新配置？(y/N): ").strip().lower()
            if response != 'y':
                print("保持现有配置")
                return

    # 显示说明
    print(f"{Colors.BLUE}【说明】{Colors.NC}")
    print("此服务需要 Gemini API Key 用于 AI 视频分析")
    print("我们使用 aihubmix.com 代理访问 Gemini API")
    print()
    print(f"{Colors.YELLOW}获取 API Key：{Colors.NC}")
    print("方式 1（推荐）：使用 aihubmix.com 代理")
    print("  1. 访问：https://aihubmix.com")
    print("  2. 注册并获取 API Key")
    print("  3. 复制 API Key（格式：sk-xxxxx）")
    print()
    print("方式 2：使用 Google 官方 API")
    print("  1. 访问：https://makersuite.google.com/app/apikey")
    print("  2. 登录 Google 账号")
    print("  3. 点击 'Create API Key' 创建密钥")
    print("  注意：官方 API 需要科学上网")
    print()

    # 输入 API Key
    print(f"{Colors.BLUE}【配置】{Colors.NC}")
    api_key = input("请输入 Gemini API Key: ").strip()

    if not api_key:
        print(f"{Colors.RED}❌ API Key 不能为空{Colors.NC}")
        sys.exit(1)

    # 简单验证格式
    if len(api_key) < 20:
        print(f"{Colors.YELLOW}⚠️  API Key 长度似乎不正确{Colors.NC}")
        response = input("是否继续？(y/N): ").strip().lower()
        if response != 'y':
            sys.exit(1)

    # 保存到 .env
    env_content = f"""# Gemini API Key（必需）
# 通过 aihubmix.com 代理访问 Gemini API
# 获取地址：https://aihubmix.com
GEMINI_API_KEY={api_key}

# 可选配置
# 输出目录
OUTPUT_DIR=clips

# 缓存目录
CACHE_DIR=data/cache
"""

    with open(env_path, 'w') as f:
        f.write(env_content)

    print()
    print(f"{Colors.GREEN}✅ API Key 配置成功！{Colors.NC}")
    print(f"   配置文件：{env_path}")
    print()

    # 测试 API Key（可选）
    print(f"{Colors.BLUE}【测试】{Colors.NC}")
    response = input("是否测试 API Key 有效性？(Y/n): ").strip().lower()

    if response != 'n':
        print("正在测试...")
        try:
            import requests

            # 使用 aihubmix.com 代理测试
            url = f"https://aihubmix.com/gemini/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
            headers = {"Content-Type": "application/json"}
            payload = {
                "contents": [{
                    "parts": [{"text": "Hello"}]
                }]
            }

            response = requests.post(url, json=payload, headers=headers, timeout=10)

            if response.status_code == 200:
                print(f"{Colors.GREEN}✅ API Key 有效！{Colors.NC}")
            else:
                print(f"{Colors.YELLOW}⚠️  API Key 可能无效（状态码: {response.status_code}）{Colors.NC}")
        except Exception as e:
            print(f"{Colors.RED}❌ API Key 测试失败: {e}{Colors.NC}")
            print(f"{Colors.YELLOW}   请检查 API Key 是否正确{Colors.NC}")

    print()
    print("=" * 60)
    print(f"{Colors.GREEN}配置完成！{Colors.NC}")
    print()
    print("下一步：")
    print("  python check_dependencies.py  # 检查所有依赖")
    print("  python skill.py --input <项目目录>  # 开始剪辑")
    print("=" * 60)
    print()

if __name__ == "__main__":
    main()
