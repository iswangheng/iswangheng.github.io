# API 配置指南

## Gemini API Key 获取和配置

### 1. 获取 API Key

#### 步骤 1：访问 Google AI Studio

访问：https://makersuite.google.com/app/apikey

#### 步骤 2：登录 Google 账号

使用你的 Google 账号登录（需要有 Google 账号）

#### 步骤 3：创建 API Key

1. 点击 "Create API Key" 按钮
2. 选择一个 Google Cloud 项目（或创建新项目）
3. 等待 API Key 生成
4. 复制生成的 API Key（格式类似：`AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX`）

⚠️ **重要**：请妥善保管你的 API Key，不要泄露给他人

### 2. 配置 API Key

#### 方法 1：使用配置向导（推荐）

```bash
python setup_api.py
```

配置向导会：
1. 提示你输入 API Key
2. 验证 API Key 格式
3. 测试 API Key 有效性
4. 保存到 `.env` 文件

#### 方法 2：手动编辑 .env 文件

1. 复制 `.env.example` 为 `.env`：
   ```bash
   cp .env.example .env
   ```

2. 编辑 `.env` 文件：
   ```bash
   nano .env
   # 或使用其他编辑器
   ```

3. 填写 API Key：
   ```
   GEMINI_API_KEY=你的API_Key
   ```

4. 保存并退出

### 3. 验证配置

运行依赖检查脚本：

```bash
python check_dependencies.py
```

如果看到：
```
✅ .env 配置正常
```

说明配置成功！

### 4. API 使用限制

#### 免费额度

Gemini API 提供免费额度：
- **每分钟请求数**：60 次
- **每天请求数**：1500 次
- **每月 Token 数**：100万 Token

#### 成本估算

对于 AI 短剧剪辑服务：
- **视频理解**：约 5 元/部（10集短剧）
- **单集分析**：约 0.5 元/集
- **Token 消耗**：约 10万 Token/部

#### 付费方案

如果免费额度不够，可以升级到付费方案：
- 访问：https://console.cloud.google.com/billing
- 启用计费账号
- 价格：约 $0.001/1K Token（输入）

### 5. 常见问题

#### Q1：API Key 无效

**错误信息**：
```
❌ API Key 测试失败: Invalid API key
```

**解决方案**：
1. 检查 API Key 是否完整复制
2. 确认 API Key 没有多余的空格
3. 重新生成 API Key

#### Q2：API 配额超限

**错误信息**：
```
Resource has been exhausted (e.g. check quota)
```

**解决方案**：
1. 等待配额重置（每分钟/每天）
2. 升级到付费方案
3. 使用缓存避免重复调用

#### Q3：API 请求超时

**错误信息**：
```
Timeout waiting for response
```

**解决方案**：
1. 检查网络连接
2. 重试请求
3. 使用代理（如果在国内）

#### Q4：.env 文件不生效

**症状**：
- 运行时提示 API Key 未配置
- 但 .env 文件中已填写

**解决方案**：
1. 确认 .env 文件在项目根目录
2. 检查文件名是否正确（不是 `.env.txt`）
3. 重启终端或重新加载环境变量

### 6. 安全建议

#### ✅ 推荐做法

1. **不要提交 .env 到 Git**
   - `.env` 已在 `.gitignore` 中
   - 确认 `git status` 不显示 `.env`

2. **定期轮换 API Key**
   - 每 3-6 个月更换一次
   - 如果怀疑泄露，立即更换

3. **限制 API Key 权限**
   - 在 Google Cloud Console 中限制 API Key 只能访问 Gemini API
   - 设置 IP 白名单（可选）

#### ❌ 避免做法

1. **不要在代码中硬编码 API Key**
   ```python
   # ❌ 错误
   api_key = "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

   # ✅ 正确
   import os
   api_key = os.getenv("GEMINI_API_KEY")
   ```

2. **不要分享 API Key**
   - 不要通过聊天工具发送
   - 不要截图包含 API Key 的内容

3. **不要在公开仓库中提交 API Key**
   - 检查 Git 历史记录
   - 如果不小心提交，立即更换 API Key

### 7. 高级配置

#### 使用代理

如果在国内访问 Gemini API 有困难，可以配置代理：

编辑 `.env` 文件：
```
GEMINI_API_KEY=你的API_Key

# 代理配置（可选）
HTTP_PROXY=http://127.0.0.1:7890
HTTPS_PROXY=http://127.0.0.1:7890
```

#### 自定义 API 端点

如果使用自定义的 Gemini API 端点：

编辑 `.env` 文件：
```
GEMINI_API_KEY=你的API_Key
GEMINI_API_BASE=https://your-custom-endpoint.com
```

### 8. 监控 API 使用

#### 查看使用情况

访问 Google Cloud Console：
https://console.cloud.google.com/apis/dashboard

查看：
- 每日请求数
- Token 消耗量
- 错误率

#### 设置告警

在 Google Cloud Console 中设置告警：
1. 访问：https://console.cloud.google.com/monitoring/alerting
2. 创建告警策略
3. 设置阈值（如：每日请求数 > 1000）
4. 配置通知方式（邮件/短信）

## 总结

✅ **配置完成检查清单**：

- [ ] 已获取 Gemini API Key
- [ ] 已运行 `python setup_api.py` 或手动编辑 `.env`
- [ ] 已运行 `python check_dependencies.py` 验证配置
- [ ] 已了解 API 使用限制和成本
- [ ] 已将 `.env` 添加到 `.gitignore`

完成以上步骤后，你就可以开始使用 AI 短剧剪辑服务了！

```bash
python ai_drama_cutter.py --input "漫剧素材/项目名"
```
