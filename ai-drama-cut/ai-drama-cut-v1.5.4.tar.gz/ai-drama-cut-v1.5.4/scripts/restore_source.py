#!/usr/bin/env python3
"""
恢复源代码（用于开发调试）
使用方法: python scripts/restore_source.py
"""
import shutil
from pathlib import Path

# 需要恢复的模块
CORE_MODULES = [
    "scripts/understand/analyze_segment.py",
    "scripts/understand/generate_clips.py",
    "scripts/understand/quality_filter.py",
    "scripts/understand/extract_segments.py",
    "scripts/understand/smart_cut_finder.py",
    "scripts/understand/video_overlay/__init__.py",
    "scripts/understand/video_overlay/overlay_styles.py",
    "scripts/understand/video_overlay/tilted_label.py",
    "scripts/understand/video_overlay/video_overlay.py",
    "scripts/preprocess/sensitive_mask_workflow.py",
    "scripts/preprocess/ocr_subtitle.py",
    "scripts/preprocess/sensitive_detector.py",
    "scripts/preprocess/subtitle_detector.py",
    "scripts/preprocess/video_cleaner.py",
]

PROJECT_ROOT = Path(__file__).parent.parent


def restore_source():
    """从 .orig 备份恢复源代码"""
    print("🔄 恢复源代码...")

    restored_count = 0
    for module_path in CORE_MODULES:
        src = PROJECT_ROOT / module_path
        orig = src.with_suffix(src.suffix + '.orig')

        if not orig.exists():
            print(f"  ⚠️  备份不存在，跳过: {module_path}")
            continue

        if src.exists():
            # 删除编译后的 .so 文件
            so_file = src.with_suffix('.so')
            dylib_file = src.with_suffix('.dylib')

            if so_file.exists():
                so_file.unlink()
            if dylib_file.exists():
                dylib_file.unlink()

        # 恢复源代码
        shutil.copy2(orig, src)
        print(f"  ✓ 恢复: {module_path}")
        restored_count += 1

    print(f"\n✅ 成功恢复 {restored_count} 个文件")
    print("\n💡 提示: 源代码已恢复，可以正常开发了")


if __name__ == "__main__":
    restore_source()
