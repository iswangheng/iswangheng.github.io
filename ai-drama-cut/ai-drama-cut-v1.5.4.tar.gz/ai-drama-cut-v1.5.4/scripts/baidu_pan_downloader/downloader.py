# 核心下载流程编排
# 专用于短剧下载：从分享链接中提取短剧名，只下载前 N 集视频到 downloads/短剧名/ 目录
# 支持多账号 token 轮换、并发下载、异常时自动清理临时文件

import os
import re
import time
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

from . import config
from . import api
from .token_manager import TokenManager

logger = logging.getLogger(__name__)

# 文件名冲突计数器（线程安全）
_filename_counter = 0
_filename_lock = threading.Lock()


class BaiduPanDownloader:
    """百度网盘短剧下载器"""

    def __init__(self, spacetoken: str = None):
        # 初始化 token 管理器
        self._token_manager = TokenManager()
        self._token_manager.init()

        # 如果手动指定了 spacetoken，仍然支持（向后兼容）
        self._fixed_token = spacetoken or config.SPACETOKEN

        if self._token_manager.token_count == 0 and not self._fixed_token:
            raise ValueError(
                "无可用 token：memberlist 为空且未配置 BAIDU_SPACETOKEN"
            )

        if self._token_manager.token_count > 0:
            logger.info("使用 token 池模式，共 %d 个账号", self._token_manager.token_count)
        else:
            logger.info("使用固定 token 模式（未从 memberlist 获取到账号）")

    def _get_token(self) -> str:
        """获取一个可用的 token（优先从池中轮换）"""
        if self._token_manager.token_count > 0:
            return self._token_manager.get_token()
        return self._fixed_token

    def download(
        self,
        share_url: str,
        pwd: str = None,
        save_dir: str = None,
        max_episodes: int = None,
    ):
        """
        主入口：从分享链接下载短剧视频到本地
        同一个短剧的整个流程使用同一个 token（转存文件在该账号网盘中）
        无论成功失败都会清理网盘临时文件
        """
        save_dir = save_dir or config.DOWNLOAD_DIR
        max_ep = max_episodes or config.MAX_EPISODES

        # 获取本次流程使用的 token（整个流程复用同一个）
        spacetoken = self._get_token()
        logger.info("本次下载使用 token: ...%s", spacetoken[-20:])

        # 1. 解析分享链接，提取 surl
        short_url = self._extract_short_url(share_url)
        if not short_url:
            raise ValueError(f"无法从链接中提取 surl: {share_url}")
        logger.info("提取到 surl: %s", short_url)

        # 2. 验证提取码（有密码时）
        spwd = None
        if pwd:
            verify_surl = short_url[1:]
            resp = api.share_verify(spacetoken, verify_surl, pwd)
            if resp.get("errno") != 0:
                raise RuntimeError(f"验证提取码失败: {resp.get('show_msg', resp)}")
            spwd = resp["data"]["spwd"]
            logger.info("提取码验证成功")

        # 3. 查询外链信息
        info_resp = api.share_info(spacetoken, short_url, spwd)
        if info_resp.get("errno") != 0 or not info_resp.get("data"):
            raise RuntimeError(f"查询外链信息失败: {info_resp.get('show_msg', info_resp)}")

        share_data = info_resp["data"]
        link_info = share_data.get("link_info") or share_data.get("linkInfo", {})
        uk = link_info.get("uk")
        share_id = link_info.get("share_id") or link_info.get("shareId")
        file_list = share_data.get("list", [])

        if not file_list:
            raise RuntimeError("外链中没有可下载的文件")

        # 4. 提取短剧名（根目录文件夹名）
        drama_name = self._extract_drama_name(file_list)
        logger.info("短剧名: %s", drama_name)

        # 5. 在分享目录中找到"成片"目录，获取视频列表并按集数排序
        videos = self._find_episode_videos(
            spacetoken, uk, share_id, file_list, spwd, max_ep
        )
        if not videos:
            raise RuntimeError("未找到可下载的视频文件")
        logger.info("找到 %d 集视频（限制 %d 集）", len(videos), max_ep)

        # 6. 收集所有 fsid 并转存
        fsid_list = [int(v["fs_id"]) for v in videos]
        fsid_json = str(fsid_list)
        transfer_resp = api.share_transfer(
            spacetoken,
            str(uk),
            str(share_id),
            fsid_json,
            spwd=spwd,
            scope=config.TRANSFER_SCOPE,
            to_path=config.TRANSFER_PATH,
        )
        if transfer_resp.get("errno") != 0:
            raise RuntimeError(f"转存失败: {transfer_resp.get('show_msg', transfer_resp)}")

        task_id = transfer_resp.get("task_id")
        logger.info("转存响应 task_id=%s", task_id)

        # 7-9: try/finally 确保无论成功失败都清理临时文件
        to_fsids = None
        try:
            to_fsids = self._resolve_transfer_result(spacetoken, transfer_resp, task_id)
            logger.info("转存完成，目标 fsid: %s", to_fsids)

            # 8. 下载视频到 save_dir/短剧名/
            drama_dir = os.path.join(save_dir, drama_name)
            os.makedirs(drama_dir, exist_ok=True)
            downloaded = self._download_video_files(spacetoken, to_fsids, drama_dir)
        finally:
            # 9. 无论成功失败都清理百度网盘临时文件
            if to_fsids:
                self._cleanup(spacetoken, to_fsids)

        logger.info("完成! 短剧「%s」共下载 %d 集到 %s", drama_name, downloaded, drama_dir)
        return downloaded

    # ─── 短剧相关 ──────────────────────────────────────

    @staticmethod
    def _extract_drama_name(file_list: list) -> str:
        """从根目录文件夹名提取短剧名，并清洗掉书名号、括号后缀等"""
        name = None
        for f in file_list:
            if str(f.get("isdir", 0)) == "1":
                name = f.get("server_filename", "未知短剧")
                break
        if not name:
            name = file_list[0].get("server_filename", "未知短剧")
            name = re.sub(r"\d+集?\..*$", "", name).strip()

        # 清洗：去掉书名号
        name = name.replace("《", "").replace("》", "")
        # 清洗：去掉末尾的括号后缀，如 (2)、（2）
        name = re.sub(r"[(\（]\d+[)\）]$", "", name).strip()

        return name or "未知短剧"

    def _find_episode_videos(
        self, spacetoken, uk, share_id, file_list, spwd, max_ep
    ) -> list:
        """
        在分享目录中查找视频文件，按集数排序，返回前 max_ep 集
        优先从"成片"目录找，找不到就从所有目录找
        """
        all_videos = []

        for f in file_list:
            if str(f.get("isdir", 0)) == "1":
                fsid = int(f.get("fs_id") or f.get("fsid"))
                videos = self._collect_videos_prefer_finished(
                    spacetoken, uk, share_id, fsid, spwd
                )
                all_videos.extend(videos)
            else:
                if self._is_video(f.get("server_filename", "")):
                    all_videos.append(f)

        if not all_videos:
            return []

        # 按集数排序
        all_videos.sort(key=lambda v: self._parse_episode_num(v.get("server_filename", "")))

        # 取前 max_ep 集
        return all_videos[:max_ep]

    # 优先选择的目录关键词（按优先级从高到低）
    _PREFER_KEYWORDS = ["成片", "成品", "完成", "正片", "原版", "无水印", "素材"]
    # 需要排除的目录关键词
    _SKIP_KEYWORDS = {"纯净", "无bgm", "三视图", "海报", "照片", "封面", "预告", "图片"}

    def _collect_videos_prefer_finished(
        self, spacetoken, uk, share_id, fsid, spwd
    ) -> list:
        """
        收集目录下的视频，优先只取"成片"子目录
        如果没有成片目录，则取所有子目录中的视频
        """
        # 先列出当前目录的内容
        resp = api.share_list(
            spacetoken, uk, share_id, fsid, spwd, page=1, page_size=100
        )
        items = resp.get("list", [])
        if not items:
            return []

        # 分离子目录和文件
        sub_dirs = []
        videos = []
        for item in items:
            if str(item.get("isdir", 0)) == "1":
                sub_dirs.append(item)
            elif self._is_video(item.get("server_filename", "")):
                videos.append(item)

        # 如果当前目录直接有视频文件，返回
        if videos:
            return videos

        # 如果有子目录，按优先级关键词匹配最佳目录
        if sub_dirs:
            finished_dir = None
            for kw in self._PREFER_KEYWORDS:
                for d in sub_dirs:
                    name = d.get("server_filename", "")
                    if kw in name:
                        finished_dir = d
                        break
                if finished_dir:
                    break

            if finished_dir:
                # 只从成片目录收集
                logger.info("使用「%s」目录", finished_dir["server_filename"])
                target_fsid = int(finished_dir.get("fs_id") or finished_dir.get("fsid"))
                return self._collect_all_videos_flat(spacetoken, uk, share_id, target_fsid, spwd)
            else:
                # 没有成片目录，排除明确不需要的目录后从剩余目录收集
                all_vids = []
                for d in sub_dirs:
                    d_name = d.get("server_filename", "").lower()
                    if any(kw in d_name for kw in self._SKIP_KEYWORDS):
                        logger.info("跳过目录「%s」", d["server_filename"])
                        continue
                    d_fsid = int(d.get("fs_id") or d.get("fsid"))
                    all_vids.extend(
                        self._collect_all_videos_flat(spacetoken, uk, share_id, d_fsid, spwd)
                    )
                return all_vids

        return []

    def _collect_all_videos_flat(
        self, spacetoken, uk, share_id, fsid, spwd
    ) -> list:
        """从指定目录递归收集所有视频文件"""
        videos = []
        page = 1

        while True:
            resp = api.share_list(
                spacetoken, uk, share_id, fsid, spwd, page=page
            )
            items = resp.get("list", [])
            if not items:
                break

            for item in items:
                if str(item.get("isdir", 0)) == "1":
                    sub_fsid = int(item.get("fs_id") or item.get("fsid"))
                    videos.extend(
                        self._collect_all_videos_flat(spacetoken, uk, share_id, sub_fsid, spwd)
                    )
                elif self._is_video(item.get("server_filename", "")):
                    videos.append(item)

            if len(items) < 100:
                break
            page += 1

        return videos

    @staticmethod
    def _is_video(filename: str) -> bool:
        """判断文件是否为视频"""
        _, ext = os.path.splitext(filename.lower())
        return ext in config.VIDEO_EXTENSIONS

    # ─── 集数解析（支持中文数字） ────────────────────────

    # 中文数字映射
    _CN_DIGITS = {
        "零": 0, "〇": 0,
        "一": 1, "壹": 1,
        "二": 2, "贰": 2, "两": 2,
        "三": 3, "叁": 3,
        "四": 4, "肆": 4,
        "五": 5, "伍": 5,
        "六": 6, "陆": 6,
        "七": 7, "柒": 7,
        "八": 8, "捌": 8,
        "九": 9, "玖": 9,
        "十": 10, "拾": 10,
        "百": 100,
    }

    @classmethod
    def _cn_to_int(cls, cn: str) -> int:
        """中文数字转阿拉伯数字，支持一~九百九十九"""
        if not cn:
            return 9999
        result = 0
        current = 0
        for char in cn:
            val = cls._CN_DIGITS.get(char)
            if val is None:
                continue
            if val == 100:
                result += (current or 1) * 100
                current = 0
            elif val == 10:
                result += (current or 1) * 10
                current = 0
            else:
                current = val
        result += current
        return result if result > 0 else 9999

    @classmethod
    def _parse_episode_num(cls, filename: str) -> int:
        """
        从文件名中提取集数数字，用于排序
        支持格式: "1集.mp4", "第1集.mp4", "复婚1.mp4", "EP01.mp4",
                  "第一集.mp4", "第十二集.mp4", "二十集.mp4" 等
        """
        name = os.path.splitext(filename)[0]

        # 模式1: 阿拉伯数字 — "第X集" / "EPX" / "epX"
        m = re.search(r'(?:第|EP|ep)(\d+)', name)
        if m:
            return int(m.group(1))

        # 模式2: 阿拉伯数字 — "X集" / "X话"
        m = re.search(r'(\d+)[集话]', name)
        if m:
            return int(m.group(1))

        # 模式3: 中文数字 — "第X集"（X为中文数字）
        cn_chars = "零〇一壹二贰两三叁四肆五伍六陆七柒八捌九玖十拾百"
        m = re.search(r'第([' + cn_chars + r']+)集', name)
        if m:
            return cls._cn_to_int(m.group(1))

        # 模式4: 中文数字 — "X集"（X为中文数字）
        m = re.search(r'([' + cn_chars + r']+)集', name)
        if m:
            return cls._cn_to_int(m.group(1))

        # 模式5: "EP01", "E01"
        m = re.search(r'[eEpP]+(\d+)', name)
        if m:
            return int(m.group(1))

        # 模式6: 文件名末尾的数字 "复婚10"
        m = re.search(r'(\d+)\s*$', name)
        if m:
            return int(m.group(1))

        # 模式7: 兜底 — 文件名中的第一个数字
        m = re.search(r'(\d+)', name)
        if m:
            return int(m.group(1))

        return 9999

    # ─── 转存与下载 ────────────────────────────────────

    def _resolve_transfer_result(self, spacetoken: str, transfer_resp: dict, task_id) -> list:
        """解析转存结果，返回目标 fsid 字符串列表"""
        if task_id is None or str(task_id) == "0":
            mappings = transfer_resp.get("extra", {}).get("list", [])
            return [str(m["to_fs_id"]) for m in mappings]

        # 异步任务，轮询等待
        logger.info("异步转存任务 %s，开始轮询...", task_id)
        for _ in range(60):
            time.sleep(2)
            resp = api.share_task_query(spacetoken, str(task_id))
            data = resp.get("data", {})
            status = data.get("status", "")

            if status == "success":
                return [str(item["to_fs_id"]) for item in data.get("list", [])]
            elif status == "fail":
                raise RuntimeError(f"异步转存任务失败: {data}")

            logger.info("任务进行中... 进度: %s%%", data.get("progress", "?"))

        raise RuntimeError("异步转存任务超时（120秒）")

    def _download_video_files(self, spacetoken: str, fsids: list, drama_dir: str) -> int:
        """获取下载链接并并发下载视频文件到短剧目录"""
        meta_resp = api.file_metas_with_dlink(spacetoken, fsids)
        file_list = meta_resp.get("list", [])
        if not file_list:
            logger.warning("获取文件元数据为空")
            return 0

        # 过滤出视频文件
        video_files = [
            f for f in file_list
            if not int(f.get("isdir", 0)) and self._is_video(f.get("server_filename", ""))
        ]

        if not video_files:
            logger.warning("没有可下载的视频文件")
            return 0

        # 并发下载
        count = 0
        with ThreadPoolExecutor(max_workers=config.DOWNLOAD_WORKERS) as pool:
            futures = {
                pool.submit(self._download_single_file, spacetoken, f, drama_dir): f
                for f in video_files
            }
            for future in as_completed(futures):
                try:
                    if future.result():
                        count += 1
                except Exception as e:
                    f = futures[future]
                    logger.error("下载异常: %s, 错误: %s", f.get("server_filename", "?"), e)
        return count

    def _download_single_file(self, spacetoken: str, file_info: dict, save_dir: str) -> bool:
        """流式下载单个文件到本地（使用 Session 复用连接）"""
        global _filename_counter
        dlink = file_info.get("dlink")
        filename = file_info.get("server_filename") or file_info.get("serverFilename", "unknown")
        if not dlink:
            logger.warning("文件 %s 没有下载链接，跳过", filename)
            return False

        download_url = api.build_download_url(spacetoken, dlink)
        file_path = os.path.join(save_dir, filename)

        # 线程安全的文件名冲突处理
        if os.path.exists(file_path):
            with _filename_lock:
                _filename_counter += 1
                counter = _filename_counter
            base, ext = os.path.splitext(filename)
            file_path = os.path.join(save_dir, f"{base}_{counter}{ext}")

        size = file_info.get("size", 0)
        size_mb = size / (1024 * 1024) if size else 0
        logger.info("下载: %s (%.1f MB)", filename, size_mb)

        session = api.get_session()
        try:
            with session.get(download_url, stream=True, timeout=config.DOWNLOAD_TIMEOUT) as resp:
                resp.raise_for_status()
                downloaded = 0
                with open(file_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=config.DOWNLOAD_CHUNK_SIZE):
                        f.write(chunk)
                        downloaded += len(chunk)

            logger.info("完成: %s (%.1f MB)", filename, downloaded / (1024 * 1024))
            return True
        except Exception as e:
            logger.error("下载失败: %s, 错误: %s", filename, e)
            if os.path.exists(file_path):
                os.remove(file_path)
            return False

    def _cleanup(self, spacetoken: str, fsids: list):
        """删除百度网盘中转存的临时文件"""
        try:
            meta_resp = api.file_metas_with_dlink(spacetoken, fsids)
            file_list = meta_resp.get("list", [])
            paths = [f["path"] for f in file_list if f.get("path")]

            if paths:
                logger.info("清理临时文件: %s", paths)
                api.delete_file(spacetoken, paths, scope="0")
                logger.info("临时文件清理完成")
        except Exception as e:
            logger.warning("清理临时文件失败（不影响下载结果）: %s", e)

    @staticmethod
    def _extract_short_url(share_url: str) -> str:
        """从分享链接中提取 surl"""
        if not share_url:
            return None
        if "pan.baidu.com/s/" in share_url:
            match = re.search(r"/s/([^?\s]+)", share_url)
            if match:
                return match.group(1).strip()
        return share_url.strip()
