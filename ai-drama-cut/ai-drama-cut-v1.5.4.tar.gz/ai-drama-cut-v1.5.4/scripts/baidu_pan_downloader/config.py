# 百度网盘 API 配置
# appid 和 cid 为固定值，spacetoken 需要根据实际账号配置

import os

APPID = "119534436"
CID = "1000061684711"
SECRET_KEY = "sbzhSCSZD1kWgFyKo48Slj1Odw8vUd87"

# spacetoken: 从环境变量读取，或在此处直接填写
SPACETOKEN = os.environ.get(
    "BAIDU_SPACETOKEN",
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIxMDAwMDYxNjg0NzExIiwianRpIjoiMTEwMTUxODUxOTQ1OSIsImlhdCI6MTc3MzgwMDA3NywiaXNzIjoid3d3LmFwYWFzLmJhaWR1LmNvbSIsImR1cmF0aW9uIjoxNzc2MzkyMDc3LCJyZXBldGl0aW9uIjowfQ.guT_kpPltgghsCkDguSlaE9vf-D6Dq3g0tEbvlxtR6--ZTDM5Tq5ahc-g7AgEb4_d-nQ0_59PAZ7gleAhM0mSJK-70izKpZCIXLjx-MfhdiIo2Q83tSNgAEyW51lN-uzJN5NrQ4n5vlmHXuNo19o6mM13LgoGZVRpfrWpuKP6T4",
)

# 默认下载目录
DOWNLOAD_DIR = os.environ.get("BAIDU_DOWNLOAD_DIR", "./downloads")

# HTTP 请求超时（秒）
REQUEST_TIMEOUT = 30

# 文件下载超时：(连接超时, 读取超时)
# 读取超时设为 None 表示不限制，避免大文件下载中途超时
DOWNLOAD_TIMEOUT = (15, None)

# 下载流式读取的 chunk 大小（字节）
DOWNLOAD_CHUNK_SIZE = 64 * 1024

# 转存文件保存路径（百度网盘内的临时路径）
TRANSFER_PATH = "/"

# 转存文件可见范围：0-个人可见；1-群组可见；2-全员可见
TRANSFER_SCOPE = "2"

# 最大下载集数（只下载前 N 集视频）
MAX_EPISODES = 10

# 视频文件扩展名
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".ts", ".m4v"}

# 并发下载线程数
DOWNLOAD_WORKERS = 3

# API 重试次数
API_MAX_RETRIES = 3
