# 百度网盘 API 封装
# 移植自 BaiDuUtil.java，封装所有百度网盘 API 调用
# 使用 Session 复用 TCP 连接，带指数退避重试

import json
import logging
import time
from urllib.parse import quote

import requests

from . import config
from .signer import sign_url

logger = logging.getLogger(__name__)

# API 基础地址
_BASE = "https://apaas.baidu.com/apaas/1.0"

# 请求超时
_TIMEOUT = config.REQUEST_TIMEOUT

# 模块级 Session：复用 TCP 连接池，避免每次请求新建连接
_session = requests.Session()
_session.headers.update({"User-Agent": "BaiduPanDownloader/1.0"})


def _common_params() -> str:
    """返回公共 URL 参数片段"""
    return f"appid={config.APPID}&cid={config.CID}"


def _request_with_retry(method: str, url: str, max_retries: int = None, **kwargs) -> dict:
    """
    带指数退避重试的请求封装
    只对可重试错误重试（ConnectionError、Timeout、5xx），4xx 不重试
    """
    if max_retries is None:
        max_retries = config.API_MAX_RETRIES

    for attempt in range(max_retries + 1):
        try:
            resp = _session.request(method, url, timeout=_TIMEOUT, **kwargs)
            if resp.status_code >= 500 and attempt < max_retries:
                wait = 2 ** attempt
                logger.warning("服务端错误 %d，%ds 后重试 (%d/%d)", resp.status_code, wait, attempt + 1, max_retries)
                time.sleep(wait)
                continue
            resp.raise_for_status()
            try:
                return resp.json()
            except ValueError:
                # 百度偶尔返回非 JSON（HTML 错误页等），视为可重试
                if attempt < max_retries:
                    wait = 2 ** attempt
                    logger.warning("响应非 JSON，%ds 后重试 (%d/%d)", wait, attempt + 1, max_retries)
                    time.sleep(wait)
                    continue
                raise RuntimeError(f"API 返回非 JSON 响应: {resp.text[:200]}")
        except (requests.ConnectionError, requests.Timeout) as e:
            if attempt == max_retries:
                raise
            wait = 2 ** attempt
            logger.warning("网络错误: %s，%ds 后重试 (%d/%d)", e, wait, attempt + 1, max_retries)
            time.sleep(wait)


def get_session() -> requests.Session:
    """暴露 Session 供下载文件时复用连接池"""
    return _session


def _get(url: str, headers: dict = None) -> dict:
    """发送 GET 请求并返回 JSON（带重试）"""
    return _request_with_retry("GET", url, headers=headers)


def _post_form(url: str, data: dict, headers: dict = None) -> dict:
    """发送 POST 表单请求并返回 JSON（带重试）"""
    return _request_with_retry("POST", url, data=data, headers=headers)


# ─── 账户相关（需要签名） ───────────────────────────────


def memberlist() -> dict:
    """获取百度网盘账号列表（需要签名）"""
    ts = int(time.time())
    url = f"{_BASE}/account/saas/memberlist?{_common_params()}&apaastime={ts}"
    sig = sign_url(url, config.SECRET_KEY)
    return _get(url, headers={"Authorization": sig})


def refresh_token(old_token: str) -> dict:
    """刷新 spacetoken（需要签名）"""
    ts = int(time.time())
    url = (
        f"{_BASE}/account/saas/refresh?{_common_params()}"
        f"&refreshtoken={old_token}&apaastime={ts}"
    )
    sig = sign_url(url, config.SECRET_KEY)
    return _get(url, headers={"Authorization": sig})


# ─── 外链分享相关 ──────────────────────────────────────


def share_verify(spacetoken: str, short_url: str, pwd: str = None) -> dict:
    """
    验证外链提取码
    注意：short_url 需要去掉第一个字符（Java 代码中 substring(1)）
    返回 data.spwd
    """
    url = f"{_BASE}/saas/share/verify?{_common_params()}&spacetoken={spacetoken}"
    form = {"short_url": short_url}
    if pwd:
        form["pwd"] = pwd
    return _post_form(url, form)


def share_info(spacetoken: str, short_url: str, spwd: str = None) -> dict:
    """
    查询外链信息（保留完整 short_url）
    返回 data.linkInfo.uk / data.linkInfo.shareId / data.list（文件列表）
    """
    url = f"{_BASE}/saas/share/info?{_common_params()}&spacetoken={spacetoken}"
    form = {"short_url": short_url}
    if spwd:
        form["spwd"] = spwd
    headers = {"Accept-Encoding": "identity"}
    return _post_form(url, form, headers=headers)


def share_list(
    spacetoken: str,
    uk: int,
    shareid: int,
    fsid: int,
    spwd: str = None,
    page: int = 1,
    page_size: int = 100,
) -> dict:
    """查询外链文件列表（用于遍历目录）"""
    url = f"{_BASE}/saas/share/list?{_common_params()}&spacetoken={spacetoken}"
    form = {
        "uk": str(uk),
        "shareid": str(shareid),
        "fsid": str(fsid),
        "page": str(page),
        "page_size": str(page_size),
    }
    if spwd:
        form["spwd"] = spwd
    return _post_form(url, form)


def share_transfer(
    spacetoken: str,
    from_uk: str,
    shareid: str,
    fsid_list: str,
    spwd: str = None,
    scope: str = "2",
    to_path: str = "/",
    ondup: str = "newcopy",
) -> dict:
    """
    转存外链文件到自己网盘
    fsid_list: JSON 数组字符串，如 "[123,456]"
    返回 task_id（0=同步成功，非0=异步任务）和 extra.list（文件映射）
    """
    url = f"{_BASE}/saas/share/transfer?{_common_params()}&spacetoken={spacetoken}"
    form = {
        "from": from_uk,
        "shareid": shareid,
        "fsid_list": fsid_list,
        "to_path": to_path,
        "ondup": ondup,
    }
    if spwd:
        form["spwd"] = spwd
    if scope:
        form["scope"] = scope
    return _post_form(url, form)


def share_task_query(spacetoken: str, task_id: str) -> dict:
    """查询异步转存任务状态，返回 data.status / data.list"""
    url = (
        f"{_BASE}/saas/share/taskquery?{_common_params()}"
        f"&spacetoken={spacetoken}&task_id={task_id}"
    )
    return _get(url)


# ─── 文件操作相关 ──────────────────────────────────────


def file_metas_with_dlink(spacetoken: str, fsids: list) -> dict:
    """
    获取文件下载链接
    fsids: 字符串列表，如 ["123", "456"]
    返回 list[].dlink
    """
    fsids_json = json.dumps(fsids)
    fsids_encoded = quote(fsids_json, safe="")
    url = (
        f"{_BASE}/saas/file/filemetaswithdlink?{_common_params()}"
        f"&fsids={fsids_encoded}&scope=2&spacetoken={spacetoken}"
    )
    return _get(url)


def file_list(
    spacetoken: str, page: int = 1, num: int = 100, dir_path: str = "/"
) -> dict:
    """列出网盘目录下的文件"""
    # 百度不兼容标准 URL 编码，对特殊字符手动处理
    safe_dir = dir_path
    safe_dir = safe_dir.replace("#", "%23")
    safe_dir = safe_dir.replace("+", "%2B")
    safe_dir = safe_dir.replace("&", "%26")
    url = (
        f"{_BASE}/saas/file/list?{_common_params()}"
        f"&scope=2&spacetoken={spacetoken}"
        f"&dir={safe_dir}&page={page}&num={num}&order=time"
    )
    return _get(url)


def delete_file(spacetoken: str, file_paths: list, scope: str = "0") -> dict:
    """
    删除网盘文件
    file_paths: 文件路径列表
    opera 固定为 "delete"
    """
    url = (
        f"{_BASE}/saas/file/filemanager?{_common_params()}"
        f"&spacetoken={spacetoken}&opera=delete&scope={scope}"
    )
    form = {"filelist": json.dumps(file_paths)}
    return _post_form(url, form)


def build_download_url(spacetoken: str, dlink: str) -> str:
    """拼接真实文件下载 URL"""
    return f"{dlink}&appid={config.APPID}&cid={config.CID}&spacetoken={spacetoken}"
