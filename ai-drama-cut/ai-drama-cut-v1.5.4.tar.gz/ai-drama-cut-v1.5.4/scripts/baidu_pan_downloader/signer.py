# URL 签名工具
# 移植自 URLSigner.java，使用 HMAC-SHA1 对 URL 查询参数进行签名

import hmac
import hashlib
import base64
from urllib.parse import urlparse, parse_qs, quote


def sign_url(url_str: str, secret_key: str) -> str:
    """
    对 URL 进行 HMAC-SHA1 签名
    流程：解析查询参数 → 按 key 排序 → URL encode 拼接 → HMAC-SHA1 → Base64
    """
    parsed = urlparse(url_str)
    query_params = parse_qs(parsed.query, keep_blank_values=True)

    canonical = _build_canonical_query_string(query_params)

    mac = hmac.new(
        secret_key.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha1,
    )
    return base64.b64encode(mac.digest()).decode("utf-8")


def _build_canonical_query_string(params: dict) -> str:
    """
    构建规范化查询字符串：key 排序，多值也排序，URL encode 后用 & 拼接
    """
    if not params:
        return ""

    parts = []
    for key in sorted(params.keys()):
        values = sorted(params[key])
        for value in values:
            encoded_key = quote(key, safe="")
            encoded_value = quote(value, safe="")
            parts.append(f"{encoded_key}={encoded_value}")

    return "&".join(parts)
