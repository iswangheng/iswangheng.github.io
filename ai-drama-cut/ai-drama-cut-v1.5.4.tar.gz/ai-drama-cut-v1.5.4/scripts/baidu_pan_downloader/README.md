# 百度网盘短剧下载模块

## 模块简介

独立的百度网盘分享链接下载模块，专为短剧批量下载场景设计。通过百度网盘 apaas API 实现：分享链接解析 → 提取码验证 → 文件转存 → 并发下载 → 临时文件清理的完整流程。

支持多账号 token 池轮换、自动刷新过期 token、API 重试、并发下载、异常时自动清理网盘临时文件。

## 目录结构

```
baidu_pan_downloader/
├── __init__.py        # 包声明
├── __main__.py        # CLI 入口（python -m baidu_pan_downloader）
├── config.py          # 全局配置（API 密钥、超时、并发数等）
├── signer.py          # URL HMAC-SHA1 签名工具
├── api.py             # 百度网盘 API 封装（Session 复用 + 重试）
├── token_manager.py   # 多账号 token 池（自动刷新 + 轮换）
├── downloader.py      # 核心下载流程编排
└── README.md          # 本文档
```

## 核心流程

```
调用方
  │
  ▼
BaiduPanDownloader(spacetoken=None)
  │  初始化 TokenManager → 调 memberlist() 拉取所有账号
  │  过期 token 自动调 refresh_token() 刷新
  │
  ▼
downloader.download(share_url, pwd, save_dir, max_episodes)
  │
  ├─ 1. 解析分享链接，提取 surl
  ├─ 2. share_verify()  验证提取码
  ├─ 3. share_info()    查询外链信息（uk, shareId, 文件列表）
  ├─ 4. 提取短剧名（根目录文件夹名）
  ├─ 5. 遍历目录，优先「成片」目录，按集数排序，取前 N 集
  ├─ 6. share_transfer() 转存到当前账号网盘
  │
  ├─ try:
  │  ├─ 7. 解析转存结果（同步/异步任务）
  │  ├─ 8. file_metas_with_dlink() 获取下载链接
  │  └─ 9. ThreadPoolExecutor 并发下载到本地
  │
  └─ finally:
     └─ 10. delete_file() 清理网盘临时文件（无论成功失败）
```

## 调用方式

### 方式一：CLI 命令行

```bash
python -m baidu_pan_downloader \
  --url "https://pan.baidu.com/s/1H6T8PCt7HWjKIezZxuF95g" \
  --pwd "mx62" \
  --episodes 10 \
  --output ./downloads/ \
  -v
```

### 方式二：Python 代码调用

```python
from baidu_pan_downloader.downloader import BaiduPanDownloader

# 初始化（自动从 memberlist 加载 token 池）
downloader = BaiduPanDownloader()

# 下载短剧
count = downloader.download(
    share_url="https://pan.baidu.com/s/1H6T8PCt7HWjKIezZxuF95g",
    pwd="mx62",
    save_dir="./downloads/",
    max_episodes=10,
)
print(f"下载完成，共 {count} 个文件")
```

### 方式三：批量调用

```python
downloader = BaiduPanDownloader()

tasks = [
    {"url": "https://pan.baidu.com/s/1xxx", "pwd": "abcd"},
    {"url": "https://pan.baidu.com/s/1yyy", "pwd": "efgh"},
    # ...
]

for task in tasks:
    try:
        count = downloader.download(
            share_url=task["url"],
            pwd=task["pwd"],
            max_episodes=10,
        )
        print(f"成功: {task['url']} -> {count} 个文件")
    except Exception as e:
        print(f"失败: {task['url']} -> {e}")
        # 单个失败不影响后续任务，临时文件已在 finally 中清理
```

注意：`BaiduPanDownloader` 实例可复用，token 池在实例内部管理，每次 `download()` 调用会自动轮换 token。

## 关键设计

### Token 池（token_manager.py）

- 启动时调 `memberlist()` 拉取全部 7 个账号的 spacetoken
- 过期 token 自动调 `refresh_token()` 刷新（预留 1 小时缓冲）
- `get_token()` round-robin 轮换，分散请求压力
- 线程安全：`_lock` 保护读写，`_refresh_lock` 防止并发重复刷新
- 同一部短剧的整个流程（转存→下载→清理）使用同一个 token

### API 层（api.py）

- 模块级 `requests.Session()` 复用 TCP 连接池
- `_request_with_retry()` 指数退避重试（1s/2s/4s，最多 3 次）
- 只对可重试错误重试：ConnectionError、Timeout、5xx、非 JSON 响应
- 4xx 错误不重试，直接抛出

### 下载层（downloader.py）

- `ThreadPoolExecutor(max_workers=3)` 并发下载
- 下载超时 `(15, None)`：连接 15s 超时，读取不限时（避免大文件中途断开）
- chunk 大小 64KB，提升 IO 吞吐
- 下载失败自动删除不完整文件
- `try/finally` 保证网盘临时文件必清理

## 配置项（config.py）

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `APPID` | `119534436` | 百度 apaas 应用 ID |
| `CID` | `1000061684711` | 百度 apaas 客户端 ID |
| `SECRET_KEY` | `sbzhSCS...` | HMAC 签名密钥 |
| `SPACETOKEN` | 环境变量 / 硬编码 | 降级用固定 token |
| `DOWNLOAD_DIR` | `./downloads` | 默认下载目录 |
| `REQUEST_TIMEOUT` | `30` | API 请求超时（秒） |
| `DOWNLOAD_TIMEOUT` | `(15, None)` | 下载超时（连接, 读取） |
| `DOWNLOAD_CHUNK_SIZE` | `64KB` | 流式读取块大小 |
| `DOWNLOAD_WORKERS` | `3` | 并发下载线程数 |
| `API_MAX_RETRIES` | `3` | API 重试次数 |
| `MAX_EPISODES` | `10` | 默认下载集数 |
| `TRANSFER_PATH` | `/` | 网盘转存临时路径 |
| `TRANSFER_SCOPE` | `2` | 转存可见范围 |
| `VIDEO_EXTENSIONS` | `.mp4,.mkv,...` | 视频文件扩展名 |

## 吞吐量评估

基于实测数据（7 个账号，服务器在上海）：

| 场景 | 每集大小 | 集数 | 单部耗时 | 24h 吞吐量 |
|------|----------|------|----------|------------|
| 保守估计 | 35 MB | 10 集 | ~1.8 分钟 | ~800 部/天 |
| 保守估计 | 35 MB | 15 集 | ~2.6 分钟 | ~550 部/天 |

实测下载速度 1.3~3.5 MB/s（非 SVIP 账号），3 线程并发有效吞吐约 3.8 MB/s。

### 扩容到 2000 部/天

当前单实例串行处理约 800 部/天。要达到 2000 部/天，有两条路：

1. **多实例并行**：部署 3 个下载实例，每个实例分配不同的任务队列，即可达到 2400 部/天
2. **升级 SVIP**：如果账号升级为 SVIP（10+ MB/s），单实例即可达到 2000+ 部/天

## 依赖

```
requests>=2.28.0
```

无其他第三方依赖。Python 3.8+。

## 异常处理

| 异常场景 | 处理方式 |
|----------|----------|
| token 全部过期 | 自动调 refresh_token 逐个刷新 |
| API 网络超时 | 指数退避重试 3 次 |
| 百度返回 5xx | 指数退避重试 3 次 |
| 百度返回非 JSON | 视为可重试错误，重试 3 次 |
| 转存失败 | 抛出异常，不会留下临时文件 |
| 单文件下载失败 | 删除不完整文件，继续下载其他文件 |
| 下载中途崩溃 | finally 块清理已转存的临时文件 |
| 文件名冲突 | 线程安全的原子计数器生成唯一后缀 |
