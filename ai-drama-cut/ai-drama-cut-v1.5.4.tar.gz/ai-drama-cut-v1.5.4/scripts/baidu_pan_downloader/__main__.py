# 命令行入口
# 用法: python -m baidu_pan_downloader --url "分享链接" [--pwd "提取码"] [--output ./downloads/]

import argparse
import logging
import sys

from .downloader import BaiduPanDownloader
from . import config


def main():
    parser = argparse.ArgumentParser(
        description="百度网盘分享链接下载工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m baidu_pan_downloader --url "https://pan.baidu.com/s/1xxx"
  python -m baidu_pan_downloader --url "https://pan.baidu.com/s/1xxx" --pwd "abcd"
  python -m baidu_pan_downloader --url "https://pan.baidu.com/s/1xxx" --output ./my_downloads/
        """,
    )
    parser.add_argument("--url", required=True, help="百度网盘分享链接")
    parser.add_argument("--pwd", default=None, help="提取码（公开链接不需要）")
    parser.add_argument("--output", default=None, help="下载根目录（默认 ./downloads/）")
    parser.add_argument(
        "--episodes", type=int, default=None,
        help=f"下载前几集（默认 {config.MAX_EPISODES}）",
    )
    parser.add_argument(
        "--spacetoken", default=None, help="spacetoken（默认从环境变量或 config.py 读取）"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="显示详细日志")

    args = parser.parse_args()

    # 配置日志
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    try:
        downloader = BaiduPanDownloader(spacetoken=args.spacetoken)
        count = downloader.download(
            share_url=args.url,
            pwd=args.pwd,
            save_dir=args.output,
            max_episodes=args.episodes,
        )
        print(f"\n下载完成，共 {count} 个文件")
    except Exception as e:
        logging.error("下载失败: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
