# 多账号 token 池管理
# 管理多个百度网盘账号的 spacetoken，支持自动刷新和轮换使用
# 解决单 token 瓶颈和 token 过期问题

import base64
import json
import logging
import threading
import time

logger = logging.getLogger(__name__)


class TokenManager:
    """
    多账号 spacetoken 池管理器
    - 启动时从 memberlist() 拉取所有账号 token
    - round-robin 轮换分配 token
    - 自动检测过期并刷新（预留 1 小时缓冲）
    - 线程安全，支持并发下载场景
    """

    # 过期缓冲时间（秒）：提前 1 小时刷新
    _EXPIRE_BUFFER = 3600

    def __init__(self):
        self._tokens = []       # [(spacetoken, expire_timestamp), ...]
        self._index = 0         # 轮换索引
        self._lock = threading.Lock()
        self._refresh_lock = threading.Lock()  # 防止并发重复刷新
        self._initialized = False

    def init(self):
        """初始化 token 池，从 memberlist 拉取所有账号"""
        self.refresh_all()
        self._initialized = True

    def get_token(self) -> str:
        """
        轮换获取一个有效的 token
        过期时自动触发全量刷新
        """
        with self._lock:
            if not self._tokens:
                raise RuntimeError("token 池为空，请先调用 init() 初始化")

            # 尝试找到一个有效 token（最多遍历一轮）
            for _ in range(len(self._tokens)):
                token, expire_ts = self._tokens[self._index]
                self._index = (self._index + 1) % len(self._tokens)

                if not self._is_expired(expire_ts):
                    return token

            # 所有 token 都过期了，刷新整个池
            logger.info("所有 token 已过期，触发全量刷新")

        # 在锁外刷新，用 refresh_lock 防止多线程并发重复刷新
        with self._refresh_lock:
            # 双重检查：拿到刷新锁后再看一次，可能别的线程已经刷新好了
            with self._lock:
                for i in range(len(self._tokens)):
                    token, expire_ts = self._tokens[i]
                    if not self._is_expired(expire_ts):
                        self._index = (i + 1) % len(self._tokens)
                        return token
            self.refresh_all()

        with self._lock:
            if self._tokens:
                token, _ = self._tokens[0]
                self._index = 1 % len(self._tokens)
                return token
            raise RuntimeError("刷新后 token 池仍为空")

    def refresh_all(self):
        """调用 memberlist() 获取所有账号最新 token"""
        # 延迟导入避免循环依赖
        from . import api

        try:
            resp = api.memberlist()
            if resp.get("errno") != 0:
                logger.error("获取账号列表失败: %s", resp.get("show_msg", resp))
                return

            members = resp.get("data", []) or resp.get("member_list", [])
            if not members:
                logger.warning("memberlist 返回空列表")
                return

            new_tokens = []
            for member in members:
                token = member.get("spacetoken", "")
                if not token:
                    continue
                role = member.get("role", 0)
                name = member.get("display_name") or member.get("baidu_name", "未知账号")

                # 检查 token 是否过期，过期则调 refresh_token 刷新
                expire_ts = self._parse_expire_time(token)
                if self._is_expired(expire_ts):
                    logger.info("账号 %s 的 token 已过期，尝试刷新...", name)
                    token = self._refresh_single_token(api, token, name)
                    if not token:
                        continue
                    expire_ts = self._parse_expire_time(token)

                logger.info(
                    "加载 token: 账号=%s, role=%d, 过期时间=%s",
                    name, role,
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(expire_ts)) if expire_ts else "未知",
                )
                new_tokens.append((token, expire_ts))

            with self._lock:
                self._tokens = new_tokens
                self._index = 0

            logger.info("token 池初始化完成，共 %d 个账号", len(new_tokens))

        except Exception as e:
            logger.error("刷新 token 池失败: %s", e)

    def _is_expired(self, expire_ts: float) -> bool:
        """判断 token 是否已过期（含缓冲时间）"""
        if not expire_ts:
            return False  # 无法解析过期时间时默认不过期，让服务端判断
        return time.time() >= (expire_ts - self._EXPIRE_BUFFER)

    @staticmethod
    def _refresh_single_token(api, old_token: str, account_name: str) -> str:
        """调用 refresh_token API 刷新单个过期 token，返回新 token 或 None"""
        try:
            resp = api.refresh_token(old_token)
            if resp.get("errno") != 0:
                logger.warning("刷新 %s 的 token 失败: %s", account_name, resp.get("show_msg", resp))
                return None
            new_token = resp.get("data", {}).get("spacetoken", "")
            if not new_token:
                logger.warning("刷新 %s 返回空 token", account_name)
                return None
            logger.info("刷新 %s 的 token 成功", account_name)
            return new_token
        except Exception as e:
            logger.warning("刷新 %s 的 token 异常: %s", account_name, e)
            return None

    @staticmethod
    def _parse_expire_time(token: str) -> float:
        """
        解析 JWT payload 中的 duration 字段作为过期时间戳
        duration 是 Unix 时间戳，表示 token 的过期时间
        """
        try:
            parts = token.split(".")
            if len(parts) < 2:
                return 0
            # JWT payload 是 base64url 编码
            payload_b64 = parts[1]
            # 补齐 padding
            padding = 4 - len(payload_b64) % 4
            if padding != 4:
                payload_b64 += "=" * padding
            payload_bytes = base64.urlsafe_b64decode(payload_b64)
            payload = json.loads(payload_bytes)
            return float(payload.get("duration", 0))
        except Exception:
            return 0

    @property
    def token_count(self) -> int:
        """当前池中 token 数量"""
        with self._lock:
            return len(self._tokens)
