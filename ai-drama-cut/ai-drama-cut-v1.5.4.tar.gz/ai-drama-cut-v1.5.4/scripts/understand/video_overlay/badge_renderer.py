"""
角标渲染器 - 20种多形态角标样式

支持6种形态：
- tilted_banner: 45度倾斜条幅（现有样式扩展）
- horizontal_banner: 横向标签（带尖角/切角）
- square_icon: 圆角方形（类App图标）
- triangle_corner: 三角贴角
- text_only: 无背景纯文字（厚描边）
- ink_stamp: 水墨/印章风

全部用 PIL 预渲染 PNG，再由调用方用 FFmpeg overlay 叠加到视频。
动态缩放：基于视频较小边 / 360 的比例。

作者：杭州雷鸣AI短剧项目
"""
import os
import math
import tempfile
from pathlib import Path
from typing import Any, Optional, Tuple

# PIL 可选依赖
try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# BadgeStyle 定义在 overlay_styles 中（避免循环导入）
# 调用方传入 BadgeStyle 实例，badge_renderer 只负责渲染


# ==================== 全局常量 ====================

BADGE_TEXT_OPTIONS = ["热门短剧", "爆款短剧", "必看短剧"]

# 系统字体候选列表（默认字体）
FONT_CANDIDATES = [
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
]

# 多样化中文字体池（每个角标随机选一种，增加视觉变化）
FONT_POOL = [
    # 宋体（衬线，古典优雅）
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    # 黑体（无衬线，现代简洁）
    "/System/Library/Fonts/STHeiti Medium.ttc",
    # 冬青黑体（日系无衬线，清爽）
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    # 阿里普惠体 Bold（现代商务感）
    os.path.expanduser("~/Library/Fonts/Alibaba-PuHuiTi-Bold.ttf"),
    # 阿里普惠体 Heavy（超粗，力量感）
    os.path.expanduser("~/Library/Fonts/Alibaba-PuHuiTi-Heavy.ttf"),
    # OPPO Sans Heavy（圆润现代）
    os.path.expanduser("~/Library/Fonts/OPPOSans-H.ttf"),
    # OPPO Sans 4.0（新版圆润）
    os.path.expanduser("~/Library/Fonts/OPPO Sans 4.0.ttf"),
]


def _find_font(size: int, font_path: str = None) -> Optional["ImageFont.FreeTypeFont"]:
    """查找并加载中文字体

    Args:
        size: 字体大小
        font_path: 指定字体路径，为 None 时使用默认候选列表
    """
    if not PIL_AVAILABLE:
        return None

    # 优先使用指定字体
    if font_path and Path(font_path).exists():
        try:
            return ImageFont.truetype(font_path, size)
        except Exception:
            pass

    # 回退到默认候选列表
    for path in FONT_CANDIDATES:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    try:
        return ImageFont.load_default()
    except Exception:
        return None


def _pick_random_font() -> Optional[str]:
    """从字体池中随机选一个可用字体路径"""
    import random
    available = [p for p in FONT_POOL if Path(p).exists()]
    if available:
        return random.choice(available)
    return None


def _add_texture_to_image(img: "Image.Image", texture_type: str = "stripes") -> "Image.Image":
    """给图像添加纹理效果，让纯色背景更有质感

    **关键**：只在非透明区域（角标本身）添加纹理，不影响透明背景

    Args:
        img: 原始图像
        texture_type: 纹理类型 - "stripes"(斜纹), "dots"(点阵), "shimmer"(光泽渐变)

    Returns:
        添加纹理后的图像
    """
    if not PIL_AVAILABLE:
        return img

    w, h = img.size

    # 创建纹理层
    texture = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)

    if texture_type == "stripes":
        # 斜纹纹理 — 白色细线条
        spacing = max(6, min(w, h) // 30)
        for i in range(-h, w + h, spacing):
            draw.line([(i, 0), (i + h, h)], fill=(255, 255, 255, 30), width=1)
        # 再加一层反向斜纹（交叉效果）
        for i in range(-h, w + h, spacing * 3):
            draw.line([(i + h, 0), (i, h)], fill=(255, 255, 255, 18), width=1)

    elif texture_type == "dots":
        # 点阵纹理 — 规则排列的小圆点
        spacing = max(6, min(w, h) // 20)
        for y in range(0, h, spacing):
            offset_x = spacing // 2 if (y // spacing) % 2 else 0
            for x in range(offset_x, w, spacing):
                draw.ellipse([x-1, y-1, x+1, y+1], fill=(255, 255, 255, 35))

    elif texture_type == "shimmer":
        # 光泽渐变 — 从上到下一道亮光
        for y in range(h):
            # 上部 1/3 有高光
            if y < h // 3:
                alpha = int(40 * (1 - y / (h / 3)))
                draw.line([(0, y), (w, y)], fill=(255, 255, 255, alpha))

    # **关键修改**：使用原图的 alpha 通道作为遮罩，只在非透明区域叠加纹理
    if img.mode == "RGBA":
        from PIL import ImageChops
        alpha_mask = img.split()[3]  # 原图 alpha 通道
        # 将纹理 alpha 与原图 alpha 相乘 → 原图透明处纹理也透明
        tex_r, tex_g, tex_b, tex_a = texture.split()
        masked_alpha = ImageChops.multiply(tex_a, alpha_mask)
        texture = Image.merge("RGBA", (tex_r, tex_g, tex_b, masked_alpha))

    # 叠加纹理
    result = Image.alpha_composite(img, texture)
    return result


def _hex_to_rgb(hex_color: str, alpha: int = 255) -> Tuple[int, int, int, int]:
    """将 '#RRGGBB' 转换为 (R,G,B,A)"""
    h = hex_color.lstrip('#')
    if len(h) == 6:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return (r, g, b, alpha)
    return (200, 50, 50, alpha)


def _scale(value: int, ratio: float) -> int:
    """按分辨率比例缩放整数值"""
    return max(4, int(value * ratio))


# ==================== BadgeRenderer ====================

class BadgeRenderer:
    """
    角标 PNG 渲染器

    使用方式：
        renderer = BadgeRenderer()
        png_path = renderer.render(style, "热门短剧", 360, 640)
        # 返回临时 PNG 路径，由调用方 overlay 到视频后删除
    """

    def __init__(self):
        if not PIL_AVAILABLE:
            raise ImportError(
                "badge_renderer 需要 Pillow 库。请运行: pip install Pillow"
            )

    # ------------------------------------------------------------------ #
    #  公共入口
    # ------------------------------------------------------------------ #

    def render(
        self,
        style: Any,
        text: str,
        video_width: int,
        video_height: int,
        output_path: Optional[str] = None,
    ) -> str:
        """
        渲染角标为 PNG 文件。

        Args:
            style: 角标样式
            text:  显示文字（如"热门短剧"）
            video_width, video_height: 视频分辨率（用于动态缩放）
            output_path: 可选输出路径；不填则自动创建临时文件

        Returns:
            PNG 文件路径
        """
        if output_path is None:
            tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            output_path = tmp.name
            tmp.close()

        # 计算分辨率缩放比例（基于较小边 / 360）
        smaller = min(video_width, video_height)
        ratio = smaller / 360.0

        # 随机选择字体（增加视觉多样性）
        random_font_path = _pick_random_font()

        dispatch = {
            "tilted_banner":     self._render_tilted_banner,
            "tilted_text":       self._render_tilted_text,
            "horizontal_banner": self._render_horizontal_banner,
            "square_icon":       self._render_square_icon,
            "triangle_corner":   self._render_triangle_corner,
            "text_only":         self._render_text_only,
            "ink_stamp":         self._render_ink_stamp,
            "comic_text":        self._render_comic_text,
            "gradient_tilted":   self._render_gradient_tilted,
            "wave_tilted":       self._render_wave_tilted,
            "zigzag_tilted":     self._render_zigzag_tilted,
            "split_tilted":      self._render_split_tilted,
        }
        func = dispatch.get(style.shape, self._render_tilted_banner)
        func(style, text, ratio, output_path, random_font_path)

        # 给角标背景添加纹理修饰
        texture_map = {
            "tilted_banner":     "stripes",
            "tilted_text":       "stripes",
            "horizontal_banner": "stripes",
            "square_icon":       "dots",
            "triangle_corner":   "stripes",
            "text_only":         "dots",
            "ink_stamp":         None,       # 印章本身就有做旧效果
            "comic_text":        "dots",
            "gradient_tilted":   "stripes",
            "wave_tilted":       None,       # 波浪本身就是装饰
            "zigzag_tilted":     None,       # 锯齿本身就是装饰
            "split_tilted":      "stripes",
        }
        texture_type = texture_map.get(style.shape, "stripes")
        if texture_type:
            try:
                badge_img = Image.open(output_path).convert("RGBA")
                badge_img = _add_texture_to_image(badge_img, texture_type)
                badge_img.save(output_path, "PNG")
            except Exception:
                pass

        return output_path

    # ------------------------------------------------------------------ #
    #  A. 倾斜条幅 (tilted_banner)
    # ------------------------------------------------------------------ #

    def _render_tilted_banner(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """45度倾斜条幅，对齐原始 tilted_label.py 的尺寸（base 28px字体/60px条幅）"""
        canvas = 400   # 固定画布，不随分辨率变化
        # 与原始 tilted_label.py 保持一致：base 28px，scale_factor = ratio * 0.8
        scale_factor = ratio * 0.8
        font_size = int(28 * scale_factor)
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(60 * scale_factor)
        box_y = (canvas - box_h) // 2

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba   = _hex_to_rgb(style.bg_color, alpha=242)   # ~95% 透明度
        text_rgba = _hex_to_rgb(style.text_color)

        # 绘制横向色条
        draw.rectangle([0, box_y, canvas, box_y + box_h], fill=bg_rgba)

        # 描边（如果有）
        if style.border_width > 0 and style.border_color:
            bw = style.border_width
            bc = _hex_to_rgb(style.border_color)
            draw.rectangle([0, box_y - bw, canvas, box_y],           fill=bc)
            draw.rectangle([0, box_y + box_h, canvas, box_y + box_h + bw], fill=bc)

        # 文字
        font = _find_font(font_size, font_path)
        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4
        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        # 黑色阴影
        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        # 旋转 45 度（position 由调用方选择，这里统一不翻转）
        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  A2. 透明背景倾斜文字 (tilted_text)
    # ------------------------------------------------------------------ #

    def _render_tilted_text(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """带背景色条的倾斜标签，旋转45度。
        优化：从透明背景改为带色条背景，参考 tilted_banner，字体缩小。
        """
        canvas = 400
        scale_factor = ratio * 0.8
        font_size = int(22 * scale_factor)  # 从32缩小到22
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(50 * scale_factor)      # 色条高度
        box_y = (canvas - box_h) // 2

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 背景色条（使用 border_color 作为背景色）
        bg_rgba = _hex_to_rgb(style.border_color or "#CC0000", alpha=235)
        draw.rectangle([0, box_y, canvas, box_y + box_h], fill=bg_rgba)

        # 文字
        font = _find_font(font_size, font_path)
        text_rgba = _hex_to_rgb(style.text_color)

        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4

        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        # 黑色阴影
        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        # 旋转45度
        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  B. 横向标签 (horizontal_banner)
    # ------------------------------------------------------------------ #

    def _render_horizontal_banner(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """横向标签，右侧带斜切尖角"""
        font_size = _scale(18, ratio * 0.85)
        pad_x     = _scale(14, ratio)
        pad_y     = _scale(8, ratio)
        tip_w     = _scale(20, ratio)   # 尖角宽度

        font = _find_font(font_size, font_path)
        dummy_img = Image.new("RGBA", (1, 1))
        dummy_draw = ImageDraw.Draw(dummy_img)
        if font:
            bbox = dummy_draw.textbbox((0, 0), text, font=font)
            # bbox[0]/[1] 是文字的左/上偏移（ascender offset），需要纳入计算
            bx0, by0 = bbox[0], bbox[1]
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            bx0, by0 = 0, 0
            tw, th = font_size * len(text), font_size + 4

        w = tw + pad_x * 2 + tip_w
        h = th + pad_y * 2

        img  = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba   = _hex_to_rgb(style.bg_color, alpha=230)
        text_rgba = _hex_to_rgb(style.text_color)

        # 矩形主体（不含尖角区域）
        draw.rectangle([0, 0, w - tip_w, h], fill=bg_rgba)

        # 右侧斜切尖角（三角形）
        draw.polygon(
            [(w - tip_w, 0), (w, h // 2), (w - tip_w, h)],
            fill=bg_rgba
        )

        # 边框
        if style.border_width > 0 and style.border_color:
            bw = style.border_width
            bc = _hex_to_rgb(style.border_color, 220)
            draw.rectangle([0, 0, w - tip_w, h], outline=bc, width=bw)

        # 文字：修正 ascender offset 使文字真正居中
        tx = pad_x - bx0
        ty = pad_y - by0
        if style.border_width > 0 and style.border_color:
            bc = _hex_to_rgb(style.border_color)
            draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 150))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  C. 圆角方形 (square_icon)
    # ------------------------------------------------------------------ #

    def _render_square_icon(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """圆角方形，上行大字 + 下行小字（类 App 图标）
        参考截图：紧凑小图标，两行文字填满方形，背景色占比不大。
        """
        # 拆分文字（如"热门短剧" → "热门" + "短剧"）
        mid = len(text) // 2
        line1 = text[:mid]
        line2 = text[mid:]

        # 紧凑尺寸：比之前小（0.55 代替 0.9），让图标更精致
        scale = ratio * 0.55
        font_big = _find_font(_scale(28, scale), font_path)
        font_sml = _find_font(_scale(22, scale), font_path)

        # 先量文字，再根据文字大小决定 icon 尺寸
        dummy = Image.new("RGBA", (1, 1))
        dd    = ImageDraw.Draw(dummy)

        if font_big:
            bb1 = dd.textbbox((0, 0), line1, font=font_big)
            tw1, th1 = bb1[2] - bb1[0], bb1[3] - bb1[1]
            by1 = bb1[1]
        else:
            tw1, th1, by1 = _scale(28, scale) * len(line1), _scale(28, scale), 0

        if font_sml:
            bb2 = dd.textbbox((0, 0), line2, font=font_sml)
            tw2, th2 = bb2[2] - bb2[0], bb2[3] - bb2[1]
            by2 = bb2[1]
        else:
            tw2, th2, by2 = _scale(22, scale) * len(line2), _scale(22, scale), 0

        gap    = _scale(4, scale)      # 两行间距
        pad    = _scale(10, scale)     # icon 内边距
        width  = max(tw1, tw2) + pad * 2
        height = th1 + gap + th2 + pad * 2
        size   = max(width, height)    # 保持正方形
        radius = _scale(10, scale)

        img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_top    = _hex_to_rgb(style.bg_color, alpha=240)
        bg_bottom = _hex_to_rgb(style.extra.get("bg_bottom", "#1A1A1A"), alpha=240)
        text_rgba = _hex_to_rgb(style.text_color)

        # 圆角矩形整体
        draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=bg_top)

        # 下半用深色（模拟截图双色分区）
        split_y = size // 2
        draw.rectangle([0, split_y, size - 1, size - 1], fill=bg_bottom)
        # 裁掉下方两圆角之外的矩形（重新画圆角覆盖）
        draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius,
                                outline=(0, 0, 0, 0), width=0)  # noop - 用clip模拟

        # 描边
        if style.border_width > 0 and style.border_color:
            bc = _hex_to_rgb(style.border_color, 200)
            draw.rounded_rectangle(
                [0, 0, size - 1, size - 1],
                radius=radius, outline=bc, width=style.border_width
            )

        # 垂直居中两行文字
        total_h = th1 + gap + th2
        y_start = (size - total_h) // 2

        x1 = (size - tw1) // 2
        y1 = y_start - by1
        x2 = (size - tw2) // 2
        y2 = y_start + th1 + gap - by2

        shadow = (0, 0, 0, 180)
        text2_rgba = _hex_to_rgb(style.extra.get("text2_color", style.text_color))

        draw.text((x1 + 1, y1 + 1), line1, font=font_big, fill=shadow)
        draw.text((x1, y1), line1, font=font_big, fill=text_rgba)
        draw.text((x2 + 1, y2 + 1), line2, font=font_sml, fill=shadow)
        draw.text((x2, y2), line2, font=font_sml, fill=text2_rgba)

        img.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  D. 三角贴角 (triangle_corner)
    # ------------------------------------------------------------------ #

    def _render_triangle_corner(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """等腰直角三角形贴在角落，文字沿斜边排列"""
        tri_size  = _scale(100, ratio * 0.9)
        font_size = _scale(14, ratio * 0.8)
        font      = _find_font(font_size, font_path)

        img  = Image.new("RGBA", (tri_size, tri_size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba   = _hex_to_rgb(style.bg_color, alpha=230)
        text_rgba = _hex_to_rgb(style.text_color)

        # 上-左三角（左上贴角）
        draw.polygon([(0, 0), (tri_size, 0), (0, tri_size)], fill=bg_rgba)

        # 辅助底色（深色）
        if style.extra.get("aux_color"):
            aux = _hex_to_rgb(style.extra["aux_color"], 180)
            aux_size = _scale(20, ratio * 0.9)
            draw.polygon(
                [(0, 0), (aux_size, 0), (0, aux_size)],
                fill=aux
            )

        # 文字沿45度斜线排列
        if font:
            # 旋转 -45 度写文字
            txt_img = Image.new("RGBA", (tri_size * 2, tri_size * 2), (0, 0, 0, 0))
            txt_draw = ImageDraw.Draw(txt_img)
            bb = txt_draw.textbbox((0, 0), text, font=font)
            tw, th = bb[2] - bb[0], bb[3] - bb[1]
            cx = txt_img.width // 2 - tw // 2
            cy = txt_img.height // 2 - th // 2

            # 描边
            if style.border_color:
                bc = _hex_to_rgb(style.border_color)
                for dx, dy in [(-1,-1),(1,-1),(-1,1),(1,1)]:
                    txt_draw.text((cx+dx, cy+dy), text, font=font, fill=bc)
            txt_draw.text((cx, cy), text, font=font, fill=text_rgba)

            txt_rot = txt_img.rotate(-45, resample=Image.BICUBIC)
            # 粘贴到三角区域中部
            paste_x = -txt_img.width // 4
            paste_y = -txt_img.height // 4
            img.paste(txt_rot, (paste_x, paste_y), txt_rot)

        img.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  E. 纯文字描边 (text_only)
    # ------------------------------------------------------------------ #

    def _render_text_only(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """圆角胶囊标签：实色背景 + 单行文字，紧凑精致
        优化：从无背景纯描边改为带背景的胶囊形标签，参考横幅风格。
        """
        font_size = _scale(16, ratio * 0.85)  # 缩小字体
        font      = _find_font(font_size, font_path)

        dummy_img  = Image.new("RGBA", (1, 1))
        dummy_draw = ImageDraw.Draw(dummy_img)
        if font:
            bbox = dummy_draw.textbbox((0, 0), text, font=font)
            bx0, by0 = bbox[0], bbox[1]
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            bx0, by0 = 0, 0
            tw, th = font_size * len(text), font_size + 4

        pad_x = _scale(12, ratio)
        pad_y = _scale(7, ratio)
        w = tw + pad_x * 2
        h = th + pad_y * 2

        img  = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 圆角胶囊背景（border_color 作为背景色，营造实色标签感）
        bg_rgba = _hex_to_rgb(style.border_color or "#CC0000", alpha=230)
        radius = h // 2  # 完全圆角 = 胶囊形
        draw.rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=bg_rgba)

        # 文字居中
        text_rgba = _hex_to_rgb(style.text_color)
        tx = pad_x - bx0
        ty = pad_y - by0

        # 轻微阴影
        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 160))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  F. 水墨印章 (ink_stamp)
    # ------------------------------------------------------------------ #

    def _render_ink_stamp(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """水墨/印章风格 - 不规则方形背景 + 做旧文字"""
        size      = _scale(90, ratio * 0.9)
        font_size = _scale(16, ratio * 0.85)
        font      = _find_font(font_size, font_path)

        img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba   = _hex_to_rgb(style.bg_color, alpha=220)
        text_rgba = _hex_to_rgb(style.text_color)

        # 不规则正方形（用多边形模拟笔刷感）
        jitter = max(2, _scale(4, ratio))
        corners = [
            (jitter,      jitter),
            (size - jitter * 2, jitter // 2),
            (size - jitter,     size - jitter),
            (jitter // 2, size - jitter * 2),
        ]
        draw.polygon(corners, fill=bg_rgba)

        # 内部文字（分两行）
        mid = len(text) // 2
        lines = [text[:mid], text[mid:]] if len(text) >= 3 else [text]

        line_h = font_size + 2
        total_h = line_h * len(lines)
        y_start = (size - total_h) // 2

        for i, line in enumerate(lines):
            if font:
                bb = draw.textbbox((0, 0), line, font=font)
                tw = bb[2] - bb[0]
            else:
                tw = font_size * len(line)
            tx = (size - tw) // 2
            ty = y_start + i * line_h
            # 轻微阴影制造做旧感
            draw.text((tx + 1, ty + 1), line, font=font, fill=(0, 0, 0, 100))
            draw.text((tx, ty), line, font=font, fill=text_rgba)

        # 轻微高斯模糊模拟油墨渗透
        img = img.filter(ImageFilter.GaussianBlur(0.6))
        img.save(output_path, "PNG")


    # ------------------------------------------------------------------ #
    #  G. 漫画厚描边大字 (comic_text)
    # ------------------------------------------------------------------ #

    def _render_comic_text(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """紧凑圆角方块：两行文字 + 实色背景，类似 square_icon 风格。
        优化：从透明背景超大字改为带背景的紧凑方块，字体缩小。
        """
        mid = len(text) // 2
        line1 = text[:mid]
        line2 = text[mid:]

        scale = ratio * 0.6
        font_big = _find_font(_scale(20, scale), font_path)  # 从32缩小到20
        font_sml = _find_font(_scale(16, scale), font_path)  # 从32缩小到16

        dummy = Image.new("RGBA", (1, 1))
        dd    = ImageDraw.Draw(dummy)

        if font_big:
            bb1 = dd.textbbox((0, 0), line1, font=font_big)
            tw1, th1 = bb1[2] - bb1[0], bb1[3] - bb1[1]
            by1 = bb1[1]
        else:
            tw1, th1, by1 = _scale(20, scale) * len(line1), _scale(20, scale), 0

        if font_sml:
            bb2 = dd.textbbox((0, 0), line2, font=font_sml)
            tw2, th2 = bb2[2] - bb2[0], bb2[3] - bb2[1]
            by2 = bb2[1]
        else:
            tw2, th2, by2 = _scale(16, scale) * len(line2), _scale(16, scale), 0

        gap    = _scale(3, scale)
        pad    = _scale(10, scale)
        width  = max(tw1, tw2) + pad * 2
        height = th1 + gap + th2 + pad * 2
        size   = max(width, height)
        radius = _scale(8, scale)

        img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 实色背景（使用 border_color 作为主背景）
        bg_rgba = _hex_to_rgb(style.border_color or "#1A1A1A", alpha=240)
        draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=bg_rgba)

        # 描边
        if style.extra.get("icon_color"):
            border_rgba = _hex_to_rgb(style.extra["icon_color"], 200)
            draw.rounded_rectangle(
                [0, 0, size - 1, size - 1],
                radius=radius, outline=border_rgba, width=2
            )

        # 垂直居中两行文字
        total_h = th1 + gap + th2
        y_start = (size - total_h) // 2

        x1 = (size - tw1) // 2
        y1 = y_start - by1
        x2 = (size - tw2) // 2
        y2 = y_start + th1 + gap - by2

        text_rgba = _hex_to_rgb(style.text_color)
        shadow = (0, 0, 0, 180)

        draw.text((x1 + 1, y1 + 1), line1, font=font_big, fill=shadow)
        draw.text((x1, y1), line1, font=font_big, fill=text_rgba)
        draw.text((x2 + 1, y2 + 1), line2, font=font_sml, fill=shadow)
        draw.text((x2, y2), line2, font=font_sml, fill=text_rgba)

        img.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  I. 渐变色条倾斜标签 (gradient_tilted)
    # ------------------------------------------------------------------ #

    def _render_gradient_tilted(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """渐变色条倾斜标签，旋转45度，背景双色渐变"""
        canvas = 400
        scale_factor = ratio * 0.8
        font_size = int(22 * scale_factor)
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(50 * scale_factor)
        box_y = (canvas - box_h) // 2

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 渐变背景（从 border_color 到 bg_color）
        color1 = _hex_to_rgb(style.border_color or "#E84040", alpha=235)
        color2 = _hex_to_rgb(style.bg_color or "#FFD700", alpha=235)

        for y in range(box_y, box_y + box_h):
            t = (y - box_y) / box_h
            r = int(color1[0] * (1 - t) + color2[0] * t)
            g = int(color1[1] * (1 - t) + color2[1] * t)
            b = int(color1[2] * (1 - t) + color2[2] * t)
            a = int(color1[3] * (1 - t) + color2[3] * t)
            draw.line([(0, y), (canvas, y)], fill=(r, g, b, a))

        # 文字
        font = _find_font(font_size, font_path)
        text_rgba = _hex_to_rgb(style.text_color)

        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4

        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  J. 波浪边色条倾斜标签 (wave_tilted)
    # ------------------------------------------------------------------ #

    def _render_wave_tilted(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """波浪边色条倾斜标签，旋转45度，上下边缘波浪形"""
        import math
        canvas = 400
        scale_factor = ratio * 0.8
        font_size = int(22 * scale_factor)
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(50 * scale_factor)
        box_y = (canvas - box_h) // 2
        wave_amp = int(6 * scale_factor)  # 波浪振幅

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba = _hex_to_rgb(style.border_color or "#CC0000", alpha=235)

        # 画波浪色条（逐列扫描）
        for x in range(canvas):
            # 上边缘波浪
            wave_top = int(wave_amp * math.sin(x * math.pi * 6 / canvas))
            # 下边缘波浪
            wave_bot = int(wave_amp * math.sin(x * math.pi * 6 / canvas + math.pi))
            y1 = box_y + wave_top
            y2 = box_y + box_h + wave_bot
            draw.line([(x, y1), (x, y2)], fill=bg_rgba)

        # 文字
        font = _find_font(font_size, font_path)
        text_rgba = _hex_to_rgb(style.text_color)

        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4

        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  K. 锯齿边色条倾斜标签 (zigzag_tilted)
    # ------------------------------------------------------------------ #

    def _render_zigzag_tilted(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """锯齿边色条倾斜标签，旋转45度，上下边缘锯齿形"""
        canvas = 400
        scale_factor = ratio * 0.8
        font_size = int(22 * scale_factor)
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(50 * scale_factor)
        box_y = (canvas - box_h) // 2
        zigzag_h = int(5 * scale_factor)  # 锯齿高度
        zigzag_w = int(12 * scale_factor)  # 锯齿宽度

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        bg_rgba = _hex_to_rgb(style.border_color or "#CC0000", alpha=235)

        # 主体矩形
        draw.rectangle([0, box_y + zigzag_h, canvas, box_y + box_h - zigzag_h], fill=bg_rgba)

        # 上边缘锯齿
        x = 0
        while x < canvas:
            draw.polygon([
                (x, box_y + zigzag_h),
                (x + zigzag_w // 2, box_y),
                (x + zigzag_w, box_y + zigzag_h)
            ], fill=bg_rgba)
            x += zigzag_w

        # 下边缘锯齿
        x = 0
        while x < canvas:
            draw.polygon([
                (x, box_y + box_h - zigzag_h),
                (x + zigzag_w // 2, box_y + box_h),
                (x + zigzag_w, box_y + box_h - zigzag_h)
            ], fill=bg_rgba)
            x += zigzag_w

        # 文字
        font = _find_font(font_size, font_path)
        text_rgba = _hex_to_rgb(style.text_color)

        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4

        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

    # ------------------------------------------------------------------ #
    #  L. 双色拼接色条倾斜标签 (split_tilted)
    # ------------------------------------------------------------------ #

    def _render_split_tilted(
        self, style: Any, text: str, ratio: float, output_path: str, font_path: str = None
    ) -> None:
        """双色拼接色条倾斜标签，旋转45度，左右两段不同颜色"""
        canvas = 400
        scale_factor = ratio * 0.8
        font_size = int(22 * scale_factor)
        font_size = font_size if font_size % 2 == 0 else font_size + 1
        box_h = int(50 * scale_factor)
        box_y = (canvas - box_h) // 2

        img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 左半段颜色
        color1 = _hex_to_rgb(style.border_color or "#E84040", alpha=235)
        draw.rectangle([0, box_y, canvas // 2, box_y + box_h], fill=color1)

        # 右半段颜色
        color2 = _hex_to_rgb(style.bg_color or "#FFD700", alpha=235)
        draw.rectangle([canvas // 2, box_y, canvas, box_y + box_h], fill=color2)

        # 中间分界线（装饰）
        draw.line([(canvas // 2, box_y), (canvas // 2, box_y + box_h)],
                  fill=(255, 255, 255, 100), width=2)

        # 文字
        font = _find_font(font_size, font_path)
        text_rgba = _hex_to_rgb(style.text_color)

        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        else:
            tw, th = font_size * len(text), font_size + 4

        tx = (canvas - tw) // 2
        ty = box_y + (box_h - th) // 2

        draw.text((tx + 1, ty + 1), text, font=font, fill=(0, 0, 0, 200))
        draw.text((tx, ty), text, font=font, fill=text_rgba)

        img_rot = img.rotate(45, expand=False, resample=Image.BICUBIC)
        img_rot.save(output_path, "PNG")

def get_badge_overlay_position(
    png_path: str,
    video_width: int,
    video_height: int,
    position: str,
    shape: str,
    ratio: float,
) -> Tuple[int, int]:
    """
    计算角标 PNG 在视频上的 overlay 位置 (x, y)。

    对于 tilted_banner：沿用 tilted_label.py 的 canvas_half 算法
    对于其他形态：直接贴在角落，留出少量边距
    """
    margin = max(8, int(12 * ratio))

    # 获取 PNG 实际尺寸
    try:
        with Image.open(png_path) as png:
            pw, ph = png.size
    except Exception:
        pw, ph = 80, 80

    if shape in ("tilted_banner", "tilted_text", "gradient_tilted", "wave_tilted", "zigzag_tilted", "split_tilted"):
        # tilted_banner / tilted_text 画布固定 400，用 canvas_half 定位
        canvas_half = 200
        corner_offset = max(8, int(70 * ratio * 0.8))
        corner_offset = corner_offset if corner_offset % 2 == 0 else corner_offset + 1
        if position == "top-right":
            x = video_width - corner_offset - canvas_half
            y = corner_offset - canvas_half
        else:
            x = corner_offset - canvas_half
            y = corner_offset - canvas_half
    else:
        if position == "top-right":
            x = video_width - pw - margin
            y = margin
        else:
            x = margin
            y = margin

    return x, y
