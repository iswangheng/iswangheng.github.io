"""
AI训练脚本包 - AI Short Drama短剧剪辑技能训练
"""
__version__ = "1.0.0"