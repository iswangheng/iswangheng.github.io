"""
百度网盘 Cookie 认证管理

从环境变量读取 BDUSS 和 STOKEN，构建请求所需的 Cookie 和 Headers。
提供 check_login() 方法验证 Cookie 是否有效。
"""

from typing import Dict, Optional, Tuple

import requests

from scripts.baidu_pan.config import BaiduPanConfig, config as default_config


class BaiduAuth:
    """百度网盘认证管理"""

    # 用户信息接口
    USER_INFO_URL = "https://pan.baidu.com/rest/2.0/xpan/nas?method=uinfo"

    def __init__(self, cfg: Optional[BaiduPanConfig] = None):
        self.config = cfg or default_config

    def get_session(self) -> requests.Session:
        """
        创建已认证的 requests Session

        Returns:
            配置好 Cookie 和 Headers 的 Session
        """
        session = requests.Session()
        session.cookies.update(self.config.get_cookies())
        session.headers.update(self.config.get_headers())
        return session

    def check_login(self) -> Tuple[bool, Dict]:
        """
        验证 Cookie 是否有效

        Returns:
            (is_valid, user_info)
            user_info 包含 baidu_name, netdisk_name, vip_type 等
        """
        # 先检查配置
        valid, err = self.config.validate()
        if not valid:
            return False, {"error": err}

        session = self.get_session()
        try:
            resp = session.get(self.USER_INFO_URL, timeout=self.config.timeout)
            data = resp.json()

            if data.get("errno") == 0:
                return True, {
                    "baidu_name": data.get("baidu_name", ""),
                    "netdisk_name": data.get("netdisk_name", ""),
                    "vip_type": data.get("vip_type", 0),
                    "uk": data.get("uk", 0),
                }
            else:
                return False, {
                    "error": f"登录验证失败: errno={data.get('errno')}, errmsg={data.get('errmsg', '未知错误')}"
                }
        except requests.RequestException as e:
            return False, {"error": f"网络请求失败: {e}"}
