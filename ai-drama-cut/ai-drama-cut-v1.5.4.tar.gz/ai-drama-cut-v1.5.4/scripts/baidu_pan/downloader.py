"""
百度网盘短剧下载器

针对短剧素材优化的下载流程：
  1. 解析分享链接，自动识别短剧名
  2. 智能选择纯净版素材文件夹
  3. 只下载前 N 集视频（过滤图片等非视频文件）
  4. 本地目录结构：downloads/baidu/{剧名}/视频文件
"""

import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from urllib.parse import unquote

from scripts.baidu_pan.config import BaiduPanConfig, config as default_config
from scripts.baidu_pan.auth import BaiduAuth
from scripts.baidu_pan.share_parser import parse_share_url
from scripts.baidu_pan.client import BaiduPanClient

logger = logging.getLogger(__name__)

# 视频文件扩展名
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".ts", ".m4v"}

# 优先选择的文件夹关键词（按优先级从高到低）
PREFER_FOLDER_KEYWORDS = ["成片", "原版", "无水印", "素材"]

# 需要排除的文件夹关键词（去掉BGM的不是我们要的）
EXCLUDE_FOLDER_KEYWORDS = ["纯净", "无BGM", "海报", "照片", "图片"]


class BaiduPanDownloader:
    """百度网盘短剧下载器"""

    def __init__(self, cfg: Optional[BaiduPanConfig] = None):
        self.config = cfg or default_config
        self.auth = BaiduAuth(self.config)
        self.client = BaiduPanClient(self.config)
        self._login_checked = False

    def ensure_login(self) -> dict:
        """
        检查 Cookie 是否有效，无效时抛出异常。
        批量任务循环中应定期调用此方法。
        返回用户信息 dict。
        """
        is_valid, user_info = self.auth.check_login()
        if not is_valid:
            self._login_checked = False
            raise RuntimeError(f"Cookie 已失效: {user_info.get('error', '未知错误')}，请更新 BAIDU_BDUSS 和 BAIDU_STOKEN")
        self._login_checked = True
        return user_info

    def download_drama(
        self,
        share_url: str,
        pwd: str = "",
        local_dir: Optional[Union[str, Path]] = None,
        max_episodes: int = 10,
        cleanup: bool = True,
    ) -> Tuple[str, List[Path]]:
        """
        下载短剧素材（核心方法）

        自动识别剧名，选择纯净版，只下载前 N 集视频。

        Args:
            share_url: 分享链接
            pwd: 提取码
            local_dir: 本地下载根目录（默认 downloads/baidu）
            max_episodes: 最多下载几集（默认 10）
            cleanup: 下载后清理网盘转存文件

        Returns:
            (剧名, 下载的文件路径列表)
        """
        # 1. 验证登录（复用 ensure_login）
        user_info = self.ensure_login()
        logger.info(f"登录成功: {user_info.get('netdisk_name', '')}")

        # 2. 解析 + 验证
        share_info = parse_share_url(share_url, pwd)
        verify_result = self.client.verify_share(share_info.surl, share_info.pwd)
        shareid = verify_result["shareid"]
        uk = verify_result["uk"]
        sekey = unquote(verify_result["randsk"])
        logger.info("提取码验证成功")

        # 3. 获取根目录，识别剧名
        root_items = self.client.get_share_file_list(shareid, uk, recursive=False)
        drama_name, drama_path = self._detect_drama_name(root_items)
        logger.info(f"短剧名: {drama_name}")

        # 4. 选择最佳素材文件夹（优先纯净版）
        source_folder = self._select_source_folder(shareid, uk, drama_path)
        logger.info(f"素材文件夹: {source_folder}")

        # 5. 获取该文件夹下的所有文件
        all_files = self.client.get_share_file_list(shareid, uk, dir_path=source_folder, recursive=False)

        # 6. 过滤：只要视频文件
        video_files = [f for f in all_files if not f["isdir"] and self._is_video(f["name"])]
        if not video_files:
            raise RuntimeError(f"未找到视频文件: {source_folder}")
        logger.info(f"找到 {len(video_files)} 个视频文件")

        # 7. 按集数排序，取前 N 集
        video_files = self._sort_by_episode(video_files)
        selected = video_files[:max_episodes]
        total_size = sum(f["size"] for f in selected)
        logger.info(f"选取前 {len(selected)} 集, 共 {total_size / (1024 * 1024):.0f} MB")
        for f in selected:
            ep = self._extract_episode_number(f["name"])
            logger.info(f"  第{ep}集: {f['name']} ({f['size'] / (1024 * 1024):.1f} MB)")

        # 8. 检查网盘剩余空间
        try:
            quota = self.client.get_quota()
            free_mb = quota["free"] / (1024 * 1024)
            total_size_mb = total_size / (1024 * 1024)
            logger.info(f"网盘剩余空间: {free_mb:.0f} MB")
            if quota["free"] < total_size * 1.2:  # 预留 20% 余量
                raise RuntimeError(
                    f"网盘空间不足: 剩余 {free_mb:.0f} MB，需要 {total_size_mb:.0f} MB（含20%余量）"
                )
        except RuntimeError:
            raise
        except Exception as e:
            logger.warning(f"检查网盘空间失败（继续执行）: {e}")

        # 9. 准备本地目录: downloads/baidu/{剧名}/
        if local_dir is None:
            local_dir = self.config.download_dir
        else:
            local_dir = Path(local_dir)
        drama_dir = local_dir / drama_name
        drama_dir.mkdir(parents=True, exist_ok=True)

        # 9. 转存 + 下载（try/finally 确保无论成功失败都清理网盘临时文件）
        pan_sub_dir = f"{self.config.pan_dir}/{drama_name}"
        self.client.create_dir(pan_sub_dir)

        fsid_list = [f["fs_id"] for f in selected]
        self.client.transfer_files(shareid, uk, sekey, fsid_list, pan_sub_dir)

        downloaded_files = []
        try:
            # 获取转存后的 fs_id
            my_files = self.client.list_my_files(pan_sub_dir)
            my_files_map = {f["name"]: f for f in my_files if not f["isdir"]}

            # 构建待下载任务列表（跳过已完成的）
            download_tasks = []
            for idx, f in enumerate(selected):
                local_path = drama_dir / f["name"]

                if local_path.exists() and local_path.stat().st_size == f["size"]:
                    logger.info(f"[{idx + 1}/{len(selected)}] 已存在: {f['name']}")
                    downloaded_files.append(local_path)
                    continue

                my_file = my_files_map.get(f["name"])
                if not my_file:
                    logger.warning(f"[{idx + 1}/{len(selected)}] 跳过: 网盘中未找到 {f['name']}")
                    continue

                download_tasks.append((idx, f, my_file, local_path))

            # 并发下载（3 线程）
            if download_tasks:
                logger.info(f"开始并发下载 {len(download_tasks)} 个文件（3 线程）")
                with ThreadPoolExecutor(max_workers=3) as pool:
                    futures = {
                        pool.submit(self._download_single, task, len(selected)): task
                        for task in download_tasks
                    }
                    for future in as_completed(futures):
                        task = futures[future]
                        try:
                            result = future.result()
                            if result:
                                downloaded_files.append(result)
                        except Exception as e:
                            logger.error(f"下载异常: {task[1]['name']}, 错误: {e}")
        finally:
            # 无论成功失败都清理网盘临时文件，防止空间泄漏
            if cleanup:
                try:
                    paths_to_delete = [f"{pan_sub_dir}/{f['name']}" for f in selected]
                    self.client.delete_files(paths_to_delete)
                    self.client.delete_files([pan_sub_dir])
                    logger.info("网盘临时文件清理完成")
                except Exception as e:
                    logger.warning(f"清理网盘文件失败（不影响已下载内容）: {e}")

        logger.info(f"完成: {drama_name} {len(downloaded_files)}/{len(selected)} 集 → {drama_dir}")
        return drama_name, downloaded_files

    # ---- 内部方法 ----

    def _download_single(self, task: tuple, total: int) -> Optional[Path]:
        """下载单个文件（供线程池调用）"""
        idx, f, my_file, local_path = task
        size_mb = f['size'] / (1024 * 1024)
        logger.info(f"[{idx + 1}/{total}] 下载: {f['name']} ({size_mb:.1f} MB)")
        try:
            dlink = self.client.get_download_link(my_file["fs_id"])
            return self.client.download_file(dlink, local_path)
        except Exception as e:
            logger.error(f"[{idx + 1}/{total}] 下载失败: {f['name']}, {e}")
            return None

    @staticmethod
    def _clean_drama_name(raw_name: str) -> str:
        """
        清理剧名中的杂质

        《赘婿：跨年掌乾坤》(2) → 赘婿：跨年掌乾坤
        《错爱灼心》 → 错爱灼心
        复婚 → 复婚
        """
        name = raw_name.strip()
        # 去掉书名号
        name = name.replace("《", "").replace("》", "")
        # 去掉尾部的 (数字)、（数字）
        name = re.sub(r'[\(（]\d+[\)）]\s*$', '', name)
        # 去掉首尾空格
        return name.strip()

    @classmethod
    def _detect_drama_name(cls, root_items: List[Dict]) -> Tuple[str, str]:
        """
        从根目录识别短剧名

        分享根目录通常是一个以剧名命名的文件夹，如：
          /我的资源/复婚  → 剧名 "复婚"
          /解说/酒庄迷局  → 剧名 "酒庄迷局"
          /《赘婿：跨年掌乾坤》(2) → 剧名 "赘婿：跨年掌乾坤"
        """
        # 找第一个文件夹
        for item in root_items:
            if item["isdir"]:
                name = cls._clean_drama_name(item["name"])
                path = item["path"]
                return name, path

        # 没有文件夹，从文件名提取（如 "复婚1.mp4" → "复婚"）
        for item in root_items:
            name = item["name"]
            match = re.match(r'^(.+?)[\d]+\.', name)
            if match:
                return cls._clean_drama_name(match.group(1)), "/"

        raise RuntimeError("无法识别短剧名，请检查分享链接")

    def _select_source_folder(self, shareid: str, uk: str, drama_path: str) -> str:
        """
        选择最佳素材文件夹

        优先级：成片 > 原版 > 无水印 > 第一个包含视频且不在排除列表的文件夹
        排除：纯净版、无BGM（去掉背景音乐的不是我们要的）、海报/照片
        """
        sub_items = self.client.get_share_file_list(shareid, uk, dir_path=drama_path, recursive=False)

        # 收集所有子文件夹
        folders = [item for item in sub_items if item["isdir"]]

        if not folders:
            # 没有子文件夹，视频直接在 drama_path 下
            return drama_path

        # 按优先关键词匹配
        for keyword in PREFER_FOLDER_KEYWORDS:
            for folder in folders:
                if keyword in folder["name"]:
                    logger.info(f"匹配到素材文件夹: {folder['name']} (关键词: {keyword})")
                    return folder["path"]

        # 没匹配到优先关键词，选第一个包含视频且不在排除列表的文件夹
        for folder in folders:
            # 检查是否在排除列表
            excluded = any(kw in folder["name"] for kw in EXCLUDE_FOLDER_KEYWORDS)
            if excluded:
                logger.info(f"跳过文件夹: {folder['name']}（排除关键词命中）")
                continue

            sub_files = self.client.get_share_file_list(shareid, uk, dir_path=folder["path"], recursive=False)
            has_video = any(self._is_video(f["name"]) for f in sub_files if not f["isdir"])
            if has_video:
                logger.info(f"选择文件夹: {folder['name']}（第一个包含视频的文件夹）")
                return folder["path"]

        # 所有文件夹都被排除了，放宽条件：选任意包含视频的文件夹
        for folder in folders:
            sub_files = self.client.get_share_file_list(shareid, uk, dir_path=folder["path"], recursive=False)
            has_video = any(self._is_video(f["name"]) for f in sub_files if not f["isdir"])
            if has_video:
                logger.warning(f"所有文件夹都在排除列表，退而选择: {folder['name']}")
                return folder["path"]

        # 兜底：返回剧名目录本身
        return drama_path

    @staticmethod
    def _is_video(filename: str) -> bool:
        """判断是否为视频文件"""
        ext = Path(filename).suffix.lower()
        return ext in VIDEO_EXTENSIONS

    # 中文数字映射
    _CN_DIGITS = {
        "零": 0, "〇": 0,
        "一": 1, "壹": 1,
        "二": 2, "贰": 2, "两": 2,
        "三": 3, "叁": 3,
        "四": 4, "肆": 4,
        "五": 5, "伍": 5,
        "六": 6, "陆": 6,
        "七": 7, "柒": 7,
        "八": 8, "捌": 8,
        "九": 9, "玖": 9,
        "十": 10, "拾": 10,
        "百": 100,
    }

    @classmethod
    def _cn_to_int(cls, cn: str) -> int:
        """
        中文数字转阿拉伯数字

        支持：一 ~ 九百九十九
        例：十二→12, 二十→20, 一百零三→103
        """
        if not cn:
            return 9999

        result = 0
        current = 0

        for char in cn:
            val = cls._CN_DIGITS.get(char)
            if val is None:
                continue
            if val == 100:
                result += (current or 1) * 100
                current = 0
            elif val == 10:
                result += (current or 1) * 10
                current = 0
            else:
                current = val

        result += current
        return result if result > 0 else 9999

    @classmethod
    def _extract_episode_number(cls, filename: str) -> int:
        """
        从文件名提取集数

        支持格式：
          复婚1.mp4 → 1        10集.mp4 → 10
          EP01.mp4 → 1         第3集.mp4 → 3
          第一集.mp4 → 1       第十二集.mp4 → 12
          二十集.mp4 → 20      第一百零三集.mp4 → 103
        """
        name = Path(filename).stem

        # 模式1: 阿拉伯数字 — "第X集" / "EPX" / "epX"
        match = re.search(r'(?:第|EP|ep)(\d+)', name)
        if match:
            return int(match.group(1))

        # 模式2: 阿拉伯数字 — "X集"
        match = re.search(r'(\d+)集', name)
        if match:
            return int(match.group(1))

        # 模式3: 中文数字 — "第X集"（X为中文数字）
        cn_chars = "零〇一壹二贰两三叁四肆五伍六陆七柒八捌九玖十拾百"
        match = re.search(r'第([' + cn_chars + r']+)集', name)
        if match:
            return cls._cn_to_int(match.group(1))

        # 模式4: 中文数字 — "X集"（X为中文数字）
        match = re.search(r'([' + cn_chars + r']+)集', name)
        if match:
            return cls._cn_to_int(match.group(1))

        # 模式5: 文件名末尾的阿拉伯数字（如 "复婚10"）
        match = re.search(r'(\d+)\s*$', name)
        if match:
            return int(match.group(1))

        # 模式6: 文件名中任意位置的阿拉伯数字
        match = re.search(r'(\d+)', name)
        if match:
            return int(match.group(1))

        return 9999  # 无法识别的排最后

    @classmethod
    def _sort_by_episode(cls, files: List[Dict]) -> List[Dict]:
        """按集数排序"""
        return sorted(files, key=lambda f: cls._extract_episode_number(f["name"]))
