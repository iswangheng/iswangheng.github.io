"""
百度网盘分享链接解析

支持多种链接格式：
  - https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA?pwd=7csm
  - https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA + 提取码 7csm
"""

import re
from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs


@dataclass
class ShareInfo:
    """分享链接解析结果"""
    surl: str       # 短链标识（去掉开头的 '1'）
    pwd: str        # 提取码
    raw_url: str    # 原始链接


def parse_share_url(url: str, pwd: str = "") -> ShareInfo:
    """
    解析百度网盘分享链接

    Args:
        url: 分享链接
        pwd: 提取码（如果链接中没有 pwd 参数则必须提供）

    Returns:
        ShareInfo 结构化数据

    Raises:
        ValueError: 链接格式不正确
    """
    url = url.strip()

    # 从 URL 中提取 surl
    # 格式: https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA
    match = re.search(r"pan\.baidu\.com/s/([a-zA-Z0-9_-]+)", url)
    if not match:
        raise ValueError(f"无法识别的分享链接格式: {url}")

    surl_full = match.group(1)

    # surl 去掉开头的 '1'（百度接口要求）
    if surl_full.startswith("1"):
        surl = surl_full[1:]
    else:
        surl = surl_full

    # 从 URL 参数中提取 pwd
    if not pwd:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        pwd_list = params.get("pwd", [])
        if pwd_list:
            pwd = pwd_list[0]

    if not pwd:
        raise ValueError("缺少提取码，请通过 pwd 参数提供")

    return ShareInfo(surl=surl, pwd=pwd, raw_url=url)
