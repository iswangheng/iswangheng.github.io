"""
百度网盘配置管理

环境变量：
  BAIDU_BDUSS - 百度通行证 Cookie（必需）
  BAIDU_STOKEN - 安全令牌 Cookie（必需）
  BAIDU_PAN_DIR - 网盘转存目录（默认 /AI-Drama-Downloads）
  BAIDU_DOWNLOAD_DIR - 本地下载目录（默认 downloads/baidu）
"""

import os
from pathlib import Path
from typing import Dict, Tuple

from dotenv import load_dotenv

# 自动加载项目根目录的 .env 文件
load_dotenv(Path(__file__).parent.parent.parent / ".env")


class BaiduPanConfig:
    """百度网盘配置"""

    def __init__(self):
        # Cookie 认证（必需）
        self.bduss = os.getenv("BAIDU_BDUSS", "")
        self.stoken = os.getenv("BAIDU_STOKEN", "")

        # 网盘转存目录
        self.pan_dir = os.getenv("BAIDU_PAN_DIR", "/AI-Drama-Downloads")

        # 本地下载目录
        download_dir = os.getenv("BAIDU_DOWNLOAD_DIR", "downloads/baidu")
        self.download_dir = Path(download_dir)

        # User-Agent（模拟浏览器）
        self.user_agent = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )

        # 请求超时（秒）
        self.timeout = 30

        # 下载分块大小（8MB）
        self.chunk_size = 8 * 1024 * 1024

    def validate(self) -> Tuple[bool, str]:
        """
        验证配置是否完整

        Returns:
            (is_valid, error_message)
        """
        if not self.bduss:
            return False, "缺少环境变量 BAIDU_BDUSS"

        if not self.stoken:
            return False, "缺少环境变量 BAIDU_STOKEN"

        return True, ""

    def get_cookies(self) -> Dict[str, str]:
        """获取 Cookie 字典"""
        return {
            "BDUSS": self.bduss,
            "STOKEN": self.stoken,
        }

    def get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        return {
            "User-Agent": self.user_agent,
            "Referer": "https://pan.baidu.com/",
        }


# 全局配置实例
config = BaiduPanConfig()
