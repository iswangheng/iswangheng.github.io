# 百度网盘下载模块

独立模块，通过百度网盘 Web 接口实现分享链接下载。

## 功能特性

- ✅ 分享链接解析（支持多种格式）
- ✅ Cookie 认证（BDUSS + STOKEN）
- ✅ 自动转存到网盘
- ✅ 流式下载到本地
- ✅ 断点续传支持
- ✅ 进度回调
- 🔄 网盘文件清理（TODO）

## 环境配置

### 1. 获取百度网盘 Cookie

1. 登录 [pan.baidu.com](https://pan.baidu.com)
2. 打开浏览器开发者工具（F12）
3. 切换到 Application → Cookies → https://pan.baidu.com
4. 复制 `BDUSS` 和 `STOKEN` 的值

### 2. 配置环境变量

在项目根目录的 `.env` 文件中添加：

```bash
# 百度网盘 Cookie（必需）
BAIDU_BDUSS=你的BDUSS值
BAIDU_STOKEN=你的STOKEN值

# 可选配置
BAIDU_PAN_DIR=/AI-Drama-Downloads        # 网盘转存目录
BAIDU_DOWNLOAD_DIR=downloads/baidu       # 本地下载目录
```

## 使用方式

### 命令行测试

```bash
# 基本用法（链接中包含提取码）
python test/test_baidu_pan_demo.py \
    "https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA?pwd=7csm"

# 分开传提取码
python test/test_baidu_pan_demo.py \
    "https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA" \
    --pwd 7csm

# 指定下载目录
python test/test_baidu_pan_demo.py \
    "https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA?pwd=7csm" \
    --output "downloads/my_drama"

# 下载完成后清理网盘（TODO）
python test/test_baidu_pan_demo.py \
    "https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA?pwd=7csm" \
    --cleanup
```

### Python API

```python
from scripts.baidu_pan import BaiduPanDownloader

# 创建下载器
downloader = BaiduPanDownloader()

# 下载分享链接
downloaded_files = downloader.download_share(
    share_url="https://pan.baidu.com/s/1JlYrAolAV2wpT0NuvaPnMA?pwd=7csm",
    pwd="7csm",  # 可选，如果链接中没有
    local_dir="downloads/baidu",  # 可选，默认使用配置
    cleanup=False,  # 可选，下载后是否清理网盘
)

print(f"下载完成: {len(downloaded_files)} 个文件")
for f in downloaded_files:
    print(f"  - {f}")
```

## 工作流程

1. **验证登录** - 检查 Cookie 是否有效
2. **解析链接** - 提取 surl 和提取码
3. **验证提取码** - 获取 shareid、uk、randsk
4. **获取文件列表** - 列出分享中的所有文件
5. **转存到网盘** - 将文件转存到自己的网盘
6. **下载到本地** - 逐个下载文件到本地目录
7. **清理网盘** - （可选）删除转存的文件

## 技术架构

```
scripts/baidu_pan/
├── __init__.py          # 模块入口
├── config.py            # 配置管理（环境变量）
├── auth.py              # Cookie 认证
├── share_parser.py      # 分享链接解析
├── client.py            # HTTP 客户端（封装百度网盘接口）
└── downloader.py        # 主流程编排
```

**隔离设计**：所有 HTTP 请求都通过 `client.py` 发出。后续切换到百度官方 API 时，只需替换 `client.py` 的实现，其他模块无需修改。

## 注意事项

### 限制

- **下载速度**：普通用户限速 ~200KB/s，SVIP 满速
- **dlink 有效期**：8 小时
- **大文件**：>50MB 必须通过 dlink 下载

### Cookie 安全

- Cookie 包含账号权限，请勿泄露
- 建议使用环境变量，不要硬编码在代码中
- `.env` 文件已在 `.gitignore` 中，不会提交到 Git

### 错误处理

常见错误：

- `缺少环境变量 BAIDU_BDUSS` - 未配置 Cookie
- `登录验证失败` - Cookie 已过期或无效
- `提取码验证失败` - 提取码错误或链接已失效
- `转存失败: errno=12` - 文件已存在（不算错误）

## 后续优化

- [ ] 支持文件夹递归下载
- [ ] 网盘文件清理接口
- [ ] 下载进度条（tqdm）
- [ ] 多线程并发下载
- [ ] 官方 API 支持（需申请开发者权限）
- [ ] 自动刷新 Cookie

## 相关文档

- [百度网盘 Web 接口文档](https://github.com/iikira/BaiduPCS-Go/wiki)
- [百度网盘开放平台](https://pan.baidu.com/union/doc/)
