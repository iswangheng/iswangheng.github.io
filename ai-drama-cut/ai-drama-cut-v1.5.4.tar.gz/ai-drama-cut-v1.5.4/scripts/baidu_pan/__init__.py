"""
百度网盘短剧下载模块

独立模块，通过百度网盘 Web 接口实现：
  分享链接验证 → 自动识别剧名 → 选择纯净版 → 下载前N集视频

使用方式：
    from scripts.baidu_pan import BaiduPanDownloader
    downloader = BaiduPanDownloader()
    drama_name, files = downloader.download_drama("https://pan.baidu.com/s/xxx?pwd=xxxx")
"""

from scripts.baidu_pan.downloader import BaiduPanDownloader
from scripts.baidu_pan.share_parser import ShareInfo, parse_share_url

__all__ = ["BaiduPanDownloader", "ShareInfo", "parse_share_url"]
