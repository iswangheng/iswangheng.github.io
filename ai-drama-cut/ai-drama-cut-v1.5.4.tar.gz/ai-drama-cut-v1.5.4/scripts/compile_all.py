#!/usr/bin/env python3
"""
完全编译保护 - 所有 Python 代码都编译
使用方法: python scripts/compile_all.py
编译后：
- 所有核心算法 → .so 文件（无法逆向）
- 所有工具脚本 → .so 文件（无法逆向）
- 入口脚本 → 保留源码（简单的流程编排）
"""
import os
import shutil
import subprocess
from pathlib import Path
from typing import List

# 完全编译：所有脚本模块（除了入口）
ALL_MODULES = [
    # 核心分析模块
    "scripts/understand/analyze_segment.py",
    "scripts/understand/generate_clips.py",
    "scripts/understand/quality_filter.py",
    "scripts/understand/smart_cut_finder.py",
    "scripts/understand/video_understand.py",
    "scripts/understand/understand_skill.py",
    "scripts/understand/render_clips.py",

    # 视频叠加模块
    "scripts/understand/video_overlay/__init__.py",
    "scripts/understand/video_overlay/overlay_styles.py",
    "scripts/understand/video_overlay/tilted_label.py",
    "scripts/understand/video_overlay/video_overlay.py",

    # 预处理模块
    "scripts/preprocess/__init__.py",
    "scripts/preprocess/sensitive_mask_workflow.py",
    "scripts/preprocess/ocr_subtitle.py",
    "scripts/preprocess/sensitive_detector.py",
    "scripts/preprocess/subtitle_detector.py",
    "scripts/preprocess/video_cleaner.py",

    # 数据处理模块
    "scripts/data_models.py",
    "scripts/config.py",

    # 视频处理工具
    "scripts/extract_keyframes.py",
    "scripts/extract_asr.py",
    "scripts/detect_ending_credits.py",
    "scripts/asr_analyzer.py",

    # 工具模块
    "scripts/log_config.py",
    "scripts/manage_version.py",
    "scripts/remote_update.py",
]

# 保留源码的入口脚本（只是流程编排，不包含核心算法）
ENTRY_POINTS = [
    "openclaw/skill.py",      # OpenClaw 入口
    "openclaw/runtime.py",    # 运行时工具
]

PROJECT_ROOT = Path(__file__).parent.parent


def create_setup_py():
    """创建 Cython 编译配置"""
    setup_content = '''"""
完全编译配置 - 所有模块都编译
"""
from setuptools import setup, Extension
from Cython.Build import cythonize
import os

extensions = [
'''

    # 添加每个模块的 Extension
    for module_path in ALL_MODULES:
        module_path = Path(module_path)
        module_name = str(module_path.with_suffix('')).replace('/', '.')
        setup_content += f'    Extension("{module_name}", ["{module_path}"], include_dirs=["."]),\n'

    setup_content += ''']

setup(
    name="ai-drama-cut-protected",
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            'language_level': "3",
            'embedsignature': False,      # 不嵌入函数签名
            'emit_code_comments': False,  # 不生成代码注释
        },
        annotate=False,
    ),
)
'''
    setup_path = PROJECT_ROOT / "setup_cython_all.py"
    setup_path.write_text(setup_content, encoding='utf-8')
    return setup_path


def backup_source_files():
    """备份所有源代码"""
    print("📦 备份所有源代码...")
    backup_dir = PROJECT_ROOT / ".source_backup"
    backup_dir.mkdir(exist_ok=True)

    for module_path in ALL_MODULES:
        src = PROJECT_ROOT / module_path
        if src.exists():
            # 保持目录结构
            dest = backup_dir / module_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)

    print(f"  ✓ 备份到: {backup_dir.relative_to(PROJECT_ROOT)}")


def compile_all_modules():
    """编译所有模块"""
    print("\n🔨 开始完全编译...")

    setup_path = create_setup_py()
    print(f"  ✓ 生成编译配置")

    cmd = ["python3", "setup_cython_all.py", "build_ext", "--inplace"]
    print(f"  ▶ 执行编译...")

    result = subprocess.run(
        cmd,
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"  ❌ 编译失败:")
        print(result.stderr)
        raise RuntimeError("编译失败")

    print("  ✓ 编译成功")

    # 清理
    build_dir = PROJECT_ROOT / "build"
    if build_dir.exists():
        shutil.rmtree(build_dir)
    setup_path.unlink()

    # 删除 .c 文件
    for module_path in ALL_MODULES:
        c_file = PROJECT_ROOT / module_path.replace('.py', '.c')
        if c_file.exists():
            c_file.unlink()


def remove_all_source_files():
    """删除所有 .py 文件"""
    print("\n🗑️  删除所有源代码...")

    for module_path in ALL_MODULES:
        src = PROJECT_ROOT / module_path
        if src.exists():
            src.unlink()
            print(f"  ✓ 删除: {module_path}")


def verify_compiled():
    """验证编译结果"""
    print("\n✅ 验证编译结果...")

    for module_path in ALL_MODULES:
        module_path = Path(module_path)

        # 检查编译产物（支持多种命名格式）
        base_path = PROJECT_ROOT / str(module_path).replace('.py', '')

        # 可能的编译产物名称
        # macOS Cython 命名格式: analyze_segment.cpython-310-darwin.so

        # 检查是否存在（使用 glob 模式匹配）
        found = False
        for name_pattern in [base_path.parent / f"{base_path.name}*.so",
                            base_path.parent / f"{base_path.name}*.dylib"]:
            matches = list(PROJECT_ROOT.glob(str(name_pattern)))
            if matches:
                found = True
                break

        if not found:
            print(f"  ❌ 缺少编译产物: {module_path}")
            return False

    print("  ✓ 所有模块已编译")

    # 统计
    so_count = len(list(PROJECT_ROOT.rglob("*.so")))
    dylib_count = len(list(PROJECT_ROOT.rglob("*.dylib")))
    py_count = len(ALL_MODULES)

    print(f"\n📊 编译统计:")
    print(f"  - 原始 .py 文件: {py_count}")
    print(f"  - 编译后 .so: {so_count}")
    print(f"  - 编译后 .dylib: {dylib_count}")

    return True


def show_protection_level():
    """展示保护级别"""
    print("\n" + "=" * 60)
    print("🔒 完全编译保护级别")
    print("=" * 60)

    print("\n✅ 已编译（无法逆向）:")
    print("  • AI 分析算法 (analyze_segment.so)")
    print("  • 剪辑组合逻辑 (generate_clips.so)")
    print("  • 质量筛选规则 (quality_filter.so)")
    print("  • 视频叠加算法 (video_overlay/*.so)")
    print("  • 预处理模块 (preprocess/*.so)")
    print("  • 配置和工具 (config.so, log_config.so)")
    print("  • 所有数据处理逻辑")

    print("\n⚪  保留源码（简单入口）:")
    for entry in ENTRY_POINTS:
        print(f"  • {entry}")

    print("\n🛡️  保护强度:")
    print("  • 核心算法: C 级别机器码，无法还原为 Python")
    print("  • AI Prompt: 混淆在二进制中，无法提取")
    print("  • 数据结构: 编译后类型信息丢失")
    print("  • 函数逻辑: 需要汇编级逆向工程")

    print("\n⚠️  用户无法看到:")
    print("  • AI 分析 Prompt")
    print("  • 高光点/钩子点识别算法")
    print("  • 质量筛选阈值和规则")
    print("  • 花字叠加实现细节")
    print("  • 敏感词检测逻辑")


def main():
    """主流程"""
    print("=" * 60)
    print("AI Drama Cut - 完全编译保护")
    print("=" * 60)

    try:
        backup_source_files()
        compile_all_modules()
        remove_all_source_files()

        if verify_compiled():
            show_protection_level()

            print("\n" + "=" * 60)
            print("✅ 完全编译完成！")
            print("=" * 60)
            print("\n💡 恢复源代码:")
            print("  python scripts/restore_all_source.py")
            print("\n📦 打包发布:")
            print("  bash openclaw/package.sh")

        else:
            print("\n❌ 验证失败")
            return 1

    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main() or 0)
