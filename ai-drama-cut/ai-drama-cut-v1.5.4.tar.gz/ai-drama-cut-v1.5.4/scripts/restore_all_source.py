#!/usr/bin/env python3
"""
恢复所有源代码
使用方法: python scripts/restore_all_source.py
"""
import shutil
from pathlib import Path

ALL_MODULES = [
    "scripts/understand/analyze_segment.py",
    "scripts/understand/generate_clips.py",
    "scripts/understand/quality_filter.py",
    "scripts/understand/extract_segments.py",
    "scripts/understand/smart_cut_finder.py",
    "scripts/understand/video_understand.py",
    "scripts/understand/understand_skill.py",
    "scripts/understand/render_clips.py",
    "scripts/understand/video_overlay/__init__.py",
    "scripts/understand/video_overlay/overlay_styles.py",
    "scripts/understand/video_overlay/tilted_label.py",
    "scripts/understand/video_overlay/video_overlay.py",
    "scripts/preprocess/__init__.py",
    "scripts/preprocess/sensitive_mask_workflow.py",
    "scripts/preprocess/ocr_subtitle.py",
    "scripts/preprocess/sensitive_detector.py",
    "scripts/preprocess/subtitle_detector.py",
    "scripts/preprocess/video_cleaner.py",
    "scripts/dataclasses.py",
    "scripts/config.py",
    "scripts/extract_keyframes.py",
    "scripts/extract_asr.py",
    "scripts/detect_ending_credits.py",
    "scripts/asr_analyzer.py",
    "scripts/log_config.py",
    "scripts/manage_version.py",
    "scripts/remote_update.py",
    "scripts/read_excel.py",
    "scripts/check_dependencies.py",
]

PROJECT_ROOT = Path(__file__).parent.parent


def restore_all():
    """从备份恢复所有源代码"""
    print("🔄 恢复所有源代码...")

    backup_dir = PROJECT_ROOT / ".source_backup"

    if not backup_dir.exists():
        print(f"  ❌ 备份目录不存在: {backup_dir}")
        return False

    restored_count = 0
    for module_path in ALL_MODULES:
        src = PROJECT_ROOT / module_path
        backup = backup_dir / module_path

        if not backup.exists():
            print(f"  ⚠️  备份不存在: {module_path}")
            continue

        # 删除编译产物
        so_file = src.with_suffix('.so')
        dylib_file = src.with_suffix('.dylib')
        if so_file.exists():
            so_file.unlink()
        if dylib_file.exists():
            dylib_file.unlink()

        # 恢复源代码
        src.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup, src)
        print(f"  ✓ 恢复: {module_path}")
        restored_count += 1

    print(f"\n✅ 成功恢复 {restored_count} 个文件")
    print("\n💡 提示: 所有源代码已恢复，可以正常开发")

    return True


if __name__ == "__main__":
    restore_all()
