#!/usr/bin/env python3
"""
编译核心模块为 Cython 扩展
使用方法: python scripts/compile_core.py
编译后的 .so 文件无法逆向（C 级别）
"""
import os
import shutil
import subprocess
from pathlib import Path
from typing import List

# 需要编译的核心模块（商业机密）
CORE_MODULES = [
    "scripts/understand/analyze_segment.py",
    "scripts/understand/generate_clips.py",
    "scripts/understand/quality_filter.py",
    "scripts/understand/extract_segments.py",
    "scripts/understand/smart_cut_finder.py",
    "scripts/understand/video_overlay/__init__.py",
    "scripts/understand/video_overlay/overlay_styles.py",
    "scripts/understand/video_overlay/tilted_label.py",
    "scripts/understand/video_overlay/video_overlay.py",
    "scripts/preprocess/sensitive_mask_workflow.py",
    "scripts/preprocess/ocr_subtitle.py",
    "scripts/preprocess/sensitive_detector.py",
    "scripts/preprocess/subtitle_detector.py",
    "scripts/preprocess/video_cleaner.py",
]

PROJECT_ROOT = Path(__file__).parent.parent


def create_setup_py():
    """创建 Cython 编译配置"""
    setup_content = '''"""
Cython 编译配置
自动生成，不要手动修改
"""
from setuptools import setup, Extension
from Cython.Build import cythonize
import os

# 需要编译的模块
extensions = [
'''

    # 添加每个模块的 Extension
    for module_path in CORE_MODULES:
        module_path = Path(module_path)
        module_name = str(module_path.with_suffix('')).replace('/', '.')
        setup_content += f'    Extension("{module_name}", ["{module_path}"], include_dirs=["."]),\n'

    setup_content += ''']

# 编译配置
setup(
    name="ai-drama-cut-core",
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            'language_level': "3",
            'embedsignature': False,  # 不嵌入函数签名（逆向更难）
            'emit_code_comments': False,  # 不生成代码注释
        },
        annotate=False,  # 不生成 HTML 注释文件
    ),
)
'''
    setup_path = PROJECT_ROOT / "setup_cython.py"
    setup_path.write_text(setup_content, encoding='utf-8')
    return setup_path


def backup_source_files():
    """备份源代码到 .orig 文件"""
    print("📦 备份源代码...")
    for module_path in CORE_MODULES:
        src = PROJECT_ROOT / module_path
        if src.exists():
            backup = src.with_suffix(src.suffix + '.orig')
            shutil.copy2(src, backup)
            print(f"  ✓ 备份: {module_path}")


def compile_modules():
    """执行 Cython 编译"""
    print("\n🔨 开始编译核心模块...")

    # 创建 setup.py
    setup_path = create_setup_py()
    print(f"  ✓ 生成编译配置: {setup_path.relative_to(PROJECT_ROOT)}")

    # 执行编译
    cmd = [
        "python3",
        "setup_cython.py",
        "build_ext",
        "--inplace",
    ]

    print(f"  ▶ 执行编译命令...")
    result = subprocess.run(
        cmd,
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"  ❌ 编译失败:")
        print(result.stderr)
        raise RuntimeError("Cython 编译失败")

    print("  ✓ 编译成功")

    # 清理
    print("\n🧹 清理临时文件...")
    build_dir = PROJECT_ROOT / "build"
    if build_dir.exists():
        shutil.rmtree(build_dir)
        print("  ✓ 删除 build/")

    setup_path.unlink()
    print("  ✓ 删除 setup_cython.py")


def remove_source_files():
    """删除原始 .py 文件（保留 .orig 备份）"""
    print("\n🗑️  删除原始源代码...")
    for module_path in CORE_MODULES:
        src = PROJECT_ROOT / module_path
        if src.exists():
            src.unlink()
            print(f"  ✓ 删除: {module_path}")

    # 删除生成的 .c 文件（Cython 中间产物）
    for module_path in CORE_MODULES:
        c_file = PROJECT_ROOT / module_path.replace('.py', '.c')
        if c_file.exists():
            c_file.unlink()
            print(f"  ✓ 删除: {c_file.relative_to(PROJECT_ROOT)}")


def verify_compiled_modules():
    """验证编译后的模块"""
    print("\n✅ 验证编译结果...")

    for module_path in CORE_MODULES:
        module_path = Path(module_path)
        so_file = PROJECT_ROOT / str(module_path).replace('.py', '.so')

        if not so_file.exists():
            # macOS 可能是 .dylib
            dylib_file = PROJECT_ROOT / str(module_path).replace('.py', '.dylib')
            if not dylib_file.exists():
                print(f"  ❌ 编译产物未找到: {module_path}")
                return False

        print(f"  ✓ {so_file.name if so_file.exists() else dylib_file.name}")

    return True


def main():
    """主流程"""
    print("=" * 60)
    print("AI Drama Cut - 核心模块编译保护")
    print("=" * 60)

    try:
        # 1. 备份源代码
        backup_source_files()

        # 2. 编译
        compile_modules()

        # 3. 删除源代码
        remove_source_files()

        # 4. 验证
        if verify_compiled_modules():
            print("\n" + "=" * 60)
            print("✅ 编译完成！核心模块已保护")
            print("=" * 60)
            print("\n📝 提示:")
            print("  - 源代码已备份为 *.orig 文件")
            print("  - 编译后的 .so 文件无法逆向")
            print("  - import 语句不需要修改，Python 会自动加载 .so")
            print("\n⚠️  注意:")
            print("  - .so 文件与平台和 Python 版本绑定")
            print("  - 需要为不同平台分别编译")
            print("  - 运行 'python scripts/compile_core.py' 恢复源码")

        else:
            print("\n❌ 验证失败，请检查编译结果")
            return 1

    except Exception as e:
        print(f"\n❌ 错误: {e}")
        return 1


if __name__ == "__main__":
    exit(main() or 0)
