#!/usr/bin/env python3
"""
批量处理编排器 - V19

支持多部剧同时处理完整流程（理解 + 渲染），M1 Pro 16GB 建议最多 2 并发。

使用方式:
    # 处理多部剧（2并发）
    python -m scripts.batch_process \
        "漫剧素材/百里将就" \
        "漫剧素材/烈日重生" \
        --max-concurrent 2

    # 带敏感词预处理
    python -m scripts.batch_process \
        "漫剧素材/百里将就" \
        --preprocess

    # 仅渲染（跳过理解阶段）
    python -m scripts.batch_process \
        "漫剧素材/百里将就" \
        --render-only

    # 仅理解（跳过渲染阶段）
    python -m scripts.batch_process \
        "漫剧素材/百里将就" \
        --understand-only
"""
import subprocess
import time
import sys
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime


def process_single_project(
    project_path: str,
    preprocess: bool = False,
    understand: bool = True,
    render: bool = True,
    add_ending: bool = True,
    add_overlay: bool = True,
    compress: bool = True,
    compress_target: int = 100,
) -> dict:
    """处理单个项目的完整流程

    Args:
        project_path: 项目路径（如 "漫剧素材/百里将就"）
        preprocess: 是否执行敏感词预处理
        understand: 是否执行视频理解
        render: 是否执行渲染
        add_ending: 是否添加片尾
        add_overlay: 是否添加花字
        compress: 是否压缩
        compress_target: 压缩目标MB

    Returns:
        处理结果字典
    """
    project_name = Path(project_path).name
    result = {
        'project': project_name,
        'path': project_path,
        'stages': {},
        'success': True,
        'total_elapsed': 0,
    }

    total_start = time.time()

    # 阶段1: 敏感词预处理
    if preprocess:
        stage_start = time.time()
        print(f"[{project_name}] 阶段1: 敏感词预处理...")
        cmd = [
            sys.executable, '-m',
            'scripts.preprocess.sensitive_mask_workflow',
            project_path, '--skip-existing'
        ]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=3600
            )
            elapsed = time.time() - stage_start
            result['stages']['preprocess'] = {
                'success': proc.returncode == 0,
                'elapsed': elapsed,
                'error': proc.stderr[-300:] if proc.returncode != 0 else None
            }
            if proc.returncode != 0:
                print(f"[{project_name}] ❌ 预处理失败: {proc.stderr[-200:]}")
                result['success'] = False
                result['total_elapsed'] = time.time() - total_start
                return result
            print(f"[{project_name}] ✅ 预处理完成 ({elapsed:.0f}秒)")
        except subprocess.TimeoutExpired:
            result['stages']['preprocess'] = {
                'success': False, 'error': '超时(1小时)'
            }
            result['success'] = False
            result['total_elapsed'] = time.time() - total_start
            return result

    # 阶段2: 视频理解
    if understand:
        stage_start = time.time()
        print(f"[{project_name}] 阶段2: 视频理解...")
        cmd = [
            sys.executable, '-m',
            'scripts.understand.video_understand',
            project_path
        ]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=7200
            )
            elapsed = time.time() - stage_start
            result['stages']['understand'] = {
                'success': proc.returncode == 0,
                'elapsed': elapsed,
                'error': proc.stderr[-300:] if proc.returncode != 0 else None
            }
            if proc.returncode != 0:
                print(f"[{project_name}] ❌ 理解失败: {proc.stderr[-200:]}")
                result['success'] = False
                result['total_elapsed'] = time.time() - total_start
                return result
            print(f"[{project_name}] ✅ 理解完成 ({elapsed:.0f}秒)")
        except subprocess.TimeoutExpired:
            result['stages']['understand'] = {
                'success': False, 'error': '超时(2小时)'
            }
            result['success'] = False
            result['total_elapsed'] = time.time() - total_start
            return result

    # 阶段3: 渲染
    if render:
        stage_start = time.time()
        analysis_path = f"data/analysis/{project_name}"
        if not Path(analysis_path).exists():
            result['stages']['render'] = {
                'success': False,
                'error': f'分析结果不存在: {analysis_path}'
            }
            result['success'] = False
            result['total_elapsed'] = time.time() - total_start
            return result

        print(f"[{project_name}] 阶段3: 渲染剪辑...")
        cmd = [
            sys.executable, '-m',
            'scripts.understand.render_clips',
            analysis_path, project_path,
        ]
        if add_ending:
            cmd.append('--add-ending')
        else:
            cmd.append('--no-ending')
        if not add_overlay:
            cmd.append('--no-overlay')
        if compress:
            cmd.extend(['--compress-target', str(compress_target)])
        else:
            cmd.append('--no-compress')

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=7200
            )
            elapsed = time.time() - stage_start
            result['stages']['render'] = {
                'success': proc.returncode == 0,
                'elapsed': elapsed,
                'error': proc.stderr[-300:] if proc.returncode != 0 else None
            }
            if proc.returncode != 0:
                print(f"[{project_name}] ❌ 渲染失败: {proc.stderr[-200:]}")
                result['success'] = False
            else:
                print(f"[{project_name}] ✅ 渲染完成 ({elapsed:.0f}秒)")
        except subprocess.TimeoutExpired:
            result['stages']['render'] = {
                'success': False, 'error': '超时(2小时)'
            }
            result['success'] = False

    result['total_elapsed'] = time.time() - total_start
    return result


def batch_process(
    projects: list,
    max_concurrent: int = 2,
    preprocess: bool = False,
    understand: bool = True,
    render: bool = True,
    add_ending: bool = True,
    add_overlay: bool = True,
    compress: bool = True,
    compress_target: int = 100,
) -> dict:
    """批量处理多个项目（支持并发）

    Args:
        projects: 项目路径列表
        max_concurrent: 最大并发数（M1 Pro 16GB 建议2）
        其他参数同 process_single_project

    Returns:
        批量处理结果
    """
    total_start = time.time()

    print(f"\n{'='*60}")
    print(f"批量处理编排器 - V19")
    print(f"{'='*60}")
    print(f"项目数量: {len(projects)}")
    print(f"最大并发: {max_concurrent}")
    print(f"流程: {'预处理→' if preprocess else ''}{'理解→' if understand else ''}{'渲染' if render else ''}")
    print(f"开始时间: {datetime.now().strftime('%H:%M:%S')}")
    print(f"{'='*60}\n")

    results = []

    if max_concurrent <= 1:
        # 串行处理
        for i, project in enumerate(projects, 1):
            print(f"\n[{i}/{len(projects)}] 处理: {project}")
            result = process_single_project(
                project, preprocess=preprocess,
                understand=understand, render=render,
                add_ending=add_ending, add_overlay=add_overlay,
                compress=compress, compress_target=compress_target,
            )
            results.append(result)
    else:
        # 并发处理
        with ProcessPoolExecutor(max_workers=max_concurrent) as executor:
            futures = {
                executor.submit(
                    process_single_project, project,
                    preprocess, understand, render,
                    add_ending, add_overlay, compress, compress_target,
                ): project
                for project in projects
            }

            for future in as_completed(futures):
                project = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                    status = "✅" if result['success'] else "❌"
                    elapsed = result.get('total_elapsed', 0)
                    print(f"\n{status} {result['project']} 完成 ({elapsed:.0f}秒)")
                except Exception as e:
                    results.append({
                        'project': Path(project).name,
                        'success': False,
                        'error': str(e),
                        'total_elapsed': 0,
                    })
                    print(f"\n❌ {project} 异常: {e}")

    # 汇总
    total_elapsed = time.time() - total_start
    success_count = sum(1 for r in results if r.get('success'))

    print(f"\n\n{'='*60}")
    print(f"批量处理完成")
    print(f"{'='*60}")
    print(f"成功: {success_count}/{len(projects)}")
    print(f"总耗时: {total_elapsed:.0f}秒 ({total_elapsed/60:.1f}分钟)")

    if success_count > 0:
        avg = sum(r.get('total_elapsed', 0) for r in results if r.get('success')) / success_count
        print(f"平均耗时: {avg:.0f}秒/部 ({avg/60:.1f}分钟/部)")
        throughput = success_count / (total_elapsed / 3600) if total_elapsed > 0 else 0
        print(f"吞吐量: {throughput:.1f} 部/小时")

    if success_count < len(projects):
        print(f"\n失败项目:")
        for r in results:
            if not r.get('success'):
                err = r.get('error', '未知')
                stages = r.get('stages', {})
                for stage, info in stages.items():
                    if not info.get('success'):
                        err = f"{stage}: {info.get('error', '未知')}"
                        break
                print(f"  - {r['project']}: {err}")

    return {
        'total_projects': len(projects),
        'success_count': success_count,
        'total_elapsed': total_elapsed,
        'results': results,
    }


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description='批量处理编排器 - V19: 支持多部剧并发处理完整流程',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 2部剧并发处理
  python -m scripts.batch_process "漫剧素材/百里将就" "漫剧素材/烈日重生"

  # 带敏感词预处理
  python -m scripts.batch_process "漫剧素材/百里将就" --preprocess

  # 仅渲染
  python -m scripts.batch_process "漫剧素材/百里将就" --render-only
        """
    )

    parser.add_argument('projects', nargs='+', help='项目路径列表')
    parser.add_argument('--max-concurrent', type=int, default=2,
                        help='最大并发数（M1 Pro 16GB建议2，默认2）')
    parser.add_argument('--preprocess', action='store_true',
                        help='执行敏感词预处理')
    parser.add_argument('--understand-only', action='store_true',
                        help='仅执行视频理解（跳过渲染）')
    parser.add_argument('--render-only', action='store_true',
                        help='仅执行渲染（跳过理解）')
    parser.add_argument('--no-ending', action='store_true',
                        help='禁用片尾视频')
    parser.add_argument('--no-overlay', action='store_true',
                        help='禁用花字叠加')
    parser.add_argument('--no-compress', action='store_true',
                        help='禁用视频压缩')
    parser.add_argument('--compress-target', type=int, default=100,
                        choices=[50, 100, 150, 200],
                        help='压缩目标大小MB（默认100）')

    args = parser.parse_args()

    understand = not args.render_only
    render = not args.understand_only

    batch_process(
        projects=args.projects,
        max_concurrent=args.max_concurrent,
        preprocess=args.preprocess,
        understand=understand,
        render=render,
        add_ending=not args.no_ending,
        add_overlay=not args.no_overlay,
        compress=not args.no_compress,
        compress_target=args.compress_target,
    )


if __name__ == "__main__":
    main()
