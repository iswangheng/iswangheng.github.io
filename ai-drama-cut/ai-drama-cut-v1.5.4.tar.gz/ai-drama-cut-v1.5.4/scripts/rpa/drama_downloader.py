"""
常读平台短剧自动下载 RPA 脚本

功能：
- 自动登录常读平台（邮箱+密码）
- 处理滑块验证码（自动+手动兜底）
- 搜索指定剧名
- 批量下载指定集数范围
- 保存 zip 到 downloads/ 目录

使用方式：
    # 基本用法
    python -m scripts.rpa.drama_downloader "剧名"

    # 指定集数
    python -m scripts.rpa.drama_downloader "剧名" --start 1 --end 20

    # 指定下载目录
    python -m scripts.rpa.drama_downloader "剧名" --output custom_dir/

    # 凭证通过环境变量传入
    CHANGDU_EMAIL="xxx" CHANGDU_PASSWORD="xxx" python -m scripts.rpa.drama_downloader "剧名"
"""
import argparse
import asyncio
import hashlib
import json
import logging
import os
import random
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Set, Tuple

from playwright.async_api import async_playwright, Page, BrowserContext

from scripts.rpa.config import (
    BASE_URL,
    DOWNLOAD_DIR,
    DEFAULT_START_EP,
    DEFAULT_END_EP,
    PAGE_LOAD_TIMEOUT,
    ELEMENT_WAIT_TIMEOUT,
    DOWNLOAD_TIMEOUT,
    CAPTCHA_MAX_ATTEMPTS,
    MIN_DELAY,
    MAX_DELAY,
    TYPE_DELAY,
    SESSION_DIR,
    SESSION_FILE,
    SESSION_META_FILE,
    SESSION_TTL_HOURS,
)
from scripts.rpa.captcha_solver import solve_slider_captcha
from scripts.rpa.alert import alert_login_failed, alert_batch_failures

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


# ============ 自定义异常 ============

class CaptchaFailedError(Exception):
    """验证码验证失败"""
    pass


class DramaNotFoundError(Exception):
    """未找到指定短剧"""
    pass


class DownloadFailedError(Exception):
    """下载失败"""
    pass


class LoginFailedError(Exception):
    """登录失败"""
    pass


def _hash_account(email: str) -> str:
    """返回账号摘要，避免在 sidecar 中保存明文邮箱。"""
    return hashlib.sha256(email.strip().lower().encode("utf-8")).hexdigest()


def _parse_task_name_episodes(task_name_text: str) -> Set[int]:
    """从下载中心任务名称中提取集数。"""
    episodes: Set[int] = set()
    normalized = re.sub(r"\s+", "", task_name_text)

    comma_match = re.search(r"-(\d+(?:,\d+)*)$", normalized)
    if comma_match:
        for num_str in comma_match.group(1).split(","):
            if num_str.strip().isdigit():
                episodes.add(int(num_str.strip()))
        return episodes

    range_match = re.search(r"-(\d+)\s*[-~至到]\s*(\d+)$", normalized)
    if range_match:
        start = int(range_match.group(1))
        end = int(range_match.group(2))
        if start <= end:
            episodes.update(range(start, end + 1))
        else:
            episodes.update(range(end, start + 1))
    return episodes


def _parse_filename_episodes(text: str) -> Set[int]:
    """从解压后文件名中宽松提取集数信息。"""
    episodes: Set[int] = set()
    normalized = text.replace("第", " ").replace("集", " ")

    for start_str, end_str in re.findall(r"(\d+)\s*[-~至到]\s*(\d+)", normalized):
        start = int(start_str)
        end = int(end_str)
        if start <= end:
            episodes.update(range(start, end + 1))
        else:
            episodes.update(range(end, start + 1))

    for num_str in re.findall(r"(?<![A-Za-z0-9])(\d+)(?![A-Za-z0-9])", normalized):
        episodes.add(int(num_str))

    return episodes


def _row_matches_episode_range(task_name_text: str, drama_name: str, start_ep: int, end_ep: int) -> bool:
    """基于下载中心任务名称列做精确范围匹配。"""
    normalized = re.sub(r"\s+", "", task_name_text)
    normalized_drama = re.sub(r"\s+", "", drama_name)
    if not normalized.startswith(normalized_drama + "-"):
        return False

    episodes = _parse_task_name_episodes(normalized)
    requested = set(range(start_ep, end_ep + 1))
    return episodes == requested


def _iter_video_files(extract_dir: str) -> List[Path]:
    video_exts = {".mp4", ".mkv", ".mov", ".avi", ".m4v", ".ts", ".flv", ".wmv"}
    return sorted(
        path for path in Path(extract_dir).rglob("*")
        if path.is_file() and path.suffix.lower() in video_exts
    )


def _validate_extracted_episodes(extract_dir: str, start_ep: int, end_ep: int) -> Tuple[bool, str]:
    """校验解压目录是否至少覆盖请求区间。"""
    video_files = _iter_video_files(extract_dir)
    if not video_files:
        return False, "解压目录中未找到视频文件"

    expected_count = end_ep - start_ep + 1
    if len(video_files) < expected_count:
        return False, f"视频文件数量不足，期望至少 {expected_count} 个，实际 {len(video_files)} 个"

    parsed_episodes: Set[int] = set()
    parsed_any = False
    for video_file in video_files:
        episodes = _parse_filename_episodes(video_file.stem)
        if episodes:
            parsed_any = True
            parsed_episodes.update(episodes)

    if parsed_any:
        missing = [ep for ep in range(start_ep, end_ep + 1) if ep not in parsed_episodes]
        if missing:
            return False, f"解压结果缺少请求集数: {missing}"

    return True, f"校验通过，共 {len(video_files)} 个视频文件"


def _build_session_meta(email: str, now_ts: Optional[float] = None) -> dict:
    return {
        "account_hash": _hash_account(email),
        "saved_at": int(now_ts if now_ts is not None else time.time()),
    }


async def _wait_for_any_visible(page: Page, selectors: List[str], timeout_ms: int = 10_000):
    """等待任一选择器可见，返回命中的 locator。"""
    deadline = time.time() + timeout_ms / 1000.0
    while time.time() < deadline:
        for selector in selectors:
            try:
                locator = page.locator(selector).first
                if await locator.is_visible(timeout=500):
                    return locator, selector
            except Exception:
                continue
        await page.wait_for_timeout(300)
    return None, None


async def _fill_and_verify_input(locator, value: str, field_name: str):
    """输入后回读校验，并显式触发受控表单事件。"""
    await locator.click()
    await locator.fill("")
    await locator.page.wait_for_timeout(100)
    await locator.fill(value)
    await locator.evaluate(
        """
        (el, inputValue) => {
            const nativeSetter = Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype,
                'value'
            ).set;
            nativeSetter.call(el, inputValue);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }
        """,
        value,
    )
    await locator.evaluate("el => el.dispatchEvent(new Event('blur', {bubbles: true}))")
    await locator.page.wait_for_timeout(300)

    actual_value = await locator.input_value()
    if actual_value != value:
        raise LoginFailedError(
            f"{field_name} 输入未生效，期望长度 {len(value)}，实际长度 {len(actual_value)}"
        )


def _is_session_meta_valid(meta: Optional[dict], email: str, now_ts: Optional[float] = None,
                           ttl_hours: int = SESSION_TTL_HOURS) -> Tuple[bool, str]:
    """验证 session sidecar 是否与当前账号和 TTL 匹配。"""
    if not isinstance(meta, dict):
        return False, "session 元信息缺失或格式错误"

    expected_hash = _hash_account(email)
    if meta.get("account_hash") != expected_hash:
        return False, "session 账号不匹配"

    saved_at = meta.get("saved_at")
    if not isinstance(saved_at, (int, float)):
        return False, "session 保存时间缺失或格式错误"

    now = now_ts if now_ts is not None else time.time()
    ttl_seconds = ttl_hours * 3600
    if now - float(saved_at) > ttl_seconds:
        return False, f"session 已超过 {ttl_hours} 小时 TTL"

    return True, "session 元信息有效"


# ============ 核心下载器 ============

class DramaDownloader:
    """
    常读平台短剧批量下载器

    完整流程：登录 → 验证码 → 搜索 → 进入详情 → 批量下载 → 确认 → 保存文件
    """

    def __init__(self, email: str, password: str, download_dir: str = DOWNLOAD_DIR,
                 headless: bool = False):
        """
        初始化下载器

        Args:
            email: 登录邮箱
            password: 登录密码
            download_dir: 下载保存目录
            headless: 是否使用无头浏览器（开发调试建议 False）
        """
        self.email = email
        self.password = password
        self.download_dir = os.path.abspath(download_dir)
        self.headless = headless

        self.playwright = None
        self.browser = None
        self.context = None  # type: Optional[BrowserContext]
        self.page = None  # type: Optional[Page]

        # 确保下载目录和 session 目录存在
        os.makedirs(self.download_dir, exist_ok=True)
        os.makedirs(SESSION_DIR, exist_ok=True)

    async def _random_delay(self, min_s: float = MIN_DELAY, max_s: float = MAX_DELAY):
        """添加随机延迟，模拟人类操作节奏"""
        delay = random.uniform(min_s, max_s)
        await self.page.wait_for_timeout(int(delay * 1000))

    def _load_session_meta(self) -> Optional[dict]:
        if not os.path.exists(SESSION_META_FILE):
            return None
        try:
            with open(SESSION_META_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"读取 session 元信息失败: {e}")
            return None

    def _can_reuse_session(self) -> bool:
        if not os.path.exists(SESSION_FILE):
            return False

        meta = self._load_session_meta()
        is_valid, reason = _is_session_meta_valid(meta, self.email)
        if not is_valid:
            logger.info(f"放弃复用 session: {reason}")
            return False

        return True

    def _clear_session_files(self):
        for path in (SESSION_FILE, SESSION_META_FILE):
            if os.path.exists(path):
                try:
                    os.remove(path)
                except OSError as e:
                    logger.warning(f"删除 session 文件失败 {path}: {e}")

    async def start_browser(self):
        """
        启动浏览器

        如果存在已保存且元信息有效的 session 文件，会自动恢复 cookies 和 localStorage，
        避免每次都重新登录。
        """
        logger.info("启动浏览器...")
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ],
        )

        context_options = {
            "viewport": {"width": 1280, "height": 800},
            "accept_downloads": True,
        }
        if self._can_reuse_session():
            logger.info("发现有效 session，尝试恢复登录态...")
            context_options["storage_state"] = SESSION_FILE
        elif os.path.exists(SESSION_FILE):
            logger.info("session 文件存在但不满足复用条件，将以空上下文启动")

        self.context = await self.browser.new_context(**context_options)
        self.page = await self.context.new_page()
        self.page.set_default_timeout(PAGE_LOAD_TIMEOUT)
        logger.info("浏览器启动完成")

    async def _save_session(self):
        """保存当前浏览器 session（cookies + localStorage）到文件"""
        try:
            await self.context.storage_state(path=SESSION_FILE)
            with open(SESSION_META_FILE, "w", encoding="utf-8") as f:
                json.dump(_build_session_meta(self.email), f, ensure_ascii=False, indent=2)
            logger.info(f"登录态已保存到: {SESSION_FILE}")
        except Exception as e:
            logger.warning(f"保存 session 失败: {e}")

    async def _is_logged_in(self) -> bool:
        """
        检查当前是否已登录

        先访问受保护页面，再同时验证 URL 与后台业务 DOM 是否可用。
        """
        try:
            await self.page.goto(BASE_URL + "sale/short-play/list", wait_until="networkidle")
            await self.page.wait_for_timeout(2000)
            current_url = self.page.url
            if "/sale/" not in current_url:
                logger.info(f"session 已过期（被重定向到: {current_url}）")
                return False

            protected_selectors = [
                "table tbody tr",
                ".arco-table",
                "input[placeholder*='漫剧名称']",
                ".book_name_content",
            ]
            for selector in protected_selectors:
                try:
                    locator = self.page.locator(selector).first
                    if await locator.is_visible(timeout=3000):
                        logger.info(f"session 有效，已登录（当前页: {current_url}, DOM: {selector}）")
                        return True
                except Exception:
                    continue

            logger.info(f"session URL 正常但业务 DOM 不可用，视为半失效（当前页: {current_url}）")
            return False
        except Exception:
            return False

    async def close_browser(self):
        """关闭浏览器（关闭前自动保存 session）"""
        if self.context:
            await self._save_session()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        logger.info("浏览器已关闭")

    # ─────────────────── 登录流程 ───────────────────

    async def login(self):
        """
        执行登录流程

        步骤：
        1. 打开首页
        2. 点击"登录 / 注册"按钮
        3. 勾选协议
        4. 填写邮箱密码
        5. 点击登录
        6. 处理滑块验证码
        7. 等待登录成功（页面跳转到后台）
        """
        logger.info(f"打开首页: {BASE_URL}")
        await self.page.goto(BASE_URL)
        await self.page.wait_for_load_state("networkidle")
        await self._random_delay()

        # 步骤1：点击"登录 / 注册"按钮
        logger.info("点击登录按钮...")
        login_btn = self.page.locator("text=登录").first
        try:
            await login_btn.wait_for(state="visible", timeout=ELEMENT_WAIT_TIMEOUT)
            await login_btn.click()
        except Exception:
            # 尝试其他可能的选择器
            login_btn = self.page.locator("text=登录 / 注册").first
            await login_btn.click()

        await self._random_delay()

        # 步骤2：等待登录弹窗出现
        logger.info("等待登录弹窗...")
        email_input = self.page.locator("input[name='email']")
        await email_input.wait_for(state="visible", timeout=ELEMENT_WAIT_TIMEOUT)

        # 步骤3：填写邮箱（用 type 逐字输入，触发表单验证事件）
        logger.info("填写邮箱...")
        await _fill_and_verify_input(email_input, self.email, "邮箱")
        await self._random_delay(0.3, 0.6)

        # 步骤4：填写密码
        logger.info("填写密码...")
        pwd_input = self.page.locator("input[name='password']")
        await _fill_and_verify_input(pwd_input, self.password, "密码")
        await self._random_delay(0.3, 0.8)

        # 步骤5：勾选"我已阅读并同意"协议（自定义 div checkbox）
        logger.info("勾选用户协议...")
        agreement_check = self.page.locator(".account-center-agreement-check")
        await agreement_check.wait_for(state="visible", timeout=5000)
        await agreement_check.click()
        logger.info("已勾选协议")
        await self._random_delay(0.5, 1.0)

        # 步骤6：等待登录按钮变为可用状态，然后点击
        logger.info("提交登录...")
        login_button = self.page.locator("button.account-center-action-button")
        await login_button.wait_for(state="visible", timeout=5000)

        # 等待按钮从 disabled 变为 enabled（最多等 5 秒）
        for _ in range(10):
            is_disabled = await login_button.get_attribute("disabled")
            if is_disabled is None:
                break
            logger.info("等待登录按钮启用...")
            await self.page.wait_for_timeout(500)

        # 检查按钮是否仍然 disabled
        is_disabled = await login_button.get_attribute("disabled")
        if is_disabled is not None:
            title = await login_button.get_attribute("title")
            raise LoginFailedError(f"登录按钮未启用，停止提交（title: {title}）")

        await login_button.click()
        logger.info("已点击登录按钮")

        await self._random_delay(1.0, 2.0)

        # 步骤7：处理验证码
        logger.info("检查验证码...")
        captcha_ok = await solve_slider_captcha(
            self.page,
            max_attempts=CAPTCHA_MAX_ATTEMPTS,
        )
        if not captcha_ok:
            raise CaptchaFailedError("验证码验证失败，无法登录")

        # 步骤8：等待登录成功（验证码通过后页面会自动跳转）
        logger.info("等待登录完成...")
        # 等待 URL 变化或后台元素出现
        for _ in range(20):
            current_url = self.page.url
            if "/page/home" in current_url or "/dashboard" in current_url or "/sale/" in current_url:
                logger.info(f"✅ 登录成功！已跳转到: {current_url}")
                break
            await self.page.wait_for_timeout(1000)
        else:
            logger.warning(f"当前页面: {self.page.url}，继续执行")

        await self.page.wait_for_load_state("networkidle")
        await self._random_delay()

        # 登录成功后保存 session
        await self._save_session()

    # ─────────────────── 搜索短剧 ───────────────────

    async def search_drama(self, drama_name: str):
        """
        搜索指定短剧

        步骤：
        1. 点击左侧"漫剧列表"菜单
        2. 在搜索框输入剧名
        3. 点击搜索
        4. 从结果列表中点击目标剧集

        Args:
            drama_name: 要搜索的短剧名称

        Raises:
            DramaNotFoundError: 搜索无结果
        """
        logger.info(f"搜索短剧: {drama_name}")

        # 步骤1：直接导航到漫剧列表页面（比点击菜单更可靠）
        drama_list_url = BASE_URL + "sale/short-play/list"
        logger.info(f"导航到漫剧列表: {drama_list_url}")
        await self.page.goto(drama_list_url)
        await self.page.wait_for_load_state("networkidle")
        await self._random_delay()

        # 步骤3：等待筛选区或表格加载，然后输入剧名
        logger.info("输入搜索关键词...")
        ready_locator, ready_selector = await _wait_for_any_visible(
            self.page,
            [
                ".arco-table",
                "table tbody tr",
                "input[placeholder*='漫剧名称']",
                "input[placeholder*='漫剧']",
                "input[placeholder*='请输入']",
            ],
            timeout_ms=12_000,
        )
        if not ready_locator:
            raise DramaNotFoundError("漫剧列表页未加载出表格或筛选区")
        logger.info(f"页面已就绪: {ready_selector}")

        search_input, search_selector = await _wait_for_any_visible(
            self.page,
            [
                "input[placeholder*='漫剧名称']",
                "input[placeholder*='剧名']",
                "input[placeholder*='请输入']",
                ".arco-form-item input[type='text']:not([name='email']):not([name='password'])",
                ".arco-input-wrapper input[type='text']:not([name='email']):not([name='password'])",
            ],
            timeout_ms=8_000,
        )
        if search_input:
            logger.info(f"找到搜索框: {search_selector}")
            await _fill_and_verify_input(search_input, drama_name, "搜索关键词")
        else:
            logger.info("未定位到显式搜索框，转为直接在结果表中查找剧名")

        # 步骤3：点击搜索按钮（若存在）
        logger.info("点击搜索...")
        search_button, search_btn_selector = await _wait_for_any_visible(
            self.page,
            [
                "button:has-text('搜索')",
                "button:has-text('查询')",
                ".arco-form button",
                "button[type='submit']",
            ],
            timeout_ms=3_000,
        )
        if search_button:
            await search_button.click()
            logger.info(f"已点击搜索按钮: {search_btn_selector}")

        await self._random_delay(1.0, 2.0)
        await self.page.wait_for_load_state("networkidle")

        # 步骤4：在搜索结果表格中找到目标剧集，点击同一行详情入口
        logger.info("查找搜索结果...")
        await self._random_delay()

        rows = self.page.locator("table tbody tr")
        row_count = await rows.count()
        if row_count == 0:
            raise DramaNotFoundError("漫剧列表表格为空")

        target_row = None
        for i in range(row_count):
            row = rows.nth(i)
            try:
                row_text = await row.text_content() or ""
                if drama_name in row_text:
                    target_row = row
                    logger.info(f"在第 {i + 1} 行找到目标剧名")
                    break
            except Exception:
                continue

        if not target_row:
            raise DramaNotFoundError(f"搜索结果中未找到: {drama_name}")

        detail_link = target_row.locator(f"a:has-text('{drama_name}'), a[href*='detail']").first
        try:
            if await detail_link.is_visible(timeout=2000):
                await detail_link.click()
                logger.info("通过目标行链接进入详情页")
            else:
                raise Exception("详情链接不可见")
        except Exception:
            detail_btn = target_row.locator("button:has-text('查看详情'), a:has-text('查看详情'), text=查看详情").first
            await detail_btn.click()
            logger.info("通过目标行'查看详情'按钮进入详情页")

        logger.info(f"✅ 找到并进入剧集: {drama_name}")
        await self._random_delay()
        await self.page.wait_for_load_state("networkidle")

    # ─────────────────── 批量下载 ───────────────────

    async def download_episodes(self, drama_name: str, start_ep: int = 1, end_ep: int = 10):
        """
        批量下载指定集数范围的视频

        步骤：
        1. 在剧集详情页点击"批量下载"按钮
        2. 在弹窗中设置下载集数范围
        3. 确认下载
        4. 跳转到下载页面
        5. 等待任务创建并点击下载

        Args:
            drama_name: 剧名（用于保存文件名）
            start_ep: 起始集数
            end_ep: 结束集数

        Raises:
            DownloadFailedError: 下载过程出错
        """
        logger.info(f"开始下载 {drama_name} 第 {start_ep}-{end_ep} 集")

        # ── 步骤1：在详情页点击"批量下载"按钮 ──
        logger.info("查找批量下载按钮...")
        await self.page.wait_for_timeout(2000)

        batch_btn = self.page.locator("text=批量下载").first
        try:
            await batch_btn.wait_for(state="visible", timeout=10_000)
            await batch_btn.click()
            logger.info("已点击'批量下载'")
        except Exception:
            # 备选：可能是 button 或 span
            batch_btn2 = self.page.locator("button:has-text('批量下载'), span:has-text('批量下载')").first
            await batch_btn2.click()
            logger.info("已点击'批量下载'（备选选择器）")

        await self._random_delay()

        # ── 步骤2：在弹窗中设置集数范围 ──
        # 弹窗有两个输入框：起始集（默认1）和结束集
        # 需要在第二个输入框填入 end_ep
        logger.info(f"设置下载范围: 第 {start_ep} 集 到 第 {end_ep} 集")
        await self.page.wait_for_timeout(1500)

        # 查找弹窗内的所有 input（Arco Design Modal）
        modal_inputs = self.page.locator(".arco-modal input[type='text'], .arco-modal input[type='number'], .arco-modal .arco-input")
        input_count = await modal_inputs.count()
        logger.info(f"弹窗内找到 {input_count} 个输入框")

        if input_count >= 2:
            # 第一个输入框：起始集（通常默认为1）
            first_input = modal_inputs.nth(0)
            await first_input.click()
            await first_input.fill(str(start_ep))
            logger.info(f"设置起始集: {start_ep}")

            await self._random_delay(0.2, 0.4)

            # 第二个输入框：结束集
            second_input = modal_inputs.nth(1)
            await second_input.click()
            await second_input.fill(str(end_ep))
            logger.info(f"设置结束集: {end_ep}")
        elif input_count == 1:
            # 只有一个输入框，可能只需要填结束集
            single_input = modal_inputs.nth(0)
            await single_input.click()
            await single_input.fill(str(end_ep))
            logger.info(f"设置结束集: {end_ep}")
        else:
            logger.warning("未找到集数输入框，尝试继续")

        await self._random_delay(0.3, 0.6)

        # ── 步骤3：点击弹窗中的"下载"按钮 ──
        logger.info("点击下载按钮...")
        modal_download_btn = self.page.locator(".arco-modal button:has-text('下载')").first
        try:
            await modal_download_btn.wait_for(state="visible", timeout=5000)
            await modal_download_btn.click()
            logger.info("已点击弹窗内'下载'按钮")
        except Exception:
            # 备选
            for text in ["下载", "确认", "确定"]:
                try:
                    btn = self.page.locator(f".arco-modal button:has-text('{text}')").first
                    if await btn.is_visible(timeout=1000):
                        await btn.click()
                        logger.info(f"已点击弹窗内'{text}'按钮")
                        break
                except Exception:
                    continue

        await self._random_delay(1.0, 2.0)

        # ── 步骤4：处理"跳转到下载中心"提示弹窗 ──
        logger.info("查找跳转提示...")
        await self.page.wait_for_timeout(1500)

        jump_selectors = [
            "text=跳转到下载中心",
            "text=前往下载中心",
            ".arco-modal button:has-text('跳转')",
            ".arco-modal a:has-text('下载中心')",
        ]
        for selector in jump_selectors:
            try:
                jump_btn = self.page.locator(selector).first
                if await jump_btn.is_visible(timeout=3000):
                    await jump_btn.click()
                    logger.info(f"已点击: {selector}")
                    break
            except Exception:
                continue
        else:
            # 如果没有跳转弹窗，直接导航到下载中心
            logger.info("未找到跳转弹窗，直接导航到下载中心")
            await self.page.goto(BASE_URL + "sale/download-center")

        await self.page.wait_for_load_state("networkidle")
        await self._random_delay()

        # ── 步骤5：在下载中心等待任务生成并下载 ──
        await self._download_from_center(drama_name, start_ep, end_ep)

    async def _download_from_center(self, drama_name: str, start_ep: int, end_ep: int):
        """
        在下载中心等待任务生成完成，然后点击下载

        下载中心的任务需要几十秒到一分钟生成。
        生成完成后"下载"按钮变为可点击状态。
        下载的 zip 文件名是乱码，需要重命名。

        Args:
            drama_name: 剧名（用于重命名文件）
            start_ep: 起始集
            end_ep: 结束集
        """
        logger.info("进入下载中心，等待任务生成...")

        # 确保在下载中心页面
        if "/download-center" not in self.page.url:
            await self.page.goto(BASE_URL + "sale/download-center")
            await self.page.wait_for_load_state("networkidle")

        # 轮询等待下载按钮变为可点击状态
        max_wait = 120  # 最多等待 2 分钟
        poll_interval = 5  # 每 5 秒检查一次
        start_time = time.time()

        saw_same_drama_history = False
        saw_pending_target_task = False

        while time.time() - start_time < max_wait:
            elapsed = int(time.time() - start_time)
            logger.info(f"等待下载任务生成... ({elapsed}s/{max_wait}s)")

            rows = self.page.locator("table tbody tr")
            row_count = await rows.count()
            matching_ready_rows = []

            for i in range(row_count):
                row = rows.nth(i)
                try:
                    cells = row.locator("td")
                    task_name_locator = cells.nth(1)
                    download_link = cells.nth(2).locator("text=下载").first
                    status_locator = cells.nth(3)
                    created_at_locator = cells.nth(4)

                    task_name = ((await task_name_locator.text_content()) or "").strip()
                    status_text = ((await status_locator.text_content()) or "").strip()
                    created_at_text = ((await created_at_locator.text_content()) or "").strip()
                    row_text = ((await row.text_content()) or "").strip()

                    if drama_name not in task_name:
                        continue

                    if not _row_matches_episode_range(task_name, drama_name, start_ep, end_ep):
                        saw_same_drama_history = True
                        logger.info(f"跳过同剧名但范围不匹配的任务名: {task_name}")
                        continue

                    if "完成" not in status_text:
                        saw_pending_target_task = True
                        logger.info(f"找到目标任务但尚未可下载: {task_name} | 状态: {status_text or row_text[:80]}")
                        continue

                    if not await download_link.is_visible(timeout=1000):
                        logger.info(f"目标任务已完成但下载链接不可见: {task_name}")
                        continue

                    created_at = None
                    if created_at_text:
                        try:
                            created_at = datetime.strptime(created_at_text, "%Y-%m-%d %H:%M:%S")
                        except ValueError:
                            logger.info(f"无法解析创建时间，保留原文本参与日志: {created_at_text}")

                    matching_ready_rows.append((task_name, created_at, created_at_text, download_link))

                except Exception as e:
                    logger.debug(f"行 {i} 处理失败: {e}")
                    continue

            if len(matching_ready_rows) > 1:
                matching_ready_rows.sort(key=lambda item: (item[1] is not None, item[1] or datetime.min), reverse=True)
                newest_task_name = matching_ready_rows[0][0]
                newest_created_at = matching_ready_rows[0][2]
                logger.info(
                    f"找到多个精确匹配任务，按创建时间选择最新一条: {newest_task_name} @ {newest_created_at}"
                )

            if len(matching_ready_rows) >= 1:
                task_name, _, created_at_text, download_btn = matching_ready_rows[0]
                logger.info(f"开始下载目标任务 [{task_name}]，创建时间: {created_at_text}")

                async with self.page.expect_download(timeout=DOWNLOAD_TIMEOUT) as download_info:
                    await download_btn.click()

                download = await download_info.value
                logger.info(f"下载开始，原始文件名: {download.suggested_filename}")

                final_name = f"{drama_name}_ep{start_ep}-{end_ep}.zip"
                save_path = os.path.join(self.download_dir, final_name)
                await download.save_as(save_path)

                file_size = os.path.getsize(save_path)
                logger.info(f"✅ 下载完成: {save_path}")
                logger.info(f"   文件大小: {file_size / 1024 / 1024:.1f} MB")

                await self._extract_zip(save_path, drama_name, start_ep, end_ep)
                return

            # 未找到就绪的任务，刷新列表
            try:
                search_btn = self.page.locator("button:has-text('搜索')").first
                if await search_btn.is_visible(timeout=1000):
                    await search_btn.click()
                    logger.info("点击搜索刷新列表")
                else:
                    await self.page.reload()
                    logger.info("刷新页面")
            except Exception:
                await self.page.reload()

            await self.page.wait_for_load_state("networkidle")
            await self.page.wait_for_timeout(poll_interval * 1000)

        if saw_pending_target_task:
            raise DownloadFailedError(
                f"等待超时（{max_wait}秒）：目标任务 [{drama_name}] ep{start_ep}-{end_ep} 一直未进入可下载状态"
            )
        if saw_same_drama_history:
            raise DownloadFailedError(
                f"等待超时（{max_wait}秒）：只发现同剧名历史任务，未找到范围精确匹配 ep{start_ep}-{end_ep} 的可下载任务"
            )
        raise DownloadFailedError(f"等待超时（{max_wait}秒）：下载任务未生成完成")

    async def _extract_zip(self, zip_path: str, drama_name: str, start_ep: int, end_ep: int):
        """
        解压 zip 文件到以剧名命名的文件夹，并校验请求集数是否落地。

        Args:
            zip_path: zip 文件路径
            drama_name: 剧名（用于创建目标文件夹）
            start_ep: 起始集数
            end_ep: 结束集数
        """
        import zipfile

        extract_dir = os.path.join(self.download_dir, drama_name)
        if os.path.exists(extract_dir):
            logger.info(f"清理解压目录中的历史文件: {extract_dir}")
            shutil.rmtree(extract_dir)
        os.makedirs(extract_dir, exist_ok=True)

        logger.info(f"解压到: {extract_dir}")
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                zf.extractall(extract_dir)

            is_valid, message = _validate_extracted_episodes(extract_dir, start_ep, end_ep)
            if not is_valid:
                raise DownloadFailedError(f"解压结果校验失败: {message}；保留 zip: {zip_path}")

            logger.info(f"✅ 解压完成，{message}")
            os.remove(zip_path)
            logger.info(f"已删除 zip: {zip_path}")
        except zipfile.BadZipFile as e:
            logger.error(f"zip 文件损坏: {zip_path}")
            raise DownloadFailedError(f"zip 文件损坏: {zip_path}") from e
        except DownloadFailedError:
            raise
        except Exception as e:
            logger.warning(f"解压失败: {e}，zip 文件保留在: {zip_path}")
            raise DownloadFailedError(f"解压失败: {e}") from e

    # ─────────────────── 主流程 ───────────────────

    async def _ensure_logged_in(self):
        """确保已登录，session 过期则自动重新登录"""
        is_logged_in = await self._is_logged_in()
        if not is_logged_in:
            logger.info("session 已过期，重新登录...")
            await self.login()
        else:
            logger.info("session 有效")

    async def _run_single_task(self, drama_name: str, start_ep: int, end_ep: int,
                               max_retries: int = 2) -> dict:
        """
        执行单个下载任务（带重试）

        Args:
            drama_name: 剧名
            start_ep: 起始集
            end_ep: 结束集
            max_retries: 最大重试次数

        Returns:
            结果字典 {"drama": str, "status": "success"|"failed", "error": str|None, "path": str|None}
        """
        for attempt in range(1, max_retries + 1):
            try:
                logger.info(f"--- 任务: {drama_name} ep{start_ep}-{end_ep} (尝试 {attempt}/{max_retries}) ---")

                # 每个任务前确保登录态
                await self._ensure_logged_in()

                # 搜索
                await self.search_drama(drama_name)

                # 下载
                await self.download_episodes(drama_name, start_ep, end_ep)

                result_path = os.path.join(self.download_dir, drama_name)
                logger.info(f"✅ 任务完成: {drama_name}")
                return {"drama": drama_name, "status": "success", "error": None, "path": result_path}

            except DramaNotFoundError as e:
                # 搜不到剧就不重试了
                logger.error(f"❌ {drama_name}: 未找到，跳过")
                return {"drama": drama_name, "status": "failed", "error": str(e), "path": None}

            except (CaptchaFailedError, LoginFailedError) as e:
                # 登录/验证码失败，清除 session 重试
                logger.warning(f"登录相关错误: {e}，清除 session 重试...")
                self._clear_session_files()
                if attempt < max_retries:
                    await self.page.wait_for_timeout(3000)
                    continue
                # 最后一次重试也失败 → P0 报警
                alert_login_failed(str(e))
                return {"drama": drama_name, "status": "failed", "error": str(e), "path": None}

            except Exception as e:
                logger.warning(f"任务出错 (尝试 {attempt}): {e}")
                if attempt < max_retries:
                    # 重试前等待，可能是网络波动
                    await self.page.wait_for_timeout(5000)
                    continue
                return {"drama": drama_name, "status": "failed", "error": str(e), "path": None}

        return {"drama": drama_name, "status": "failed", "error": "超过最大重试次数", "path": None}

    async def run(self, drama_name: str, start_ep: int = DEFAULT_START_EP,
                  end_ep: int = DEFAULT_END_EP):
        """
        执行单个下载任务（兼容旧接口）

        浏览器在任务完成后关闭。
        """
        logger.info("=" * 60)
        logger.info(f"常读平台短剧下载器")
        logger.info(f"剧名: {drama_name}")
        logger.info(f"集数: 第 {start_ep} 集 ~ 第 {end_ep} 集")
        logger.info(f"保存目录: {self.download_dir}")
        logger.info("=" * 60)

        try:
            await self.start_browser()
            result = await self._run_single_task(drama_name, start_ep, end_ep)
            if result["status"] == "failed":
                raise DownloadFailedError(result["error"])
            logger.info("🎉 全部流程完成！")
        finally:
            if not self.headless:
                logger.info("浏览器将在 5 秒后关闭（可按 Ctrl+C 保持）")
                try:
                    await self.page.wait_for_timeout(5000)
                except Exception:
                    pass
            await self.close_browser()

    async def run_batch(self, tasks: list, keep_browser: bool = True):
        """
        批量执行下载任务（浏览器常驻模式）

        Args:
            tasks: 任务列表，每个元素为 {"drama": "剧名", "start": 1, "end": 10}
            keep_browser: 完成后是否保持浏览器打开

        Returns:
            结果列表
        """
        logger.info("=" * 60)
        logger.info(f"批量下载模式 - 共 {len(tasks)} 个任务")
        logger.info(f"保存目录: {self.download_dir}")
        logger.info("=" * 60)

        results = []
        alert_file = os.path.join(self.download_dir, "download_alerts.log")

        try:
            await self.start_browser()

            for i, task in enumerate(tasks, 1):
                drama = task["drama"]
                start = task.get("start", DEFAULT_START_EP)
                end = task.get("end", DEFAULT_END_EP)

                logger.info(f"\n[{i}/{len(tasks)}] {drama} ep{start}-{end}")

                result = await self._run_single_task(drama, start, end)
                results.append(result)

                # 失败任务写入报警日志
                if result["status"] == "failed":
                    alert_msg = f"[ALERT] {time.strftime('%Y-%m-%d %H:%M:%S')} | 下载失败: {drama} ep{start}-{end} | 原因: {result['error']}\n"
                    with open(alert_file, "a", encoding="utf-8") as f:
                        f.write(alert_msg)
                    logger.error(alert_msg.strip())

                # 任务间间隔，避免被风控
                if i < len(tasks):
                    delay = random.uniform(3, 6)
                    logger.info(f"等待 {delay:.1f}s 后执行下一个任务...")
                    await self.page.wait_for_timeout(int(delay * 1000))

        except KeyboardInterrupt:
            logger.info("用户中断批量任务")
        finally:
            if not keep_browser:
                await self.close_browser()
            else:
                logger.info("浏览器保持打开，可继续使用")
                # 仍然保存 session
                await self._save_session()

        # 汇总报告
        success = sum(1 for r in results if r["status"] == "success")
        failed = sum(1 for r in results if r["status"] == "failed")
        logger.info(f"\n{'='*60}")
        logger.info(f"批量下载完成: 成功 {success}/{len(results)}, 失败 {failed}/{len(results)}")
        if failed > 0:
            logger.warning(f"失败任务详情已写入: {alert_file}")
            failed_list = [r for r in results if r["status"] == "failed"]
            for r in failed_list:
                logger.warning(f"  - {r['drama']}: {r['error']}")
            # 发送报警邮件
            alert_batch_failures(failed_list, len(results))
        logger.info(f"{'='*60}")

        return results


# ============ CLI 入口 ============

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="常读平台短剧自动下载工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 下载单部短剧
  python -m scripts.rpa.drama_downloader "休书落纸" --start 1 --end 10

  # 从任务列表文件批量下载（浏览器常驻）
  python -m scripts.rpa.drama_downloader --batch tasks.json

  # 任务列表文件格式 (tasks.json):
  [
    {"drama": "休书落纸", "start": 1, "end": 10},
    {"drama": "另一部剧", "start": 1, "end": 20}
  ]

  # 凭证通过环境变量传入
  CHANGDU_EMAIL="xxx" CHANGDU_PASSWORD="xxx" \\
    python -m scripts.rpa.drama_downloader "剧名"
        """,
    )
    parser.add_argument("drama_name", nargs="?", default=None, help="要下载的短剧名称（单任务模式）")
    parser.add_argument("--start", type=int, default=DEFAULT_START_EP, help="起始集数（默认 1）")
    parser.add_argument("--end", type=int, default=DEFAULT_END_EP, help="结束集数（默认 10）")
    parser.add_argument("--output", default=DOWNLOAD_DIR, help=f"下载保存目录（默认 {DOWNLOAD_DIR}）")
    parser.add_argument("--email", default=None, help="登录邮箱（也可用 CHANGDU_EMAIL 环境变量）")
    parser.add_argument("--password", default=None, help="登录密码（也可用 CHANGDU_PASSWORD 环境变量）")
    parser.add_argument("--headless", action="store_true", help="无头模式（不显示浏览器窗口）")
    parser.add_argument("--batch", default=None, help="批量任务列表 JSON 文件路径")
    return parser.parse_args()


async def main():
    """主入口"""
    args = parse_args()

    # 获取凭证
    email = args.email or os.getenv("CHANGDU_EMAIL", "")
    password = args.password or os.getenv("CHANGDU_PASSWORD", "")

    if not email or not password:
        print("❌ 请提供登录凭证！")
        print('  CHANGDU_EMAIL="xxx" CHANGDU_PASSWORD="xxx" python -m scripts.rpa.drama_downloader ...')
        sys.exit(1)

    downloader = DramaDownloader(
        email=email,
        password=password,
        download_dir=args.output,
        headless=args.headless,
    )

    try:
        if args.batch:
            # 批量模式：从 JSON 文件读取任务列表
            import json
            with open(args.batch, "r", encoding="utf-8") as f:
                tasks = json.load(f)
            logger.info(f"从 {args.batch} 加载了 {len(tasks)} 个任务")
            results = await downloader.run_batch(tasks, keep_browser=False)
            # 有失败任务则返回非零退出码
            if any(r["status"] == "failed" for r in results):
                sys.exit(1)
        elif args.drama_name:
            # 单任务模式
            await downloader.run(args.drama_name, args.start, args.end)
        else:
            print("❌ 请指定剧名或 --batch 任务文件")
            print("   python -m scripts.rpa.drama_downloader --help")
            sys.exit(1)

    except (CaptchaFailedError, DramaNotFoundError, DownloadFailedError, LoginFailedError) as e:
        logger.error(str(e))
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("用户中断")
        await downloader.close_browser()
        sys.exit(0)


if __name__ == "__main__":
    asyncio.run(main())
