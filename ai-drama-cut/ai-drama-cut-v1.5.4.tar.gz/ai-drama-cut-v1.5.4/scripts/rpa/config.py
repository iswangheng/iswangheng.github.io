"""
常读平台 RPA 配置文件

所有敏感凭证通过环境变量读取，不硬编码在代码中。
"""
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_FILE = PROJECT_ROOT / ".env"
if ENV_FILE.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(ENV_FILE)
    except Exception:
        pass

# ============ 登录凭证（环境变量） ============
EMAIL = os.getenv("CHANGDU_EMAIL", "")
PASSWORD = os.getenv("CHANGDU_PASSWORD", "")

# ============ 网站地址 ============
BASE_URL = "https://www.changdupingtai.com/"

# ============ 下载配置 ============
DOWNLOAD_DIR = "downloads"
DEFAULT_START_EP = 1
DEFAULT_END_EP = 10

# ============ 超时配置（毫秒） ============
PAGE_LOAD_TIMEOUT = 30_000
ELEMENT_WAIT_TIMEOUT = 10_000
DOWNLOAD_TIMEOUT = 300_000  # 下载超时 5 分钟

# ============ 验证码配置 ============
CAPTCHA_MAX_ATTEMPTS = 5

# ============ 反检测配置 ============
# 操作间随机延迟范围（秒）
MIN_DELAY = 0.5
MAX_DELAY = 1.5
# 输入时每个字符的延迟（毫秒）
TYPE_DELAY = 80

# ============ 登录态持久化 ============
# 浏览器 session 保存路径（cookies + localStorage）
SESSION_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), ".session")
SESSION_FILE = os.path.join(SESSION_DIR, "changdu_session.json")
SESSION_META_FILE = os.path.join(SESSION_DIR, "changdu_session.meta.json")
SESSION_TTL_HOURS = 72

# ============ 报警配置 ============
ALERT_EMAIL_TO = "wangheng@weiling.cn"
# 发件邮箱（用登录邮箱，通过 SMTP 发送）
ALERT_EMAIL_FROM = os.getenv("ALERT_EMAIL_FROM", "iswangheng@126.com")
ALERT_EMAIL_SMTP_HOST = os.getenv("ALERT_EMAIL_SMTP_HOST", "smtp.126.com")
ALERT_EMAIL_SMTP_PORT = int(os.getenv("ALERT_EMAIL_SMTP_PORT", "465"))
ALERT_EMAIL_SMTP_PASSWORD = os.getenv("ALERT_EMAIL_SMTP_PASSWORD", "")
