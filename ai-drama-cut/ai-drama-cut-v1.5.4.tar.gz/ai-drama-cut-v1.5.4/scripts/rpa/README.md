# 常读平台 RPA 模块说明

## 模块概述

`scripts/rpa/` 负责通过 Playwright 驱动浏览器，自动完成常读平台的登录、验证码处理、剧目搜索、批量下载和下载结果解压。

当前实现的主路径为：

1. 启动 Playwright Chromium 浏览器
2. 尝试加载 `.session/changdu_session.json` 恢复登录态
3. 若 session 失效，则重新执行邮箱密码登录
4. 自动处理字节跳动滑块验证码
5. 搜索指定短剧并进入详情页
6. 触发批量下载任务，跳转下载中心轮询等待
7. 下载 zip，按剧名重命名并自动解压

## 关键文件

- `scripts/rpa/drama_downloader.py`：主流程实现
- `scripts/rpa/captcha_solver.py`：滑块验证码识别与拖拽
- `scripts/rpa/config.py`：常量配置与 session 路径
- `scripts/rpa/alert.py`：登录/批量失败报警
- `.session/changdu_session.json`：Playwright storage state 持久化文件
- `.session/changdu_session.meta.json`：session 账号摘要和保存时间 sidecar

## 当前验证结果

基于本轮真实测试，以下链路已经验证通过：

1. 根目录 `.env` 中的 `CHANGDU_EMAIL` / `CHANGDU_PASSWORD` 会被 `scripts/rpa/config.py` 自动加载
2. `.session/changdu_session.json` 与 `.session/changdu_session.meta.json` 可以联合用于 session 复用；账号变更或 TTL 过期时会放弃旧 session
3. 登录态检查会同时验证后台 URL 与业务 DOM，避免半失效 session 被误判为可用
4. 可以成功搜索剧目 `休书落纸` 并稳定进入详情页
5. 下载中心会基于 `任务名称` 列精确匹配请求范围，例如 `休书落纸-1,2,3`
6. 当同剧名历史任务存在时，会跳过 `休书落纸-1,2` / `休书落纸-1,2,3,4,5,6,7,8,9,10` 这类范围不匹配任务
7. 当同名同范围任务存在多条时，会按 `创建时间` 选择最新一条，而不是误点旧任务
8. 真实测试中，`休书落纸` 第 `1-3` 集任务经历 `加密中` → `压缩中` → 可下载，最终成功下载并解压为 `3` 个视频文件
9. 解压前会先清理目标剧目录，避免历史文件污染本次校验结果

## 运行方式

优先从项目根目录 `.env` 读取 `CHANGDU_EMAIL` / `CHANGDU_PASSWORD`；如果当前 shell 已导出同名环境变量，则以当前 shell 为准。

```bash
python -m scripts.rpa.drama_downloader "剧名" --start 1 --end 10
```

也可以显式覆盖：

```bash
CHANGDU_EMAIL="xxx" CHANGDU_PASSWORD="xxx" \
python -m scripts.rpa.drama_downloader "剧名" --start 1 --end 10
```

批量模式：

```bash
python -m scripts.rpa.drama_downloader --batch tasks.json
```

## 稳定性问题与设计风险

以下风险基于代码审查和一次真实下载测试整理，按优先级排序。

### P0

#### 1. session 生命周期和身份信息缺少显式管理

现状：
- 只要 `.session/changdu_session.json` 存在，就会优先作为 `storage_state` 直接加载
- 文件中没有额外的元信息来说明该 session 属于哪个账号、生成时间、上次验证时间、生成环境

风险：
- 切换账号后可能误用旧 session
- session 文件损坏或部分失效时难以定位
- 多人共用目录时容易混淆登录态来源

涉及代码：
- `scripts/rpa/drama_downloader.py`
- `scripts/rpa/config.py`

### P1

#### 2. 登录态有效性校验过粗

现状：
- `_is_logged_in()` 通过访问后台页并检查 URL 是否包含 `/sale/` 来判断是否登录

风险：
- 只能证明没有立即跳回登录页
- 不能证明后台接口、下载权限和业务页面状态都可用
- 某些半失效 session 会在搜索或下载阶段才暴露问题

涉及代码：
- `scripts/rpa/drama_downloader.py:_is_logged_in`

#### 3. 页面选择器对前端结构高度敏感

现状：
- 搜索框、按钮、弹窗、下载按钮大量依赖中文文案、Arco Design 类名和页面结构
- 例如 `text=批量下载`、`.arco-modal button:has-text('下载')`、`span.text-button:has-text('下载')`

风险：
- 页面文案、class、层级稍有调整就会失效
- 前端改版后故障会集中爆发

涉及代码：
- `scripts/rpa/drama_downloader.py`

#### 4. 下载中心任务匹配不够严格

现状：
- `_download_from_center()` 通过 `drama_name in row_text` 来匹配目标行
- 再通过包含 `下载完成` 判断任务就绪

风险：
- 同剧名存在历史任务或重复任务时，可能点到错误任务
- 没有严格绑定任务创建时间、集数范围或唯一任务 ID

涉及代码：
- `scripts/rpa/drama_downloader.py:_download_from_center`

#### 5. 验证码识别策略依赖当前图像结构

现状：
- `captcha_solver.py` 假设 iframe、图片尺寸、背景图/滑块图结构相对稳定
- 缺口定位依赖 OpenCV 边缘检测和模板匹配

风险：
- 字节验证码样式或 DOM 一旦调整，成功率会明显下降
- 这类失败通常是平台变化触发，恢复成本高

涉及代码：
- `scripts/rpa/captcha_solver.py`

#### 6. 登录按钮处理方式较激进

现状：
- 如果登录按钮始终是 disabled，代码会直接移除 `disabled` 属性并 `force=True` 点击

风险：
- 可能绕过真实的前端校验流程
- 也可能更容易触发站点的反自动化逻辑
- 会掩盖表单状态本身的问题

涉及代码：
- `scripts/rpa/drama_downloader.py:login`

### P2

#### 7. 重试策略比较粗，错误类型区分不够

现状：
- 普通异常统一等待后重试
- 登录/验证码错误统一删 session 后重试

风险：
- 页面结构变化、权限问题、网络问题、任务生成慢等不同故障被混合处理
- 一部分错误重试没有意义，只会放大运行时间和平台压力

涉及代码：
- `scripts/rpa/drama_downloader.py:_run_single_task`

#### 8. 下载结果完整性校验不足

现状：
- 下载完成后直接解压 zip
- 只记录了解压后的文件数量，没有核对集数完整性、文件名、文件可播放性或损坏情况

风险：
- 表面上流程成功，但下载结果可能不完整或损坏
- 问题会推迟到后续处理阶段才暴露

涉及代码：
- `scripts/rpa/drama_downloader.py:_extract_zip`

#### 9. 批量模式复用单个浏览器上下文，状态污染风险存在

现状：
- `run_batch()` 在单个浏览器和 context 中串行执行多个任务

风险：
- 某个任务留下的弹窗、筛选条件、页面状态、下载中心残留，可能影响后续任务
- 批量任务越长，状态漂移越明显

涉及代码：
- `scripts/rpa/drama_downloader.py:run_batch`

#### 10. 凭证管理和 session 管理是两套独立机制

现状：
- 凭证通过环境变量读取
- session 单独保存在 `.session/changdu_session.json`
- 二者之间没有统一的可观测状态说明

风险：
- 会出现“密码不可见但 session 还能用”的状态
- session 一旦过期，恢复路径依赖当前 shell 是否注入环境变量
- 运维和排障成本较高

涉及代码：
- `scripts/rpa/config.py`
- `scripts/rpa/drama_downloader.py`

## 总体判断

当前 `rpa` 模块已经能稳定跑通单次真实下载任务，session 复用也有效。但它更接近“可以工作的业务自动化脚本”，还不是“高可靠、强可观测的下载服务”。

如果后续要继续增强，优先级建议为：

1. 收紧下载中心任务匹配逻辑
2. 增强 session 元信息与失效观测
3. 增加下载结果完整性校验
4. 降低对页面文案和 DOM 结构的脆弱依赖
