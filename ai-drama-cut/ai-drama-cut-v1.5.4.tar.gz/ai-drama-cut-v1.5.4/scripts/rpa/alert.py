"""
P0 报警模块 - 邮件通知

当发生以下 P0 级别事件时发送邮件报警：
- 验证码连续 5 次破解失败（下载服务瘫痪）
- 登录失败（凭证可能失效）
- 连续多个任务失败（可能被风控）
"""
import logging
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from scripts.rpa.config import (
    ALERT_EMAIL_TO,
    ALERT_EMAIL_FROM,
    ALERT_EMAIL_SMTP_HOST,
    ALERT_EMAIL_SMTP_PORT,
    ALERT_EMAIL_SMTP_PASSWORD,
)

logger = logging.getLogger(__name__)

# 防止短时间内重复发送同类报警（冷却 10 分钟）
_alert_cooldown = {}
COOLDOWN_SECONDS = 600


def send_alert(subject: str, body: str, level: str = "P0"):
    """
    发送报警邮件

    Args:
        subject: 邮件主题
        body: 邮件正文
        level: 报警级别（P0/P1/P2）
    """
    # 冷却检查：同一 subject 10 分钟内不重复发
    now = time.time()
    if subject in _alert_cooldown:
        if now - _alert_cooldown[subject] < COOLDOWN_SECONDS:
            logger.info(f"报警冷却中，跳过: {subject}")
            return
    _alert_cooldown[subject] = now

    full_subject = f"[{level}] 常读RPA下载服务 - {subject}"
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

    html_body = f"""
    <div style="font-family: sans-serif; padding: 20px;">
        <h2 style="color: {'#d32f2f' if level == 'P0' else '#f57c00'};">
            {level} 报警 - 常读平台 RPA 下载服务
        </h2>
        <table style="border-collapse: collapse; margin: 16px 0;">
            <tr><td style="padding: 8px; font-weight: bold;">时间</td>
                <td style="padding: 8px;">{timestamp}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">级别</td>
                <td style="padding: 8px;">{level}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">事件</td>
                <td style="padding: 8px;">{subject}</td></tr>
        </table>
        <div style="background: #f5f5f5; padding: 16px; border-radius: 8px;
                    white-space: pre-wrap; font-size: 14px;">
{body}
        </div>
        <p style="color: #999; margin-top: 20px; font-size: 12px;">
            此邮件由常读平台 RPA 下载服务自动发送
        </p>
    </div>
    """

    msg = MIMEMultipart("alternative")
    msg["Subject"] = full_subject
    msg["From"] = ALERT_EMAIL_FROM
    msg["To"] = ALERT_EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    if not ALERT_EMAIL_SMTP_PASSWORD:
        logger.warning(f"未配置 SMTP 密码，报警邮件无法发送。报警内容: {full_subject}")
        logger.warning(f"请设置环境变量 ALERT_EMAIL_SMTP_PASSWORD")
        # 即使发不了邮件，也写入本地日志
        _write_local_alert(full_subject, body)
        return

    try:
        with smtplib.SMTP_SSL(ALERT_EMAIL_SMTP_HOST, ALERT_EMAIL_SMTP_PORT, timeout=10) as server:
            server.login(ALERT_EMAIL_FROM, ALERT_EMAIL_SMTP_PASSWORD)
            server.sendmail(ALERT_EMAIL_FROM, [ALERT_EMAIL_TO], msg.as_string())
        logger.info(f"报警邮件已发送: {full_subject} → {ALERT_EMAIL_TO}")
    except Exception as e:
        logger.error(f"报警邮件发送失败: {e}")
        _write_local_alert(full_subject, body)


def _write_local_alert(subject: str, body: str):
    """邮件发送失败时写入本地报警日志"""
    import os
    alert_file = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        "downloads", "alerts.log"
    )
    os.makedirs(os.path.dirname(alert_file), exist_ok=True)
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(alert_file, "a", encoding="utf-8") as f:
        f.write(f"\n{'='*60}\n")
        f.write(f"[{timestamp}] {subject}\n")
        f.write(f"{body}\n")
    logger.info(f"报警已写入本地日志: {alert_file}")


# ============ 预定义报警 ============

def alert_captcha_failed(attempts: int, error: str):
    """P0: 验证码连续破解失败"""
    send_alert(
        "验证码破解失败 - 下载服务可能瘫痪",
        f"验证码连续 {attempts} 次自动破解均失败。\n"
        f"下载服务无法登录，所有任务将被阻塞。\n\n"
        f"最后一次错误: {error}\n\n"
        f"可能原因:\n"
        f"1. 字节跳动验证码策略升级\n"
        f"2. IP 被风控\n"
        f"3. 网络异常\n\n"
        f"建议操作:\n"
        f"1. 手动登录一次常读平台，确认验证码是否正常\n"
        f"2. 检查服务器网络状况\n"
        f"3. 如验证码类型变更，需更新破解逻辑",
        level="P0",
    )


def alert_login_failed(error: str):
    """P0: 登录失败"""
    send_alert(
        "登录失败 - 凭证可能失效",
        f"登录常读平台失败。\n\n"
        f"错误: {error}\n\n"
        f"可能原因:\n"
        f"1. 邮箱或密码已变更\n"
        f"2. 账号被封禁\n"
        f"3. 网站登录流程改版\n\n"
        f"建议操作:\n"
        f"1. 手动登录 https://www.changdupingtai.com/ 确认凭证\n"
        f"2. 检查环境变量 CHANGDU_EMAIL / CHANGDU_PASSWORD",
        level="P0",
    )


def alert_batch_failures(failed_tasks: list, total: int):
    """P1: 批量任务中多个失败"""
    task_details = "\n".join(
        f"  - {t['drama']}: {t['error']}" for t in failed_tasks
    )
    send_alert(
        f"批量下载 {len(failed_tasks)}/{total} 个任务失败",
        f"批量下载任务中有 {len(failed_tasks)} 个失败（共 {total} 个）。\n\n"
        f"失败任务:\n{task_details}",
        level="P1" if len(failed_tasks) < total / 2 else "P0",
    )
