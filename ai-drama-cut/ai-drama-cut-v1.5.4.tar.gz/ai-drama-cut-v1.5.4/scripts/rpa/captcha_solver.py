"""
字节跳动拼图验证码自动破解模块

常读平台使用字节跳动验证中心（rmc.bytedance.com/verifycenter）的拼图验证码，
嵌在 iframe 中（<div id="captcha_container"><iframe ...>）。

自动破解策略：
1. 进入验证码 iframe
2. 截取拼图背景图（含缺口阴影）
3. 用 OpenCV 边缘检测 + 模板匹配定位缺口位置
4. 计算拖拽距离
5. 模拟人类拖拽轨迹完成验证
"""
import random
import time
import logging
import base64
import io

import cv2
import numpy as np

logger = logging.getLogger(__name__)


def _find_gap_position(bg_bytes: bytes, slider_bytes: bytes = None) -> int:
    """
    通过图像处理找到拼图缺口的 X 坐标

    方法：对背景图做边缘检测，缺口区域会有明显的矩形边缘。
    通过列方向的边缘密度峰值定位缺口水平位置。

    Args:
        bg_bytes: 背景图的 PNG/JPEG 字节数据
        slider_bytes: 滑块图的字节数据（可选，用于模板匹配）

    Returns:
        缺口的 X 坐标（像素）
    """
    # 解码背景图
    bg_arr = np.frombuffer(bg_bytes, np.uint8)
    bg_img = cv2.imdecode(bg_arr, cv2.IMREAD_COLOR)
    if bg_img is None:
        raise ValueError("无法解码背景图")

    h, w = bg_img.shape[:2]
    logger.info(f"背景图尺寸: {w}x{h}")

    # 如果有滑块图，优先用模板匹配
    if slider_bytes:
        try:
            gap_x = _template_match(bg_img, slider_bytes)
            if gap_x > 0:
                logger.info(f"模板匹配找到缺口位置: x={gap_x}")
                return gap_x
        except Exception as e:
            logger.warning(f"模板匹配失败: {e}，回退到边缘检测")

    # 边缘检测方法
    gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)
    # 高斯模糊降噪
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # Canny 边缘检测
    edges = cv2.Canny(blurred, 100, 200)

    # 缺口通常不在最左边（滑块起始位置），从 w*0.2 开始搜索
    start_x = int(w * 0.2)

    # 计算每列的边缘像素数量
    col_sums = np.sum(edges[:, start_x:] > 0, axis=0)

    # 用滑动窗口找到边缘密度最高的区域（缺口的左边缘）
    window_size = 5
    if len(col_sums) < window_size:
        # 图太小，直接取最大值
        gap_x = start_x + int(np.argmax(col_sums))
    else:
        # 滑动窗口平均
        kernel = np.ones(window_size) / window_size
        smoothed = np.convolve(col_sums, kernel, mode='valid')
        gap_x = start_x + int(np.argmax(smoothed))

    logger.info(f"边缘检测找到缺口位置: x={gap_x}")
    return gap_x


def _template_match(bg_img: np.ndarray, slider_bytes: bytes) -> int:
    """
    用模板匹配在背景图中定位滑块缺口

    Args:
        bg_img: 背景图 (BGR)
        slider_bytes: 滑块图字节数据

    Returns:
        缺口的 X 坐标，失败返回 -1
    """
    slider_arr = np.frombuffer(slider_bytes, np.uint8)
    slider_img = cv2.imdecode(slider_arr, cv2.IMREAD_UNCHANGED)
    if slider_img is None:
        return -1

    # 如果滑块图有 alpha 通道，提取有效区域
    if slider_img.shape[2] == 4:
        alpha = slider_img[:, :, 3]
        # 找到非透明区域的边界
        rows = np.any(alpha > 50, axis=1)
        cols = np.any(alpha > 50, axis=0)
        if not np.any(rows) or not np.any(cols):
            return -1
        rmin, rmax = np.where(rows)[0][[0, -1]]
        cmin, cmax = np.where(cols)[0][[0, -1]]
        # 裁剪有效区域
        slider_crop = slider_img[rmin:rmax+1, cmin:cmax+1, :3]
    else:
        slider_crop = slider_img[:, :, :3]

    # 转灰度
    bg_gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)
    slider_gray = cv2.cvtColor(slider_crop, cv2.COLOR_BGR2GRAY)

    # 边缘检测后做模板匹配（对颜色变化更鲁棒）
    bg_edges = cv2.Canny(bg_gray, 100, 200)
    slider_edges = cv2.Canny(slider_gray, 100, 200)

    # 模板匹配
    result = cv2.matchTemplate(bg_edges, slider_edges, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)

    logger.info(f"模板匹配置信度: {max_val:.3f}, 位置: {max_loc}")

    if max_val > 0.3:  # 置信度阈值
        return max_loc[0]
    return -1


def _generate_human_track(distance: float) -> list:
    """
    生成高度模拟人类的拖拽轨迹

    人类拖拽特征：
    1. 非线性加速：开始慢 → 快速加速 → 匀速 → 提前减速 → 微调
    2. 随机停顿：中途可能有 1-2 次短暂停顿（思考/调整）
    3. Y 轴抖动：持续的微小抖动，不是完全水平
    4. 末尾微调：接近目标时有小幅度的前后调整
    5. 速度波动：即使在匀速阶段也有微小波动

    Args:
        distance: 需要拖拽的总距离（像素）

    Returns:
        轨迹点列表，每个点包含 dx, dy, duration
    """
    track = []
    current = 0

    # 分阶段：启动(10%) → 加速(25%) → 匀速(40%) → 减速(20%) → 微调(5%)
    phase_starts = [0, distance * 0.1, distance * 0.35, distance * 0.75, distance * 0.95]

    # 是否在中途停顿（30% 概率）
    pause_at = None
    if random.random() < 0.3:
        pause_at = random.uniform(distance * 0.3, distance * 0.6)

    while current < distance:
        remaining = distance - current

        # 判断当前阶段
        if current < phase_starts[1]:
            # 启动阶段：很慢，模拟按下鼠标后的犹豫
            step = random.uniform(1, 3)
            duration = random.randint(30, 60)
        elif current < phase_starts[2]:
            # 加速阶段：快速增加速度
            progress = (current - phase_starts[1]) / (phase_starts[2] - phase_starts[1])
            step = random.uniform(3 + progress * 10, 5 + progress * 15)
            duration = random.randint(15, 30)
        elif current < phase_starts[3]:
            # 匀速阶段：速度稳定但有波动
            base_speed = 12
            step = random.uniform(base_speed * 0.8, base_speed * 1.2)
            duration = random.randint(10, 25)
        elif current < phase_starts[4]:
            # 减速阶段：逐渐减速
            progress = (current - phase_starts[3]) / (phase_starts[4] - phase_starts[3])
            step = random.uniform(8 * (1 - progress * 0.7), 12 * (1 - progress * 0.7))
            duration = random.randint(20, 40)
        else:
            # 微调阶段：非常小的步长，精确对准
            step = random.uniform(0.5, 2)
            duration = random.randint(30, 60)

        step = min(step, remaining)

        # Y 轴抖动：持续的微小抖动，模拟手部不稳
        dy = random.uniform(-2, 2)
        # 在加速和匀速阶段抖动更明显
        if phase_starts[1] < current < phase_starts[3]:
            dy *= 1.5

        track.append({"dx": step, "dy": dy, "duration": duration})
        current += step

        # 中途停顿
        if pause_at and abs(current - pause_at) < 5 and len(track) > 3:
            # 停顿 100-300ms
            track.append({"dx": 0, "dy": random.uniform(-0.5, 0.5), "duration": random.randint(100, 300)})
            pause_at = None  # 只停顿一次

    # 末尾微调：前后小幅度调整（人类对准目标的特征）
    if random.random() > 0.2:
        # 先过头一点
        track.append({"dx": random.uniform(2, 5), "dy": random.uniform(-1, 1), "duration": random.randint(40, 80)})
        # 再回退
        track.append({"dx": -random.uniform(1, 3), "dy": random.uniform(-0.5, 0.5), "duration": random.randint(50, 100)})
        # 最后微调
        track.append({"dx": random.uniform(-1, 1), "dy": random.uniform(-0.5, 0.5), "duration": random.randint(30, 60)})

    return track


async def _get_captcha_frame(page):
    """
    获取验证码 iframe 的 frame 对象

    Returns:
        Playwright Frame 对象，未找到返回 None
    """
    # 方式1：通过 #captcha_container 内的 iframe
    try:
        iframe_el = page.locator("#captcha_container iframe").first
        if await iframe_el.is_visible(timeout=2000):
            frame = await iframe_el.content_frame()
            if frame:
                return frame
    except Exception:
        pass

    # 方式2：通过 src 匹配
    try:
        iframe_el = page.locator("iframe[src*='verifycenter'], iframe[src*='bytedance']").first
        if await iframe_el.is_visible(timeout=1000):
            frame = await iframe_el.content_frame()
            if frame:
                return frame
    except Exception:
        pass

    # 方式3：遍历所有 frames
    for frame in page.frames:
        if "verifycenter" in frame.url or "bytedance" in frame.url:
            return frame

    return None


async def _extract_images_from_frame(frame) -> tuple:
    """
    从验证码 iframe 中提取背景图和滑块图

    字节验证码的 DOM 结构通常包含：
    - 背景图：<img> 或 canvas（拼图背景）
    - 滑块图：<img> 或 canvas（拼图块）

    Returns:
        (bg_bytes, slider_bytes) 元组，slider_bytes 可能为 None
    """
    bg_bytes = None
    slider_bytes = None

    # 等待验证码图片加载
    await frame.wait_for_timeout(1000)

    # 尝试获取所有图片元素
    images = await frame.query_selector_all("img")
    logger.info(f"iframe 内找到 {len(images)} 个 img 元素")

    for img in images:
        src = await img.get_attribute("src")
        if not src:
            continue

        # 获取图片尺寸
        box = await img.bounding_box()
        if not box:
            continue

        width = box["width"]
        height = box["height"]
        logger.info(f"  img: {width:.0f}x{height:.0f} src={src[:80]}...")

        # 背景图通常较大（宽 > 200），滑块图较小（宽 < 100）
        if width > 150 and height > 80:
            # 这是背景图
            try:
                if src.startswith("data:"):
                    # base64 编码的图片
                    b64_data = src.split(",", 1)[1]
                    bg_bytes = base64.b64decode(b64_data)
                else:
                    # URL 图片，通过 page 下载
                    resp = await frame.page.request.get(src)
                    bg_bytes = await resp.body()
                logger.info(f"  → 识别为背景图 ({width:.0f}x{height:.0f})")
            except Exception as e:
                logger.warning(f"  → 获取背景图失败: {e}")

        elif width < 100 and height > 30:
            # 这可能是滑块图
            try:
                if src.startswith("data:"):
                    b64_data = src.split(",", 1)[1]
                    slider_bytes = base64.b64decode(b64_data)
                else:
                    resp = await frame.page.request.get(src)
                    slider_bytes = await resp.body()
                logger.info(f"  → 识别为滑块图 ({width:.0f}x{height:.0f})")
            except Exception as e:
                logger.warning(f"  → 获取滑块图失败: {e}")

    # 如果没找到 img，尝试 canvas
    if bg_bytes is None:
        canvases = await frame.query_selector_all("canvas")
        logger.info(f"iframe 内找到 {len(canvases)} 个 canvas 元素")
        for i, canvas in enumerate(canvases):
            box = await canvas.bounding_box()
            if not box:
                continue
            width = box["width"]
            height = box["height"]
            logger.info(f"  canvas[{i}]: {width:.0f}x{height:.0f}")

            if width > 150 and height > 80 and bg_bytes is None:
                try:
                    data_url = await canvas.evaluate(
                        "el => el.toDataURL('image/png')"
                    )
                    b64_data = data_url.split(",", 1)[1]
                    bg_bytes = base64.b64decode(b64_data)
                    logger.info(f"  → canvas 背景图获取成功")
                except Exception as e:
                    logger.warning(f"  → canvas 背景图获取失败: {e}")

    return bg_bytes, slider_bytes


async def _find_and_drag_slider(frame, page, gap_x: int, bg_width: float, bg_element_box: dict = None) -> bool:
    """
    在验证码 iframe 中找到滑块并拖拽到目标位置

    Args:
        frame: 验证码 iframe 的 Frame 对象
        page: 主页面 Page 对象
        gap_x: 缺口在背景图显示坐标中的 X 位置（像素）
        bg_width: 背景图的实际显示宽度（像素）
        bg_element_box: 背景图元素的 bounding_box（用于计算绝对坐标）

    Returns:
        是否拖拽成功
    """
    # 查找滑块按钮
    slider_selectors = [
        "[class*='secsdk-captcha-drag-icon']",
        "[class*='drag-icon']",
        "[class*='slider'] [class*='icon']",
        "[class*='slider-btn']",
        "[class*='move-btn']",
        "[class*='handler']",
        "[class*='drag']",
    ]

    slider = None
    for selector in slider_selectors:
        try:
            el = frame.locator(selector).first
            if await el.is_visible(timeout=1000):
                slider = el
                logger.info(f"找到滑块: {selector}")
                break
        except Exception:
            continue

    if not slider:
        logger.error("未找到任何可拖拽的滑块元素")
        return False

    # 获取滑块在页面中的绝对位置
    slider_box = await slider.bounding_box()
    if not slider_box:
        logger.error("无法获取滑块位置")
        return False

    logger.info(f"滑块位置: x={slider_box['x']:.0f}, y={slider_box['y']:.0f}, "
                f"w={slider_box['width']:.0f}, h={slider_box['height']:.0f}")

    # 计算拖拽距离
    # gap_x 是缺口在背景图显示坐标中的位置
    # 滑块初始位置在背景图左侧，需要拖拽到 gap_x 处
    # 但要考虑：滑块的中心应该对准缺口的中心
    # 滑块图宽度约 68px（原始），显示约 42px（缩放后）
    # 缺口宽度也约 42px
    # 所以拖拽距离 ≈ gap_x（缺口左边缘位置）
    drag_distance = gap_x

    # 添加小随机偏移（±3px），避免每次完全一样
    drag_distance += random.uniform(-3, 3)

    # 确保距离合理
    drag_distance = max(10, min(drag_distance, bg_width * 0.95))

    logger.info(f"拖拽距离: {drag_distance:.1f}px")

    # 生成人类轨迹
    track = _generate_human_track(drag_distance)

    # 计算总拖拽时间
    total_duration = sum(p["duration"] for p in track)
    logger.info(f"轨迹点数: {len(track)}, 预计耗时: {total_duration}ms")

    # 执行拖拽
    start_x = slider_box["x"] + slider_box["width"] / 2
    start_y = slider_box["y"] + slider_box["height"] / 2

    # 先移动到滑块上方，模拟鼠标移入
    await page.mouse.move(start_x, start_y - 20)
    await page.wait_for_timeout(random.randint(100, 200))
    # 移动到滑块中心
    await page.mouse.move(start_x, start_y)
    await page.wait_for_timeout(random.randint(200, 500))

    # 按下鼠标
    await page.mouse.down()
    # 按下后短暂停顿（人类反应时间）
    await page.wait_for_timeout(random.randint(100, 250))

    current_x = start_x
    current_y = start_y

    for point in track:
        current_x += point["dx"]
        current_y += point["dy"]
        # 使用 steps 参数让移动更平滑
        await page.mouse.move(current_x, current_y, steps=random.randint(1, 3))
        await page.wait_for_timeout(point["duration"])

    # 到达目标后短暂停顿再松开（人类确认动作）
    await page.wait_for_timeout(random.randint(100, 300))
    await page.mouse.up()

    # 等待验证结果
    await page.wait_for_timeout(2000)
    return True


async def _is_captcha_present(page) -> bool:
    """检测字节跳动验证码是否存在"""
    try:
        container = page.locator("#captcha_container")
        if await container.is_visible(timeout=1000):
            iframe = container.locator("iframe")
            if await iframe.count() > 0:
                return True
    except Exception:
        pass

    try:
        iframe = page.locator("iframe[src*='verifycenter'], iframe[src*='bytedance']")
        if await iframe.is_visible(timeout=1000):
            return True
    except Exception:
        pass

    return False


async def _is_captcha_gone(page) -> bool:
    """检查验证码是否已消失"""
    try:
        container = page.locator("#captcha_container")
        if await container.is_visible(timeout=500):
            iframe = container.locator("iframe")
            if await iframe.count() > 0 and await iframe.first.is_visible(timeout=300):
                return False
    except Exception:
        pass

    try:
        iframe = page.locator("iframe[src*='verifycenter'], iframe[src*='bytedance']")
        if await iframe.is_visible(timeout=500):
            return False
    except Exception:
        pass

    return True


async def solve_slider_captcha(page, max_attempts: int = 5) -> bool:
    """
    自动破解字节跳动滑块验证码

    流程：
    1. 检测验证码 iframe
    2. 进入 iframe 提取背景图和滑块图
    3. OpenCV 边缘检测定位缺口位置
    4. 模拟人类轨迹拖拽滑块
    5. 失败则重试（最多 max_attempts 次）
    6. 全部失败触发 P0 报警邮件

    Args:
        page: Playwright page 对象
        max_attempts: 自动尝试最大次数

    Returns:
        是否成功通过验证码
    """
    logger.info("等待验证码出现...")
    await page.wait_for_timeout(2000)

    if not await _is_captcha_present(page):
        logger.info("未检测到验证码，跳过")
        return True

    logger.info("检测到字节跳动验证码，开始自动破解")
    last_error = ""

    for attempt in range(1, max_attempts + 1):
        logger.info(f"--- 第 {attempt}/{max_attempts} 次尝试 ---")

        try:
            # 获取验证码 iframe
            frame = await _get_captcha_frame(page)
            if not frame:
                last_error = "无法获取验证码 iframe"
                logger.warning(last_error)
                await page.wait_for_timeout(1000)
                continue

            # 提取图片
            bg_bytes, slider_bytes = await _extract_images_from_frame(frame)
            if bg_bytes is None:
                last_error = "无法提取背景图"
                logger.warning(last_error)
                await page.wait_for_timeout(1000)
                continue

            # 获取背景图的显示尺寸
            bg_display_width = 300  # 默认值
            try:
                imgs = await frame.query_selector_all("img")
                for img in imgs:
                    box = await img.bounding_box()
                    if box and box["width"] > 150:
                        bg_display_width = box["width"]
                        break
            except Exception:
                pass

            # 图像处理找缺口
            gap_x = _find_gap_position(bg_bytes, slider_bytes)

            # 计算显示坐标（图片可能被缩放）
            bg_arr = np.frombuffer(bg_bytes, np.uint8)
            bg_img = cv2.imdecode(bg_arr, cv2.IMREAD_COLOR)
            original_width = bg_img.shape[1]
            scale = bg_display_width / original_width
            display_gap_x = gap_x * scale

            logger.info(f"原始缺口: {gap_x}px, 缩放比: {scale:.2f}, 显示缺口: {display_gap_x:.1f}px")

            # 拖拽滑块
            dragged = await _find_and_drag_slider(frame, page, display_gap_x, bg_display_width)
            if not dragged:
                last_error = "拖拽滑块失败"
                continue

            # 检查是否通过
            await page.wait_for_timeout(1500)
            if await _is_captcha_gone(page):
                logger.info(f"验证码自动破解成功！(第 {attempt} 次)")
                return True

            last_error = f"第 {attempt} 次拖拽未通过验证"
            logger.info("本次拖拽未通过验证，重试...")
            # 等待验证码刷新
            await page.wait_for_timeout(random.randint(1000, 2000))

        except Exception as e:
            last_error = str(e)
            logger.warning(f"第 {attempt} 次尝试出错: {e}")
            await page.wait_for_timeout(1000)

    # 全部失败 → P0 报警
    logger.error(f"验证码连续 {max_attempts} 次破解失败！触发 P0 报警")
    try:
        from scripts.rpa.alert import alert_captcha_failed
        alert_captcha_failed(max_attempts, last_error)
    except Exception as e:
        logger.error(f"发送报警失败: {e}")

    return False
