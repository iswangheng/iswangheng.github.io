# 核心模块编译保护 - 使用指南

## 目的

将核心商业机密模块编译为 `.so` 文件，防止源代码泄露。

## 安装依赖

```bash
pip install cython
```

## 使用方法

### 1. 编译核心模块（发布时）

```bash
python scripts/compile_core.py
```

**编译流程**：
1. 自动备份源代码为 `*.orig` 文件
2. 使用 Cython 编译为核心 `.so` 文件
3. 删除原始 `.py` 文件（保留备份）
4. 清理中间产物（`.c` 文件、`build/` 目录）

**编译产物**：
- `scripts/understand/analyze_segment.so`  ✅ 无法逆向
- `scripts/understand/generate_clips.so`   ✅ 无法逆向
- `scripts/understand/quality_filter.so`   ✅ 无法逆向
- ... （共 14 个核心模块）

### 2. 恢复源代码（开发时）

```bash
python scripts/restore_source.py
```

**恢复流程**：
1. 从 `*.orig` 备份恢复源代码
2. 删除编译后的 `.so` 文件
3. 源代码可正常编辑和调试

### 3. 打包发布

```bash
# 编译核心模块
python scripts/compile_core.py

# 正常打包
bash openclaw/package.sh
```

打包后的 tarball **不包含源代码**，只包含：
- ✅ 核心模块（`.so` 文件）
- ✅ 工具脚本（`.py` 文件，不涉及机密）
- ✅ 配置和文档

## 技术细节

### 什么是 Cython？

Cython 是一个 Python 编译器，将 Python 代码编译为 C 扩展模块：

```python
# 原始 Python 代码（analyze_segment.py）
def analyze_segment(keyframes, asr_segments):
    """分析视频片段"""
    # ... 你的核心算法 ...

# 编译后（analyze_segment.so）
# ✅ C 级别的机器码
# ✅ 无法使用标准工具反编译
# ✅ 即使反编译也是混乱的 C 代码
```

### 保护强度

| 保护方式 | 难度 | 说明 |
|---------|------|------|
| **源代码** | ⭐ | 任何人都能看到 |
| **.pyc** | ⭐⭐ | 很容易反编译（uncompyle6） |
| **混淆代码** | ⭐⭐⭐ | 可以阅读但难理解 |
| **Cython .so** | ⭐⭐⭐⭐⭐ | 需要逆向工程汇编代码 |

### Python 如何导入 .so 文件？

**无需修改 import 语句！**

```python
# 编译前
from scripts.understand.analyze_segment import analyze_segment

# 编译后（同样的代码）
from scripts.understand.analyze_segment import analyze_segment
# Python 会自动加载 analyze_segment.so
```

## 平台兼容性

⚠️ **重要：`.so` 文件与平台绑定**

编译后的文件只能在相同平台使用：
- **macOS (x86_64)** → 只能在 Intel Mac 上运行
- **macOS (arm64)** → 只能在 Apple Silicon (M1/M2) 上运行
- **Linux (x86_64)** → 只能在 Linux x86_64 上运行
- **Python 版本** → 编译时使用的 Python 版本

### 多平台发布策略

**方案 1：为每个平台分别编译**
```bash
# 在 Intel Mac 上编译
python scripts/compile_core.py
bash openclaw/package.sh
# 生成: ai-drama-cut-v1.5.0-macos-x86_64.tar.gz

# 在 Apple Silicon 上编译
python scripts/compile_core.py
bash openclaw/package.sh
# 生成: ai-drama-cut-v1.5.0-macos-arm64.tar.gz
```

**方案 2：使用 GitHub Actions 自动编译**
```yaml
# .github/workflows/compile.yml
# 自动为每个平台编译并发布
```

**方案 3：Docker 容器**
```dockerfile
# 提供包含编译后模块的 Docker 镜像
FROM python:3.10-slim
COPY ai-drama-cut-v1.5.0-linux-x86_64.tar.gz /app/
```

## 验证保护效果

### 编译前
```bash
cat scripts/understand/analyze_segment.py
# 输出: 完整的 Python 源代码，包括 AI Prompt
```

### 编译后
```bash
cat scripts/understand/analyze_segment.so
# 输出: 二进制乱码
```

### 反编译尝试
```bash
# 使用 strings 工具查看字符串
strings scripts/understand/analyze_segment.so | grep -i "prompt"
# 输出: 只能看到零散的字符串，无法还原完整逻辑
```

## 开发工作流

### 日常开发
```bash
# 1. 恢复源代码
python scripts/restore_source.py

# 2. 正常开发和测试
python -m scripts.understand.video_understand "漫剧素材/项目名"

# 3. 提交代码
git add scripts/understand/analyze_segment.py
git commit -m "feat: 优化分析算法"
```

### 发布版本
```bash
# 1. 编译核心模块
python scripts/compile_core.py

# 2. 打包
bash openclaw/package.sh

# 3. 恢复源代码（继续开发）
python scripts/restore_source.py

# 4. 发布 tarball
# 上传 dist/ai-drama-cut-v1.5.0.tar.gz
```

## 常见问题

### Q: 编译后的代码能用吗？
A: 完全可以。Python 会自动识别并导入 `.so` 文件，无需修改任何代码。

### Q: 编译后还能调试吗？
A: **不能**。编译后的代码无法设置断点或单步调试。所以开发时保持源代码，只编译发布版本。

### Q: 编译后性能会提升吗？
A: 会有一定提升（10-30%），但主要目的是代码保护，不是性能优化。

### Q: 如果需要修改代码怎么办？
A: 运行 `python scripts/restore_source.py` 恢复源代码，修改后重新编译。

### Q: 用户能在不同平台使用吗？
A: 需要为每个平台分别编译。建议提供多个版本的 tarball：
- `ai-drama-cut-v1.5.0-macos-arm64.tar.gz`
- `ai-drama-cut-v1.5.0-macos-x86_64.tar.gz`
- `ai-drama-cut-v1.5.0-linux-x86_64.tar.gz`

## 安全建议

1. **不要将 `*.orig` 文件打包进 tarball**
   - 打包脚本会自动排除这些文件

2. **不要将 `*.orig` 文件提交到 Git**
   - 在 `.gitignore` 中添加 `*.orig`

3. **安全存储源代码备份**
   - 开发完成后，将 `*.orig` 文件移到安全的地方
   - 或加密存储

4. **定期更新编译版本**
   - 每次发布新版本时重新编译
   - 避免使用旧的编译产物

## 总结

✅ **优点**：
- 核心算法完全保护
- AI Prompt 不泄露
- 不影响使用体验
- 性能略有提升

⚠️ **注意事项**：
- 需要多平台编译
- 开发时需要恢复源码
- 增加发布流程复杂度

🎯 **推荐使用场景**：
- 商业化分发
- 包含核心算法
- 需要保护 AI Prompt
- SaaS 服务本地部署
