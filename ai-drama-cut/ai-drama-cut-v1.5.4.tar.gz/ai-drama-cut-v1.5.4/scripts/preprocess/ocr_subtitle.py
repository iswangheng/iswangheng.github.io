"""
OCR字幕识别模块

功能：
1. 对视频帧进行OCR识别字幕文本
2. 检测字幕中的敏感词
3. 返回敏感词出现的时间戳

使用方法：
    from scripts.preprocess.ocr_subtitle import (
        detect_sensitive_words_from_ocr
    )

    # 检测字幕中的敏感词
    video_path = "path/to/video.mp4"
    sensitive_words = {"死", "杀", "血"}
    subtitle_region = SubtitleRegion(...)  # 字幕区域
    sample_fps = 1.0  # 采样帧率（每秒1帧）

    segments = detect_sensitive_words_from_ocr(
        video_path=video_path,
        sensitive_words=sensitive_words,
        subtitle_region=subtitle_region
    )
"""

import cv2
import numpy as np
from pathlib import Path
from typing import List, Set, Optional, Tuple
from dataclasses import dataclass
import json
import subprocess

from .subtitle_detector import SubtitleRegion


# ========== V19: OCR 引擎模块级单例（避免每集重新加载，省2-5s/集） ==========
_ocr_engine_instance = None
_ocr_engine_type = None

def _get_ocr_engine():
    """获取 OCR 引擎单例实例

    注意: PaddleOCR 3.x 不再支持 use_gpu 参数，
    GPU 加速由 PaddlePaddle 框架层面自动检测。
    """
    global _ocr_engine_instance, _ocr_engine_type
    if _ocr_engine_instance is not None:
        return _ocr_engine_instance

    # 优先尝试 PaddleOCR
    try:
        from paddleocr import PaddleOCR
        _ocr_engine_instance = PaddleOCR(lang='ch')
        _ocr_engine_type = 'paddleocr'
        print("✅ OCR引擎单例: PaddleOCR")
        return _ocr_engine_instance
    except ImportError:
        print("⚠️ PaddleOCR未安装，尝试EasyOCR...")
    except Exception as e:
        print(f"⚠️ PaddleOCR初始化失败: {e}，尝试EasyOCR...")

    # 回退到 EasyOCR（尝试 GPU）
    try:
        from easyocr import Reader
        _ocr_engine_instance = Reader(['ch_sim', 'en'], gpu=True)
        _ocr_engine_type = 'easyocr'
        print("✅ OCR引擎单例: EasyOCR (GPU)")
        return _ocr_engine_instance
    except Exception as e:
        print(f"⚠️ EasyOCR GPU失败: {e}，尝试CPU...")
        try:
            from easyocr import Reader
            _ocr_engine_instance = Reader(['ch_sim', 'en'], gpu=False)
            _ocr_engine_type = 'easyocr'
            print("✅ OCR引擎单例: EasyOCR (CPU)")
            return _ocr_engine_instance
        except ImportError:
            print("❌ EasyOCR也未安装")
            return None


@dataclass
class SubtitleSegment:
    """字幕片段 - OCR识别的字幕内容"""
    start_time: float        # 开始时间（秒）
    end_time: float          # 结束时间（秒）
    subtitle_text: str      # 字幕文本
    sensitive_word: str       # 检测到的敏感词
    frame_idx: int            # 帧索引

    def __repr__(self):
        return f"SubtitleSegment({self.start_time:.1f}s-{self.end_time:.1f}s, '{self.subtitle_text[:20]}...')"


def extract_frames_for_ocr(
    video_path: str,
    sample_fps: float = 1.0,
    output_dir: Optional[str] = None
) -> List[Tuple[int, np.ndarray, float]]:
    """
    使用 FFmpeg 管道提取视频帧用于OCR识别

    V19优化: 改用 ffmpeg -vf fps=N 管道输出，避免解码非采样帧
    30fps视频采样1fps时省83%解码量，预期2-3x提速

    Args:
        video_path: 视频文件路径
        sample_fps: 采样帧率（每秒采样多少帧）
        output_dir: 输出目录（可选，用于保存帧图片）

    Returns:
        帧列表 [(帧索引, 帧图像, 时间戳)]
    """
    # 先用 ffprobe 获取视频信息
    probe_cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,r_frame_rate',
        '-of', 'json', video_path
    ]
    try:
        probe_result = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=10)
        probe_data = json.loads(probe_result.stdout)
        stream = probe_data['streams'][0]
        width = int(stream['width'])
        height = int(stream['height'])
        fps_str = stream['r_frame_rate']
        if '/' in fps_str:
            num, den = fps_str.split('/')
            video_fps = float(num) / float(den)
        else:
            video_fps = float(fps_str)
    except Exception:
        # 回退到 cv2 获取信息
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise FileNotFoundError(f"视频文件不存在: {video_path}")
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()

    # 使用 FFmpeg 管道输出采样帧（只解码需要的帧，大幅提速）
    cmd = [
        'ffmpeg', '-i', video_path,
        '-vf', f'fps={sample_fps}',
        '-f', 'rawvideo', '-pix_fmt', 'bgr24',
        '-loglevel', 'error',
        '-'
    ]

    frames = []
    frame_size = width * height * 3  # BGR24

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        frame_count = 0

        while True:
            raw_frame = proc.stdout.read(frame_size)
            if len(raw_frame) < frame_size:
                break

            frame = np.frombuffer(raw_frame, dtype=np.uint8).reshape((height, width, 3))
            timestamp = frame_count / sample_fps
            # 计算原始帧索引（近似值）
            original_frame_idx = int(timestamp * video_fps)

            frames.append((original_frame_idx, frame, timestamp))

            # 保存帧图片（如果指定了输出目录）
            if output_dir:
                output_path = Path(output_dir) / f"frame_{original_frame_idx:06d}.jpg"
                cv2.imwrite(str(output_path), frame)

            frame_count += 1

        proc.wait()
    except Exception as e:
        print(f"⚠️ FFmpeg管道提取帧失败，回退到cv2: {e}")
        # 回退到原始 cv2 方式
        return _extract_frames_for_ocr_cv2(video_path, sample_fps, output_dir)

    return frames


def _extract_frames_for_ocr_cv2(
    video_path: str,
    sample_fps: float = 1.0,
    output_dir: Optional[str] = None
) -> List[Tuple[int, np.ndarray, float]]:
    """cv2 回退方案（原始实现）"""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise FileNotFoundError(f"视频文件不存在: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    sample_interval = max(1, int(fps / sample_fps))

    frames = []
    for i in range(0, total_frames, sample_interval):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ret, frame = cap.read()
        if ret:
            timestamp = i / fps
            frames.append((i, frame, timestamp))
            if output_dir:
                output_path = Path(output_dir) / f"frame_{i:06d}.jpg"
                cv2.imwrite(str(output_path), frame)

    cap.release()
    return frames


def init_ocr_engine():
    """
    初始化OCR引擎（V19: 使用模块级单例）

    优先使用PaddleOCR（识别准确度更高），失败则回退到EasyOCR
    """
    return _get_ocr_engine()


def ocr_subtitle_region(
    frame: np.ndarray,
    subtitle_region: SubtitleRegion,
    ocr_engine
) -> Optional[str]:
    """
    对帧的指定字幕区域进行OCR识别

    Args:
        frame: 帧图像
        subtitle_region: 字幕区域配置
        ocr_engine: OCR引擎

    Returns:
        识别到的字幕文本（如果没有字幕返回None）
    """
    h, w = frame.shape[:2]

    # 提取字幕区域
    y = int(h * subtitle_region.y_ratio)
    region_h = int(h * subtitle_region.height_ratio)
    subtitle_img = frame[y:y+region_h, :]

    # OCR识别
    try:
        # 检测OCR引擎类型
        engine_type = detect_ocr_engine_type(ocr_engine)
        
        if engine_type == 'paddleocr':
            # PaddleOCR - 新版API (3.x)
            result = ocr_engine.ocr(subtitle_img)
            
            if result and len(result) > 0:
                r = result[0]
                # 新版PaddleOCR返回OCRResult对象，支持dict接口
                texts = r.get('rec_texts', []) if hasattr(r, 'get') else []
                if texts:
                    combined = ''
                    for text in texts:
                        text = text.strip()
                        if text:
                            combined += text
                    return combined if combined else None
            return None
        
        elif engine_type == 'easyocr':
            # EasyOCR
            result = ocr_engine.readtext(subtitle_img)
            if result:
                # EasyOCR返回: [(box, text, confidence), ...]
                # 需要按位置排序
                text_boxes = []
                for line in result:
                    if len(line) >= 2:
                        text = line[1].strip()
                        box = line[0]
                        if box is not None and len(box) >= 4:
                            # 取左上角X坐标
                            x_min = min([p[0] for p in box])
                            text_boxes.append((x_min, text))
                
                if text_boxes:
                    text_boxes.sort(key=lambda x: x[0])
                    combined = ''.join([text for _, text in text_boxes])
                    return combined
        
        return None
        
    except Exception as e:
        # 静默处理OCR错误
        return None


def detect_ocr_engine_type(ocr_engine) -> str:
    """检测OCR引擎类型"""
    if ocr_engine is None:
        return 'unknown'
    
    engine_name = type(ocr_engine).__name__
    if 'PaddleOCR' in engine_name or engine_name == 'PaddleOCR':
        return 'paddleocr'
    elif 'Reader' in engine_name:
        return 'easyocr'
    
    # 通过属性判断
    if hasattr(ocr_engine, 'readtext'):
        return 'easyocr'
    elif hasattr(ocr_engine, 'ocr'):
        return 'paddleocr'
    
    return 'unknown'


def detect_sensitive_words_from_ocr(
    video_path: str,
    sensitive_words: Set[str],
    subtitle_region: SubtitleRegion,
    sample_fps: float = 2.0,
    verbose: bool = True,
    output_dir: Optional[str] = None
) -> List[SubtitleSegment]:
    """
    对视频进行OCR字幕识别，检测敏感词

    Args:
        video_path: 视频文件路径
        sensitive_words: 敏感词集合
        subtitle_region: 字幕区域配置
        sample_fps: 采样帧率（默认2fps，平衡精度和性能）
                      - 1fps: 精度1秒，粗略
                      - 2fps: 精度0.5秒，推荐
                      - 视频fps: 精确到帧，但耗时长
        verbose: 是否打印详细信息
        output_dir: 输出目录（可选，用于保存标注图）

    Returns:
        敏感词片段列表
    """
    # 获取视频实际帧率
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"❌ 无法打开视频: {video_path}")
        return []
    
    video_fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_duration = total_frames / video_fps
    cap.release()
    
    if verbose:
        print("=" * 60)
        print("OCR字幕识别 - 敏感词检测")
        print("=" * 60)
        print(f"视频: {video_path}")
        print(f"视频帧率: {video_fps} fps")
        print(f"视频时长: {video_duration:.2f}秒")
        print(f"敏感词: {sensitive_words}")
        print(f"采样率: {sample_fps} fps (每{1.0/sample_fps*1000:.0f}ms采样1次)")

    # 初始化OCR引擎
    ocr_engine = init_ocr_engine()
    if ocr_engine is None:
        print("❌ OCR引擎初始化失败")
        return []

    # 提取视频帧
    if verbose:
        print("\n提取视频帧...")

    frames = extract_frames_for_ocr(video_path, sample_fps, output_dir)

    if not frames:
        print("❌ 未提取到任何帧")
        return []

    if verbose:
        print(f"提取了 {len(frames)} 帧")

    # 获取视频FPS
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    cap.release()

    # 计算帧间隔（用于时间范围计算）
    frame_duration = 1.0 / sample_fps

    # 对每帧进行OCR识别
    ocr_results = []  # 保存OCR结果用于后续ASR结合

    for frame_idx, frame, timestamp in frames:
        # 对字幕区域进行OCR识别
        subtitle_text = ocr_subtitle_region(frame, subtitle_region, ocr_engine)

        if subtitle_text:
            # 检查是否包含敏感词（词组匹配，不拆分）
            for word in sensitive_words:
                if word in subtitle_text:  # 词组完整匹配
                    # 记录OCR结果
                    ocr_results.append({
                        'timestamp': timestamp,
                        'text': subtitle_text,
                        'sensitive_word': word,
                        'frame_idx': frame_idx
                    })

                    if verbose:
                        print(f"  帧 {frame_idx} ({timestamp:.3f}s): 发现敏感词 '{word}'")
                        print(f"     字幕: {subtitle_text}")

                    # 生成标注图（如果指定了输出目录）
                    if output_dir:
                        _generate_annotation_frame(
                            frame, frame_idx, subtitle_text, subtitle_region,
                            output_dir
                        )

    # 如果没有OCR结果，直接返回
    if not ocr_results:
        return []

    # 尝试加载ASR数据进行OCR+ASR结合
    try:
        # 尝试加载ASR
        from scripts.extract_asr import load_asr_from_file
        from scripts.config import TrainingConfig
        import os
        
        # 查找ASR缓存文件
        project_name = Path(video_path).parent.name
        asr_cache_dir = TrainingConfig.CACHE_DIR / "asr" / project_name
        
        if asr_cache_dir.exists():
            # 找到对应的ASR文件
            episode = int(Path(video_path).stem.split('-')[-1]) if '-' in Path(video_path).stem else 1
            asr_file = asr_cache_dir / f"{episode}.json"
            
            if asr_file.exists():
                asr_segments = load_asr_from_file(str(asr_file), episode)
                
                if asr_segments:
                    if verbose:
                        print(f"\n找到ASR数据，共 {len(asr_segments)} 个片段")
                        print("使用OCR+ASR结合模式...")
                    
                    # 使用OCR+ASR结合模式
                    from scripts.preprocess.sensitive_detector import detect_sensitive_segments_with_ocr_asr
                    
                    sensitive_segments = detect_sensitive_segments_with_ocr_asr(
                        ocr_results=ocr_results,
                        asr_segments=asr_segments,
                        sensitive_words=sensitive_words,
                        verbose=verbose
                    )
                    
                    return sensitive_segments
    except Exception as e:
        if verbose:
            print(f"⚠️ 加载ASR失败，使用纯OCR模式: {e}")

    # 如果没有ASR数据，使用纯OCR模式
    if verbose:
        print("\n使用纯OCR模式...")
    
    # 转换为SubtitleSegment格式
    all_subtitle_segments = []
    for ocr in ocr_results:
        segment = SubtitleSegment(
            start_time=ocr['timestamp'],
            end_time=ocr['timestamp'] + frame_duration,
            subtitle_text=ocr['text'],
            sensitive_word=ocr['sensitive_word'],
            frame_idx=ocr['frame_idx']
        )
        all_subtitle_segments.append(segment)

    # 合并连续的敏感词片段
    merged_segments = _merge_continuous_segments(all_subtitle_segments, gap_threshold=1.0)

    if verbose:
        print(f"\n检测到 {len(merged_segments)} 个敏感词片段（已合并连续片段）")

    return merged_segments


def _merge_continuous_segments(
    segments: List[SubtitleSegment],
    gap_threshold: float = 1.0
) -> List[SubtitleSegment]:
    """
    合并连续的敏感词片段

    Args:
        segments: 敏感词片段列表
        gap_threshold: 间隔阈值（秒），如果间隔小于这个阈值，则认为是同一个敏感词

    Returns:
        合并后的片段列表
    """
    if not segments:
        return []

    # 按时间排序
    segments.sort(key=lambda x: x.start_time)

    merged = []

    for seg in segments:
        if not merged:
            merged.append(seg)
        else:
            # 检查与上一个片段的间隔
            if seg.start_time - merged[-1].end_time <= gap_threshold:
                # 合并到上一个片段
                merged[-1] = SubtitleSegment(
                    start_time=merged[-1].start_time,
                    end_time=seg.end_time,
                    subtitle_text=f"{merged[-1].subtitle_text} {seg.subtitle_text}",
                    sensitive_word=seg.sensitive_word,
                    frame_idx=merged[-1].frame_idx
                )
            else:
                # 创建新片段
                merged.append(seg)

    return merged


def _generate_annotation_frame(
    frame: np.ndarray,
    frame_idx: int,
    subtitle_text: str,
    subtitle_region: SubtitleRegion,
    output_dir: str
) -> str:
    """生成标注帧（保存到文件）"""
    from PIL import Image, ImageDraw, ImageFont

    # 从BGR转RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # 转换为PIL图像
    img = Image.fromarray(rgb_frame)
    draw = ImageDraw.Draw(img)

    h, w = frame.shape[:2]
    y = int(h * subtitle_region.y_ratio)
    region_h = int(h * subtitle_region.height_ratio)

    # 红框标注字幕区域
    draw.rectangle(
        [(0, y), (w, y + region_h)],
        outline=(255, 0, 0),
        width=2
    )

    # 标注字幕文本
    font = None
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 16)
    except:
        pass

    # 显示字幕文本（截断）
    display_text = subtitle_text[:50] + "..." if len(subtitle_text) > 50 else subtitle_text
    draw.text((10, y + region_h + 10), display_text, fill=(255, 0, 0), font=font)

    # 保存
    output_path = Path(output_dir) / f"frame_{frame_idx}_annotated.jpg"
    img.save(output_path)

    return str(output_path)


# 测试代码
if __name__ == "__main__":
    print("=" * 60)
    print("OCR字幕识别模块测试")
    print("=" * 60)

    # 测试《烈日重生》
    video_path = "260306-待剪辑-漫剧网盘素材1/烈日重生/烈日重生-1.mp4"

    import os
    if not os.path.exists(video_path):
        print(f"视频不存在: {video_path}")
    else:
        # 模拟字幕区域
        subtitle_region = SubtitleRegion(
            y_ratio=0.60,
            height_ratio=0.061,
            detection_method="pixel_variance",
            confidence=0.95
        )

        # 测试敏感词
        sensitive_words = {"死", "杀", "血", "尸体", "干尸"}

        result = detect_sensitive_words_from_ocr(
            video_path=video_path,
            sensitive_words=sensitive_words,
            subtitle_region=subtitle_region,
            sample_fps=1.0,
            verbose=True,
            output_dir="test/temp/ocr_test"
        )

        if result:
            print("\n✅ 测试完成!")
            for seg in result:
                print(f"  [{seg.start_time:.1f}s - {seg.end_time:.1f}s] '{seg.subtitle_text}'")
        else:
            print("\n❌ 未检测到敏感词")
