"""
字幕区域检测模块

功能：
1. 像素变化检测法（最可靠，置信度95%）- 分析多帧像素变化，变化大的区域=字幕
2. Gemini视觉分析检测（备选方案）
3. OCR检测（备选方案）
4. 默认比例检测（底部10-12%区域，最后备选）
5. 保存/加载检测结果

检测策略（按优先级）：
    像素变化检测 → Gemini → OCR → 默认比例

使用方法：
    from scripts.preprocess.subtitle_detector import (
        detect_subtitle_region,
        SubtitleRegion
    )

    # 检测字幕区域（推荐提供video_path以使用像素变化检测法）
    region = detect_subtitle_region(keyframe_paths, video_path="/path/to/video.mp4")

    # 获取像素坐标
    y, height = region.get_pixel_coords(video_height)
"""

import json
import subprocess
from pathlib import Path
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass, asdict

import cv2
import numpy as np

from scripts.utils.subprocess_utils import run_command
from scripts.config import TimeoutConfig


@dataclass
class SubtitleRegion:
    """字幕区域配置"""
    y_ratio: float           # Y位置比例 (0-1)，相对于视频高度
    height_ratio: float      # 高度比例 (0-1)，相对于视频高度
    detection_method: str    # 检测方法: "gemini", "ocr", "default"
    confidence: float        # 置信度 (0-1)

    def get_pixel_coords(self, video_height: int) -> Tuple[int, int]:
        """
        获取像素坐标

        Args:
            video_height: 视频高度（像素）

        Returns:
            (y, height) 像素坐标
        """
        y = int(video_height * self.y_ratio)
        height = int(video_height * self.height_ratio)
        return y, height

    def to_dict(self) -> dict:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> 'SubtitleRegion':
        """从字典创建"""
        return cls(
            y_ratio=data['y_ratio'],
            height_ratio=data['height_ratio'],
            detection_method=data.get('detection_method', 'unknown'),
            confidence=data.get('confidence', 0.0)
        )

    def __repr__(self):
        return f"SubtitleRegion(y={self.y_ratio:.2%}, h={self.height_ratio:.2%}, method={self.detection_method}, conf={self.confidence:.0%})"


def get_video_resolution(video_path: str) -> Tuple[int, int]:
    """
    获取视频分辨率

    Args:
        video_path: 视频文件路径（支持 str 或 Path 对象）

    Returns:
        (width, height) 视频分辨率
    """
    # 兼容 Path 对象（在编译后的类型检查之后转换）
    if isinstance(video_path, Path):
        video_path = str(video_path)

    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height',
        '-of', 'csv=p=0',
        video_path
    ]

    result = run_command(
        cmd,
        timeout=TimeoutConfig.FFPROBE_QUICK,
        retries=1,
        error_msg=f"ffprobe获取分辨率超时: {video_path}"
    )
    if result is None or result.returncode != 0:
        print(f"⚠️ 无法获取视频分辨率: {video_path}")
        return 1920, 1080  # 默认返回1080p

    width, height = map(int, result.stdout.strip().split(','))
    return width, height


def detect_subtitle_region_default() -> SubtitleRegion:
    """
    默认比例检测

    大部分视频字幕位于底部10-12%区域

    Returns:
        SubtitleRegion
    """
    return SubtitleRegion(
        y_ratio=0.88,           # 字幕顶部位置（底部12%区域）
        height_ratio=0.10,      # 字幕高度（10%高度）
        detection_method="default",
        confidence=0.5          # 默认方案置信度较低
    )


def detect_subtitle_region_pixel_variance(video_path: str, verbose: bool = True) -> SubtitleRegion:
    """
    像素变化检测法（最可靠）

    原理：
    1. 提取多帧底部区域
    2. 计算每行的跨帧活跃度
    3. 选出连续、稳定且更像字幕的主区域
    4. 变化小的行 = 固定文案或背景

    Args:
        video_path: 视频文件路径（支持 str 或 Path 对象）
        verbose: 是否打印详细信息

    Returns:
        SubtitleRegion
    """
    # 兼容 Path 对象（在编译后的类型检查之后转换）
    if isinstance(video_path, Path):
        video_path = str(video_path)

    if verbose:
        print("  🔍 使用像素变化检测法...")
        print("  📹 提取多帧...")

    cap = cv2.VideoCapture(video_path)
    frames = []

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    sample_interval = int(fps * 2)
    if sample_interval < 1:
        sample_interval = 1

    available_frames = total_frames // sample_interval
    frame_count = min(50, max(15, available_frames))

    for i in range(frame_count):
        frame_idx = i * sample_interval
        if frame_idx >= total_frames:
            break
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        if ret:
            frames.append(frame)

    cap.release()

    if len(frames) < 2:
        if verbose:
            print("  ⚠️ 声数不够，使用默认参数")
        return detect_subtitle_region_default()

    if verbose:
        print(f"  ✅ 提取了 {len(frames)} 帧")

    h, _ = frames[0].shape[:2]
    bottom_start = int(h * 0.5)
    bottom_end = h
    row_scores = _compute_multiframe_row_scores(frames, bottom_start, bottom_end)
    best_cluster = _select_subtitle_cluster(row_scores)

    if best_cluster is None:
        if verbose:
            print("  ⚠️ 未检测到明显的字幕区域，使用默认参数")
        return detect_subtitle_region_default()

    subtitle_start, subtitle_end = best_cluster

    padding = int(h * 0.02)
    subtitle_start = max(bottom_start, subtitle_start - padding)
    subtitle_end = min(bottom_end, subtitle_end + padding + 1)

    y_ratio = subtitle_start / h
    height_ratio = (subtitle_end - subtitle_start) / h

    if verbose:
        print("  ✅ 检测到字幕区域:")
        print(f"     开始行: Y={subtitle_start} ({y_ratio:.1%})")
        print(f"     结束行: Y={subtitle_end} ({subtitle_end/h:.1%})")
        print(f"     字幕高度: {subtitle_end - subtitle_start}px ({height_ratio:.1%})")

    return SubtitleRegion(
        y_ratio=y_ratio,
        height_ratio=height_ratio,
        detection_method="pixel_variance",
        confidence=0.95
    )


def detect_subtitle_region_gemini(keyframe_paths: List[str]) -> Optional[SubtitleRegion]:
    """
    Gemini视觉分析检测字幕区域

    Args:
        keyframe_paths: 关键帧图片路径列表

    Returns:
        SubtitleRegion 或 None（检测失败）
    """
    try:
        import google.generativeai as genai
        import os

        # 检查API Key
        api_key = os.environ.get('GEMINI_API_KEY')
        if not api_key:
            print("⚠️ 未设置 GEMINI_API_KEY，跳过Gemini检测")
            return None

        # 配置Gemini
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash')

        # 选择中间的关键帧进行分析（更有代表性）
        if not keyframe_paths:
            return None

        sample_frame = keyframe_paths[len(keyframe_paths) // 2]

        # 读取图片
        from PIL import Image
        img = Image.open(sample_frame)
        video_width, video_height = img.size

        # 构建Prompt
        prompt = f"""分析这张视频截图，识别字幕区域的位置。

请返回JSON格式（不要包含```json标记）：
{{
    "has_subtitle": true或false,
    "subtitle_y": 字幕顶部Y坐标（像素值）,
    "subtitle_height": 字幕高度（像素值）,
    "confidence": 置信度（0-1之间的小数）
}}

注意：
1. 字幕通常在视频底部
2. 如果没有字幕，返回 has_subtitle: false
3. subtitle_y 是字幕区域的顶部Y坐标
4. confidence 表示你对检测结果的信心程度

图片尺寸: {video_width}x{video_height}"""

        # 调用Gemini
        response = model.generate_content([prompt, img])
        result_text = response.text.strip()

        # 解析JSON
        import json
        # 移除可能的markdown标记
        if result_text.startswith('```'):
            result_text = result_text.split('\n', 1)[1]  # 移除第一行
            result_text = result_text.rsplit('\n', 1)[0]  # 移除最后一行

        result = json.loads(result_text)

        if not result.get('has_subtitle', False):
            print("  ℹ️ Gemini检测: 该帧没有字幕")
            return None

        # 计算比例
        y_ratio = result['subtitle_y'] / video_height
        height_ratio = result['subtitle_height'] / video_height
        confidence = result.get('confidence', 0.8)

        print(f"  ✅ Gemini检测: 字幕区域 y={y_ratio:.2%}, h={height_ratio:.2%}, 置信度={confidence:.0%}")

        return SubtitleRegion(
            y_ratio=y_ratio,
            height_ratio=height_ratio,
            detection_method="gemini",
            confidence=confidence
        )

    except Exception as e:
        print(f"  ⚠️ Gemini检测失败: {e}")
        return None


def detect_subtitle_region_ocr(keyframe_paths: List[str]) -> Optional[SubtitleRegion]:
    """
    OCR检测字幕区域

    Args:
        keyframe_paths: 关键帧图片路径列表

    Returns:
        SubtitleRegion 或 None（检测失败）
    """
    try:
        # 尝试导入OCR库
        try:
            from paddleocr import PaddleOCR
            ocr = PaddleOCR(use_angle_cls=True, lang='ch', show_log=False)
        except ImportError:
            print("  ℹ️ PaddleOCR未安装，跳过OCR检测")
            return None

        from PIL import Image

        # 分析多个关键帧
        all_boxes = []

        for frame_path in keyframe_paths[:5]:  # 只分析前5帧
            try:
                img = Image.open(frame_path)
                img_width, img_height = img.size

                # OCR识别
                result = ocr.ocr(frame_path, cls=True)

                if result and result[0]:
                    for line in result[0]:
                        box = line[0]  # 文字框坐标
                        # 获取Y坐标范围
                        y_coords = [point[1] for point in box]
                        min_y = min(y_coords)
                        max_y = max(y_coords)

                        # 只保留底部30%区域的文字（字幕通常在底部）
                        if min_y > img_height * 0.7:
                            all_boxes.append({
                                'min_y': min_y,
                                'max_y': max_y,
                                'height': max_y - min_y
                            })

            except Exception as e:
                continue

        if not all_boxes:
            print("  ℹ️ OCR检测: 未找到字幕区域的文字")
            return None

        # 计算字幕区域（取所有文字框的包围盒）
        min_y = min(box['min_y'] for box in all_boxes)
        max_y = max(box['max_y'] for box in all_boxes)

        # 获取图片尺寸
        img = Image.open(keyframe_paths[0])
        _, img_height = img.size

        # 计算比例
        y_ratio = min_y / img_height
        height_ratio = (max_y - min_y) / img_height

        # 添加一些边距（10%）
        height_ratio *= 1.1

        print(f"  ✅ OCR检测: 字幕区域 y={y_ratio:.2%}, h={height_ratio:.2%}")

        return SubtitleRegion(
            y_ratio=y_ratio,
            height_ratio=height_ratio,
            detection_method="ocr",
            confidence=0.7
        )

    except Exception as e:
        print(f"  ⚠️ OCR检测失败: {e}")
        return None


def detect_subtitle_region(
    keyframe_paths: List[str],
    video_path: Optional[str] = None,
    force_method: Optional[str] = None,
    verbose: bool = True
) -> SubtitleRegion:
    """
    检测字幕区域（四层策略）

    检测顺序：像素变化检测 → Gemini → OCR → 默认比例

    像素变化检测法最可靠（置信度95%），因为它：
    1. 分析多帧的像素变化
    2. 变化大的区域 = 字幕区域（对话在变化）
    3. 变化小的区域 = 固定文案或背景

    Args:
        keyframe_paths: 关键帧图片路径列表（用于Gemini/OCR备选方案）
        video_path: 视频文件路径（用于像素变化检测，推荐提供）
        force_method: 强制使用指定方法 ("pixel_variance", "gemini", "ocr", "default")
        verbose: 是否打印详细信息

    Returns:
        SubtitleRegion 字幕区域配置
    """
    if verbose:
        print("\n" + "=" * 60)
        print("字幕区域检测")
        print("=" * 60)

    # 如果强制指定方法
    if force_method:
        if force_method == "default":
            if verbose:
                print("📌 使用默认比例检测")
            return detect_subtitle_region_default()
        elif force_method == "pixel_variance":
            if verbose:
                print("📌 使用像素变化检测法")
            if video_path:
                return detect_subtitle_region_pixel_variance(video_path, verbose)
            else:
                print("  ⚠️ 未提供video_path，回退到默认比例")
                return detect_subtitle_region_default()
        elif force_method == "gemini":
            if verbose:
                print("📌 使用Gemini视觉分析")
            return detect_subtitle_region_gemini(keyframe_paths) or detect_subtitle_region_default()
        elif force_method == "ocr":
            if verbose:
                print("📌 使用OCR检测")
            return detect_subtitle_region_ocr(keyframe_paths) or detect_subtitle_region_default()

    # 自动检测流程：像素变化检测法优先（最可靠）
    if video_path:
        if verbose:
            print("🔍 Step 1: 使用像素变化检测法（最可靠）...")

        region = detect_subtitle_region_pixel_variance(video_path, verbose)

        if region and region.confidence >= 0.9:
            if verbose:
                print(f"✅ 像素变化检测成功，置信度: {region.confidence:.0%}")
            return region

    # 像素变化检测失败或无video_path，尝试Gemini
    if verbose:
        print("🔍 Step 2: 尝试Gemini视觉分析...")

    region = detect_subtitle_region_gemini(keyframe_paths)

    if region and region.confidence >= 0.8:
        if verbose:
            print(f"✅ Gemini检测成功，置信度: {region.confidence:.0%}")
        return region

    # Gemini失败或置信度低，尝试OCR
    if verbose:
        print("🔍 Step 3: 尝试OCR检测...")

    region = detect_subtitle_region_ocr(keyframe_paths)

    if region:
        if verbose:
            print(f"✅ OCR检测成功")
        return region

    # OCR也失败，使用默认比例
    if verbose:
        print("🔍 Step 4: 使用默认比例...")

    region = detect_subtitle_region_default()
    if verbose:
        print(f"✅ 使用默认比例: y={region.y_ratio:.2%}, h={region.height_ratio:.2%}")

    return region


def save_subtitle_config(
    region: SubtitleRegion,
    project_name: str,
    video_resolution: Tuple[int, int],
    output_dir: str = "data/analysis"
) -> str:
    """
    保存字幕区域配置

    Args:
        region: 字幕区域配置
        project_name: 项目名称
        video_resolution: 视频分辨率 (width, height)
        output_dir: 输出目录

    Returns:
        配置文件路径
    """
    output_path = Path(output_dir) / project_name / "subtitle_config.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    config = {
        "project_name": project_name,
        "video_resolution": f"{video_resolution[0]}x{video_resolution[1]}",
        "subtitle_region": region.to_dict(),
        "note": "如果遮盖位置不准，可手动修改 y_ratio 和 height_ratio"
    }

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    print(f"✅ 字幕区域配置已保存: {output_path}")
    return str(output_path)


def load_subtitle_config(
    project_name: str,
    config_dir: str = "data/analysis"
) -> Optional[SubtitleRegion]:
    """
    加载字幕区域配置

    Args:
        project_name: 项目名称
        config_dir: 配置目录

    Returns:
        SubtitleRegion 或 None（配置不存在）
    """
    config_path = Path(config_dir) / project_name / "subtitle_config.json"

    if not config_path.exists():
        return None

    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    region = SubtitleRegion.from_dict(config['subtitle_region'])
    print(f"✅ 加载字幕区域配置: {region}")

    return region


def _cluster_rows(active_rows: List[int], max_gap: int = 5) -> List[Tuple[int, int]]:
    """将活跃行聚类为连续区域。"""
    if not active_rows:
        return []

    clusters = []
    cluster_start = active_rows[0]
    prev_y = active_rows[0]

    for y in active_rows[1:]:
        if y - prev_y <= max_gap:
            prev_y = y
        else:
            clusters.append((cluster_start, prev_y))
            cluster_start = y
            prev_y = y

    clusters.append((cluster_start, prev_y))
    return clusters



def _select_subtitle_cluster(
    row_scores: List[Tuple[int, float]],
    min_cluster_height: int = 8,
    lower_search_ratio: float = 0.82,
) -> Optional[Tuple[int, int]]:
    """从多帧活跃度中选出最像字幕的连续区域。"""
    if not row_scores:
        return None

    values = np.array([score for _, score in row_scores], dtype=np.float32)
    if values.size == 0:
        return None

    threshold = float(np.mean(values) + np.std(values))
    active_rows = [y for y, score in row_scores if score > threshold]
    clusters = _cluster_rows(active_rows)
    if not clusters:
        return None

    max_y = row_scores[-1][0]
    min_valid_y = int((max_y + 1) * lower_search_ratio)

    best_cluster = None
    best_score = float("-inf")
    for start_y, end_y in clusters:
        height = end_y - start_y + 1
        if height < min_cluster_height:
            continue

        cluster_scores = [score for y, score in row_scores if start_y <= y <= end_y]
        if not cluster_scores:
            continue

        mean_score = float(np.mean(cluster_scores))
        center_y = (start_y + end_y) / 2.0
        position_bonus = max(0.0, (center_y - min_valid_y) / max(1.0, (max_y - min_valid_y)))
        continuity_bonus = min(height / 24.0, 1.0)
        height_penalty = max(0.0, (height - 24) / 24.0)
        score = mean_score * (1.0 + 0.20 * continuity_bonus + 0.10 * position_bonus - 0.45 * height_penalty)

        if score > best_score:
            best_score = score
            best_cluster = (start_y, end_y)

    if best_cluster is not None:
        return best_cluster

    fallback_clusters = []
    for start_y, end_y in clusters:
        height = end_y - start_y + 1
        center_y = (start_y + end_y) / 2.0
        if height >= min_cluster_height and center_y >= min_valid_y:
            fallback_clusters.append((start_y, end_y))

    if fallback_clusters:
        return max(fallback_clusters, key=lambda c: c[1] - c[0])

    return None



def _compute_multiframe_row_scores(
    frames: List[np.ndarray],
    start_y: int,
    end_y: int,
) -> List[Tuple[int, float]]:
    """计算各行跨帧活跃度，优先突出字幕这类持续变化的文本带。"""
    if len(frames) < 2 or start_y >= end_y:
        return []

    gray_frames = [cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) for frame in frames]
    frame_stack = np.stack(gray_frames, axis=0)
    region_stack = frame_stack[:, start_y:end_y, :]
    if region_stack.size == 0:
        return []

    temporal_std = np.std(region_stack, axis=0)
    row_temporal_scores = np.mean(temporal_std, axis=1)

    temporal_diff = np.abs(np.diff(region_stack.astype(np.int16), axis=0))
    row_diff_scores = np.mean(temporal_diff, axis=(0, 2)) if temporal_diff.size else np.zeros_like(row_temporal_scores)

    # 字幕通常表现为横向局部聚集的高变化文本带；满宽大面积运动更像人物/背景变化。
    binary_motion = temporal_std > np.mean(temporal_std)
    motion_coverage = np.mean(binary_motion, axis=1)
    coverage_weight = np.clip(1.0 - np.abs(motion_coverage - 0.20) / 0.20, 0.10, 1.0)

    row_scores = (0.65 * row_temporal_scores + 0.35 * row_diff_scores) * coverage_weight
    return [(start_y + idx, float(score)) for idx, score in enumerate(row_scores)]



def _get_default_subtitle_bottom_y(video_height: int) -> Optional[int]:
    """返回保守默认字幕区域的底部 Y 坐标。"""
    if video_height <= 0:
        return None

    default_region = detect_subtitle_region_default()
    y, height = default_region.get_pixel_coords(video_height)
    if height <= 0:
        return None
    return min(video_height - 1, y + height)



def get_subtitle_bottom_y(video_path: str, sample_frame_count: int = 5) -> Optional[int]:
    """检测视频字幕区域的底部 Y 坐标（从顶部量起，像素单位）。

    采样视频时长 20%-80% 区间的多帧，使用跨帧活跃度识别主字幕带，
    再返回该区域底边，提高对底部噪声和人物边缘的鲁棒性。
    检测失败时回退到保守默认字幕区域，并输出可诊断日志。

    结果会缓存到 data/cache/subtitle_region/<项目名>/<集数>.json 中。

    Args:
        video_path: 视频文件路径（支持 str 或 Path 对象）
        sample_frame_count: 采样帧数（默认5帧）

    Returns:
        字幕区域底部 Y 坐标（从视频顶部量起的像素值）
    """
    # 兼容 Path 对象（在编译后的类型检查之后转换）
    if isinstance(video_path, Path):
        video_path = str(video_path)

    import statistics

    def _fallback(reason: str, video_height: int) -> Optional[int]:
        fallback_y = _get_default_subtitle_bottom_y(video_height)
        if fallback_y is None:
            print(f"⚠️ get_subtitle_bottom_y: {reason}，且无法生成保守回退坐标")
            return None
        print(f"⚠️ get_subtitle_bottom_y: {reason}，回退到保守字幕底部 Y={fallback_y}")
        return fallback_y

    cap = None
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(f"⚠️ 无法打开视频: {video_path}")
            return None

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        start_frame = int(total_frames * 0.20)
        end_frame = int(total_frames * 0.80)
        sample_frames = []

        if end_frame > start_frame and sample_frame_count > 0:
            step = max(1, (end_frame - start_frame) // sample_frame_count)
            for i in range(sample_frame_count):
                frame_idx = start_frame + i * step
                if frame_idx >= end_frame:
                    break
                cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
                ret, frame = cap.read()
                if ret:
                    sample_frames.append(frame)

        if len(sample_frames) < 2:
            return _fallback(f"采样帧不足({len(sample_frames)})", video_height)

        bottom_start = int(video_height * 0.72)
        bottom_end = video_height
        row_scores = _compute_multiframe_row_scores(sample_frames, bottom_start, bottom_end)
        if not row_scores:
            return _fallback("跨帧活跃度为空", video_height)

        best_cluster = _select_subtitle_cluster(row_scores)
        if best_cluster is None:
            return _fallback("未选出有效字幕簇", video_height)

        _, bottom_y = best_cluster
        result = int(statistics.median([bottom_y]))

        return min(result, video_height - 1)

    except Exception as e:
        print(f"⚠️ get_subtitle_bottom_y 失败: {e}")
        return _fallback(f"异常退出: {e}", int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) if cap is not None else 0)
    finally:
        if cap is not None:
            cap.release()


@dataclass
class BuiltinDisclaimerInfo:
    """内置免责声明检测结果"""
    detected: bool
    top_y: Optional[int] = None       # 免责声明区域顶部Y坐标(像素)
    bottom_y: Optional[int] = None    # 免责声明区域底部Y坐标(像素)
    video_height: int = 0
    text_sample: str = ""

    @property
    def top_y_ratio(self) -> float:
        if self.top_y is not None and self.video_height > 0:
            return self.top_y / self.video_height
        return 0.0

    def to_dict(self) -> dict:
        return {
            'detected': self.detected,
            'top_y': self.top_y,
            'bottom_y': self.bottom_y,
            'video_height': self.video_height,
            'text_sample': self.text_sample,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'BuiltinDisclaimerInfo':
        if not data:
            return cls(detected=False)
        return cls(
            detected=data.get('detected', False),
            top_y=data.get('top_y'),
            bottom_y=data.get('bottom_y'),
            video_height=data.get('video_height', 0),
            text_sample=data.get('text_sample', ''),
        )


# 免责声明关键词（命中>=1个即可确认，降低检测门槛）
DISCLAIMER_KEYWORDS = [
    "AI生成", "纯属虚构", "仅供娱乐", "无不良引导", "无不良导向",
    "请勿模仿", "如有雷同", "虚构作品", "剧情虚构", "禁止引导",
    "娱乐", "虚构", "AI制作", "请勿当真", "娱乐作品", "剧情纯属",
    "本剧由", "制作", "虚构剧情",
]


def _parse_ocr_result(result) -> List[Tuple[str, float, int, int]]:
    """解析PaddleOCR结果，兼容2.x和3.x API。

    Returns:
        [(text, confidence, min_y, max_y), ...]
    """
    items = []
    if not result:
        return items
    for page in result:
        if not page:
            continue
        # PaddleOCR 3.x: dict with rec_texts, rec_scores, rec_polys
        if isinstance(page, dict):
            texts = page.get('rec_texts', [])
            scores = page.get('rec_scores', [])
            polys = page.get('rec_polys', page.get('dt_polys', []))
            for i, text in enumerate(texts):
                score = scores[i] if i < len(scores) else 0.0
                if i < len(polys):
                    ys = polys[i][:, 1]
                    items.append((text, score, int(ys.min()), int(ys.max())))
                else:
                    items.append((text, score, 0, 0))
        # PaddleOCR 2.x: list of [box, (text, conf)]
        elif isinstance(page, list):
            for line in page:
                if not line or len(line) < 2:
                    continue
                box, (text, conf) = line[0], line[1]
                ys = [p[1] for p in box]
                items.append((text, conf, int(min(ys)), int(max(ys))))
    return items


def detect_builtin_disclaimer(
    video_path: str,
    sample_frame_count: int = 3,
    verbose: bool = True,
) -> BuiltinDisclaimerInfo:
    """
    检测视频是否内置免责声明文字。

    方案：对视频底部区域做OCR，多帧中如果反复出现免责声明关键词（>=2个），
    就确认存在内置免责声明，并返回其Y坐标范围。

    Args:
        video_path: 视频文件路径
        sample_frame_count: 采样帧数（默认3帧足够）
        verbose: 是否打印详细信息

    Returns:
        BuiltinDisclaimerInfo
    """
    import os
    import tempfile
    not_found = BuiltinDisclaimerInfo(detected=False)

    cap = None
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return not_found

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if total_frames < 10 or video_height < 100:
            return not_found

        # 扫描底部20%区域
        scan_top = int(video_height * 0.80)

        # 初始化OCR
        try:
            os.environ.setdefault('PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK', 'True')
            from paddleocr import PaddleOCR
            ocr = PaddleOCR(lang='ch')
            if verbose:
                print(f"  ✅ PaddleOCR初始化成功")
        except ImportError as e:
            if verbose:
                print(f"  ❌ PaddleOCR不可用，无法检测内置免责声明")
                print(f"     错误: {e}")
                print(f"  💡 这会导致视频已有免责声明时，会重复添加")
                print(f"  🔧 解决方案：确保 PaddleOCR 和 PaddlePaddle 已安装")
            return not_found
        except Exception as e:
            if verbose:
                print(f"  ❌ PaddleOCR初始化失败: {e}")
                print(f"  💡 这会导致无法检测内置免责声明")
            return not_found

        # 采样帧：取视频开头、中间、结尾
        frame_positions = []
        for t in [0.05, 0.3, 0.5, 0.7, 0.95]:  # 增加开头和结尾采样
            frame_positions.append(int(total_frames * t))

        # 对每帧做OCR，收集免责声明候选
        all_disclaimer_texts = []
        all_top_ys = []
        all_bottom_ys = []

        for pos in frame_positions[:sample_frame_count]:
            cap.set(cv2.CAP_PROP_POS_FRAMES, pos)
            ret, frame = cap.read()
            if not ret:
                continue

            roi = frame[scan_top:, :]
            # PaddleOCR需要文件路径或numpy array
            result = ocr.ocr(roi)
            items = _parse_ocr_result(result)

            # 检查关键词
            frame_texts = []
            frame_min_y = video_height
            frame_max_y = 0
            for text, conf, min_y, max_y in items:
                hits = [kw for kw in DISCLAIMER_KEYWORDS if kw in text]
                if hits:
                    frame_texts.append(text)
                    frame_min_y = min(frame_min_y, scan_top + min_y)
                    frame_max_y = max(frame_max_y, scan_top + max_y)

            if frame_texts:
                all_disclaimer_texts.append(" ".join(frame_texts))
                all_top_ys.append(frame_min_y)
                all_bottom_ys.append(frame_max_y)

        # 判断：至少1帧检测到免责声明关键词（降低检测门槛）
        if len(all_disclaimer_texts) < 1:
            if verbose and all_disclaimer_texts:
                print(f"  📋 仅{len(all_disclaimer_texts)}帧检测到免责声明，不够确认")
            return not_found

        # 合并所有文字，检查关键词命中数
        combined_text = " ".join(all_disclaimer_texts)
        keyword_hits = sum(1 for kw in DISCLAIMER_KEYWORDS if kw in combined_text)
        if keyword_hits < 1:  # 降低到至少1个关键词
            if verbose:
                print(f"  📋 关键词命中{keyword_hits}个，不够确认")
            return not_found

        # 取Y坐标的中位数（更稳定）
        top_y = int(np.median(all_top_ys))
        bottom_y = int(np.median(all_bottom_ys))
        text_sample = all_disclaimer_texts[0]

        if verbose:
            print(f"  ✅ 确认内置免责声明: y={top_y}-{bottom_y}, "
                  f"关键词{keyword_hits}个, \"{text_sample}\"")

        return BuiltinDisclaimerInfo(
            detected=True,
            top_y=top_y,
            bottom_y=bottom_y,
            video_height=video_height,
            text_sample=text_sample,
        )

    except Exception as e:
        if verbose:
            print(f"  ⚠️ 内置免责声明检测失败: {e}")
        return not_found
    finally:
        if cap is not None:
            cap.release()


class SubtitleDetector:
    """
    字幕区域检测器（类封装版本）

    使用方法：
        detector = SubtitleDetector()
        region = detector.detect(keyframe_paths, video_path)
    """

    def __init__(self, force_method: Optional[str] = None):
        """
        初始化检测器

        Args:
            force_method: 强制使用指定方法 ("gemini", "ocr", "default")
        """
        self.force_method = force_method

    def detect(
        self,
        keyframe_paths: List[str],
        video_path: Optional[str] = None,
        verbose: bool = True
    ) -> SubtitleRegion:
        """
        检测字幕区域

        Args:
            keyframe_paths: 关键帧图片路径列表
            video_path: 视频文件路径
            verbose: 是否打印详细信息

        Returns:
            SubtitleRegion
        """
        return detect_subtitle_region(keyframe_paths, video_path, self.force_method, verbose)


# 测试代码
if __name__ == "__main__":
    print("=" * 60)
    print("字幕区域检测模块测试")
    print("=" * 60)

    # 测试默认检测
    region = detect_subtitle_region_default()
    print(f"\n默认字幕区域: {region}")

    # 测试像素坐标计算
    y, height = region.get_pixel_coords(1920)
    print(f"1080p视频像素坐标: y={y}, height={height}")

    y, height = region.get_pixel_coords(1920)
    print(f"竖屏1080x1920视频像素坐标: y={y}, height={height}")
